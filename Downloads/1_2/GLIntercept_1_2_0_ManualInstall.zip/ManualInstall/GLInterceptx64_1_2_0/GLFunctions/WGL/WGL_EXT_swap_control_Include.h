#define GLI_INCLUDE_WGL_EXT_SWAP_CONTROL


GLboolean wglSwapIntervalEXT(GLint interval);

GLint wglGetSwapIntervalEXT(void);

