#define GLI_INCLUDE_WGL_3DFX_MULTISAMPLE

enum Main {

  WGL_SAMPLE_BUFFERS_3DFX       = 0x2060,
  WGL_SAMPLES_3DFX              = 0x2061,

};

