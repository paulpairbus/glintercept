#define GLI_INCLUDE_WGL_ARB_EXTENSIONS_STRING

const GLasciistring *wglGetExtensionsStringARB(void * hdc);

//Add EXT version
const GLasciistring *wglGetExtensionsStringEXT(void);

