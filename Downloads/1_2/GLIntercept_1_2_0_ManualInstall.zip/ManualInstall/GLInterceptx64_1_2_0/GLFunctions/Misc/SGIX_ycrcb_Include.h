#define GLI_INCLUDE_GL_SGIX_YCRCB

enum Main {

  GL_YCRCB_422_SGIX       = 0x81BB,
  GL_YCRCB_444_SGIX       = 0x81BC,

};

