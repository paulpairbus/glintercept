#define GLI_INCLUDE_HP_OCCLUSION_TEST

//The extension is not finished?
enum Main {

  GL_OCCLUSION_TEST_HP                    =  0x8165,
  GL_OCCLUSION_TEST_RESULT_HP             =  0x8166,
};

