#define GLI_INCLUDE_GL_SGIX_FOG_OFFSET

enum Main {

  GL_FOG_OFFSET_SGIX             = 0x8198,
  GL_FOG_OFFSET_VALUE_SGIX       = 0x8199,

};

