#define GLI_INCLUDE_EXT_TEXTURE_MIRROR_CLAMP

enum Main {

  GL_MIRROR_CLAMP_EXT                =     0x8742,
  GL_MIRROR_CLAMP_TO_EDGE_EXT        =     0x8743,
  GL_MIRROR_CLAMP_TO_BORDER_EXT      =     0x8912,
};


