#define GLI_INCLUDE_GL_SGIX_SCALEBIAS_HINT

enum Main {

  GL_SCALEBIAS_HINT_SGIX       = 0x8322,

};

