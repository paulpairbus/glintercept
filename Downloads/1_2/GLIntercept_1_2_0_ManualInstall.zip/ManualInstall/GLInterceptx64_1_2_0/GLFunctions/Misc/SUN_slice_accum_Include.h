#define GLI_INCLUDE_GL_SUN_SLICE_ACCUM

enum Main {

  GL_SLICE_ACCUM_SUN       = 0x85CC,

};

