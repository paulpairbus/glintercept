#define GLI_INCLUDE_GL_EXT_TEXTURE_PERTURB_NORMAL

enum Main {

  GL_PERTURB_EXT              = 0x85AE,
  GL_TEXTURE_NORMAL_EXT       = 0x85AF,

};

void glTextureNormalEXT(GLenum[Main] mode);
