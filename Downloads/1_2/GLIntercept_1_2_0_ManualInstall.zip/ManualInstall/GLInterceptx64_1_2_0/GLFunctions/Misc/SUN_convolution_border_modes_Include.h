#define GLI_INCLUDE_GL_SUN_CONVOLUTION_BORDER_MODES

enum Main {

  GL_WRAP_BORDER_SUN       = 0x81D4,

};

