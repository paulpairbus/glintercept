#define GLI_INCLUDE_EXT_DRAW_INSTANCED

void glDrawArraysInstancedEXT(GLenum[Primitives] mode, GLint first, GLsizei count, GLsizei primcount);
void glDrawElementsInstancedEXT(GLenum[Primitives] mode, GLsizei count, GLenum[Main] type, const GLvoid * indices, GLsizei primcount);
