#define GLI_INCLUDE_GL_NV_FOG_DISTANCE

enum Main {

  GL_FOG_DISTANCE_MODE_NV        = 0x855A,
  GL_EYE_RADIAL_NV               = 0x855B,
  GL_EYE_PLANE_ABSOLUTE_NV       = 0x855C,

};

