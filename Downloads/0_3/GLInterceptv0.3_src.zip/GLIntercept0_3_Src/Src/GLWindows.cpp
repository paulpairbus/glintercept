/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  Parts of this file may be derived from GLTrace version 2.3
  by Phil Frisbie, Jr. (phil@hawksoft.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "GLWindows.h"
#include "BuiltInFunction.h"

extern GLDriver glDriver;
 
USING_ERRORLOG

static bool init=false; 
#define INIT_DRIVER if(!init) {init=true; if(!glDriver.Init()){exit(1);}}

//A dummy value to pass to the logger
int wglDummyValue=0xBAADF00D;


///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY wglChoosePixelFormat (HDC a, CONST PIXELFORMATDESCRIPTOR *b)
{
  INIT_DRIVER

  PRE_FUNCTION(wglChoosePixelFormat,a);
  int retValue = GLW.wglChoosePixelFormat(a,b);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglCopyContext (HGLRC a, HGLRC b, UINT c)
{
  INIT_DRIVER

  PRE_FUNCTION(wglCopyContext,a);
  BOOL retValue = GLW.wglCopyContext(a,b,c);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY wglCreateContext (HDC a)
{
  INIT_DRIVER

  PRE_FUNCTION(wglCreateContext,a);
  HGLRC retValue = GLW.wglCreateContext(a);
  POST_FUNCTION_RET(retValue)

  //Create our driver context
  if(retValue != NULL)
  {
    glDriver.CreateOpenGLContext(retValue);
  }

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY wglCreateLayerContext (HDC a, int b)
{
  INIT_DRIVER

  PRE_FUNCTION(wglCreateLayerContext,a);
  HGLRC retValue = GLW.wglCreateLayerContext(a,b);
  POST_FUNCTION_RET(retValue)

  //Create our driver context
  if(retValue != NULL)
  {
    glDriver.CreateOpenGLContext(retValue);
  }

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglDeleteContext (HGLRC a)
{
  INIT_DRIVER

  PRE_FUNCTION(wglDeleteContext,a);
  BOOL retValue = GLW.wglDeleteContext(a);

  //Delete for our context
  if(retValue)
  {
    glDriver.DeleteOpenGLContext(a);
  }
  
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglDescribeLayerPlane (HDC a, int b, int c, UINT d, LPLAYERPLANEDESCRIPTOR e)
{
  INIT_DRIVER

  PRE_FUNCTION(wglDescribeLayerPlane,a);
  BOOL retValue = GLW.wglDescribeLayerPlane(a,b,c,d,e);
  POST_FUNCTION_RET(retValue)
  

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY wglDescribePixelFormat (HDC a, int b, UINT c, LPPIXELFORMATDESCRIPTOR d)
{
  INIT_DRIVER

  PRE_FUNCTION(wglDescribePixelFormat,a);
  int retValue = GLW.wglDescribePixelFormat(a,b,c,d);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY wglGetCurrentContext (void)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetCurrentContext,wglDummyValue);
  HGLRC retValue = GLW.wglGetCurrentContext();
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
HDC WGLAPIENTRY wglGetCurrentDC (void)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetCurrentDC,wglDummyValue);
  HDC retValue = GLW.wglGetCurrentDC();
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
PROC WGLAPIENTRY wglGetDefaultProcAddress (LPCSTR a)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetDefaultProcAddress,a);
  PROC retValue = GLW.wglGetDefaultProcAddress(a);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY wglGetLayerPaletteEntries (HDC a, int b, int c, int d, COLORREF *e)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetLayerPaletteEntries,a);
  int retValue = GLW.wglGetLayerPaletteEntries(a,b,c,d,e);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY wglGetPixelFormat (HDC a)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetPixelFormat,a);
  int retValue = GLW.wglGetPixelFormat(a);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
PROC WGLAPIENTRY wglGetProcAddress (LPCSTR a)
{
  INIT_DRIVER

  PRE_FUNCTION(wglGetProcAddress,a);
  PROC retValue = GLW.wglGetProcAddress(a);

  //Register the new function
  retValue = (PROC)glDriver.AddExtensionFunction(a,retValue);
  
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglMakeCurrent (HDC a, HGLRC b)
{
  INIT_DRIVER

  //Get the current context
  HGLRC oldContext = GLW.wglGetCurrentContext();

  //NULL out the internal context
  glDriver.SetOpenGLContext(NULL);

  PRE_FUNCTION(wglMakeCurrent,a);
  BOOL retValue = GLW.wglMakeCurrent(a,b);
  
  //Call our driver to make the context valid
  if(retValue)
  {
    glDriver.SetOpenGLContext(b);
  }
  else
  {
    //Re-init the old context if the swap was not successful
    glDriver.SetOpenGLContext(oldContext);
  }

  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglRealizeLayerPalette (HDC a, int b, BOOL c)
{
  INIT_DRIVER

  PRE_FUNCTION(wglRealizeLayerPalette,a);
  BOOL retValue = GLW.wglRealizeLayerPalette(a,b,c);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY wglSetLayerPaletteEntries (HDC a, int b, int c, int d, CONST COLORREF *e)
{
  INIT_DRIVER

  PRE_FUNCTION(wglSetLayerPaletteEntries,a);
  int retValue = GLW.wglSetLayerPaletteEntries(a,b,c,d,e);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglSetPixelFormat (HDC a, int b, CONST PIXELFORMATDESCRIPTOR *c)
{
  INIT_DRIVER

  PRE_FUNCTION(wglSetPixelFormat,a);
  BOOL retValue = GLW.wglSetPixelFormat(a,b,c);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglShareLists (HGLRC a, HGLRC b)
{
  INIT_DRIVER
  PRE_FUNCTION(wglShareLists,a);
  BOOL retValue = GLW.wglShareLists(a,b);
 
  //If the sharing was successful, share our internal lists
  if(retValue)
  {
    GLContext * aContext = glDriver.GetOpenGLContext(a);
    GLContext * bContext = glDriver.GetOpenGLContext(b);

    //If both contexts were retrieved, assign the context data
    if(aContext && bContext)
    {
      //Share the internal list data
      if(!aContext->ShareLists(bContext))
      {
        LOGERR(("wglShareLists - Unable to share internal lists"));
      }
    }
    else
    {
      LOGERR(("wglShareLists - Unable to get internal contexts"));
    }
  }

  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglSwapBuffers (HDC a)
{
  PRE_FUNCTION(wglSwapBuffers,a);
  BOOL retValue = GLW.wglSwapBuffers(a);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglSwapLayerBuffers (HDC a, UINT b)
{
  PRE_FUNCTION(wglSwapLayerBuffers,a);
  BOOL retValue = GLW.wglSwapLayerBuffers(a,b);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglUseFontBitmapsA (HDC a, DWORD b, DWORD c, DWORD d)
{
  INIT_DRIVER

  PRE_FUNCTION(wglUseFontBitmapsA,a);
  BOOL retValue = GLW.wglUseFontBitmapsA(a,b,c,d);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglUseFontBitmapsW (HDC a, DWORD b, DWORD c, DWORD d)
{
  INIT_DRIVER

  PRE_FUNCTION(wglUseFontBitmapsW,a);
  BOOL retValue = GLW.wglUseFontBitmapsW(a,b,c,d);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglUseFontOutlinesA (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h)
{
  INIT_DRIVER

  PRE_FUNCTION(wglUseFontOutlinesA,a);
  BOOL retValue = GLW.wglUseFontOutlinesA(a,b,c,d,e,f,g,h);
  POST_FUNCTION_RET(retValue)
  
  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY wglUseFontOutlinesW (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h)
{
  INIT_DRIVER

  PRE_FUNCTION(wglUseFontOutlinesW,a);
  BOOL retValue = GLW.wglUseFontOutlinesW(a,b,c,d,e,f,g,h);
  POST_FUNCTION_RET(retValue)

  return retValue;
}
