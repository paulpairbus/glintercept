/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLogXML.h"
#include "GLDriver.h"
#include "FileUtils.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;


///////////////////////////////////////////////////////////////////////////////
//
InterceptLogXML::InterceptLogXML(const string &fileName,FunctionTable * functionTable,const ConfigData &configData, 
                                 const string &newXSLFileName):
InterceptLogText(fileName,functionTable,configData),
frameRenderCallLog(configData.frameLogEnabled),
xslFileName(newXSLFileName)
{

}



///////////////////////////////////////////////////////////////////////////////
//
InterceptLogXML::~InterceptLogXML()
{

  //Write the closing tags
  fprintf(logFile,"</FUNCTIONS>\n");
  fprintf(logFile,"</GLINTERCEPT>\n");
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLogXML::Init()
{
  //Attempt to open the file
  logFile = fopen(logFileName.c_str(),"wt");

  //Prevent NULL file settings
  if(logFile == NULL)
  {
    LOGERR(("InterceptLogXML - Unable to open log file %s",logFileName.c_str()));
    return false;
  }

  //Write the XML version info
  fprintf(logFile,"<?xml version='1.0'?>\n");

  //Add the XSL file name if applicable
  if(xslFileName.size() > 0)
  {
    fprintf(logFile,"<?xml-stylesheet type=\"text/xsl\" href=\"%s\"?>",xslFileName.c_str());
  }

  //Write the header
  fprintf(logFile,"<GLINTERCEPT>\n");

  //Write the header data
  fprintf(logFile,"<HEADER>\n");

  //Write the version
  fprintf(logFile,"<VERSION>%s</VERSION>\n",__GLI_BUILD_VER_STR);

  //Write the time stamp
  struct tm *newtime;
  time_t     aclock;

  //Get the current time
  time( &aclock );

  //Convert it
  newtime = localtime( &aclock );
  fprintf(logFile,"<TIMESTAMP>%s</TIMESTAMP>\n",asctime(newtime));

  //Close the header
  fprintf(logFile,"</HEADER>\n");

  //Open the function data
  fprintf(logFile,"<FUNCTIONS>\n");

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogXML::LogFunctionPre - Function data for index %d is NULL",index)); 
    return;
  }

  //Save the args pointer
  va_list oldArgs = args;

  //Write the starting tag
  fprintf(logFile,"<FUNCTION>\n");

  //Write the name
  fprintf(logFile,"<NAME>%s</NAME>\n",funcData->functionName.c_str());

  //Loop for all the parameters
  for(uint i=0;i<funcData->parameterArray.size();i++)
  {
    //Get the parameter
    const ParameterData * paramData = &funcData->parameterArray[i];

    //Determine if we are processing pointers
    bool isPointer=false;
    if(paramData->pointerCount > 0 || paramData->length != -1)
    {
      isPointer=true;
    }

    //Get the value
    void *value;
    if(!GetNextValue(paramData->GetGLType(),&args,isPointer,&value))
    {
      break;
    }

    //Write the parameter tag
    fprintf(logFile,"<PARAM name=\"%s\" type=\"%s\">",paramData->paramName.c_str(),paramData->GetDisplayString().c_str());

    //Test if this is an array value
    if(paramData->length != -1)
    {
      bool isArrayOfPointers = false;

      //Test for an array of pointers
      if(paramData->pointerCount > 0)
      {
        isArrayOfPointers = true;
      }

      //Assign the array
      void * array =  *((void **)value);

      //Loop and print the array
      for(uint i2=0;i2<paramData->length;i2++)
      {
        //Get the value from the array
        if(!GetNextArrayValue(paramData->GetGLType(),&array,isArrayOfPointers,&value))
        {
          break;
        }

        //Add any custom tags 
        AddParamaterTags(value,isArrayOfPointers,paramData);

        //Convert and print the value
        string out=ConvertParam(value,isArrayOfPointers,paramData);
        fprintf(logFile,"<VALUE data=\"%s\"/>",out.c_str());
      }
      fprintf(logFile,"</PARAM>\n");
    }
    else
    {
      //Add any custom tags 
      AddParamaterTags(value,isPointer,paramData);

      //Just get the single value
      string out=ConvertParam(value,isPointer,paramData);
      fprintf(logFile,"<VALUE data=\"%s\"/></PARAM>",out.c_str());
    }

  }

  //Start a new line
  fprintf(logFile,"\n");

  //Reset the argument list
  va_end(args);

  //Flag to the driver if function timing is needed
  if(functionTimerEnabled) 
  {
    glDriver.SetFunctionTimer();
  }

  //If this is an rendering function
  if(glDriver.GetCurrentContext() &&
     glDriver.GetCurrentContext()->IsRenderFuncion(funcData,index,oldArgs))
  {
    //If we log shaders on render calls, log them
    if(shaderRenderCallLog)
    {
      //Get the bound shaders
      uint vertexShader,fragmentShader;
      GLhandle programGLSL;
      glDriver.GetCurrentContext()->GetBoundShaders(vertexShader,fragmentShader,programGLSL);

      //If a valid vertex shader, log it
      if(vertexShader != 0)
      {
        AddShaderTag(vertexShader,"VP",false);
      }

      if(fragmentShader != 0)
      {
        AddShaderTag(fragmentShader,"FP",false);
      }

      if(programGLSL != 0)
      {
        AddShaderTag(programGLSL,"GLSL",true);
      }
    }

    //If we log images on render calls, log them
    if(imageRenderCallLog)
    {
      //Get the bound textures
      BoundTextureArray boundTextures;
      glDriver.GetCurrentContext()->GetBoundTextures(boundTextures);

      //If there are any textures
      if(boundTextures.size() > 0)
      {
        //Loop for all textures and log the stage and texture number
        for(uint i=0;i<boundTextures.size();i++)
        {
          fprintf(logFile,"<TEXSTAGE number=\"%u\">",boundTextures[i].texStage);
          AddImageTag(boundTextures[i].texID);
          fprintf(logFile,"</TEXSTAGE>",boundTextures[i].texStage);
        }
      }
    }

    // Register frame buffer images if requested
    if(frameRenderCallLog)
    {
      //Get the frame file names
      FrameInterceptFileNames frameFileNames;
      if(glDriver.GetCurrentContext()->GetFrameFileNames(frameFileNames))
      {
        //Add all valid tags
        fprintf(logFile,"<FRAMEBUFFER>");

        //If there is some color frame buffer
        if(frameFileNames.colorBufNames[FIDT_PRE_FRAME ].size() > 0 ||
           frameFileNames.colorBufNames[FIDT_POST_FRAME].size() > 0 ||
           frameFileNames.colorBufNames[FIDT_DIFF_FRAME].size() > 0)
        {
          fprintf(logFile,"<COLORBUFFER>");
          AddFrameTag("PRE",frameFileNames.colorBufNames[FIDT_PRE_FRAME]);
          AddFrameTag("POST",frameFileNames.colorBufNames[FIDT_POST_FRAME]);
          AddFrameTag("DIFF",frameFileNames.colorBufNames[FIDT_DIFF_FRAME]);
          fprintf(logFile,"</COLORBUFFER>");
        }

        //If there is some depth frame buffer
        if(frameFileNames.depthBufNames[FIDT_PRE_FRAME ].size() > 0 ||
           frameFileNames.depthBufNames[FIDT_POST_FRAME].size() > 0 ||
           frameFileNames.depthBufNames[FIDT_DIFF_FRAME].size() > 0)
        {
          fprintf(logFile,"<DEPTHBUFFER>");
          AddFrameTag("PRE",frameFileNames.depthBufNames[FIDT_PRE_FRAME]);
          AddFrameTag("POST",frameFileNames.depthBufNames[FIDT_POST_FRAME]);   
          AddFrameTag("DIFF",frameFileNames.depthBufNames[FIDT_DIFF_FRAME]);   
          fprintf(logFile,"</DEPTHBUFFER>");
        }

        //If there is some stencil frame buffer
        if(frameFileNames.stencilBufNames[FIDT_PRE_FRAME ].size() > 0 ||
           frameFileNames.stencilBufNames[FIDT_POST_FRAME].size() > 0 ||
           frameFileNames.stencilBufNames[FIDT_DIFF_FRAME].size() > 0)
        {
          fprintf(logFile,"<STENCILBUFFER>");
          AddFrameTag("PRE",frameFileNames.stencilBufNames[FIDT_PRE_FRAME]);
          AddFrameTag("POST",frameFileNames.stencilBufNames[FIDT_POST_FRAME]);   
          AddFrameTag("DIFF",frameFileNames.stencilBufNames[FIDT_DIFF_FRAME]);   
          fprintf(logFile,"</STENCILBUFFER>");
        }

        fprintf(logFile,"</FRAMEBUFFER>");
      }
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{

  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogXML::LogFunctionPost - Function data for index %d is NULL",index)); 
    return;
  }

  //Get the return parameter
  const ParameterData * returnData = &funcData->returnType;

  //Determine if we are processing pointers
  bool isPointer=false;
  if(returnData->pointerCount > 0 || returnData->length != -1)
  {
    isPointer=true;
  }


  //Check the return value
  if(isPointer ||
     returnData->type != PT_void)
  {
    if(retVal != NULL)
    {
      //Look up the data
      string out = ConvertParam(retVal, isPointer, returnData);

      //Log the result
      fprintf(logFile,"<RETURN type=\"%s\">",returnData->GetDisplayString().c_str());
      fprintf(logFile,"<VALUE data=\"%s\"/></RETURN>\n",out.c_str());
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionError(uint errorCode)
{
  //If the log is not writing or the error code is 0, return
  if(!logEnabled || errorCode == 0x0)
  {
    return;
  }

  //Log that an error has occured
  fprintf(logFile,"<ERROR>");

  //Get the error string
  string errorString;
  GetErrorStringValue(errorCode,errorString);

  //Log the result
  fprintf(logFile,"<VALUE data=\"%s\"/>",errorString.c_str());

  fprintf(logFile,"</ERROR>");

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionComplete()
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Test if we log function timer values
  if(functionTimerEnabled)
  {
    //Get the function time
    uint funcTime = glDriver.GetFunctionTime();
    if(funcTime >= functionTimerCutOff)
    {
      //Log the function time if it is greater than the cutoff
      fprintf(logFile,"<FUNCTIME data=\"%u\"/>",funcTime);
    }
  }

  //Complete the function
  fprintf(logFile,"</FUNCTION>\n"); 
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLogXML::ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString)
{
  //Call base class to convert the custom types
  if(InterceptLogText::ConvertCustomParam(data,isPointer,paramData,retString))
  {
    //Strip the returned string of inavlid characters 
    ConvertStringXML(retString);
    return true;
  }

  return false;
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddParamaterTags(void *data, bool isPointer,const ParameterData *paramData)
{
  //Certain types need extra data added first (not actually handled here)
  if(!isPointer)
  {
    //Determine the type
    switch(paramData->type)
    {
      case(PT_image_index):
        {
          //Get the index number
          uint num = *((uint*)data);

          //Add the image tag
          AddImageTag(num);
          break;
        }

      case(PT_shader_index):
        {
          //Get the index number
          uint num = *((uint*)data);

          //Get the associated shader 
          AddShaderTag(num,"",false);
          break;
        }
      case(PT_GLSL_handle):
        {
          //Get the handle
          GLhandle num = *((GLhandle*)data);

          //Get the associated shader 
          AddShaderTag(num,"GLSL",true);
          break;
        }

      case(PT_display_list):
        {
          //Get the index number
          uint num = *((uint*)data);

          //Get the associated display list
          AddDisplayListTag(num);
          break;
        }
    }
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddImageTag(uint texID)
{
  //Get the file names for the texture
  ImageSaveFiles imageFiles;
  if(glDriver.GetCurrentContext() && 
     glDriver.GetCurrentContext()->GetTextureFileNames(texID,imageFiles))
  {
    //Write out an image tag
    fprintf(logFile,"<IMAGE id=\"%u\"",texID);

    //Write the file name
    if(imageFiles.imageFileNames.size() > 0)
    {
      //Format the image name and print it
      ConvertFileNameXML(imageFiles.imageFileNames[0]);
      fprintf(logFile," name=\"%s\" ",imageFiles.imageFileNames[0].c_str()); 
    }

    //Write the icon name
    if(imageFiles.iconName.length() > 0)
    {
      //Format the icon name and print it
      ConvertFileNameXML(imageFiles.iconName);
      fprintf(logFile," icon=\"%s\" ",imageFiles.iconName.c_str());
    }

    fprintf(logFile,"/>"); 

    //Additional images are saved without the icon
    for(uint i=1;i<imageFiles.imageFileNames.size();i++)
    {
      //Format the icon name and print it
      ConvertFileNameXML(imageFiles.imageFileNames[i]);
      fprintf(logFile,"<IMAGE name=\"%s\" />",imageFiles.imageFileNames[i].c_str()); 
    }
  }
  else
  {
    //Write out an image tag with only the ID
    fprintf(logFile,"<IMAGE id=\"%u\" />",texID);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddShaderTag(uint shaderID,string type,bool glslShader)
{
  string shaderName;
  
  //Check for a current context
  if(glDriver.GetCurrentContext())
  {
    //If this is a GLSl shader, get the data
    if(glslShader)
    {
      //If the data could not be retrieved, ensure the string is empty
      if(!glDriver.GetCurrentContext()->GetShaderGLSLFileName(shaderID,shaderName))
      {
        shaderName = "";
      }
    }
    else
    {
      //Get the standard ARB shader file 
      if(!glDriver.GetCurrentContext()->GetShaderFileName(shaderID,shaderName))
      {
        shaderName = "";
      }
    }
  }

  //If there is a shader name to write, write it out
  if(shaderName.length() > 0)
  {
    //Convert the file name 
    ConvertFileNameXML(shaderName);

    //Check for a known type
    if(type != "")
    {
      //Write out a shader tag
      fprintf(logFile,"<SHADER id=\"%u\" type=\"%s\" name=\"%s\"/>",shaderID,type.c_str(),shaderName.c_str());
    }
    else
    {
      //Write out a shader tag
      fprintf(logFile,"<SHADER id=\"%u\" name=\"%s\"/>",shaderID,shaderName.c_str());
    }
  }
  else
  {
    //Check for a known type
    if(type != "")
    {
      //Write out an shader tag with type and ID
      fprintf(logFile,"<SHADER id=\"%u\" type=\"%s\" />",shaderID,type.c_str());
    }
    else
    {
      //Write out an shader tag with only the ID
      fprintf(logFile,"<SHADER id=\"%u\" />",shaderID);
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddFrameTag(const string &tagID, const string &filename)
{
  //Only proceed if the file name has a length
  if(filename.length() > 0)
  {
    //Convert the file name and write it out
    string convertName = filename;
    ConvertFileNameXML(convertName);
    fprintf(logFile,"<%s image=\"%s\" />",tagID.c_str(),convertName.c_str());    
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddDisplayListTag(uint listID)
{
  //Get the display list filename
  string listName;
  if(glDriver.GetCurrentContext() &&
     glDriver.GetCurrentContext()->GetDisplayListFileName(listID,listName) &&
     listName.length() > 0)
  {
    //Convert the file name 
    ConvertFileNameXML(listName);

    //Write out a display list tag
    fprintf(logFile,"<DLIST id=\"%u\" name=\"%s\"/>",listID,listName.c_str());
  }
  else
  {
    //Write out an display list tag 
    fprintf(logFile,"<DLIST id=\"%u\" />",listID);
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::ConvertStringXML(string &convertStr)
{
  string retString;
  retString.reserve(convertStr.length()+5);

  //Loop for all characters
  for(uint i=0;i<convertStr.length();i++)
  {
    //Replace all quotes with a XML quote tag
    if(convertStr[i] == '"')
    {
      retString+="&quot;";  
    }
    else
    {
      retString+=convertStr[i];  
    }
  }

  convertStr = retString;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::ConvertFileNameXML(string &convertFileName)
{
  //Get the path of this string
  int pathEnd = logFileName.rfind(FileUtils::dirSeparator);
  if(pathEnd != string::npos)
  {
    //Get the path
    string filePath = logFileName;
    filePath.erase(pathEnd+1,filePath.size()-pathEnd-1);

    //If the entire path is at the start of this string
    if(convertFileName.find(filePath,0) == 0)
    {
      //Strip the path
      convertFileName.erase(0,filePath.size());
    }
  }

  //Convert all back slashes to forward slashes
  //  (some XML browsers do not like back slashes)
  for(uint i=0;i<convertFileName.size();i++)
  {
    if(convertFileName[i] == '\\')
    {
      convertFileName[i] = '/';
    }
  }

}

