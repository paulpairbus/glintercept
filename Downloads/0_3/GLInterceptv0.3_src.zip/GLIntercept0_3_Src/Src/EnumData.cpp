/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "EnumData.h"

USING_ERRORLOG

static const string unknownValueStr("Unknown");

///////////////////////////////////////////////////////////////////////////////
//
EnumData::EnumData(const string & name,bool isBitMask):
enumName(name),
isBitMask(isBitMask)
{

}

///////////////////////////////////////////////////////////////////////////////
//
EnumData::~EnumData()
{

}

///////////////////////////////////////////////////////////////////////////////
//
const string & EnumData::GetName() const
{
  return enumName;
}

///////////////////////////////////////////////////////////////////////////////
//
int EnumData::GetEnumIndex(uint value) const
{
  //Loop and retrieve
  for(uint i=0;i<enumValues.size();i++)
  {
    //Compare the value
    if(enumValues[i].value == value)
    {
      return i;
    }
  }

  return -1;
}

///////////////////////////////////////////////////////////////////////////////
//
int EnumData::GetEnumIndex(const string & name) const
{
  //Loop and retrieve
  for(uint i=0;i<enumValues.size();i++)
  {
    //Compare the name
    if(enumValues[i].name == name)
    {
      return i;
    }
  }

  return -1;
}


///////////////////////////////////////////////////////////////////////////////
//
bool EnumData::AddEnumValue(EnumValue value)
{
  //Loop and check
  for(uint i=0;i<enumValues.size();i++)
  {
    //Compare the value and name
    if(enumValues[i].value == value.value ||
       enumValues[i].name  == value.name)
    {
      LOGERR(("EnumData::AddEnumValue - Value %d Name %s already exists",value.value,value.name.c_str()));
      return false;
    }
  }

  //Extra check for mask enum
  if(isBitMask)
  {
    //Loop and test all bits
    uint numBits =0;
    for(uint i=0;i<sizeof(uint)*8;i++)
    {
      uint mask = ((uint)1 << i);

      //If this bit is set, increment the counter
      if(mask & value.value)
      {
        numBits++;
      }
    }

    //If there was more than one bit, log an error
    if(numBits > 1)
    {
      LOGERR(("EnumData::AddEnumValue - Value %d Name %s already has %d mask bits (Masks can only have 1 bit)",value.value,value.name.c_str(),numBits));
      return false;
    }
  }

  //Add the value
  enumValues.push_back(value);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
const string & EnumData::GetEnum(uint value) const
{
  //Retrieve the index
  int index = GetEnumIndex(value);
  if(index != -1)
  {
    return enumValues[index].name;
  }

  return unknownValueStr;
}

///////////////////////////////////////////////////////////////////////////////
//
uint EnumData::GetEnum(const string & name) const
{
  //Loop and retrieve
  int index = GetEnumIndex(name);
  if(index != -1)
  {
    return enumValues[index].value;
  }

  return (uint)-1;
}

///////////////////////////////////////////////////////////////////////////////
//
string EnumData::GetDisplayString(uint value) const
{
  //Check for a bit mask 
  if(!isBitMask)
  {
    //Look for the value
    int index = GetEnumIndex(value);
    if(index != -1)
    {
      return enumValues[index].name;
    }
    else
    {
      //Add the value to the buffer
      string retString;
      StringPrintF(retString,"0x%04x",value);
      return retString;
    }

  }
  else
  {
    string bitMaskStr;
    bool  firstBit =true;

    //Loop and test all bits
    for(uint i=0;i<sizeof(uint)*8;i++)
    {
      uint mask = ((uint)1 << i);

      //Test if the mask value is used
      if(value & mask)
      {
        //Add a seperator
        if(!firstBit)
        {
          bitMaskStr = bitMaskStr  + " | ";
        }
        else
        {
          firstBit =false;
        }

        //Look-up the mask value
        int index = GetEnumIndex(mask);
        if(index != -1)
        {
          bitMaskStr = bitMaskStr + enumValues[index].name;
        }
        else
        {
          //Add the mask value to the buffer
          string retString;
          StringPrintF(retString,"0x%04x",mask);
          bitMaskStr = bitMaskStr + retString;
        }
      }
    }

    //Assign a zero string for no bits
    if(firstBit)
    {
      //Ensure this is no "zero mask" value
      int index = GetEnumIndex(value);
      if(index != -1)
      {
        return enumValues[index].name;
      }
      else
      {
        bitMaskStr = "0x000000";
      }
    }

    //Return the mask
    return bitMaskStr;
  }

}

///////////////////////////////////////////////////////////////////////////////
//
bool EnumData::Merge(EnumData & newData)
{
  bool retValue = true;

  //Loop and merge all values
  for(uint i=0;i<newData.enumValues.size();i++)
  {
    //Add and check for a existing enum
    if(!AddEnumValue(newData.enumValues[i]))
    {
      //Flag that at least one value already exists
      retValue = false;
    }
  }

  return retValue;
}