/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __FILE_UTILS_H__
#define __FILE_UTILS_H__

#include "GLInterceptConfig.h"

#include <string>
#include <vector>

using namespace std;

//@
//  Summary:
//    File utility functions that are OS specific
// 
class FileUtils
{
public:

  static char dirSeparator;                 //The characters used as directory seperators

  //Properties that can be set on files
  enum FileProperties
  {
    FP_NORMAL   = 1 << 0L,     // Standard read/write access  
    FP_READONLY = 1 << 1L,     // File is flagged as read only
  };
 
  //@
  //  Summary:
  //    To create the specified directory (if it does not already exist)
  //    Sub-directories leading up to the directory will be created if 
  //    necessary.
  //  
  //  Parameters:
  //    directory  - The directory to be created.
  //
  //  Returns:
  //    True is returned on success, false if otherwise.
  //
  static bool CreateFullDirectory(const char *directory); 

  //@
  //  Summary:
  //    To copy a file from the source to the destination file names.
  //  
  //  Parameters:
  //    srcFile  - The source file name.
  //
  //    dstFile  - The destination file name.
  //
  //    overwrite - Falg to indicate if we over-write if the dstFile already exists.
  //
  //  Returns:
  //    True is returned on success, false if otherwise.
  //
  static bool CopyFile(const string &srcFile,const string &dstFile, bool overwrite);

  //@
  //  Summary:
  //    To set the properties of a file.
  //  
  //  Parameters:
  //    fileName  - The file name to set the properties for.
  //
  //    fileProperties  - The file properties Mask to set. 
  //                      (cannot set incompatable flags such as FP_NORMAL and FP_READONLY)
  //
  //  Returns:
  //    True is returned on success, false if otherwise.
  //
  static bool SetFileProperties(const string &fileName,uint fileProperties);
};








#endif 
