/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptFrame.h"
#include "FileUtils.h"
#include "GLDriver.h"

// NOTE: This logger does not currently handle WGL_ARB_make_current_read, add support?

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
FrameInterceptFileNames::FrameInterceptFileNames()
{
  //Reset
  Reset();
}

///////////////////////////////////////////////////////////////////////////////
//
void FrameInterceptFileNames::Reset()
{
  //Set all file names to be empty
  for(uint i=0;i<FIDT_MAX;i++)
  {
    colorBufNames[i]   = "";
    depthBufNames[i]   = "";
    stencilBufNames[i] = "";
  }
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::SaveFrameData::SaveFrameData(bool pre,bool post,bool diff):
savePre(pre),
savePost(post),
saveDiff(diff),
preData(NULL),
postData(NULL),
diffData(NULL)
{
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::SaveFrameData::~SaveFrameData()
{
  ResetBuffers();
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::SaveFrameData::ResetBuffers()
{
  //Delete the buffers
  if(preData)
  { 
    delete preData;
    preData = NULL;
  }
  if(postData)
  { 
    delete postData;
    postData = NULL;
  }
  if(diffData)
  {
    delete diffData;
    diffData = NULL;
  }
}



///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::InterceptFrame(GLDriver *ogldriver,FunctionTable * functionTable,const ConfigData &configData):
InterceptData(ogldriver),
inBeginEndSection(false),
isRenderFunction(false),
imageExtension(configData.frameImageFormat),

colorSaveData(configData.framePreColorSave,configData.framePostColorSave,configData.frameDiffColorSave),
depthSaveData(configData.framePreDepthSave,configData.framePostDepthSave,configData.frameDiffDepthSave),
stencilSaveData(configData.framePreStencilSave,configData.framePostStencilSave,configData.frameDiffStencilSave)
{
  udword currColor = 0xFFFFFFFF;
  for(uint i=0;i<IF_NUM_STENCIL_COLORS;i++)
  {
    //If there are supplied values
    if(configData.frameStencilColors.size() > 0)
    {
      //Loop for all the stencil index/color pairs
      for(uint i2=0;i2<configData.frameStencilColors.size();i2+=2)
      {
        //Stop when reaching a color index thta is greater that the current index
        if(configData.frameStencilColors[i2] > i)
        {
          break;
        }

        //Assign the current color
        if(i2+1 < configData.frameStencilColors.size())
        {
          currColor = configData.frameStencilColors[i2+1];
        }
      }
    }
    else
    {
      //Just use the direct index
      currColor = 0xFF000000 | (i << 16) | (i << 8) | i;
    }

    //Set the current stencil color
    stencilColorLookup[i] = currColor;
  }


}

///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::~InterceptFrame()
{
  //Delete any buffers
  ResetBuffers();
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::SetDataSavingPath(const string &newPath)
{
  //Append the FrameBuffer directory then pass to the base class
  string path = newPath + "FrameBuffer" + FileUtils::dirSeparator;

  //Call base class to set
  InterceptData::SetDataSavingPath(path);
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::ResetBuffers()
{
  //Delete any outstanding data
  colorSaveData.ResetBuffers();
  depthSaveData.ResetBuffers();
  stencilSaveData.ResetBuffers();
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //Reset the flag
  isRenderFunction = false;

  //Return if GL calls cannot be made  or it is not a render function
  if(!driver->GetInternalGLCallMode() || 
     !driver->GetCurrentContext() ||
     !driver->GetCurrentContext()->IsRenderFuncion(funcData,index,args))
  {
    return;
  }

  //Clear old file names
  saveFileNames.Reset();

  //Only proceed if frame saving is enabled
  if(!GetDataSaving())
  {
    return;
  }
  
  //Flag to the "post" function that this is a render function
  isRenderFunction = true;

  //Store a unique save count number
  static uint saveCount=0;
  saveCount++;

  //Get the pre color buffers 
  GetBufferDataPre(GL_RGBA,&colorSaveData, saveFileNames.colorBufNames,saveCount);

  //Get the pre depth buffers 
  GetBufferDataPre(GL_DEPTH_COMPONENT,&depthSaveData, saveFileNames.depthBufNames,saveCount);

  //Get the pre stencil buffers 
  GetBufferDataPre(GL_STENCIL_INDEX,&stencilSaveData, saveFileNames.stencilBufNames,saveCount);

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{
  //If in a begin/end block, set the flag
  if(driver->GetBeginEndState())
  {
    //Set the flag to do the post render later
    if(isRenderFunction)
    {
      inBeginEndSection = true;
    }
    return;
  }

  //Return if GL calls cannot be made or frame saving is disabled 
  if(!driver->GetInternalGLCallMode() || !GetDataSaving())
  {
    return;  
  }

  //Return if it is not a render call 
  //  (and the frame did not just came off a begin/end block)
  if(!isRenderFunction && !inBeginEndSection)
  {
    return;
  }

  //Reset the flag
  inBeginEndSection = false;

  //Get the post color buffers 
  GetBufferDataPost(GL_RGBA,&colorSaveData, saveFileNames.colorBufNames);

  //Get the post depth buffers 
  GetBufferDataPost(GL_DEPTH_COMPONENT,&depthSaveData, saveFileNames.depthBufNames);

  //Get the post stencil buffers 
  GetBufferDataPost(GL_STENCIL_INDEX,&stencilSaveData, saveFileNames.stencilBufNames);


  //Reset all buffers
  ResetBuffers();
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::GetBufferDataPre(GLenum bufType,SaveFrameData *bufferData, string saveNames[3],uint saveCount) 
{
  //Return now if none of the buffers are being saved
  if(!bufferData->savePre && !bufferData->savePost && !bufferData->saveDiff)
  {
    return;
  }
  
  //Reset the save names
  saveNames[FIDT_PRE_FRAME]  = "";
  saveNames[FIDT_POST_FRAME] = "";
  saveNames[FIDT_DIFF_FRAME] = "";

  //Return now if the buffer type is not readable
  if(!IsBufferReadable(bufType))
  {
    return;
  }

  //Get the frame filename start from the type
  string frameTypeName("Frame");
  switch(bufType)
  {
    case(GL_RGBA):
      frameTypeName = "FrameColor";
      break;
    case(GL_DEPTH_COMPONENT):
      frameTypeName = "FrameDepth";
      break;
    case(GL_STENCIL_INDEX):
      frameTypeName = "FrameStencil"; 
      break;
  }

  string bufString;
  StringPrintF(bufString,"%s%s_%04u_%04u_",GetDataSavingPath().c_str(),frameTypeName.c_str(),
                                           driver->GetFrameNumber(),saveCount);

  //Assign buffer names
  if(bufferData->savePre)
  {
    saveNames[FIDT_PRE_FRAME]  = bufString + "Pre." + imageExtension;
  }
  if(bufferData->savePost)
  {
    saveNames[FIDT_POST_FRAME] = bufString + "Post." + imageExtension;
  }
  if(bufferData->saveDiff)
  {
    saveNames[FIDT_DIFF_FRAME] = bufString + "Diff." + imageExtension;
  }

  //Get the pre-buffers
  if(bufferData->savePre || bufferData->saveDiff)
  {
    bufferData->preData = GetBuffer(bufType);
  }

  //Empty the file name of buffers that could not be retrieved
  if(bufferData->preData == NULL)
  {
    saveNames[FIDT_PRE_FRAME] = "";
    saveNames[FIDT_DIFF_FRAME] = "";
  }

  //Save the buffer if it can be saved
  if(bufferData->preData && saveNames[FIDT_PRE_FRAME].length() > 0)
  {
    //Attempt to save
    if(!SaveBuffer(saveNames[FIDT_PRE_FRAME],bufferData->preData))
    {
      saveNames[FIDT_PRE_FRAME] = "";
    }
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::GetBufferDataPost(GLenum bufType,SaveFrameData *bufferData,string saveNames[3]) const
{

  //Return now if none of the buffers are being saved
  if(!bufferData->savePre && !bufferData->savePost && !bufferData->saveDiff)
  {
    return;
  }

  //Return now if the buffer type is not readable
  if(!IsBufferReadable(bufType))
  {
    return;
  }

  //Get the post buffers
  if(bufferData->savePost || bufferData->saveDiff)
  {
    bufferData->postData = GetBuffer(bufType);
  }

  //Calculate the diffs
  if(bufferData->saveDiff && bufferData->preData && bufferData->postData)
  {
    bufferData->diffData = CalculateImageDiff(bufferData->preData,bufferData->postData);
  }

  //Empty the file name of buffers that could not be retrieved
  if(bufferData->postData == NULL)
  {
    saveNames[FIDT_POST_FRAME] = "";
  }
  if(bufferData->diffData == NULL)
  {
    saveNames[FIDT_DIFF_FRAME] = "";
  }

  //Save post buffers
  if(bufferData->postData && saveNames[FIDT_POST_FRAME].length() > 0)
  {
    //Attempt to save
    if(!SaveBuffer(saveNames[FIDT_POST_FRAME],bufferData->postData))
    {
      saveNames[FIDT_POST_FRAME] = "";
    }
  }

  //Save diffs
  if(bufferData->diffData && saveNames[FIDT_DIFF_FRAME].length() > 0)
  {
    //Attempt to save
    if(!SaveBuffer(saveNames[FIDT_DIFF_FRAME],bufferData->diffData))
    {
      saveNames[FIDT_DIFF_FRAME] = "";
    }
  }

}


///////////////////////////////////////////////////////////////////////////////
//
bool InterceptFrame::SaveBuffer(const string &fileName,corona::Image * saveBuffer) const
{
  //Write the file out
  if(!corona::SaveImage(fileName.c_str(),corona::FF_AUTODETECT,saveBuffer))
  {
    LOGERR(("InterceptFrame::SaveBuffer - Unable to save image %s",fileName.c_str()));
    return false;
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptFrame::IsBufferReadable(GLenum bufType) const
{
  //Determine if the requested buffer can be retrieved
  switch(bufType)
  {
    case(GL_RGBA) : 
      return true;
      break;

    case(GL_DEPTH_COMPONENT) : 
      {
        //Get the number of depth bits
        GLint numDepthBits=0;
        GLV.glGetIntegerv(GL_DEPTH_BITS,&numDepthBits);
  
        //Only proceed if there is a depth buffer
        if(numDepthBits > 0)
        {
          return true;
        }
      }
      break;

    case(GL_STENCIL_INDEX) : 
      {
        //Get the number of stencil bits
        GLint numStencilBits=0;
        GLV.glGetIntegerv(GL_STENCIL_BITS,&numStencilBits);
        if(numStencilBits > 0)
        {
          return true;
        }
      }
      break;
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
corona::Image *InterceptFrame::GetBuffer(GLenum bufType) const
{
  //Get the size of the viewport
  GLint viewSize[4];
  GLV.glGetIntegerv(GL_VIEWPORT,&viewSize[0]);

  //If the viewport does not have a size, return NULL
  if(viewSize[2] == 0 || viewSize[3] == 0)
  {
    return NULL;
  }

  //Allocate the return image
  corona::Image * newImage = corona::CreateImage(viewSize[2],viewSize[3],corona::PF_R8G8B8A8);
  if(!newImage)
  {
    return NULL;
  }

  GLint oldReadBuffer=0, drawBuffer=0;

  //Get the current read/draw buffer type
  GLV.glGetIntegerv(GL_READ_BUFFER,&oldReadBuffer);
  GLV.glGetIntegerv(GL_DRAW_BUFFER,&drawBuffer);

  //Set the read buffer to the current draw buffer if necessary
  if(oldReadBuffer != drawBuffer)
  {
    GLV.glReadBuffer(drawBuffer);
  }

  //Set pixel transfer modes
  GLV.glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);

  //Set the required pack operations
  GLV.glPixelStorei(GL_PACK_ALIGNMENT,  1); 
  GLV.glPixelStorei(GL_PACK_LSB_FIRST,  0); 

  GLV.glPixelStorei(GL_PACK_ROW_LENGTH, 0); 
  GLV.glPixelStorei(GL_PACK_SKIP_PIXELS,0); 
  
  GLV.glPixelStorei(GL_PACK_SKIP_ROWS,  0); 
  GLV.glPixelStorei(GL_PACK_SWAP_BYTES, 0); 

  //Read the data based on the buffer type
  if(bufType == GL_RGBA)
  {
    //Read the pixels //TODO: What about ARB imaging modifying the return values? (see glReadPixels,glPixelTransfer)
    GLV.glReadPixels(viewSize[0],viewSize[1],viewSize[2],viewSize[3],bufType,GL_UNSIGNED_BYTE,newImage->getPixels());
  }
  else if(bufType == GL_DEPTH_COMPONENT)
  {
    //TODO: What about depth_bias and depth_scale
    //Allocate a retrieval array
    GLubyte * depthBuffer = new GLubyte[(viewSize[2] *viewSize[3])];
  
    //Read the pixels 
    GLV.glReadPixels(viewSize[0],viewSize[1],viewSize[2],viewSize[3],bufType,GL_UNSIGNED_BYTE,&depthBuffer[0]);

    //Pack the return data into the array
    GLubyte * srcImg   = &depthBuffer[0];
    GLubyte * dstImg   = (GLubyte *)newImage->getPixels();
    for(uint i=0;i<newImage->getWidth()*newImage->getHeight();i++)
    {
      //Copy the data
      dstImg[0] = *srcImg;
      dstImg[1] = *srcImg;
      dstImg[2] = *srcImg;
      dstImg[3] = 0xFF;

      //Increment the counters
      dstImg+=4;
      srcImg++;
    }

    //Delete the array
    delete [] depthBuffer;
  }
  else if(bufType == GL_STENCIL_INDEX)
  {
    //TODO - Disable map stencil? remove index shift/offset? (see glReadPixels, glPixelTransfer)
  
    //Allocate a retrieval array
    GLubyte * stencilBuffer = new GLubyte[(viewSize[2] *viewSize[3])];
  
    //Read the pixels 
    GLV.glReadPixels(viewSize[0],viewSize[1],viewSize[2],viewSize[3],bufType,GL_UNSIGNED_BYTE,&stencilBuffer[0]);

    //Pack the return data into the array
    GLubyte  * srcImg   = &stencilBuffer[0];
    udword   * dstImg   = (udword *)newImage->getPixels();
    for(uint i=0;i<newImage->getWidth()*newImage->getHeight();i++)
    {
      //Copy the data
      if(*srcImg < IF_NUM_STENCIL_COLORS)
      {
        *dstImg = stencilColorLookup[*srcImg];
      }
      else
      {
        *dstImg = 0xFFFFFFFF;
      }

      //Increment the counters
      dstImg++;
      srcImg++;
    }

    //Delete the array
    delete [] stencilBuffer;
  }

  //Restore transfer mode
  GLV.glPopClientAttrib();

  //Restore the read buffer (if it was changed)
  if(oldReadBuffer != drawBuffer)
  {
    GLV.glReadBuffer(oldReadBuffer);
  }

  //Flip the image 
  corona::FlipImage(newImage,corona::CA_X);

  //Return the image
  return newImage;

}

///////////////////////////////////////////////////////////////////////////////
//
corona::Image *InterceptFrame::CalculateImageDiff(corona::Image * src1,corona::Image * src2) const
{
  //If the image sizes are not the same, return 
  if(!src1 || !src2 ||
     src1->getWidth() != src2->getWidth() ||
     src1->getHeight() != src2->getHeight() ||
     src1->getFormat() != corona::PF_R8G8B8A8 || src2->getFormat() != corona::PF_R8G8B8A8)
  {
    LOGERR(("InterceptFrame::CalculateImageDiff - Invalid width/height/format"));
    return NULL;
  }

  //Create a new image of the requested dimensions
  corona::Image * newImage = corona::CreateImage(src1->getWidth(),src1->getHeight(),corona::PF_R8G8B8A8);
  if(!newImage)
  {
    return NULL;
  }

  //Flag to indcate if the images are identical
  bool noDiff = true;

  //Get the starting pointers
  udword * src1Img  = (udword *)src1->getPixels();
  udword * src2Img  = (udword *)src2->getPixels();
  udword * dstImg   = (udword *)newImage->getPixels();

  //Loop for all image elements
  for(uint i=0; i<newImage->getWidth()*newImage->getHeight();i++)
  {
    //Check if the images are different
    if(*src1Img != *src2Img)
    {
      //Assign the destination from the second image for a difference
      *dstImg = *src2Img;
      noDiff  = false;
    }
    else
    {
      //Just assign green 
      *dstImg =  0xFF00FF00;
    }

    //Increment counters
    src1Img++; 
    src2Img++;
    dstImg++; 
  } 

  //If there was no difference, assign all red
  if(noDiff)
  {
    //Reset the counter and loop for all pixels
    udword * dstImg = (udword *)newImage->getPixels();
    for(uint i=0; i<newImage->getWidth()*newImage->getHeight();i++)
    {
      //Just assign red
      *dstImg =  0xFF0000FF;
      dstImg++; 
    }
  }
  
  return newImage;
}

