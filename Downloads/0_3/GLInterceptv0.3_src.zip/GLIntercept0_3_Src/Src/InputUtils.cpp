/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/

#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InputUtils.h"

//Structure for holding key lookups
struct KeyLookup
{
  uint keyCode;
  const char *keyStr;
};

//Key code lookups for windows
KeyLookup keyLookup[] = 
{
  {VK_BACK, "backspace"},
  {VK_TAB, "tab"},
  {VK_CLEAR, "clear"},
  {VK_RETURN, "enter"},
  {VK_SHIFT, "shift"},
  {VK_CONTROL, "ctrl"},
  {VK_MENU, "alt"},
  {VK_PAUSE, "pause"},
  {VK_CAPITAL, "caps"},
  {VK_ESCAPE, "esc"},
  {VK_SPACE, "space"},
  {VK_PRIOR, "pageup"},
  {VK_NEXT, "pagedown"},
  {VK_END, "end"},
  {VK_HOME, "home"},
  {VK_LEFT, "left"},
  {VK_UP, "up"},
  {VK_RIGHT, "right"},
  {VK_DOWN, "down"},
  {VK_SELECT, "select"},
  {VK_EXECUTE, "execute"},
  {VK_SNAPSHOT, "print"},
  {VK_INSERT, "insert"},
  {VK_DELETE, "delete"},
  {VK_HELP, "help"},
  {'0', "0"},
  {'1', "1"},
  {'2', "2"},
  {'3', "3"},
  {'4', "4"},
  {'5', "5"},
  {'6', "6"},
  {'7', "7"},
  {'8', "8"},
  {'9', "9"},
  {'A', "a"},
  {'B', "b"},
  {'C', "c"},
  {'D', "d"},
  {'E', "e"},
  {'F', "f"},
  {'G', "g"},
  {'H', "h"},
  {'I', "i"},
  {'J', "j"},
  {'K', "k"},
  {'L', "l"},
  {'M', "m"},
  {'N', "n"},
  {'O', "o"},
  {'P', "p"},
  {'Q', "q"},
  {'R', "r"},
  {'S', "s"},
  {'T', "t"},
  {'U', "u"},
  {'V', "v"},
  {'W', "w"},
  {'X', "x"},
  {'Y', "y"},
  {'Z', "z"},
  {VK_LWIN, "lwin"},
  {VK_RWIN, "rwin"},
  {VK_APPS, "apps"},
  {VK_NUMPAD0, "num0"},
  {VK_NUMPAD1, "num1"},
  {VK_NUMPAD2, "num2"},
  {VK_NUMPAD3, "num3"},
  {VK_NUMPAD4, "num4"},
  {VK_NUMPAD5, "num5"},
  {VK_NUMPAD6, "num6"},
  {VK_NUMPAD7, "num7"},
  {VK_NUMPAD8, "num8"},
  {VK_NUMPAD9, "num9"},
  {VK_MULTIPLY, "mul"},
  {VK_ADD, "add"},
  {VK_SUBTRACT, "sub"},
  {VK_DECIMAL, "decimal"},
  {VK_DIVIDE, "div"},
  {VK_F1, "f1"},
  {VK_F2, "f2"},
  {VK_F3, "f3"},
  {VK_F4, "f4"},
  {VK_F5, "f5"},
  {VK_F6, "f6"},
  {VK_F7, "f7"},
  {VK_F8, "f8"},
  {VK_F9, "f9"},
  {VK_F10, "f10"},
  {VK_F11, "f11"},
  {VK_F12, "f12"},
  {VK_F13, "f13"},
  {VK_F14, "f14"},
  {VK_F15, "f15"},
  {VK_F16, "f16"},
  {VK_F17, "f17"},
  {VK_F18, "f18"},
  {VK_F19, "f19"},
  {VK_F20, "f20"},
  {VK_F21, "f21"},
  {VK_F22, "f22"},
  {VK_F23, "f23"},
  {VK_F24, "f24"},
  {VK_NUMLOCK, "numlock"},
  {VK_SCROLL, "scrolllock"}
};

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
uint InputUtils::GetKeyCode(const string & keyString)
{
  //Make the string lower case
  string lookUpStr = keyString;

  //Loop for all key lookups
  for(uint i=0;i < sizeof(keyLookup) / sizeof(KeyLookup); i++)
  {
    //If the string matches, return the code
    if(keyLookup[i].keyStr == lookUpStr)
    {
      return keyLookup[i].keyCode;
    }
  }

  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InputUtils::IsKeyDown(uint keyCode)
{
  //Return if the high byte is true (ie key is down)
  return (GetAsyncKeyState(keyCode) & 0x8000) != 0;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InputUtils::IsAllKeyDown(vector<uint> keyCodes)
{
  //Loop for all the codes
  for(uint i=0;i<keyCodes.size();i++)
  {
    //If one of the keys is not down, return now
    if(!IsKeyDown(keyCodes[i]))
    {
      return false;
    }
  }

  //Only return true when there exists some keys to test
  if(keyCodes.size() > 0)
  {
    return true;
  }

  return false;
}

