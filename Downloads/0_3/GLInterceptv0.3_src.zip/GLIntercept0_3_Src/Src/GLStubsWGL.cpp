/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "GLInterceptConfig.h"
#include "GLDriver.h"
#include "GLWindows.h"

USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
bool MapWGLFunctions(DLLLoader &openGLLib)
{
  void **tempfunc;

#define GLW_FUNC_LOOKUP(string)                 \
  tempfunc = (void**)(&GLW.##string);           \
  (*tempfunc) = openGLLib.GetFunction(#string); \
  if(GLW.##string == NULL)                      \
  {LOGERR(("Function %s unable to be mapped",#string)) return false;}

  GLW_FUNC_LOOKUP(wglChoosePixelFormat)
  GLW_FUNC_LOOKUP(wglCopyContext)
  GLW_FUNC_LOOKUP(wglCreateContext)
  GLW_FUNC_LOOKUP(wglCreateLayerContext)
  GLW_FUNC_LOOKUP(wglDeleteContext)
  GLW_FUNC_LOOKUP(wglDescribeLayerPlane)
  GLW_FUNC_LOOKUP(wglDescribePixelFormat)
  GLW_FUNC_LOOKUP(wglGetCurrentContext)
  GLW_FUNC_LOOKUP(wglGetCurrentDC)
  GLW_FUNC_LOOKUP(wglGetDefaultProcAddress)
  GLW_FUNC_LOOKUP(wglGetLayerPaletteEntries)
  GLW_FUNC_LOOKUP(wglGetPixelFormat)
  GLW_FUNC_LOOKUP(wglGetProcAddress)
  GLW_FUNC_LOOKUP(wglMakeCurrent)
  GLW_FUNC_LOOKUP(wglRealizeLayerPalette)
  GLW_FUNC_LOOKUP(wglSetLayerPaletteEntries)
  GLW_FUNC_LOOKUP(wglSetPixelFormat)
  GLW_FUNC_LOOKUP(wglShareLists)
  GLW_FUNC_LOOKUP(wglSwapBuffers)
  GLW_FUNC_LOOKUP(wglSwapLayerBuffers)
  GLW_FUNC_LOOKUP(wglUseFontBitmapsA)
  GLW_FUNC_LOOKUP(wglUseFontBitmapsW)
  GLW_FUNC_LOOKUP(wglUseFontOutlinesA)
  GLW_FUNC_LOOKUP(wglUseFontOutlinesW)

#undef GLW_FUNC_LOOKUP

  return true;
}



#define DUMMY_LOG(name) LOGERR(("Call to %s made outside of context/init",#name));

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY DummywglChoosePixelFormat (HDC a, CONST PIXELFORMATDESCRIPTOR *b)
{
  DUMMY_LOG(wglChoosePixelFormat);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglCopyContext (HGLRC a, HGLRC b, UINT c)
{
  DUMMY_LOG(wglCopyContext);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY DummywglCreateContext (HDC a)
{
  DUMMY_LOG(wglCreateContext);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY DummywglCreateLayerContext (HDC a, int b)
{
  DUMMY_LOG(wglCreateLayerContext);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglDeleteContext (HGLRC a)
{
  DUMMY_LOG(wglDeleteContext);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglDescribeLayerPlane (HDC a, int b, int c, UINT d, LPLAYERPLANEDESCRIPTOR e)
{
  DUMMY_LOG(wglDescribeLayerPlane);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY DummywglDescribePixelFormat (HDC a, int b, UINT c, LPPIXELFORMATDESCRIPTOR d)
{
  DUMMY_LOG(wglDescribePixelFormat);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
HGLRC WGLAPIENTRY DummywglGetCurrentContext (void)
{
  DUMMY_LOG(wglGetCurrentContext);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
HDC WGLAPIENTRY DummywglGetCurrentDC (void)
{
  DUMMY_LOG(wglGetCurrentDC);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
PROC WGLAPIENTRY DummywglGetDefaultProcAddress (LPCSTR a)
{
  DUMMY_LOG(wglGetDefaultProcAddress);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY DummywglGetLayerPaletteEntries (HDC a, int b, int c, int d, COLORREF *e)
{
  DUMMY_LOG(wglGetLayerPaletteEntries);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY DummywglGetPixelFormat (HDC a)
{
  DUMMY_LOG(wglGetPixelFormat);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
PROC WGLAPIENTRY DummywglGetProcAddress (LPCSTR a)
{
  DUMMY_LOG(wglGetProcAddress);
  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglMakeCurrent (HDC a, HGLRC b)
{
  DUMMY_LOG(wglMakeCurrent);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglRealizeLayerPalette (HDC a, int b, BOOL c)
{
  DUMMY_LOG(wglRealizeLayerPalette);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
int WGLAPIENTRY DummywglSetLayerPaletteEntries (HDC a, int b, int c, int d, CONST COLORREF *e)
{
  DUMMY_LOG(wglSetLayerPaletteEntries);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglSetPixelFormat (HDC a, int b, CONST PIXELFORMATDESCRIPTOR *c)
{
  DUMMY_LOG(wglSetPixelFormat);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglShareLists (HGLRC a, HGLRC b)
{
  DUMMY_LOG(wglShareLists);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglSwapBuffers (HDC a)
{
  DUMMY_LOG(wglSwapBuffers);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglSwapLayerBuffers (HDC a, UINT b)
{
  DUMMY_LOG(wglSwapLayerBuffers);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglUseFontBitmapsA (HDC a, DWORD b, DWORD c, DWORD d)
{
  DUMMY_LOG(wglUseFontBitmapsA);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglUseFontBitmapsW (HDC a, DWORD b, DWORD c, DWORD d)
{
  DUMMY_LOG(wglUseFontBitmapsW);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglUseFontOutlinesA (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h)
{
  DUMMY_LOG(wglUseFontOutlinesA);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
BOOL WGLAPIENTRY DummywglUseFontOutlinesW (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h)
{
  DUMMY_LOG(wglUseFontOutlinesW);
  return 0;
}

//Init the function table with stubs
WGLDriver GLW=
{
  DummywglChoosePixelFormat,
  DummywglCopyContext,
  DummywglCreateContext,
  DummywglCreateLayerContext,
  DummywglDeleteContext,
  DummywglDescribeLayerPlane,
  DummywglDescribePixelFormat,
  DummywglGetCurrentContext,
  DummywglGetCurrentDC,
  DummywglGetDefaultProcAddress,
  DummywglGetLayerPaletteEntries,
  DummywglGetPixelFormat,
  DummywglGetProcAddress,
  DummywglMakeCurrent,
  DummywglRealizeLayerPalette,
  DummywglSetLayerPaletteEntries,
  DummywglSetPixelFormat,
  DummywglShareLists,
  DummywglSwapBuffers,
  DummywglSwapLayerBuffers,
  DummywglUseFontBitmapsA,
  DummywglUseFontBitmapsW,
  DummywglUseFontOutlinesA,
  DummywglUseFontOutlinesW,
};



