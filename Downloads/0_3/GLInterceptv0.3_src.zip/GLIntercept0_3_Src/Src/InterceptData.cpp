/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptData.h"
#include "FileUtils.h"
#include "GLDriver.h"



USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
InterceptData::InterceptData(GLDriver *ogldriver):
driver(ogldriver),
dataSavingEnabled(false),
dataSavePath(""),
dataSavePathCreated(false)
{
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptData::~InterceptData()
{
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptData::SetDataSavingPath(const string &newPath)
{
  //Assign the new path as the current save path
  dataSavePath = newPath;

  //Flag the the directory needs creation if it is requested
  dataSavePathCreated = false;
}

///////////////////////////////////////////////////////////////////////////////
//
const string & InterceptData::GetDataSavingPath() 
{
  //iF the current path has not been created, attempt to create it
  if(!dataSavePathCreated)
  {
    //Create the new data logging directory
    if(!FileUtils::CreateFullDirectory(dataSavePath.c_str()))
    {
      LOGERR(("InterceptData::GetDataSavingPath - Unable to create directory %s ",dataSavePath.c_str())); 

      //If could not create the new directory, just use the current directory
      dataSavePath = "";
    }

    //Flag that the directory was (or attemped to be) created
    dataSavePathCreated = true;
  }

  return dataSavePath;
}
