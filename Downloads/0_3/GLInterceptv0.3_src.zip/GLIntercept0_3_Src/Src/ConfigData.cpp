/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "ConfigData.h"
#include "ConfigParser.h"
#include "FileUtils.h"
#include "InputUtils.h"

extern string dllPath;

USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
ConfigData::ConfigData():
logEnabled(false),
logXMLFormat(false),

logXSLFile(""),
logXSLBaseDir(""),

errorGetOpenGLChecks(false),
errorThreadChecking(false),
errorBreakOnError(true),
errorLogOnError(true),
errorExtendedLogError(false),
errorDebuggerErrorLog(true),

logPath(""),
logName("gliInterceptLog"),
functionDataFileName("gliIncludes.h"),

logPerFrame(false),
logOneFrameOnly(true),

imageLogEnabled(false),
imageRenderCallStateLog(true),
imageSaveIcon(true),
imageIconSize(32),
imageSavePNG(true),
imageSaveTGA(false),
imageSaveJPG(false),
imageFlipXAxis(false),
imageCubeMapTile(true),

imageSave1D(true),
imageSave2D(true),
imageSave3D(true),
imageSaveCube(true),
imageSavePBufferTex(true),

shaderLogEnabled(false),
shaderRenderCallStateLog(true),
shaderAttachLogState(true),
shaderValidatePreRender(false),
shaderLogUniformsPreRender(false),

displayListLogEnabled(false),

frameLogEnabled(false),
frameImageFormat("jpg"),
framePreColorSave(false),
framePostColorSave(false),
frameDiffColorSave(false),

framePreDepthSave(false),
framePostDepthSave(false),
frameDiffDepthSave(false),

framePreStencilSave(false),
framePostStencilSave(false),
frameDiffStencilSave(false),

timerLogEnabled(false),
timerLogCutOff(1)
{

  //Construct the path to the OpenGL filename
  char DefaultGLLibName[MAX_PATH];

  //Get the default library name
  GetSystemDirectory(DefaultGLLibName, MAX_PATH);

  //Assign the name
  openGLFileName = string(DefaultGLLibName) + FileUtils::dirSeparator + string("opengl32.dll");
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadConfigData()
{
  //Parse the config files
  ConfigParser parser;
  
  //If parsing was successful, add the data to the function table
  if(!parser.Parse(dllPath + "gliConfig.ini"))
  {
    LOGERR(("ConfigData::ReadConfigData - Unable to read config data file - %sgliConfig.ini",dllPath.c_str()));
    return;
  }

  const ConfigToken *testToken;

  //Get if the log is enabled
  testToken = parser.GetToken("LogEnabled");
  if(testToken)
  {
    testToken->Get(logEnabled);
  }

  //Get if the logging is per-frame or not
  const ConfigToken *perFrameToken = parser.GetToken("LogPerFrame");
  if(perFrameToken)
  {
    //Get if per frame logging is enabled
    testToken = perFrameToken->GetChildToken("Enabled");
    if(testToken)
    {
      testToken->Get(logPerFrame);
    }

    //Get if per-frame logging is forced to one frame at a time
    testToken = perFrameToken->GetChildToken("OneFrameOnly");
    if(testToken)
    {
      testToken->Get(logOneFrameOnly);
    }

    //Get the key codes
    testToken = perFrameToken->GetChildToken("FrameStartKeys");
    if(testToken)
    {
      //Loop for the number of values in the token
      for(uint i=0;i<testToken->GetNumValues();i++)
      {
        string value;
        testToken->Get(value,i);

        //Get the key code of the string
        uint newValue = InputUtils::GetKeyCode(value);
        if(newValue != 0)
        {
          //Add the value to the array
          logFrameKeys.push_back(newValue);
        }
      }       
    }
  }

  //Get the log path
  testToken = parser.GetToken("LogPath");
  if(testToken)
  {
    testToken->Get(logPath);

    if(logPath.size() == 0)
    {
      //Assign the dll path as the log path
      logPath = dllPath;
    }
    //If no trailing slash is provided, add one
    //  (Perhaps check that it is a valid path?)
    else if(logPath[logPath.size()-1] != '\\' &&
            logPath[logPath.size()-1] != '/')
    {
      logPath = logPath + FileUtils::dirSeparator;
    }
  }
  else
  {
    //Assign the dll path as the log path
    logPath = dllPath;
  }

  //Get if the format is XML or not
  testToken = parser.GetToken("LogFormat");
  if(testToken)
  { 
    //Get an test the string for XML format
    string value;
    if(testToken->Get(value))
    {
      if(value == "XML" || value == "xml")
      {
        logXMLFormat = true;
      }
    }
  }

  //Get the XML format data
  const ConfigToken *xmlFormatToken = parser.GetToken("XMLFormat");
  if(xmlFormatToken)
  {
    //Get the XSL file
    testToken = xmlFormatToken->GetChildToken("XSLFile");
    if(testToken)
    { 
      testToken->Get(logXSLFile);
    }

    //Get the base directory
    testToken = xmlFormatToken->GetChildToken("BaseDir");
    if(testToken)
    { 
      testToken->Get(logXSLBaseDir);

      //Add a trailing seperator
      if(logXSLBaseDir.size() > 0 &&
         logXSLBaseDir[logXSLBaseDir.size()-1] != '\\' &&
         logXSLBaseDir[logXSLBaseDir.size()-1] != '/')
      {
        logXSLBaseDir = logXSLBaseDir + FileUtils::dirSeparator;
      }
    }
  }

  //Determine if we issue error check calls
  testToken = parser.GetToken("GLErrorChecking");
  if(testToken)
  {
    testToken->Get(errorGetOpenGLChecks);
  }

  //Determine if thread checking is performed
  testToken = parser.GetToken("ThreadChecking");
  if(testToken)
  {
    testToken->Get(errorThreadChecking);
  }

  //Determine if we break on errors
  testToken = parser.GetToken("BreakOnError");
  if(testToken)
  {
    testToken->Get(errorBreakOnError);
  }

  //Determine if we log on OpenGL error
  testToken = parser.GetToken("LogOnError");
  if(testToken)
  {
    testToken->Get(errorLogOnError);
  }

  //Get if there is extened error log reporting
  testToken = parser.GetToken("ExtendedErrorLog");
  if(testToken)
  {
    testToken->Get(errorExtendedLogError);
  }
  

  //Determine if we mirror the error log to the debug window
  testToken = parser.GetToken("DebuggerErrorLog");
  if(testToken)
  {
    testToken->Get(errorDebuggerErrorLog);
  }

  //Get the log file name
  testToken = parser.GetToken("LogFileName");
  if(testToken)
  { 
    testToken->Get(logName);
  }

  //Get the OpenGL function defines
  testToken = parser.GetToken("GLFunctionDefines");
  if(testToken)
  { 
    testToken->Get(functionDataFileName);
  }

  //Get the OpenGL system library
  testToken = parser.GetToken("GLSystemLib");
  if(testToken)
  { 
    testToken->Get(openGLFileName);
  }

  //Read in the image data
  ReadImageConfigData(parser);

  //Read the shader data
  ReadShaderConfigData(parser);

  //Read the display list data
  ReadDisplayListConfigData(parser);
  
  //Read the frame log data
  ReadFrameConfigData(parser);

  //Read the timer options
  ReadTimerConfigData(parser);

  //Log all unused tokens
  parser.LogUnusedTokens();
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadImageConfigData(ConfigParser &parser)
{
  //Get if the outer log section
  const ConfigToken * imgToken = parser.GetToken("ImageLog");
  if(!imgToken)
  {
    return;
  }
  const ConfigToken *imgTestToken;

  //Get if the log is enabled
  imgTestToken = imgToken->GetChildToken("LogEnabled");
  if(imgTestToken)
  { 
    imgTestToken->Get(imageLogEnabled);
  }

  //Get if we log the state on render calls 
  imgTestToken = imgToken->GetChildToken("RenderCallStateLog");
  if(imgTestToken)
  { 
    imgTestToken->Get(imageRenderCallStateLog);
  }

  //Get if icon image saving is enabled
  const ConfigToken *imgIconToken = imgToken->GetChildToken("ImageIcon");
  if(imgIconToken)
  {
    //Get if icon saving is enabled
    imgTestToken = imgIconToken->GetChildToken("Enabled");
    if(imgTestToken)
    {
      imgTestToken->Get(imageSaveIcon);
    }

    //Get the size of the icon image
    imgTestToken = imgIconToken->GetChildToken("Size");
    if(imgTestToken)
    {
      imgTestToken->Get(imageIconSize);
    }
  }

  //Get the save formats
  imgTestToken = imgToken->GetChildToken("SaveFormats");
  if(imgTestToken)
  { 
    //Reset all save formats
    imageSavePNG  = false;
    imageSaveTGA  = false;
    imageSaveJPG  = false;

    //Loop for the number of values in the token
    for(uint i=0;i<imgTestToken->GetNumValues();i++)
    {
      string value;
      imgTestToken->Get(value,i);

      if(value == "PNG")
      {
        imageSavePNG = true;
      }
      else if(value == "TGA")
      {
        imageSaveTGA = true;
      }
      else if(value == "JPG")
      {
        imageSaveJPG = true;
      }
      else
      {
        LOGERR(("ConfigData::ReadImageConfigData - Unknown texture save format %s",value.c_str()));
      }
    }
  }

  //Get the flip X axis 
  imgTestToken = imgToken->GetChildToken("FlipXAxis");
  if(imgTestToken)
  { 
    imgTestToken->Get(imageFlipXAxis);
  }

  //Get the cube map tile property 
  imgTestToken = imgToken->GetChildToken("TileCubeMaps");
  if(imgTestToken)
  { 
    imgTestToken->Get(imageCubeMapTile);
  }

  //Get the GL texture saveing formats
  imgTestToken = imgToken->GetChildToken("SaveGLTypes");
  if(imgTestToken)
  { 
    //Reset all save formats
    imageSave1D  = false;
    imageSave2D  = false;
    imageSave3D  = false;
    imageSaveCube= false;

    //Loop for the number of values in the token
    for(uint i=0;i<imgTestToken->GetNumValues();i++)
    {
      string value;
      imgTestToken->Get(value,i);

      if(value == "1D")
      {
        imageSave1D = true;
      }
      else if(value == "2D")
      {
        imageSave2D = true;
      }
      else if(value == "3D")
      {
        imageSave3D = true;
      }
      else if(value == "CUBE")
      {
        imageSaveCube = true;
      }
      else
      {
        LOGERR(("ConfigData::ReadImageConfigData - Unknown GL texture format %s",value.c_str()));
      }
    }
  }

  //Get the p-buffer save property
  imgTestToken = imgToken->GetChildToken("SavePbufferTex");
  if(imgTestToken)
  { 
    imgTestToken->Get(imageSavePBufferTex);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadShaderConfigData(ConfigParser &parser)
{
  //Get the outer log section
  const ConfigToken * shaderToken = parser.GetToken("ShaderLog");
  if(!shaderToken)
  {
    return;
  }
  const ConfigToken *shaderTestToken;

  //Get if the log is enabled
  shaderTestToken = shaderToken->GetChildToken("LogEnabled");
  if(shaderTestToken)
  { 
    shaderTestToken->Get(shaderLogEnabled);
  }

  //Get if we log the state on render calls 
  shaderTestToken = shaderToken->GetChildToken("RenderCallStateLog");
  if(shaderTestToken)
  { 
    shaderTestToken->Get(shaderRenderCallStateLog);
  }

  //Get if we append log info 
  shaderTestToken = shaderToken->GetChildToken("AttachLogState");
  if(shaderTestToken)
  { 
    shaderTestToken->Get(shaderAttachLogState);
  }

  //Get if we validate the shaders
  shaderTestToken = shaderToken->GetChildToken("ValidatePreRender");
  if(shaderTestToken)
  { 
    shaderTestToken->Get(shaderValidatePreRender);
  }

  //Get if we log uniforms
  shaderTestToken = shaderToken->GetChildToken("UniformLogPreRender");
  if(shaderTestToken)
  { 
    shaderTestToken->Get(shaderLogUniformsPreRender);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadDisplayListConfigData(ConfigParser &parser)
{
  //Get the outer log section
  const ConfigToken * listToken = parser.GetToken("DisplayListLog");
  if(!listToken)
  {
    return;
  }
  const ConfigToken *listTestToken;

  //Get if the log is enabled
  listTestToken = listToken->GetChildToken("LogEnabled");
  if(listTestToken)
  { 
    listTestToken->Get(displayListLogEnabled);
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadFrameConfigData(ConfigParser &parser)
{
  //Get if the outer log section
  const ConfigToken * frameLogToken = parser.GetToken("FrameLog");
  if(!frameLogToken)
  {
    return;
  }
  
  const ConfigToken *frameTestToken;

  //Get if the log is enabled
  frameTestToken = frameLogToken->GetChildToken("LogEnabled");
  if(frameTestToken)
  { 
    frameTestToken->Get(frameLogEnabled);
  }

  //Get the save format
  frameImageFormat = "jpg";
  frameTestToken = frameLogToken->GetChildToken("SaveFormat");
  if(frameTestToken)
  { 
    string value;
    frameTestToken->Get(value);

    if(value == "PNG")
    {
      frameImageFormat = "png";
    }
    else if(value == "TGA")
    {
      frameImageFormat = "tga";
    }
    else if(value == "JPG")
    {
      frameImageFormat = "jpg";
    }
    else
    {
      LOGERR(("ConfigData::ReadFrameConfigData - Unknown image save format %s",value.c_str()));
    }
  }

  //Get the pre/post color options
  frameTestToken = frameLogToken->GetChildToken("ColorBufferLog");
  if(frameTestToken)
  { 
    ReadFramePrePostOptions(frameTestToken,framePreColorSave,framePostColorSave, frameDiffColorSave);
  }


  //Get the pre/post depth options
  frameTestToken = frameLogToken->GetChildToken("DepthBufferLog");
  if(frameTestToken)
  { 
    ReadFramePrePostOptions(frameTestToken,framePreDepthSave,framePostDepthSave, frameDiffDepthSave);
  }

  //Get the pre/post stencil options
  frameTestToken = frameLogToken->GetChildToken("StencilBufferLog");
  if(frameTestToken)
  { 
    ReadFramePrePostOptions(frameTestToken,framePreStencilSave,framePostStencilSave, frameDiffStencilSave);
  }

  frameTestToken = frameLogToken->GetChildToken("StencilColors");
  if(frameTestToken)
  {
    //Test for the correct number of colors
    if(frameTestToken->GetNumValues() % 2 == 1)
    {
      LOGERR(("ConfigData::ReadFrameConfigData - Uneven number of stencil colors"));
    }
    else
    {
      int currValue =-1;
      int retIndex;
      uint retColor;

      //Loop for all the value pairs
      for(uint i=0;i<frameTestToken->GetNumValues();i+=2)
      {
        //Get the index/color pair
        if(!frameTestToken->Get(retIndex,i) ||
           !frameTestToken->Get(retColor,i+1))
        {
          LOGERR(("ConfigData::ReadFrameConfigData - Error retrieving stencil color value/index"));
          frameStencilColors.empty();
          break;
        }

        //Check that the index data is sorted
        if(retIndex <= currValue)
        {
          LOGERR(("ConfigData::ReadFrameConfigData - Unsorted array of stencil colors"));
          frameStencilColors.empty();
          break;
        }
        
        //Check bounds
        if(retIndex > 255)
        {
          LOGERR(("ConfigData::ReadFrameConfigData - Stencil index is too large: %d",retIndex));
          frameStencilColors.empty();
          break;
        }
        currValue = retIndex;

        //Add the pair to the return array
        frameStencilColors.push_back(retIndex);
        frameStencilColors.push_back(retColor);
      }
    }
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadFramePrePostOptions(const ConfigToken *frameTestToken, bool &preToken, bool &postToken, bool &diffToken) const
{
  preToken = false;
  postToken= false;
  diffToken= false;

  //Loop for the number of values in the token
  for(uint i=0;i<frameTestToken->GetNumValues();i++)
  {
    string value;
    frameTestToken->Get(value,i);

    if(value == "pre")
    {
      preToken = true;
    }
    else if(value == "post")
    {
      postToken = true;
    }
    else if(value == "diff")
    {
      diffToken = true;
    }
    else
    {
      LOGERR(("ConfigData::ReadFramePrePostOptions - Unknown frame save option %s",value.c_str()));
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigData::ReadTimerConfigData(ConfigParser &parser)
{
  //Get if the outer log section
  const ConfigToken * timerToken = parser.GetToken("TimerLog");
  if(!timerToken)
  {
    return;
  }
  const ConfigToken *timerTestToken;

  //Get if the log is enabled
  timerTestToken = timerToken->GetChildToken("LogEnabled");
  if(timerTestToken)
  { 
    timerTestToken->Get(timerLogEnabled);
  }

  //Get if we log the state on render calls 
  timerTestToken = timerToken->GetChildToken("LogCutoff");
  if(timerTestToken)
  { 
    timerTestToken->Get(timerLogCutOff);
  }


}

