/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __CONFIG_DATA_H_
#define __CONFIG_DATA_H_

#include "GLInterceptConfig.h"
#include "gl.h"

#include <string>
#include <vector>

using namespace std;

class ConfigParser;
class ConfigToken;

//@
//  Summary:
//    This structure holds all the configuration data used by the GLDriver
//    and associated classes.
//  
class ConfigData
{
public:

  //@
  //  Summary:
  //    Constructor. Inits all config data to default values.
  //  
  ConfigData();

  //@
  //  Summary:
  //    To read the config data values from a configuration file.
  //  
  void ReadConfigData();

  bool logEnabled;                                // Flag to indicate if logging is enabled
  bool logXMLFormat;                              // If true use XML to log, else use plain text.

  string logXSLFile;                              // The XSL file to use when XML logging is enabled
  string logXSLBaseDir;                           // The base directory where the XSL file is located

  bool errorGetOpenGLChecks;                      // Flag to indicate if errors are checked for
  bool errorThreadChecking;                       // Flag to indicate if thread checking is performed.
  bool errorBreakOnError;                         // Flag to indicate if to break on an error
  bool errorLogOnError;                           // Flag to indicate if log OpenGL errors
  bool errorExtendedLogError;                     // Flag to indicate if extended data about an error is reported
  bool errorDebuggerErrorLog;                     // Flag to indicate if the error log is mirrored to the debugger

  bool logPerFrame;                               // Flag to indicate if we log per-frame or by the entire application
  bool logOneFrameOnly;                           // Flag to indicate if per-frame logging will only get one frame at a time
  vector<uint> logFrameKeys;                      // The key codes used to enable per-frame logging

  string logPath;                                 // The path to write the log files (including trailing seperator)
  string logName;                                 // The name of the log to write out (without extension)
  string functionDataFileName;                    // The name of the file/path to find the function config data
  string openGLFileName;                          // The full path to where the "real" opengl driver is

  bool imageLogEnabled;                           // Flag to indicate if the image log is enabled
  bool imageRenderCallStateLog;                   // Flag to indicate if the image state is recorded on render calls
  bool imageSaveIcon;                             // Save a icon version of the images 
  uint imageIconSize;                             // The size of the icon if saving icons
  bool imageSavePNG;                              // Save the images in PNG format
  bool imageSaveTGA;                              // Save the images in TGA format
  bool imageSaveJPG;                              // Save the images in JPG format
  bool imageFlipXAxis;                            // Flip the images on the X axis before writting out
  bool imageCubeMapTile;                          // Flag to indicate if cube maps are tiled together or saved as six images 

  bool imageSave1D;                               // Flag to indicate if 1D textures are saved
  bool imageSave2D;                               // Flag to indicate if 2D textures are saved (includes rect images)
  bool imageSave3D;                               // Flag to indicate if 3D textures are saved
  bool imageSaveCube;                             // Flag to indicate if Cube textures are saved
  bool imageSavePBufferTex;                       // Flag to indicate if textures that are bound to p-buffers are saved

  bool shaderLogEnabled;                          // Flag to indicate if the shader log is enabled
  bool shaderRenderCallStateLog;                  // Flag to indicate if the shader state is recorded on render calls
  bool shaderAttachLogState;                      // Flag to indicate if the shader log data is to be written.
  bool shaderValidatePreRender;                   // Flag to indicate if the shader is validated before each render.
  bool shaderLogUniformsPreRender;                // Flag to indicate if the shader is to log the uniforms before each render.

  bool displayListLogEnabled;                     // Flag to indicate if the display list log is enabled


  bool frameLogEnabled;                           // Flag to indicate if the frame log is enabled
  string frameImageFormat;                        // The format to save frame images in.
  bool framePreColorSave;                         // Save pre-color frame images
  bool framePostColorSave;                        // Save post-color frame images
  bool frameDiffColorSave;                        // Save diff-color frame images

  bool framePreDepthSave;                         // Save pre-depth frame images
  bool framePostDepthSave;                        // Save post-depth frame images
  bool frameDiffDepthSave;                        // Save diff-depth frame images

  bool framePreStencilSave;                       // Save pre-stencil frame images
  bool framePostStencilSave;                      // Save post-stencil frame images
  bool frameDiffStencilSave;                      // Save diff-stencil frame images
  vector<uint> frameStencilColors;                // The stencil color values to use when logging a stancil frame

  bool timerLogEnabled;                           // Flag to indicate if the timer log is enabled
  uint timerLogCutOff;                            // The cutoff value for the timer log.

protected:

  //@
  //  Summary:
  //    To read the image config property values.
  //  
  void ReadImageConfigData(ConfigParser &parser);

  //@
  //  Summary:
  //    To read the shader config property values.
  //  
  void ReadShaderConfigData(ConfigParser &parser);


  //@
  //  Summary:
  //    To read the display list config property values.
  //  
  void ReadDisplayListConfigData(ConfigParser &parser);

  //@
  //  Summary:
  //    To read the frame buffer logger config property values.
  //  
  void ReadFrameConfigData(ConfigParser &parser);

  //@
  //  Summary:
  //    To read the pre/post/diff options from a frame logger option.
  //  
  //  Parameters:
  //    frameTestToken  - The frame logger option for the token to test.
  //
  //    preToken - The returned pre value.
  //
  //    postToken - The returned post value.
  //
  //    diffToken - The returned diff value.
  //
  void ReadFramePrePostOptions(const ConfigToken *frameTestToken, bool &preToken, bool &postToken, bool &diffToken) const;

  //@
  //  Summary:
  //    To read the timer logger config property values.
  //  
  void ReadTimerConfigData(ConfigParser &parser);

};



#endif // __CONFIG_DATA_H_
