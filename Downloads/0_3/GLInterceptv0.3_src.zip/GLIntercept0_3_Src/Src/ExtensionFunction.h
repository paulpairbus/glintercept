/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __EXTENSION_FUNCTION_H__
#define __EXTENSION_FUNCTION_H__

#include "GLInterceptConfig.h"
#include "FunctionTable.h"
#include <string>

using namespace std;

//@
//  Summary:
//    This class wraps and stores extension functions that have been loaded
//    via OpenGL. The functions wrapping is not currently thread safe and is
//    platform dependant.
//  
class ExtensionFunction  
{
public:

  //@
  //  Summary:
  //    Constructor
  //  
  //  Parameters:
  //    functionTable  - The function table where all extension functions 
  //                     are registered. Must be valid for the duration of 
  //                     this class.
  //
  ExtensionFunction(FunctionTable * functionTable);
  virtual ~ExtensionFunction();

  //@
  //  Summary:
  //    Adds a new function of the spacified name and pointer.
  //    (The passed function is wrapped and a new pointer is returned)
  //  
  //  Parameters: 
  //    funcName  - The name of the function to add.
  //
  //    functionPtr - The function pointer.
  //
  //  Returns:
  //    Returns the function pointer to be used when calling the function 
  //    (instead of the passed function pointer)
  //
  void * AddFunction(const string & funcName,void * functionPtr);

protected:

  uint            currExtensionIndex;             //The index of the next extension to be added
  FunctionTable * functionTable;                  //The current function table pointer
};

#endif // __EXTENSION_FUNCTION_H__
