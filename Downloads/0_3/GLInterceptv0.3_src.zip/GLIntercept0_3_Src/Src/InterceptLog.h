/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __INTERCEPT_LOG_H_
#define __INTERCEPT_LOG_H_

#include "GLInterceptConfig.h"
#include <string>
#include "FunctionData.h"
#include "FunctionTable.h"

using namespace std;

//@
//  Summary:
//    This class is a base class for logging OpenGL functions.
//  
class InterceptLog 
{
public:

  //@
  //  Summary:
  //    Constructor to set up the function table.
  //  
  //  Parameters:
  //    functionTable - The table of all functions that are known/are being logged.
  //
  InterceptLog(FunctionTable * functionTable);

  //@
  //  Summary:
  //    Destructor, closes the log.
  //  
  virtual ~InterceptLog();

  //@
  //  Summary:
  //    To perform initialization. 
  //
  //  Returns:
  //    True is returned on init success, false if not.
  //
  virtual bool Init();

  //@
  //  Summary:
  //    To get the passed function and function data in a plain string format.
  //    (ie. returned string is in the format <function_name>(<parameters>,....) )
  //  
  //  Note:
  //    The return value is not included in the string. (as it is not available)
  //
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  //    retString- The string to return the function and parameters in.
  //
  void GetFunctionString(const FunctionData *funcData,uint index, va_list args, string &retString);

  //@
  //  Summary:
  //    To convert a error return value into its string representation.
  //  
  //  Parameters:
  //    errorCode - The error value to convert.
  //
  //    retString - The return string containing a string representation of the error code.
  //
  void GetErrorStringValue(uint errorCode, string &retString);

  //@
  //  Summary:
  //    To log the passed function and function data 
  //    (Before the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  inline virtual void LogFunctionPre(const FunctionData *funcData,uint index, va_list args);

  //@
  //  Summary:
  //    To perform any post-call logging of a function.
  //    (After the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - Pointer to the return value (if any).
  //
  inline virtual void LogFunctionPost(const FunctionData *funcData,uint index, void * retVal);

  //@
  //  Summary:
  //    To log that a GL error has occured to the log.
  //  
  //  Parameters:
  //    errorCode - The GL error code to log.
  //
  inline virtual void LogFunctionError(uint errorCode);

  //@
  //  Summary:
  //    To log that the current function has completed. 
  //    (ie. All data for the previous function has been processed)
  //  
  inline virtual void LogFunctionComplete();

  //@
  //  Summary:
  //    To enable/disbale the log
  //  
  //  Parameters:
  //    enable  - Flag to enable and disable the log
  //
  inline void SetLogEnabled(bool enable);


protected:

  bool   logEnabled;                              // Flag to indicate if the log is enabled or not
  const FunctionTable * functionTable;            // The function table to log functions from

  //@
  //  Summary:
  //    To convert the passed data as a string.
  //  
  //  Parameters:
  //    data  - A pointer to the parameter.
  //
  //    isPointer - Flag to indicate if the value is a pointer
  //
  //    paramData  - A pointer to the current parameter data being processed.
  //
  //  Returns:
  //    A string version of the passed value is returned.
  //
  string ConvertParam(void *data, bool isPointer,const ParameterData *paramData);

  //@
  //  Summary:
  //    If the type of the parameter is custom (ie. non-standard OpenGL)
  //    calling this method will attempt to handle the type.
  //  
  //  Parameters:
  //    data  - A pointer to the parameter.
  //
  //    isPointer - Flag to indicate if the value is a pointer
  //
  //    paramData  - A pointer to the current parameter data being processed.
  //
  //    retString  - If the data is handled, the data for the type is returned in the string.
  //
  //  Returns:
  //    If the parameter was converted, true is returned and the data is stored in retString.
  //    Else false is returned and retString is unchanged.
  //
  virtual bool ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString);

  //@
  //  Summary:
  //    To get a pointer to the next value.
  //  
  //  Parameters:
  //    pType - The type of the parameter.
  //
  //    args  - The current arguments array
  //
  //    isPointer - Flag to indicate if the value is a pointer
  //
  //    value  - Pointer to the return value.
  //
  //  Returns:
  //    Returns true if the value was retrieved, false if not.
  //
  bool GetNextValue(ParameterType pType, va_list *args, bool isPointer,void **value);

  //@
  //  Summary:
  //    To get a pointer to the next value in the passed array. Array value is also moved.
  //  
  //  Parameters:
  //    pType - The type of the parameter.
  //
  //    array  - The current array
  //
  //    isPointer - Flag to indicate if the value is a pointer
  //
  //    value  - Pointer to the return value.
  //
  //  Returns:
  //    Returns true if the value was retrieved, false if not.
  //
  bool GetNextArrayValue(ParameterType pType, void **array, bool isPointer,void **value);

private:

  const FunctionData  * glGetErrorFuncData;       // A pointer into the function table, for the glGetError() function.
};


///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptLog::SetLogEnabled(bool enable)
{
  logEnabled = enable;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptLog::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptLog::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptLog::LogFunctionError(uint errorCode)
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptLog::LogFunctionComplete()
{

}



#endif // !__INTERCEPT_LOG_H_
