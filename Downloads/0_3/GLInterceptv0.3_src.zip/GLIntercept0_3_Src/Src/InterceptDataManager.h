/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __INTERCEPT_DATA_MANAGER_H_
#define __INTERCEPT_DATA_MANAGER_H_

#include "GLInterceptConfig.h"
#include "gl.h"
#include "FunctionTable.h"

#include <string>
#include <vector>

using namespace std;

USING_ERRORLOG

class GLDriver;

#define TEMPLATE    template <class T>
#define QUAL        InterceptDataManager<T>



//@
//  Summary:
//    Structure of data about a OpenGL data type
//  
class InterceptDataType
{
public:

  //@
  //  Summary:
  //    Constructor, inits all data to default values.
  //
  //  Parameters:
  //    glID  - The unique OpenGL ID of this type.
  // 
  inline InterceptDataType(uint glID);

  //@
  //  Summary:
  //    Destructor
  //  
  inline virtual ~InterceptDataType();

  //@
  //  Summary:
  //    To return true if the data is dirty. 
  //    (ie. has changed since last save)
  //  
  inline bool IsDirty() const;

  //@
  //  Summary:
  //    To return true if the data is ready to be saved. 
  //    (ie. has been initilized with some data)
  //  
  inline bool IsReady() const;

  //@
  //  Summary:
  //    To get the OpenGL data ID of this list. Ensure the data 
  //    is ready (IsReady()) before calling. 
  //  
  //  Returns:
  //    The OpenGL data ID assigned to this data type is returned.
  //
  inline uint GetGLID() const;


protected:

  uint   id;         // The OpenGL ID

  bool   ready;      // Flag to indicate if the data is ready (ie. has been uploaded)  
  bool   dirty;      // Flag to indicate if the data is dirty 

};

///////////////////////////////////////////////////////////////////////////////
//
inline InterceptDataType::InterceptDataType(uint glID):
id(glID),
ready(false),
dirty(false)
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline InterceptDataType::~InterceptDataType()
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline uint InterceptDataType::GetGLID() const
{
  return id;
}


///////////////////////////////////////////////////////////////////////////////
//
inline bool InterceptDataType::IsDirty() const
{
  return dirty;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool InterceptDataType::IsReady() const
{
  return ready;
}




//@
//  Summary:
//    This class template maintains a list data and controls 
//    adding/deleting and retrival of the data.
//
//    The "T" type is the type of data to track. 
//  
template <class T>
class InterceptDataManager
{
public:

  //@
  //  Summary:
  //    Constructor, inits all data to default values.
  //  
	InterceptDataManager();

  //@
  //  Summary:
  //    Destructor, destroys all array data and reports any leaks.
  //  
  virtual ~InterceptDataManager();

  //@
  //  Summary:
  //    To get all the data that have been flagged as valid,ready and dirty. 
  //  
  //  Parameters:
  //    dirtyData  -  The array to return all the dirty data in.
  //
  void GetAllDirtyData(vector<T *> &dirtyData);
 
  //@
  //  Summary:
  //    To set all the data that is currently being tracked, as 
  //    dirty. (ie. needs saving)
  //  
  void SetAllDataDirty();

  //@
  //  Summary:
  //    To add a new data (OpenGL) ID to the list. The data 
  //    added needs to be set to a "ready" state before it can be used.
  //  
  //  Parameters:
  //    glID  -  The OpenGL data ID of the data to add.
  //
  void AddData(uint glID);

  //@
  //  Summary:
  //    To remove an data instance from the data list.
  //  
  //  Parameters:
  //    glID  -  The OpenGL data ID of the data to remove.
  //
  bool RemoveData(uint glID);

  //@
  //  Summary:
  //    To get the data of the passed OpenGL data ID.
  //  
  //  Parameters:
  //    glID  -  The OpenGL data ID of the data to find.
  //
  //  Returns:
  //    If the data is found, it is returned. Else NULL is returned.
  //
  T * GetData(GLint glID);

  //@
  //  Summary:
  //    To get the data of the passed OpenGL data ID. (const version)
  //  
  //  Parameters:
  //    glID  -  The OpenGL data ID of the data to find.
  //
  //  Returns:
  //    If the data is found, it is returned. Else NULL is returned.
  //
  const T * GetData(GLint glID) const;


protected:

  vector<T> dataArray;                            // Array of data already loaded

  static char * className;                        // String based name of this class instance

};

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
QUAL::InterceptDataManager()
{
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
QUAL::~InterceptDataManager()
{
  //Loop for all data and log all data still active
  for(uint i=0;i<dataArray.size();i++)
  {
    LOGERR(("%sManager::Destructor - OpenGL id %d is still active. (%s Memory leak?)",className,dataArray[i].GetGLID(),className));
  }
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
void QUAL::GetAllDirtyData(vector<T *> &dirtyData) 
{
  //Empty the array
  dirtyData.clear();

  //Loop for all data
  for(uint i=0;i<dataArray.size();i++)
  {
    //If the data is ready and dirty, save it
    if(dataArray[i].IsReady() &&
       dataArray[i].IsDirty())
    { 
      //Add the data to the dirty array
      dirtyData.push_back(&dataArray[i]);
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
void QUAL::AddData(uint glID)
{
  //Check that the ID is not already in use
  T * currData = GetData(glID);

  //Test if there is a existing entry in the array
  if(currData)
  {
    LOGERR(("%sManager::AddData - Existing %s ID %d",className,className,glID));
  }
  else
  {
    //Add a new ID to the array
    T newData(glID);
    dataArray.push_back(newData);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
bool QUAL::RemoveData(uint glID)
{
  //Loop and get the index for the passed id
  for(uint i=0;i<dataArray.size();i++)
  {
    //Test if the ID matches
    if(dataArray[i].GetGLID() == glID)
    { 
      //Erase the item
      dataArray.erase(dataArray.begin() + i);
      return true;
    }
  }

  LOGERR(("%sManager::RemoveData - Attempting to delete unknown %s ID %d",className,className,glID));
  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
T * QUAL::GetData(GLint glID)
{
  //Loop and get the index for the passed id
  for(uint i=0;i<dataArray.size();i++)
  {
    //Test if the ID matches
    if(dataArray[i].GetGLID() == glID)
    { 
      return &dataArray[i];
    }
  }

  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
const T * QUAL::GetData(GLint glID) const
{
  //Loop and get the index for the passed id
  for(uint i=0;i<dataArray.size();i++)
  {
    //Test if the ID matches
    if(dataArray[i].GetGLID() == glID)
    { 
      return &dataArray[i];
    }
  }

  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
TEMPLATE
void QUAL::SetAllDataDirty()
{
  //Loop for all data
  for(uint i=0;i<dataArray.size();i++)
  {
    //If the data is ready set it as dirty
    if(dataArray[i].IsReady())
    {
      dataArray[i].SetDirty(true); 
    }
  }

}

#undef TEMPLATE
#undef QUAL


#endif // __INTERCEPT_DATA_MANAGER_H_
