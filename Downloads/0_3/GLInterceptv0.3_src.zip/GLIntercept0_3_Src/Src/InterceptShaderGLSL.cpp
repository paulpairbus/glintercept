/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptShaderGLSL.h"
#include "FileUtils.h"
#include "GLDriver.h"


USING_ERRORLOG


//Flags to indicate what action to take when we get an
//  shader function
enum ShaderGLSLFunctionAction
{
  GLSLA_UNKNOWN =0,
  
  GLSLA_OBJECT_CREATE,
  GLSLA_OBJECT_DELETE,

  GLSLA_SHADER_SOURCE,
  GLSLA_SHADER_COMPILE,

  GLSLA_OBJECT_ATTACH,
  GLSLA_OBJECT_DETACH,

  GLSLA_LINK_PROGRAM,
  GLSLA_USE_PROGRAM,

  GLSLA_VALIDATE_PROGRAM,

};

enum ShaderGLSLFunctionType
{
  GL_CREATE_SHADER_OBJECT =0,
  GL_CREATE_PROGRAM_OBJECT,
  GL_DELETE_OBJECT,

  GL_SHADER_SOURCE,

  GL_COMPILE_SHADER,
  
  GL_ATTACH_OBJECT,
  GL_DETACH_OBJECT,

  GL_LINK_PROGRAM,

  GL_USE_PROGRAM_OBJECT,

  GL_VALADATE_PROGRAM,
};

// Structure to hold the name of functions that affect the shader state
struct ShaderGLSLLogData
{
  ShaderGLSLLogData(const char * funcName, ShaderGLSLFunctionType funcType, ShaderGLSLFunctionAction newAction);

  string                   functionName;  //The name of the function
  ShaderGLSLFunctionAction action;        //What the function does and what action to take
  ShaderGLSLFunctionType   funcType;      //The type of the function (enum version of name)
  int                      functionIndex; //Index of the function (in the function table, -may be -1 if unknown)

};


//The array of built-in known functions
ShaderGLSLLogData knownShaderFunctions[] = 
{

  //General creation/deletion shaders
  ShaderGLSLLogData("glCreateShaderObject"   ,GL_CREATE_SHADER_OBJECT,GLSLA_OBJECT_CREATE),
  ShaderGLSLLogData("glCreateShaderObjectARB",GL_CREATE_SHADER_OBJECT,GLSLA_OBJECT_CREATE),

  ShaderGLSLLogData("glCreateProgramObject"   ,GL_CREATE_PROGRAM_OBJECT,GLSLA_OBJECT_CREATE),
  ShaderGLSLLogData("glCreateProgramObjectARB",GL_CREATE_PROGRAM_OBJECT,GLSLA_OBJECT_CREATE),

  ShaderGLSLLogData("glDeleteObject"    ,GL_DELETE_OBJECT,GLSLA_OBJECT_DELETE),
  ShaderGLSLLogData("glDeleteObjectARB" ,GL_DELETE_OBJECT,GLSLA_OBJECT_DELETE),

  ShaderGLSLLogData("glShaderSource"    ,GL_SHADER_SOURCE,GLSLA_SHADER_SOURCE),
  ShaderGLSLLogData("glShaderSourceARB" ,GL_SHADER_SOURCE,GLSLA_SHADER_SOURCE),

  ShaderGLSLLogData("glCompileShader"   ,GL_COMPILE_SHADER,GLSLA_SHADER_COMPILE),
  ShaderGLSLLogData("glCompileShaderARB",GL_COMPILE_SHADER,GLSLA_SHADER_COMPILE),

  ShaderGLSLLogData("glAttachObject"    ,GL_ATTACH_OBJECT,GLSLA_OBJECT_ATTACH),  
  ShaderGLSLLogData("glAttachObjectARB" ,GL_ATTACH_OBJECT,GLSLA_OBJECT_ATTACH),  

  ShaderGLSLLogData("glDetachObject"    ,GL_DETACH_OBJECT,GLSLA_OBJECT_DETACH),  
  ShaderGLSLLogData("glDetachObjectARB" ,GL_DETACH_OBJECT,GLSLA_OBJECT_DETACH),  

  ShaderGLSLLogData("glLinkProgram"     ,GL_LINK_PROGRAM,GLSLA_LINK_PROGRAM),  
  ShaderGLSLLogData("glLinkProgramARB"  ,GL_LINK_PROGRAM,GLSLA_LINK_PROGRAM),  

  ShaderGLSLLogData("glUseProgramObject"   ,GL_USE_PROGRAM_OBJECT,GLSLA_USE_PROGRAM),  
  ShaderGLSLLogData("glUseProgramObjectARB",GL_USE_PROGRAM_OBJECT,GLSLA_USE_PROGRAM),  

  ShaderGLSLLogData("glValidateProgram"   ,GL_VALADATE_PROGRAM,GLSLA_VALIDATE_PROGRAM),  
  ShaderGLSLLogData("glValidateProgramARB",GL_VALADATE_PROGRAM,GLSLA_VALIDATE_PROGRAM),  

};



#define NUM_SHADER_LOG_FUNCTIONS sizeof(knownShaderFunctions)/sizeof(ShaderGLSLLogData)


///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLLogData::ShaderGLSLLogData(const char * funcName,ShaderGLSLFunctionType type, ShaderGLSLFunctionAction newAction):
functionName(funcName),
action(newAction),
funcType(type),
functionIndex(-1)
{
}


///////////////////////////////////////////////////////////////////////////////
//
InterceptShaderGLSL::InterceptShaderGLSL(GLDriver *ogldriver,FunctionTable * functionTable,const ConfigData &configData):
InterceptData(ogldriver),
shaderManager(),
shaderSaver(configData),
recordInfoLog(configData.shaderAttachLogState),
validatePreRender(configData.shaderValidatePreRender),
dumpUniformsPreRender(configData.shaderLogUniformsPreRender),

initialized(false),
initFailed(false),
extensionARBShaderObjects(false),

//Initernal variable init
iObjectType(0),
iHandle(0),
iHandleDetach(0),
iglGetObjectParameteriv(NULL),
iglValidateProgram(NULL),
iglGetInfoLog(NULL),
iglGetHandle(NULL),
iglGetActiveUniform(NULL),
iglGetUniformLocation(NULL),
iglGetUniformfv(NULL),
iglGetUniformiv(NULL)
{

  //Compile time assert since a storage class is re-used
  CASSERT(sizeof(uint) == sizeof(GLhandle),GLSL_handles_not_the_same_size_as_unsigned_ints);

  //Register the shader based functions with the function table
  for(uint i=0;i<NUM_SHADER_LOG_FUNCTIONS;i++)
  {
    //Set the flag
    functionTable->SetFunctionFlag(knownShaderFunctions[i].functionName,FDF_SHADER_GLSL_LOG);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptShaderGLSL::~InterceptShaderGLSL()
{
  //Turn off shader saving to flush out-standing shaders
  if(GetDataSaving())
  {
    SetDataSaving(false);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptShaderGLSL::Init()
{
  //Test if we can proceed
  if(!driver || !driver->GetInternalGLCallMode() || initFailed)
  {
    return false;
  }

  //Flag that init has been called
  initialized  = true;


  //Check extension support
  extensionARBShaderObjects   = driver->IsExtensionSupported("GL_ARB_shader_objects");

  //Init function pointers
  // (this can be done as these functions will only be called on valid programs)
  iglGetObjectParameteriv = (void (GLAPIENTRY *)(GLhandle object,GLenum pname,GLint *params))GLW.wglGetProcAddress("glGetObjectParameteriv");
  if(!iglGetObjectParameteriv)
  {
    iglGetObjectParameteriv = (void (GLAPIENTRY *)(GLhandle object,GLenum pname,GLint *params))GLW.wglGetProcAddress("glGetObjectParameterivARB");
  }

  iglGetInfoLog = (void (GLAPIENTRY *)(GLhandle object, GLsizei maxLength, GLsizei *length,GLchar *infoLog))GLW.wglGetProcAddress("glGetInfoLog");
  if(!iglGetInfoLog)
  {
    iglGetInfoLog = (void (GLAPIENTRY *)(GLhandle object, GLsizei maxLength, GLsizei *length,GLchar *infoLog))GLW.wglGetProcAddress("glGetInfoLogARB");
  }

  iglGetHandle = (GLhandle (GLAPIENTRY *) (GLenum pname))GLW.wglGetProcAddress("glGetHandle");
  if(!iglGetHandle)
  {
    iglGetHandle = (GLhandle (GLAPIENTRY *) (GLenum pname))GLW.wglGetProcAddress("glGetHandleARB");
  }

  iglValidateProgram = (void (GLAPIENTRY *) (GLhandle object))GLW.wglGetProcAddress("glValidateProgram");
  if(!iglValidateProgram)
  {
    iglValidateProgram = (void (GLAPIENTRY *) (GLhandle object))GLW.wglGetProcAddress("glValidateProgramARB");
  }

  iglGetActiveUniform = (void (GLAPIENTRY *) (GLhandle program,GLuint GLindex, GLsizei maxLength, GLsizei *length, GLint *size, GLenum *type, GLchar *name))GLW.wglGetProcAddress("glGetActiveUniform");
  if(!iglGetActiveUniform)
  {
    iglGetActiveUniform = (void (GLAPIENTRY *) (GLhandle program,GLuint GLindex, GLsizei maxLength, GLsizei *length, GLint *size, GLenum *type, GLchar *name))GLW.wglGetProcAddress("glGetActiveUniformARB");
  }

  iglGetUniformLocation = (GLint (GLAPIENTRY *) (GLhandle programObj, const GLchar *name))GLW.wglGetProcAddress("glGetUniformLocation");
  if(!iglGetUniformLocation)
  {
    iglGetUniformLocation = (GLint (GLAPIENTRY *) (GLhandle programObj, const GLchar *name))GLW.wglGetProcAddress("glGetUniformLocationARB");
  }

  iglGetUniformfv = (void (GLAPIENTRY *)  (GLhandle programObj, GLint location, GLfloat *params))GLW.wglGetProcAddress("glGetUniformfv");
  if(!iglGetUniformfv)
  {
    iglGetUniformfv = (void (GLAPIENTRY *)  (GLhandle programObj, GLint location, GLfloat *params))GLW.wglGetProcAddress("glGetUniformfvARB");
  }

  iglGetUniformiv = (void (GLAPIENTRY *) (GLhandle programObj, GLint location, GLint *params))GLW.wglGetProcAddress("glGetUniformiv");
  if(!iglGetUniformiv)
  {
    iglGetUniformiv = (void (GLAPIENTRY *) (GLhandle programObj, GLint location, GLint *params))GLW.wglGetProcAddress("glGetUniformivARB");
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptShaderGLSL::DriverAvailable()
{
  //Get the state of the driver
  if(!driver || !driver->GetInternalGLCallMode() || initFailed)
  {
    return false;
  }

  //Test if we have been init
  if(!initialized)
  {
    if(!Init())
    {
      initFailed = true;
      return false;
    }
  }
  
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::SetDataSaving(bool flag)
{
  //Assign the flag by calling the base class
  InterceptData::SetDataSaving(flag);

  //If enabling shader writing, save all currently bound shaders
  if(flag && initialized && DriverAvailable())
  {
    //Get the currently bound program
    GLhandle programID;
    GetBoundProgram(programID);

    //Look it up
    ShaderGLSLData * programData = shaderManager.GetData(programID);
    if(programID == 0 || !programData || programData->GetGLType() != GL_PROGRAM_OBJECT_ARB)
    {
      return;
    }

    //If the program is ready and dirty save it
    if(programData->IsReady() && programData->IsDirty())
    {
      SaveShaderData(programData);
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::SetDataSavingPath(const string &newPath)
{
  //Append the Shaders directory then pass to the base class
  string path = newPath + "Shaders" + FileUtils::dirSeparator;

  //Call base class to set
  InterceptData::SetDataSavingPath(path);
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //Return if GL calls cannot be made 
  if(!DriverAvailable())
  {
    return;
  }

  //If this is a render function and we are doing validation/or dumping uinforms
  //  Update the data and save (if the log is currently saving)
  if(GetDataSaving() && (validatePreRender || dumpUniformsPreRender) && 
     driver->GetCurrentContext() && 
     driver->GetCurrentContext()->IsRenderFuncion(funcData,index,args))
  {
    UpdateLogPreRender(funcData);
  }

  //If this is not an GLSL shader function, return now
  if(!(funcData->functionFlags & FDF_SHADER_GLSL_LOG))
  {
    return;
  }

  //Get the action required for the function
  int actionIndex = GetShaderActionIndex(funcData->functionName,index);
  if(actionIndex == -1)
  {
    return;
  }
  ShaderGLSLFunctionAction action = knownShaderFunctions[actionIndex].action;

  //Perform the action
  switch(action)
  {
    case(GLSLA_OBJECT_CREATE) :
      CreateObjectPre(funcData,index,args,knownShaderFunctions[actionIndex].funcType);
      break;
    case(GLSLA_OBJECT_DELETE) :
      DeleteObjectPre(funcData,index,args);
      break;

    case(GLSLA_SHADER_SOURCE) :
      ShaderSourcePre(funcData,index,args);
      break;
    case(GLSLA_SHADER_COMPILE) :
      CompileShaderPre(funcData,index,args);
      break;

    case(GLSLA_OBJECT_ATTACH) :
      AttachObjectPre(funcData,index,args);
      break;
    case(GLSLA_OBJECT_DETACH) :
      DetachObjectPre(funcData,index,args);
      break;

    case(GLSLA_LINK_PROGRAM) :
      LinkProgramPre(funcData,index,args);
      break;
    case(GLSLA_USE_PROGRAM) :
      UseProgramPre(funcData,index,args);
      break;

    case(GLSLA_VALIDATE_PROGRAM) :
      ValidateProgramPre(funcData,index,args);
      break;
    
    default:
       LOGERR(("InterceptShader::LogFunctionPre - Unknown action"));
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{
  //Return if GL calls cannot be made
  if(!(funcData->functionFlags & FDF_SHADER_GLSL_LOG) || !DriverAvailable())
  {
    return;
  }

  //Get the action required for the function
  int actionIndex = GetShaderActionIndex(funcData->functionName,index);
  if(actionIndex == -1)
  {
    return;
  }
  ShaderGLSLFunctionAction action = knownShaderFunctions[actionIndex].action;

  //Perform the action
  switch(action)
  {
    case(GLSLA_OBJECT_CREATE) :
      CreateObjectPost(funcData,index,retVal);
      break;
    case(GLSLA_OBJECT_DELETE) :
      DeleteObjectPost(funcData,index,retVal);
      break;

    case(GLSLA_SHADER_SOURCE) :
      break;
    case(GLSLA_SHADER_COMPILE) :
      CompileShaderPost(funcData,index,retVal);
      break;

    case(GLSLA_OBJECT_ATTACH) :
      break;
    case(GLSLA_OBJECT_DETACH) :
      DetachObjectPost(funcData,index,retVal);
      break;

    case(GLSLA_LINK_PROGRAM) :
      LinkProgramPost(funcData,index,retVal);
      break;
    case(GLSLA_USE_PROGRAM) :
      break;

    case(GLSLA_VALIDATE_PROGRAM) :
      ValidateProgramPost(funcData,index,retVal);
      break;

    default:
       LOGERR(("InterceptShader::LogFunctionPost - Unknown action"));
  }

}
  

///////////////////////////////////////////////////////////////////////////////
//
int InterceptShaderGLSL::GetShaderActionIndex(const string &functionName, int funcIndex)
{
  uint i;

  //Check the list to find the index 
  for(i=0;i<NUM_SHADER_LOG_FUNCTIONS;i++)
  {
    //If the index is the same, we have mapped this function previously 
    if(knownShaderFunctions[i].functionIndex == funcIndex)
    {
      return i;
    }
  }

  //If this function has not been called previously, find the name and assign the index
  for(i=0;i<NUM_SHADER_LOG_FUNCTIONS;i++)
  {
    //If the name is equal, assign the index
    if(knownShaderFunctions[i].functionName == functionName)
    {
      knownShaderFunctions[i].functionIndex = funcIndex;
      return i;
    }

  }

  //If the function is not found, something has broken with the mapping/registery
  LOGERR(("InterceptShaderGLSL::GetShaderActionIndex - Attempting to log unknown function %s",functionName.c_str()));

  return -1;
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::CreateObjectPre(const FunctionData *funcData,uint index, va_list args,ShaderGLSLFunctionType funcType)
{

  //If the function is a create shader object, get the shader type
  if(funcType == GL_CREATE_SHADER_OBJECT)
  {
    //Get the number of shader ID's created
    iObjectType = va_arg(args, GLenum);
  }
  else if(funcType == GL_CREATE_PROGRAM_OBJECT)
  {
    //If it is a program object, just assign the type
    iObjectType = GL_PROGRAM_OBJECT_ARB;
  }
  else
  {
    //Unknown function type
    LOGERR(("InterceptShaderGLSL::CreateObjectPre - Unknown function?"));
    return;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::CreateObjectPost(const FunctionData *funcData,uint index,void * retVal)
{
  //Check the type
  if(iObjectType != GL_PROGRAM_OBJECT_ARB &&
     iObjectType != GL_VERTEX_SHADER_ARB  && 
     iObjectType != GL_FRAGMENT_SHADER_ARB)
  {
    LOGERR(("InterceptShaderGLSL::CreateObjectPost - Unknown object type 0x%x",iObjectType));
    return;
  }

  //Get the returned handle
  GLhandle newHandle = *((GLhandle*)retVal);

  //Check for an exiting object
  ShaderGLSLData * shaderData = shaderManager.GetData(newHandle);
  if(shaderData)
  {
    LOGERR(("InterceptShaderGLSL::CreateObjectPost - Existing handle ID %u",newHandle));
    return;
  }

  //Create a new shader object
  shaderManager.AddData(newHandle);

  //Get a pointer to the new object
  shaderData = shaderManager.GetData(newHandle);
  if(!shaderData)
  {
    LOGERR(("InterceptShaderGLSL::CreateObjectPost - Unable to create shader ID %u",newHandle));
    return;
  }

  //Assign the object type (assigned as ready where there is some data to save)
  shaderData->SetGLType(iObjectType);
  
  //Reset the flag
  iObjectType = 0;

}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::DeleteObjectPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the handle
  iHandle = va_arg(args, GLhandle);

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::DeleteObjectPost(const FunctionData *funcData,uint funcTableIndex,void * retVal)
{
  //Get the handle and save the data if necessary
  ShaderGLSLData * shaderData = shaderManager.GetData(iHandle);
  if(!shaderData || iHandle == 0)
  {
    LOGERR(("InterceptShaderGLSL::DeleteObjectPost - Unable to find shader ID %u",iHandle));
    return;
  }

  //Save the data if it is ready
  if(shaderData->IsReady() && shaderData->IsDirty())
  {
    //Save the dirty shader before it is deleted
    SaveShaderData(shaderData);
  }

  //If it is a program object, detach all references
  // NOTE: This is not technically accurate as the program objects are not deleted fully until
  //       they are no longer bound in any context, however, keeping tack of program binding states
  //       for all contexts will be difficult for this rare case, so it is not done.
  if(shaderData->GetGLType() == GL_PROGRAM_OBJECT_ARB)
  {
    //Get a copy of the attached objects
    vector<GLhandle> attachArray = shaderData->GetAttachmentArray();

    //Delete the program object
    shaderManager.RemoveData(iHandle);
    shaderData = NULL;

    //Loop for all attachments
    for(uint i=0;i<attachArray.size();i++)
    {
      ShaderGLSLData * attachData = shaderManager.GetData(attachArray[i]);
      if(attachData)
      {
        //Do a detach from the now deleted object
        attachData->DetachObject(iHandle);

        //If the attachment was previously (user) deleted and there are no remaining attachments,
        // Completely delete now
        if(attachData->GetUserDeleted() && attachData->GetAttachmentArray().size() == 0)
        {
          shaderManager.RemoveData(attachArray[i]);
          attachData= NULL;
        }
      }
      else
      {
        LOGERR(("InterceptShaderGLSL::DeleteObjectPre - Unknown attachment %u",attachArray[i]));
      }
    }
  }
  else
  {
    //Delete now if the shader has no attachments
    if(shaderData->GetAttachmentArray().size() == 0)
    {
      shaderManager.RemoveData(iHandle);
      shaderData = NULL;
    }
    else
    {
      //Else just flag as deleted (Cannot delete until all references are detached)
      shaderData->SetUserDeleted();
    }
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::ShaderSourcePre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the handle
  GLhandle srcHandle = va_arg(args, GLhandle);  

  //Get number of strings
  GLsizei numStrings = va_arg(args, GLsizei); 

  //Get the string array
  GLchar **strArray = va_arg(args, GLchar **);  

  //Get the string length array
  GLint * strLengthArray = va_arg(args, GLint *);  

  //Lookup the shader
  ShaderGLSLData * shaderData = shaderManager.GetData(srcHandle);
  if(!shaderData || shaderData->GetGLType() == GL_PROGRAM_OBJECT_ARB ||
      shaderData->GetUserDeleted())
  {
    LOGERR(("InterceptShaderGLSL::ShaderSourcePre - Unable to find shader ID %u",srcHandle));
    return;
  }

  //Check data
  if(numStrings == 0 || strArray == NULL)
  {
    LOGERR(("InterceptShaderGLSL::ShaderSourcePre - Bad data passed as source to shader ID %u",srcHandle));
    return;
  }

  //Save the shader if dirty
  if(shaderData->IsReady() && shaderData->IsDirty())
  {
    //Save the dirty shader before it is overwitten
    SaveShaderData(shaderData);
  }

  string shaderSrc;

  //Loop for the number of strings
  for(uint i=0; i<numStrings; i++)
  {
    //If the string does have a NULL terminating character
    if(strLengthArray == NULL || strLengthArray[i] < 0)
    {
      //Append the string directly
      shaderSrc = shaderSrc + (char*)strArray[i];
    }
    else
    {
      //Append the atring using the count
      shaderSrc.append((char*)strArray[i], strLengthArray[i]);
    }
  }

  //Remove any "return" characters from the text
  // TODO: Do this in a "format" option? (performed by the save manager?)
  string shaderFormat=shaderSrc;
  shaderSrc = "";
  shaderSrc.reserve(shaderFormat.size());
  for(i=0; i<shaderFormat.size(); i++)
  {
    if(shaderFormat[i] != '\r')
    {
      shaderSrc += shaderFormat[i];
    }
  }

  //Assign the shader source
  shaderData->GetShaderSource() = shaderSrc;

  //Set the shader as ready and dirty
  shaderData->SetReady();

  //Save the shader data if possible
  SaveShaderData(shaderData);
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::CompileShaderPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the handle
  iHandle = va_arg(args, GLhandle);  
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::CompileShaderPost(const FunctionData *funcData,uint funcTableIndex,void * retVal)
{
  //Lookup the shader
  ShaderGLSLData * shaderData = shaderManager.GetData(iHandle);
  if(!shaderData || shaderData->GetGLType() == GL_PROGRAM_OBJECT_ARB ||
     !shaderData->IsReady() || shaderData->GetUserDeleted())
  {
    LOGERR(("InterceptShaderGLSL::CompileShaderPost - Unable to find active shader ID %u",iHandle));
    return;
  }


  //Append log status
  if(recordInfoLog)
  {
    string logString;
    GetLogData(shaderData,logString);

    //Assign the program source
    shaderData->GetShaderLog() = logString;

    //Set as dirty
    shaderData->SetDirty(true);
  }

  //If the shader exists and is ready and dirty, save it out
  if(shaderData->IsReady() && shaderData->IsDirty())
  {
    SaveShaderData(shaderData);
  }

  //Reset the handle
  iHandle = 0;
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::AttachObjectPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the program
  GLhandle programHandle = va_arg(args, GLhandle);  

  //Get the shader
  GLhandle shaderHandle = va_arg(args, GLhandle);  

  //Look for the program and the shader
  ShaderGLSLData * programData = shaderManager.GetData(programHandle);
  ShaderGLSLData * shaderData  = shaderManager.GetData(shaderHandle);
  if(!shaderData || !programData || shaderData == programData ||
      programData->GetGLType() != GL_PROGRAM_OBJECT_ARB ||
      shaderData->GetGLType()  == GL_PROGRAM_OBJECT_ARB ||
      shaderData->GetUserDeleted())
  {
    LOGERR(("InterceptShaderGLSL::AttachObjectPre - Invalid ID's %u,%u",programHandle,shaderHandle));
    return;
  }

  //Add the handle to each other
  programData->AttachObject(shaderHandle);
  shaderData->AttachObject(programHandle);

  //Save the shader if dirty
  if(shaderData->IsReady() && shaderData->IsDirty())
  {
    //Save the dirty shader
    SaveShaderData(shaderData);
  }

  //Save the program if dirty
  if(programData->IsReady() && programData->IsDirty())
  {
    //Save the dirty program
    SaveShaderData(programData);
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::DetachObjectPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the program
  iHandle = va_arg(args, GLhandle);  

  //Get the shader
  iHandleDetach = va_arg(args, GLhandle);  
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::DetachObjectPost(const FunctionData *funcData,uint funcTableIndex,void * retVal)
{
  //Assign the working handles
  GLhandle programHandle = iHandle;
  GLhandle shaderHandle  = iHandleDetach;

  //Test for zero handles
  if(programHandle == 0 || shaderHandle == 0)
  {
    LOGERR(("InterceptShaderGLSL::DetachObjectPost - Invalid ID's %u,%u",programHandle,shaderHandle));
    return;
  }

  //Look for the program and the shader
  // (Note: You can detach a user deleted object)
  ShaderGLSLData * programData = shaderManager.GetData(programHandle);
  ShaderGLSLData * shaderData  = shaderManager.GetData(shaderHandle);
  if(!shaderData || !programData || shaderData == programData ||
      programData->GetGLType() != GL_PROGRAM_OBJECT_ARB ||
      shaderData->GetGLType()  == GL_PROGRAM_OBJECT_ARB)
  {
    LOGERR(("InterceptShaderGLSL::DetachObjectPost - Invalid ID's %u,%u",programHandle,shaderHandle));
    return;
  }

  //Add the handle to each other
  if(!programData->DetachObject(shaderHandle))
  {
    LOGERR(("InterceptShaderGLSL::DetachObjectPost - Error detaching shader from program %u,%u",programHandle,shaderHandle));
  }
  if(!shaderData->DetachObject(programHandle))
  {
    LOGERR(("InterceptShaderGLSL::DetachObjectPost - Error detaching program from shader %u,%u",programHandle,shaderHandle));
  }

  //Save the shader if dirty
  if(shaderData->IsReady() && shaderData->IsDirty())
  {
    //Save the dirty shader
    SaveShaderData(shaderData);
  }

  //Save the program if dirty
  if(programData->IsReady() && programData->IsDirty())
  {
    //Save the dirty program
    SaveShaderData(programData);
  }

  //If the shader data is user deleted (and now has no references) delete it
  if(shaderData->GetUserDeleted() && shaderData->GetAttachmentArray().size() == 0)
  {
    //Remove
    shaderManager.RemoveData(shaderData->GetGLID());

    //This makes the pointers invalid, so reset them
    shaderData  = NULL;
    programData = NULL;
  }

  //Reset the handles
  iHandle = 0;
  iHandleDetach = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::LinkProgramPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{

  //Get the program
  GLhandle programHandle = va_arg(args, GLhandle);  

  //Look for the program 
  ShaderGLSLData * programData = shaderManager.GetData(programHandle);
  if(!programData || programData->GetGLType() != GL_PROGRAM_OBJECT_ARB)
  {
    LOGERR(("InterceptShaderGLSL::LinkProgramPre - Invalid ID %u",programHandle));
    return;
  }
  
  // On successful link, objects can be attached /detached etc without affecting the
  //  internal program -so save the source strings at the time on linking
  string vertexString;
  string fragmentString;
  string bufString;

  //Get the array of associated shaders
  const vector<GLhandle> & attachedObjects = programData->GetAttachmentArray();

  //Loop for all attachments
  for(uint i=0;i<attachedObjects.size();i++)
  {
    //Get the attachment
    const ShaderGLSLData * attachData = shaderManager.GetData(attachedObjects[i]);
    if(!attachData)
    {
      LOGERR(("InterceptShaderGLSL::LinkProgramPre - Unable to find shader ID %u",attachedObjects[i]));
    }
    else
    {
      //Save the shaders based on the different types
      switch(attachData->GetGLType())
      {
        case(GL_VERTEX_SHADER_ARB):
          StringPrintF(bufString,"\n//======================================================\n"
                                   "//   Vertex Shader %u \n"
                                   "//======================================================\n",attachedObjects[i]);
          vertexString += bufString;
          vertexString += attachData->GetShaderLog();
          vertexString += attachData->GetShaderSource();
          break;
        case(GL_FRAGMENT_SHADER_ARB):
          StringPrintF(bufString,"\n//======================================================\n"
                                   "//   Fragment Shader %u\n"
                                   "//======================================================\n",attachedObjects[i]);
          fragmentString += bufString;
          fragmentString += attachData->GetShaderLog();
          fragmentString += attachData->GetShaderSource();
          break;
        default:
          LOGERR(("InterceptShaderGLSL::LinkProgramPre - Unknown shader ID %u",attachedObjects[i]));
          break;
      }
    }
  }

  //Assign the program source
  programData->GetShaderSource() = vertexString + fragmentString;

  //Flag the program object as ready and dirty
  programData->SetReady();
  programData->SetDirty(true);

  //Assign the handle to use in the Post Linking version
  iHandle = programHandle;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::LinkProgramPost(const FunctionData *funcData,uint funcTableIndex,void * retVal)
{
  //Look for the program 
  ShaderGLSLData * programData = shaderManager.GetData(iHandle);
  if(iHandle == 0 || !programData || programData->GetGLType() != GL_PROGRAM_OBJECT_ARB)
  {
    LOGERR(("InterceptShaderGLSL::LinkProgramPost - Invalid ID %u",iHandle));
    return;
  }

  //Append log status
  if(recordInfoLog)
  {
    string logString;
    GetLogData(programData,logString);

    //Assign the program source
    programData->GetShaderLog() = logString;

    //Set as dirty
    programData->SetDirty(true);
  }

  //If the program exists and is ready and dirty, save it out
  if(programData->IsReady() && programData->IsDirty())
  {
    SaveShaderData(programData);
  }


  //Reset the handle
  iHandle = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::UseProgramPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the program
  GLhandle programHandle = va_arg(args, GLhandle);  
  if(programHandle == 0)
  {
    return;
  }

  //Look for the program 
  ShaderGLSLData * programData = shaderManager.GetData(programHandle);
  if(!programData || programData->GetGLType() != GL_PROGRAM_OBJECT_ARB)
  {
    LOGERR(("InterceptShaderGLSL::UseProgramPre - Invalid ID %u",programHandle));
    return;
  }

  //If the program exists and is ready and dirty, save it out
  if(programData->IsReady() && programData->IsDirty())
  {
    SaveShaderData(programData);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::ValidateProgramPre(const FunctionData *funcData,uint funcTableIndex, va_list args)
{
  //Get the program
  iHandle = va_arg(args, GLhandle);  

}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::ValidateProgramPost(const FunctionData *funcData,uint funcTableIndex,void * retVal)
{
  //Look for the program 
  ShaderGLSLData * programData = shaderManager.GetData(iHandle);
  if(iHandle == 0 || !programData || programData->GetGLType() != GL_PROGRAM_OBJECT_ARB)
  {
    LOGERR(("InterceptShaderGLSL::ValidateProgramPost - Invalid ID %u",iHandle));
    return;
  }
  
  //If the program exists, is ready and we record log info, save the updated log data
  if(recordInfoLog && programData->IsReady())
  {
    //Append log status
    string logString;
    GetLogData(programData,logString);

    //Assign the program source
    programData->GetShaderLog() = logString;

    //Set as dirty
    programData->SetDirty(true);

    //Save it out
    SaveShaderData(programData);
  }

  //Reset the handle
  iHandle = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::SaveAllDirtyData() 
{
  //Return if GL calls cannot be made
  if(!DriverAvailable())
  {
    return;
  }

  vector<ShaderGLSLData *> dirtyShaders;

  //Get all the dirty shaders
  shaderManager.GetAllDirtyData(dirtyShaders);

  //Loop for all shaders
  for(uint i=0;i<dirtyShaders.size();i++)
  {
    //Save the shader
    SaveShaderData(dirtyShaders[i]);
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::GetBoundProgram(GLhandle &programID)
{
  //Set initial return values
  programID  = 0;

  //Return if GL calls cannot be made
  if(!DriverAvailable())
  {
    return;
  }

  //If GLSL support, get the bound program
  if(extensionARBShaderObjects && iglGetHandle)
  {
    programID = iglGetHandle(GL_PROGRAM_OBJECT_ARB);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::GetLogData(const ShaderGLSLData *shaderData, string & retString)
{
  //Return if GL calls cannot be made
  if(!DriverAvailable())
  {
    retString = "";
    return;
  }

  //If the function pointers have not been retrieved, return now
  if(!iglGetObjectParameteriv || !iglGetInfoLog)
  {
    retString = "";
    return;
  }

  //Get the type of the object
  switch(shaderData->GetGLType())
  {
    //If a program, get the link status
    case(GL_PROGRAM_OBJECT_ARB) :
    {
      GLint linkStatus;
      iglGetObjectParameteriv(shaderData->GetGLID(), GL_OBJECT_LINK_STATUS_ARB, &linkStatus);
      if(linkStatus)
      {
        retString = "\n//== PROGRAM LINK STATUS = TRUE"; 
      }
      else
      {
        retString = "\n//== PROGRAM LINK STATUS = FALSE"; 
      }
      GLint validateStatus;
      iglGetObjectParameteriv(shaderData->GetGLID(), GL_OBJECT_VALIDATE_STATUS_ARB, &validateStatus);
      if(validateStatus)
      {
        retString += "\n//== PROGRAM VALIDATE STATUS = TRUE\n"; 
      }
      else
      {
        retString += "\n//== PROGRAM VALIDATE STATUS = FALSE\n"; 
      }
      break;
    }

    //If a shader, get the compile status
    case(GL_FRAGMENT_SHADER_ARB) :
    case(GL_VERTEX_SHADER_ARB) :
    {
      GLint compileStatus;
      iglGetObjectParameteriv(shaderData->GetGLID(), GL_OBJECT_COMPILE_STATUS_ARB, &compileStatus);
      if(compileStatus)
      {
        retString = "\n//== SHADER COMPILE STATUS = TRUE\n"; 
      }
      else
      {
        retString = "\n//== SHADER COMPILE STATUS = FALSE\n"; 
      }
      break;
    }

    default:
      LOGERR(("InterceptShaderGLSL::GetLogData - Shader %u is of unknown type %u",shaderData->GetGLID(),shaderData->GetGLType()));
      return;
  }
  
  //Get the info log size
  GLint logSize=0;
  iglGetObjectParameteriv(shaderData->GetGLID(), GL_OBJECT_INFO_LOG_LENGTH_ARB, &logSize);

  //Get the info log (only get logs of length greater than 1)
  if(logSize > 1)
  {
    //Allocate a array to hold the log
    GLchar * infoLog = new GLchar[logSize+1];
    infoLog[0] = '\0';

    //Get the info log
    iglGetInfoLog(shaderData->GetGLID(), logSize, NULL, infoLog); 
    
    //Not necessary, but just to be sure append a NULL character
    infoLog[logSize] = '\0';

    //Append to the string
    retString += "/*== INFO LOG ==\n";
    retString += (char*)infoLog;
    retString += "  == INFO LOG END ==*/\n";

    //Free info log array
    delete [] infoLog;
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::UpdateLogPreRender(const FunctionData *funcData)
{
  //Return now if not validate/dump or not dumping info data
  if(!recordInfoLog || (!validatePreRender && !dumpUniformsPreRender) ||
     !DriverAvailable() || !GetDataSaving())
  {
    return;
  }

  //Get the current bound program
  GLhandle programID;
  GetBoundProgram(programID);

  //Return if the program is not "ready" or is deleted
  ShaderGLSLData * programData = shaderManager.GetData(programID);
  if(programID == 0 || !programData || 
     programData->GetGLType() != GL_PROGRAM_OBJECT_ARB || !programData->IsReady())
  {
    return;
  }
  
  //If we validate the program, perform it before the log is updated 
  if(validatePreRender && iglValidateProgram)
  {
    iglValidateProgram(programID);
  }

  //Get the new log
  string logString;
  GetLogData(programData,logString);

  //Assign the program source
  programData->GetShaderLog() = logString;

  //Get if we dump uniforms
  if(dumpUniformsPreRender && iglGetObjectParameteriv && iglGetActiveUniform)
  {
    //Get the number of uniforms
    GLint numUniforms;
    iglGetObjectParameteriv(programData->GetGLID(), GL_OBJECT_ACTIVE_UNIFORMS_ARB, &numUniforms);

    //If there are uniforms add a tag
    if(numUniforms > 0)
    {
      programData->GetShaderLog() += "\n//======================================================\n"
                                       "//  Program uniforms (at render call) \n"
                                       "//======================================================\n";
    }

    //Get the max uniform string size
    GLint maxUniformSize;
    iglGetObjectParameteriv(programData->GetGLID(), GL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB, &maxUniformSize);

    //If there are uniforms to get, get them
    if(numUniforms > 0 && maxUniformSize > 0)
    {
      //Allocate the array to get the uniform strings
      GLchar * uniformName = new GLchar[maxUniformSize];
      string   uniformData;

      //Loop for the number of uniforms in the program
      for(uint i=0;i<numUniforms;i++)
      {
        GLint  typeSize;
        GLenum type;
        GLsizei lengthWritten;

        //Call GetActiveUniform to get the name,type and size of the type
        iglGetActiveUniform(programData->GetGLID(),i,maxUniformSize,&lengthWritten,&typeSize,&type,uniformName);
        if(lengthWritten > 0)
        {
          GetUniformValue(programData->GetGLID(),typeSize,type,uniformName,uniformData);
        }

        //Append the data to the log
        programData->GetShaderLog() += string("//  ") + string((char*)uniformName) + 
                                       string("  =  ") + uniformData + string("\n");
      }

      //Clean up the uniform name
      delete [] uniformName;
    }
  }

  //Set as dirty
  programData->SetDirty(true);

  //Save the program
  SaveShaderData(programData);

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptShaderGLSL::GetUniformValue(GLhandle progID,GLuint typeSize,GLenum type,const GLchar *uniformName,string &retString)
{
  //Determine if the functions are available
  if(!iglGetUniformfv || !iglGetUniformiv)
  {
    retString = "<unknown>";
    return;    
  }

  retString = "";

  //Call GetUniformLocation  
  GLint uniLocation = iglGetUniformLocation(progID,uniformName);
  if(uniLocation < 0)
  {
    //If the uniform is unknown, return a unknown string
    retString = "<unknown>";
    return;
  }

  bool isFloat   = true;
  bool isSamplerType = false;
  uint numElements = 1;

  //Determine the type and size of the data to get
  switch(type)
  {
    case(GL_SAMPLER_1D_ARB):
    case(GL_SAMPLER_2D_ARB):
    case(GL_SAMPLER_3D_ARB):
    case(GL_SAMPLER_CUBE_ARB):
    case(GL_SAMPLER_1D_SHADOW_ARB):
    case(GL_SAMPLER_2D_SHADOW_ARB):
    case(GL_SAMPLER_2D_RECT_ARB):
    case(GL_SAMPLER_2D_RECT_SHADOW_ARB):
      isSamplerType = true;
      numElements = 1;
      break;

    case(GL_FLOAT): 
    case(GL_INT):
    case(GL_BOOL_ARB):
      numElements = 1;
      break;

    case(GL_FLOAT_VEC2_ARB):
    case(GL_INT_VEC2_ARB):
    case(GL_BOOL_VEC2_ARB):
      numElements = 2;
      break;

    case(GL_FLOAT_VEC3_ARB):
    case(GL_INT_VEC3_ARB):
    case(GL_BOOL_VEC3_ARB):
      numElements = 3;
      break;

    case(GL_FLOAT_VEC4_ARB):
    case(GL_INT_VEC4_ARB):
    case(GL_BOOL_VEC4_ARB):
      numElements = 4;
      break;

    case(GL_FLOAT_MAT2_ARB ):
      numElements = 4;
      break;

    case(GL_FLOAT_MAT3_ARB ):
      numElements = 9;
      break;

    case(GL_FLOAT_MAT4_ARB ):
      numElements = 16;
      break;

    default:
      //Only enable this when debugging, new types may be added in future
      //LOGERR(("InterceptShaderGLSL::GetUniformValue - Unknown uniform type 0x%x",type));
      StringPrintF(retString,"<unknown type = 0x%x>",type);
      return;
  }

  //Determine if it is a non-float type
  if(type == GL_INT || type == GL_INT_VEC2_ARB ||type == GL_INT_VEC3_ARB ||type == GL_INT_VEC4_ARB ||
     type == GL_BOOL_ARB || type == GL_BOOL_VEC2_ARB ||type == GL_BOOL_VEC3_ARB ||type == GL_BOOL_VEC4_ARB ||
     isSamplerType)
  {
    isFloat = false;
  }


  //Get the total uniform data size
  uint uniformDataSize = numElements;
  if(uniformDataSize == 0)
  {
    LOGERR(("InterceptShaderGLSL::GetUniformValue - Uniform is of zero length?"));
    retString = "<unknown>";
    return;
  }

  //If the data is a float format, get the uniform via floats
  GLfloat * floatData = new GLfloat[uniformDataSize];
  GLint   * intData   = new GLint  [uniformDataSize];

  //Call apropiate GetUniform
  if(isFloat)
  {
    iglGetUniformfv(progID,uniLocation,floatData);
  }
  else
  {
    iglGetUniformiv(progID,uniLocation,intData);
  }

  string buffer;

  //Add a beginning brace
  if(numElements > 1)
  {
    retString += "(";
  }

  //Loop for the number of elements in the type
  for(uint i2=0;i2<numElements;i2++)
  {
    //Add the data to the return buffer
    if(isFloat)
    {
      StringPrintF(buffer,"%f",floatData[i2]);
    }
    else
    {
      StringPrintF(buffer,"%d",intData[i2]);
    }
    retString += buffer;

    //If the uniform was a sampler type, get the texture ID if possible
    if(!isFloat && isSamplerType)
    {
      //Get the lookup type of texture
      GLenum textureType=0;
      switch(type)
      {
        case(GL_SAMPLER_1D_ARB): 
        case(GL_SAMPLER_1D_SHADOW_ARB):
          textureType = GL_TEXTURE_1D;
          break;
        case(GL_SAMPLER_2D_ARB):
        case(GL_SAMPLER_2D_SHADOW_ARB):
          textureType = GL_TEXTURE_2D;
          break;
        case(GL_SAMPLER_3D_ARB): 
          textureType = GL_TEXTURE_3D;
          break;
        case(GL_SAMPLER_CUBE_ARB):
          textureType = GL_TEXTURE_CUBE_MAP;
          break;
        case(GL_SAMPLER_2D_RECT_ARB):
        case(GL_SAMPLER_2D_RECT_SHADOW_ARB):
          textureType = GL_TEXTURE_RECTANGLE_NV;
          break;
      }

      //Lookup the texture bound at that stage for that type
      uint retTexID;
      if(driver->GetCurrentContext() && textureType !=0 &&
         driver->GetCurrentContext()->GetBoundTexture(textureType,intData[i2],retTexID))
      {
        if(retTexID == 0)
        {
          retString += "<No Tex ID>";
        }
        else
        {
          StringPrintF(buffer,"<TexID = %u>",retTexID);
          retString += buffer;
        }
      }
    }

    //Add a comma if there are more elements to come
    if(i2<numElements-1)
    {
      retString += ",";
    }
  }

  //Add a closing brace
  if(numElements > 1)
  {
    retString += ")";
  }

  //Delete the array
  delete [] floatData;
  delete [] intData;


}


///////////////////////////////////////////////////////////////////////////////
//
bool InterceptShaderGLSL::GetShaderFileName(GLint id,string &retShaderName)
{
  //Check if the shader exists yet or not
  ShaderGLSLData * shaderData = shaderManager.GetData(id);
  if(!shaderData)
  {
    LOGERR(("InterceptShaderGLSL::GetShaderFileName - Unknown or invalid shader? ID = %d",id));
    return false;
  }
  
  //If the shader is ready, save it
  if(shaderData->IsReady())
  {
    //Save the shader if dirty
    if(shaderData->IsDirty())
    {
      //If there is an error in saving, return now
      if(!SaveShaderData(shaderData))
      {
        return false;
      }
    }
  
    //Copy the file names
    retShaderName = shaderData->GetShaderSaveFileName();
    return true;
  }

  return false;
}


///////////////////////////////////////////////////////////////////////////////
//
bool InterceptShaderGLSL::SaveShaderData(ShaderGLSLData *shaderData) 
{
  //Return if GL calls cannot be made
  if(!DriverAvailable())
  {
    return false;
  }

  //If we are not saving shaders, return now
  if(!GetDataSaving())
  {
    return false;
  }

  //Ensure that the shader is ready
  if(!shaderData->IsReady())
  {
    LOGERR(("InterceptShaderGLSL::SaveShaderData - Shader has not been uploaded yet"));
    return false;
  }

  //Get the file base name
  string shaderName;
  if(!shaderData->GetUniqueFileName(shaderName))
  {
    return false;
  }

  //Append the shader's directory name
  shaderName = GetDataSavingPath() + shaderName;

  //Write the shader out
  string retFileName;
  if(!shaderSaver.SaveShader(shaderName,shaderData,retFileName))
  {
    LOGERR(("InterceptShaderGLSL::SaveShaderData - Error saving shader"));
  }

  //Assign the return file name
  shaderData->GetShaderSaveFileName() = retFileName;

  //Flag that the shader is no longer dirty 
  //   (set this reguardless or weither shader saving was successful)
  shaderData->SetDirty(false);

  return true;
}
