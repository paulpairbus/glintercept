/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  Parts of this file may be derived from GLTrace version 2.3
  by Phil Frisbie, Jr. (phil@hawksoft.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __GL_CONTEXT_H_
#define __GL_CONTEXT_H_

#include "GLInterceptConfig.h"
#include "gl.h"
#include "InterceptImage.h"
#include "InterceptShader.h"
#include "InterceptShaderGLSL.h"
#include "InterceptFrame.h"
#include "InterceptDisplayList.h"
#include "ConfigData.h"

#include <string>

using namespace std;

class GLDriver;
class ExtensionFunction;

//@
//  Summary:
//    This class holds the internal data required for a OpenGL context.
//  
class GLContext
{
public:

  //@
  //  Summary:
  //    Constructor
  //
  //  Parameters:
  //    rcHandle   - The handle to the OpenGL context.
  //
  //    configData - The configuration options used when creating the context. 
  //                 (ie. what loggers to create)
  //
  //    glDriver   - The GLIntercept driver used for this context
  //
  //    functionTable - The function table of known OpenGL functions
  //
  GLContext(HGLRC rcHandle, const ConfigData &configData, GLDriver *glDriver, FunctionTable *functionTable);
  virtual ~GLContext();
  
  //@
  //  Summary:
  //    To log the passed function and function data 
  //    (Before the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  void LogFunctionPre(const FunctionData *funcData,uint index, va_list args);

  //@
  //  Summary:
  //    To perform any post-call logging of a function.
  //    (After the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - Pointer to the return value (if any).
  //
  void LogFunctionPost(const FunctionData *funcData,uint index, void * retVal);

  //@
  //  Summary:
  //    To share this classes' internal data with the passed context.
  //
  //  Parameters:
  //    shareContext  - The context to share data with.
  //
  //  Returns:
  //    True is returned on successful sharing, false if otherwise.
  //
  bool ShareLists(GLContext *shareContext) const;

  //@
  //  Summary:
  //    To activate the internal loggers with the passed directory name.
  //
  //  Parameters:
  //    logPath  - The directory to activate the internal loggers with.
  //
  void ActivateLoggers(const string &logPath);

  //@
  //  Summary:
  //    To suspend the internal loggers from logging.
  //
  void SuspendLoggers();


  //TODO: Better name? better place? call internally?

  //@
  //  Summary:
  //    To flag all tacked logger data as "dirty". (ie needs re-saving)
  //
  void SetLoggerDataDirty();


  //@
  //  Summary:
  //    To get the image saved filenames for a passed texture ID
  //  
  //  Parameters:
  //    texId  - The openGL texture ID to get the images for.
  //
  //    retSaveFiles - The files to be returned.
  //
  //  Returns:
  //    If the images could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetTextureFileNames(GLint texId, ImageSaveFiles &retSaveFiles);

  //@
  //  Summary:
  //    To get the shader saved filename for a passed shader ID
  //  
  //  Parameters:
  //    id  - The openGL shader (ARB program) ID to get the shader for.
  //
  //    retShaderName - The shader name to be returned.
  //
  //  Returns:
  //    If the shader file name could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetShaderFileName(GLint id,string &retShaderName);

  //@
  //  Summary:
  //    To get the GLSL shader saved filename for a passed shader ID
  //  
  //  Parameters:
  //    id  - The openGL shader (GLSL handle) ID to get the shader for.
  //
  //    retShaderName - The shader name to be returned.
  //
  //  Returns:
  //    If the shader file name could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetShaderGLSLFileName(GLint id,string &retShaderName);

  //@
  //  Summary:
  //    To get the filenames for frame buffer logging images.
  //  
  //  Parameters:
  //    retShaderName - The file name to be retrieved.
  //
  //  Returns:
  //    If the file names could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetFrameFileNames(FrameInterceptFileNames & retFrameFileNames);

  //@
  //  Summary:
  //    To get the display list saved filename for a passed display list ID
  //  
  //  Parameters:
  //    id  - The openGL list ID to get the list fileName for.
  //
  //    retListName - The display list name to be returned.
  //
  //  Returns:
  //    If the shader file name could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetDisplayListFileName(GLint id,string &retListName);


  //@
  //  Summary:
  //    To get an array of texture IDs that are bound. 
  //  
  //  Parameters:
  //    retArray  - The return array of texture IDs (and the stages) that are bound.
  //
  inline void GetBoundTextures(BoundTextureArray &retArray);

  //@
  //  Summary:
  //    To get from the OpenGL state what texture ID is active for the 
  //    passed texture stage and passed texture target.
  //  
  //  Parameters:
  //    oglTarget  - The OpenGL target of the texture ID to get.
  //
  //    texStage   - The texture stage to get the OpenGL target from.
  //
  //    retTexID   - The returned texture ID.
  //
  //  Returns:
  //    If the texture ID could be retrieved, true is returned and retTexID 
  //    contains the texture ID, Else false is returned.
  //
  inline bool GetBoundTexture(GLenum oglTarget,uint texStage,uint &retTexID);

  //@
  //  Summary:
  //    To get the id's of the bound vertex and fragment shader
  //  
  //  Parameters:
  //    vertexShaderID  - The returned shader ID of the bound vertex shader.
  //                      (returns 0 for no bound vertex shader)
  //
  //    fragmentShaderID  - The returned shader ID of the bound fragment shader.
  //                        (returns 0 for no bound fragment shader)
  //    
  //    programGLSLID     - The returned program ID of the bound GLSL program.
  //                        (returns 0 for no bound program)
  //
  inline void GetBoundShaders(uint &vertexShaderID,uint &fragmentShaderID,GLhandle &programGLSLID);

  //@
  //  Summary:
  //    To determine if the passed function performs a render.
  //  
  //  Parameters:
  //    funcData  - The function data pointer to test.
  //
  //    funcTableIndex - The index of the passed function data in the function
  //                     table.
  //
  //    args     - The arguments of the function.
  //
  //  Returns:
  //    If the passed function data pointer is a render function, 
  //    true is returned. Else false is returned.
  //
  inline bool IsRenderFuncion(const FunctionData *funcData, uint funcTableIndex, va_list args);

  //@
  //  Summary:
  //    To get cached error code for this context.
  //  
  //  Returns:
  //    The cached error code for this context is returned.
  //
  inline GLenum GetCachedError();

  //@
  //  Summary:
  //    To set the cacahed error code of this context.
  //  
  //  Parameters:
  //    newError  - The new cached error code for this context
  //
  inline void SetCachedError(GLenum newError);

  //@
  //  Summary:
  //    To get the render context handle for this context.
  //  
  //  Returns:
  //    The render context handle for this context is returned.
  //
  inline HGLRC GetRCHandle();

  //@
  //  Summary:
  //    To get the thread ID that is assigned to the context.
  //  
  //  Returns:
  //    The thread ID of the context is returned.
  //
  inline int GetContextThreadID() const;
   
  //@
  //  Summary:
  //    To set the thread ID that is assigned to the context.
  //  
  //  Parameters:
  //    newID  - The new context thread id.
  //
  inline void SetContextThreadID(int newID);

protected:
  
  HGLRC   glRCHandle;                             // The openGL rendering context handle
  GLenum  cachedError;                            // The cached error code
  int     contextThreadID;                        // The thread ID of the thread that currently has ownership of this context

  InterceptImage      *interceptImage;            // The class used to log image calls
  InterceptShader     *interceptShader;           // The class used to log shader calls
  InterceptShaderGLSL *interceptShaderGLSL;       // The class used to log GLSL shader calls
  InterceptFrame      *interceptFrame;            // The class used to save the frame buffer

  InterceptDisplayList *interceptList;            // The class used to log display list calls
};

///////////////////////////////////////////////////////////////////////////////
//
inline GLenum GLContext::GetCachedError()
{
  return cachedError;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void GLContext::SetCachedError(GLenum newError)
{
  cachedError = newError;
}

///////////////////////////////////////////////////////////////////////////////
//
inline HGLRC GLContext::GetRCHandle()
{
  return glRCHandle;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetTextureFileNames(GLint texId, ImageSaveFiles &retSaveFiles)
{
  //If we have the image logger, query the logger
  if(interceptImage)
  {
    return interceptImage->GetTextureFileNames(texId,retSaveFiles);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetShaderFileName(GLint id,string &retShaderName)
{
  //If we have the shader logger, query the logger
  if(interceptShader)
  {
    return interceptShader->GetShaderFileName(id,retShaderName);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetShaderGLSLFileName(GLint id,string &retShaderName)
{
  //If we have the GLSL shader logger, query the logger
  if(interceptShaderGLSL)
  {
    return interceptShaderGLSL->GetShaderFileName(id,retShaderName);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetFrameFileNames(FrameInterceptFileNames &retFrameFileNames)
{
  // If there exists a frame logger, get the images
  if(interceptFrame)
  {
    return interceptFrame->GetFrameFileNames(retFrameFileNames);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetDisplayListFileName(GLint id,string &retListName)
{
  //If we have the display list logger, query the logger
  if(interceptList)
  {
    return interceptList->GetDisplayListFileName(id,retListName);
  }

  return false;
}


///////////////////////////////////////////////////////////////////////////////
//
inline void GLContext::GetBoundTextures(BoundTextureArray &retArray)
{
  //If we have the image logger, query the logger
  if(interceptImage)
  {
    interceptImage->GetBoundTextures(retArray);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::GetBoundTexture(GLenum oglTarget,uint texStage,uint &retTexID)
{
  //If we have the image logger, query the logger
  if(interceptImage)
  {
    return interceptImage->GetActiveTextureID(oglTarget,texStage,retTexID);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void GLContext::GetBoundShaders(uint &vertexShaderID,uint &fragmentShaderID,GLhandle &programGLSLID)
{
  vertexShaderID   = 0;
  fragmentShaderID = 0;
  programGLSLID    = 0;

  //If we have the shader logger, query the logger
  if(interceptShader)
  {
    interceptShader->GetBoundShaders(vertexShaderID,fragmentShaderID);
  }
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->GetBoundProgram(programGLSLID);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLContext::IsRenderFuncion(const FunctionData *funcData, uint funcTableIndex, va_list args)
{
  //If it is a straight render function, return now
  if(funcData->functionFlags & FDF_RENDER_FUNC)
  {
    return true;
  }

  //If there is a display list logger, query it to determine if this is a display list call and,
  //  if it is if a render call is performed in the list.
  if(interceptList && interceptList->IsRenderListFunction(funcData,funcTableIndex,args))
  {
    return true;
  }

  return false;
}


///////////////////////////////////////////////////////////////////////////////
//
inline int GLContext::GetContextThreadID() const
{
  return contextThreadID;
}
 

///////////////////////////////////////////////////////////////////////////////
//
inline void GLContext::SetContextThreadID(int newID) 
{
  contextThreadID = newID;
}



#endif // __GL_CONTEXT_H_
