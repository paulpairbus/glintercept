/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLog.h"
#include "ErrorLog.h"
#include "GLDriver.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::InterceptLog(FunctionTable * functionTable):
logEnabled(false),
functionTable(functionTable),
glGetErrorFuncData(NULL)
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::Init()
{
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::~InterceptLog()
{
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::GetFunctionString(const FunctionData *funcData,uint index, va_list args, string &retString)
{
  //Append the function name first
  retString = funcData->functionName + "(";

  //Loop for all the parameters
  for(uint i=0;i<funcData->parameterArray.size();i++)
  {
    //Get the parameter
    const ParameterData * paramData = &funcData->parameterArray[i];

    //Determine if we are processing pointers
    bool isPointer=false;
    if(paramData->pointerCount > 0 || paramData->length != -1)
    {
      isPointer=true;
    }

    //Get the value
    void *value;
    if(!GetNextValue(paramData->GetGLType(),&args,isPointer,&value))
    {
      break;
    }

    //Test if this is an array value
    if(paramData->length != -1)
    {
      bool isArrayOfPointers = false;

      //Test for an array of pointers
      if(paramData->pointerCount > 0)
      {
        isArrayOfPointers = true;
      }

      //Assign the array
      void * array =  *((void **)value);

      //Loop and print the array
      retString += "[";
      for(uint i2=0;i2<paramData->length;i2++)
      {
        //Get the value from the array
        if(!GetNextArrayValue(paramData->GetGLType(),&array,isArrayOfPointers,&value))
        {
          break;
        }
      
        //Convert and print the value
        retString += ConvertParam(value,isArrayOfPointers,paramData);
        
        //Add a comma
        if(i2 != paramData->length - 1)
        {
          retString += ",";
        }
      }
      retString += "]";
    }
    else
    {
      //Just get the single value
      retString += ConvertParam(value,isPointer,paramData);
    }

    //Add a comma if there are more parameters
    if(i != funcData->parameterArray.size() - 1)
    {
      retString += ",";
    }
  }

  //If there are no parameters (unknown function)
  if(funcData->parameterArray.size() == 0)
  {
    retString += " ??? ";
  }

  //Close the bracket
  retString += ")";
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::GetErrorStringValue(uint errorCode, string &retString)
{
  //If we do no have a pointer to glGetError yet, get it
  if(glGetErrorFuncData == NULL)
  {
    //Get the index of the function
    int index =functionTable->FindFunction("glGetError");
    if(index != -1)
    {
      //Get the function data
      glGetErrorFuncData = functionTable->GetFunctionData(index);
    }
  }

  //If the function is still not found, just log the number
  if(glGetErrorFuncData == NULL || glGetErrorFuncData->returnType.type != PT_enum)
  {
    StringPrintF(retString,"0x%04x",errorCode);
  }
  else
  {
    //Get the return parameter
    const ParameterData * returnData = &glGetErrorFuncData->returnType;

    //Get the string version    
    retString = ConvertParam(&errorCode, false, returnData);
  }

}


///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextValue(ParameterType pType, va_list *args, bool isPointer,void **value)
{
  //Test if we are getting a pointer
  if(isPointer)
  {
    //Get the pointer value
    *value = &va_arg(*args,void *);

    //Return true
    return true;
  }

  //Determine the type to return
  switch(pType)
  {
    case(PT_enum):
    case(PT_bitfield):
      //Get the value
      *value = &va_arg(*args,unsigned int);
      break;

    case(PT_void):
      *value = NULL;
      break;

    case(PT_byte):
      //Get the value
      *value = &va_arg(*args,unsigned char);
      break;
    case(PT_short):
      //Get the value
      *value = &va_arg(*args,short);
      break;

    case(PT_int):
    case(PT_sizei):
      //Get the value
      *value = &va_arg(*args,int);
      break;

    case(PT_ubyte):
    case(PT_boolean):
      //Get the value
      *value = &va_arg(*args,unsigned char);
      break;

    case(PT_ushort):
      //Get the value
      *value = &va_arg(*args,unsigned short);
      break;

    case(PT_uint):
    case(PT_handle):
      //Get the value
      *value = &va_arg(*args,unsigned int);
      break;

    case(PT_float):
    case(PT_clampf):
      //Get the value
      *value = &va_arg(*args,float);
      break;

    case(PT_double):
    case(PT_clampd):
      //Get the value
      *value = &va_arg(*args,double);
      break;

    default:
      LOGERR(("InterceptLog::GetNextValue - Unhandled parameter in function of type %d",(int)pType));
      return false;
  }
 

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextArrayValue(ParameterType pType, void **array, bool isPointer,void **value)
{
  //The value to increment the array by
  uint arrayInc;

  //Test if we are getting a pointer
  if(isPointer)
  {
    arrayInc = sizeof(void *);
  }
  else
  {

    //Determine the type to return
    switch(pType)
    {
      case(PT_enum):
      case(PT_bitfield):
        //Get the value
        arrayInc = sizeof(unsigned int);
        break;

      case(PT_void):
        arrayInc = 0;
        break;

      case(PT_byte):
        //Get the value
        arrayInc = sizeof(unsigned char);
        break;
      case(PT_short):
        //Get the value
        arrayInc = sizeof(short);
        break;

      case(PT_int):
      case(PT_sizei):
        //Get the value
        arrayInc = sizeof(int);
        break;

      case(PT_ubyte):
      case(PT_boolean):
        //Get the value
        arrayInc = sizeof(unsigned char);
        break;

      case(PT_ushort):
        //Get the value
        arrayInc = sizeof(unsigned short);
        break;

      case(PT_uint):
      case(PT_handle): 
        //Get the value
        arrayInc = sizeof(unsigned int);
        break;

      case(PT_float):
      case(PT_clampf):
        //Get the value
        arrayInc = sizeof(float);
        break;

      case(PT_double):
      case(PT_clampd):
        //Get the value
        arrayInc = sizeof(double);
        break;

      default:
        LOGERR(("InterceptLog::GetNextArrayValue - Unhandled parameter in function of type %d",(int)pType));
        return false;
    }
  } 

  //Assign the value
  *value = *array;

  //Increment the array
  *array = ((char *)(*array) + arrayInc);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
string InterceptLog::ConvertParam(void *data, bool isPointer,const ParameterData *paramData)
{
  string retString;

  //If the data is a custom type, attempt to handle it
  if(paramData->IsCustomType() && 
     ConvertCustomParam(data,isPointer,paramData,retString))
  {
    return retString;
  }

  //If this is a pointer, out-put the address
  if(isPointer)
  {
    //Just get the pointer's address
    StringPrintF(retString,"0x%04x",*((int*)data));
  }
  else
  {

    //Do a big switch statement
    ParameterType pType=paramData->GetGLType();
    switch(pType)
    {
      case(PT_enum):
      case(PT_bitfield):
        {
          //Get the enum data
          const EnumData * enumData=functionTable->GetEnumData(paramData->index);

          //If the index is invalid, Just print the hex values
          if(enumData ==NULL)
          {
            StringPrintF(retString,"0x%04x",*((uint*)data));
          }
          else
          {
            retString = enumData->GetDisplayString(*((uint*)data));
          }
        }
        break;

      case(PT_boolean):
        {
          int num = *((unsigned char*)data);

          //Check the value
          if(num == 0)
          {
            retString = "false";
          }
          else if(num == 1)
          {
            retString = "true";
          }
          else
          {
            StringPrintF(retString,"Invalid boolean %u",num);
          }
          break;
        }

      case(PT_void):
        break;

      case(PT_byte):
        {
          int num = *((signed char*)data);
          StringPrintF(retString,"%d",num);
          break;
        }

      case(PT_short):
        {
          int num = *((short*)data);
          StringPrintF(retString,"%d",num);
          break;
        }

      case(PT_int):
      case(PT_sizei):
        {
          int num = *((int*)data);
          StringPrintF(retString,"%d",num);
          break;
        }

      case(PT_ubyte):
        {
          uint num = *((unsigned char*)data);
          StringPrintF(retString,"%u",num);
          break;
        }

      case(PT_ushort):
        {
          uint num = *((unsigned short*)data);
          StringPrintF(retString,"%u",num);
          break;
        }

      case(PT_uint):
      case(PT_handle):
        {
          uint num = *((unsigned int*)data);
          StringPrintF(retString,"%u",num);
          break;
        }

      case(PT_float):
      case(PT_clampf):
        {
          float num = *((float*)data);
          StringPrintF(retString,"%f",num);

          //Check clamped values
          if(pType == PT_clampf && (num < 0.0f || num > 1.0f))
          {
            retString = retString + "- Invalid clamped value";
          }
          break;
        }

      case(PT_double):
      case(PT_clampd):
        {
          double num = *((double*)data);
          StringPrintF(retString,"%f",num);

          //Check clamped values
          if(pType == PT_clampd && (num < 0.0 || num > 1.0))
          {
            retString = retString + "- Invalid clamped value";
          }

          break;
        }

      default:
        LOGERR(("InterceptLog::ConvertParam - Unhandled parameter in function of type %d",(int)pType));
    }
  }

  return retString;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString)
{
  //Handle pointer types first
  if(isPointer)
  {
    //If the pointer is to an array of characters, get the characters
    if(paramData->type == PT_ascii_string && paramData->pointerCount == 1)
    {
      char * charArray = *((char **)data);
      
      //If the string length is greater than 25 charcters, append it
      if(strlen(charArray) > 25)
      {
        //Assign the buffer data
        retString.assign(charArray,25);
        retString = "\"" + retString + "...\"";
      }
      else
      {
        //Assign the entire character array
        retString = charArray;
        retString = "\"" + retString + "\"";
      }

      return true;
    }
  }

  /*
  //Determine the type
  switch(paramData->type)
  {



  }
  */

  return false;
}


