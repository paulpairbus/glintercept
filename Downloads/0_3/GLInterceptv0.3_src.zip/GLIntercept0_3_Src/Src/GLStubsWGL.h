/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __GLSTUBS_WGL_H
#define __GLSTUBS_WGL_H

#include "GLInterceptConfig.h"
#include "gl.h"
#include "GLDriver.h"
#include "DLLLoader.h"

//Windows OpenGL API methods
struct WGLDriver
{
  int   (GLAPIENTRY *wglChoosePixelFormat)       (HDC a, CONST PIXELFORMATDESCRIPTOR *b);
  BOOL  (GLAPIENTRY *wglCopyContext)             (HGLRC a, HGLRC b, UINT c);
  HGLRC (GLAPIENTRY *wglCreateContext)           (HDC a);
  HGLRC (GLAPIENTRY *wglCreateLayerContext)      (HDC a, int b);
  BOOL  (GLAPIENTRY *wglDeleteContext)           (HGLRC a);
  BOOL  (GLAPIENTRY *wglDescribeLayerPlane)      (HDC a, int b, int c, UINT d, LPLAYERPLANEDESCRIPTOR e);
  int   (GLAPIENTRY *wglDescribePixelFormat)     (HDC a, int b, UINT c, LPPIXELFORMATDESCRIPTOR d);
  HGLRC (GLAPIENTRY *wglGetCurrentContext)       (void);
  HDC   (GLAPIENTRY *wglGetCurrentDC)            (void);
  PROC  (GLAPIENTRY *wglGetDefaultProcAddress)   (LPCSTR a);
  int   (GLAPIENTRY *wglGetLayerPaletteEntries)  (HDC a, int b, int c, int d, COLORREF *e);
  int   (GLAPIENTRY *wglGetPixelFormat)          (HDC a);
  PROC  (GLAPIENTRY *wglGetProcAddress)          (LPCSTR a);
  BOOL  (GLAPIENTRY *wglMakeCurrent)             (HDC a, HGLRC b);
  BOOL  (GLAPIENTRY *wglRealizeLayerPalette)     (HDC a, int b, BOOL c);
  int   (GLAPIENTRY *wglSetLayerPaletteEntries)  (HDC a, int b, int c, int d, CONST COLORREF *e);
  BOOL  (GLAPIENTRY *wglSetPixelFormat)          (HDC a, int b, CONST PIXELFORMATDESCRIPTOR *c);
  BOOL  (GLAPIENTRY *wglShareLists)              (HGLRC a, HGLRC b);
  BOOL  (GLAPIENTRY *wglSwapBuffers)             (HDC a);
  BOOL  (GLAPIENTRY *wglSwapLayerBuffers)        (HDC a, UINT b);
  BOOL  (GLAPIENTRY *wglUseFontBitmapsA)         (HDC a, DWORD b, DWORD c, DWORD d);
  BOOL  (GLAPIENTRY *wglUseFontBitmapsW)         (HDC a, DWORD b, DWORD c, DWORD d);
  BOOL  (GLAPIENTRY *wglUseFontOutlinesA)        (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);
  BOOL  (GLAPIENTRY *wglUseFontOutlinesW)        (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);
};

//The OpenGL driver
extern WGLDriver GLW;

//@
//  Summary:
//    Perform the function lookup of windows GL functions.
//  
//  Parameters:
//    openGLLib - The library to load the OpenGL functions from.
//
//  Returns:
//    True is returned on success, false is otherwise
//
bool MapWGLFunctions(DLLLoader &openGLLib);



#endif // __GLSTUBS_WGL_H
