============================================================
  
  GLIntercept v0.3 

  Copyright (c) 2004  Damian Trebilco  All rights reserved.

============================================================

Contents:
  1) Quick start guide
  2) Output
    2.1) Function Log
    2.2) Error Log
    2.3) Image Log
    2.4) Shader Log
    2.5) Frame/Render Log
    2.6) Display List Log
    2.7) Timer Log
  3) Known bugs
  4) Adding OpenGL extensions
  5) Contact
  6) Disclaimer


============================================================
1) Quick start guide

After installation, simply copy the opengl32.dll and gliConfig.ini file from 
the install directory to the executable folder of the application you want to
intercept OpenGL calls. 

Then edit the gliConfig.ini file and enable the options required then run the 
application.

If the interception was successful, a gliLog.txt will be generated in the same
directory as the opengl32.dll. (this is the error log). The results of the 
interception are also stored in the same directory by default. 
(ie. gliInterceptLog.txt)

It is important to note that GLIntercept is NOT safe when multiple render 
contexts are active at the same time on different threads. (ie you will 
probably experience crashes/ bad data) This restriction may be lifted in 
the future however, very few OpenGL applications use multiple render 
contexts at once. GLIntercept will currently report a warning if this is 
attempted.

============================================================
2) Output

2.1) Function Log

The GLIntercept function log simply records incoming OpenGL calls and saves 
them to a file. The logger can store functions in flat .txt files or in a .xml
format that can use a xsl file to present the data in a web browser.

Only OpenGL functions known by GLIntercept will have parameters of the function
logged. Unknown functions will have a ???? in the parameter field.

2.2) Error Log

Every execution of GLIntercept produces a gliLog.txt file in the directory of
the opengl32.dll. This file contains a record of any abnormal states or errors
that are detected during execution. If the image or shader logs are enabled, 
texture and shader memory leaks are also recorded here.

2.3) Image Log

The image log enables the saving of any OpenGL textures that are used in the 
application. Texture types include 1D,2D,3D,CUBE,NV_RECT and p-buffer bound 
textures. See the gliConfig.ini file for full options. 

2.4) Shader Log

The shader log enables the saving of OpenGL shaders/programs that are used 
in the application. Only ARB/NV/GLSL vertex and fragment programs/shaders
are currently supported. See the gliConfig.ini file for full options. 


2.5) Frame/Render Log
  
The frame log enables the saving of the OpenGL frame buffer pre and post 
render calls. The ability to save the "diff" of pre and post images is also 
available. The frame logger will not work correctly if you use 
WGL_ARB_make_current_read in your application. Also currently, the pixel 
transfer options will affect the buffers read back. (ie the colors values 
returned may be different from what is actually on the buffer. This may be 
fixed in future versions.
See the gliConfig.ini file for full options. 

2.6) Display List Log

The display list log enables the tracking and saving of OpenGL commands that
occur inside a display list. This includes reporting memory leaks on shutdown.
See the gliConfig.ini file for full options.  

2.7) Timer Log

The timer log is a logger the writes to the function log and flags how long
each function took to execuite. WARNING - This option is only for advanced 
OpenGL users and novice OpenGL programmers should not try to optimize
programs based on these results. See gliConfig.ini file for full options 
and a listing of special conditions for this logger.

============================================================
3) Known bugs

NOTE: GLIntercept will currently not handle multiple render contexts running 
on multiple threads at the same time. See the above note in section 1.

There are currently no known bugs in GLIntercept, however, the advanced 
loggers (ie.image,shader) assume that all function calls are valid. For this 
reason, ensure the application is free of OpenGL errors for correct usage of 
these loggers.

Possible bugs are expected in the advanced loggers if "unusual" work is done
in display lists. (ie texture/shader creation or general operations that will
not get compiled into the list) This is especially true if the "compile and
execute" option is used when creating the display list. 

GLIntercept will also have trouble determining if a display list performs 
render calls if it calls another display list internally to perform the 
render. (This will affect the frame logger)
 

GLIntercept also relies on a conformant OpenGL implementation. Current known
driver issues are:


Nvidia 59.xx and earlier

- The GLSL shader logger will crash the driver if you attempt to log the
  current uniforms. This has been fixed in the 61.xx drivers.

ATI Radeon Cat 4.6:

- The GLSL shader logger will report GL errors if uniform logging is turned on
  and samplers are contained inside the shaders. For some reason glGetUniform
  does not work for sampler values and reports an error upon calling. Also 
  note that due to this, the sampler values reported in the log will be 
  incorrect.

ATI Radeon Cat 4.1:
- glGetTexImage does not return the correct faces when retrieving cube maps.
  (This has probably been fixed in later drivers)

- when using WGL_ARB_render_texture, calls to 
  glGetIntegerv(GL_TEXTURE_BINDING_2D,&retVal); 
  do not return the currently bound texture id when the texture is bound to
  a p-buffer. It seems the driver is allocating a new texture internally when
  the texture is bound to a p-buffer. GLIntercept will complain about a 
  texture ID that is being used that was not created. The state of what 
  textures are bound during a render call is also wrong in the log output 
  because of this.

============================================================
4) Adding OpenGL extensions

While GLIntercept does cover most common extensions, adding new extensions 
is trivial.

To add a new OpenGL extension, access the GLFunctions folder in the install 
directory and add a file containing the new tokens/functions to the folder. 
The syntax of these files is very close to standard C so reference the 
existing files for syntax. Then add a #include directive to the gliIncludes.h 
file. 

GLIntercept will log any parse errors in the file to the gliLog.txt file next
time you run a OpenGL app.

============================================================
5) Contact

Any questions/bug reports/feature requests can be sent to:

dtrebilco@techie.com

This account is usually only checked on weekends so allow about a week if you
expect a reply.

============================================================
6) Disclaimer

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

