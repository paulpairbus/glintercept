============================================================
  
  GLIntercept 

  Copyright (c) 2004  Damian Trebilco  All rights reserved.

============================================================

Notes on the source:

 - All source (except some utility classes) is licenced under the GPL.
   see the Doc\licence.txt for details. Feel free to use this source as
   a reference to your own work.

 - The source to GLIntercept was compiled using Visual C++ 6.

 - The corona image library is need to compile the image loggers
   (http://sourceforge.net/projects/corona/) The binary version 
   of GLIntercept is compiled against a static version of this 
   library that is hacked to support jpg saving. GLIntercept 
   should still work with dynamic linking of corona.
