/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "GLDriver.h"
#include "FileUtils.h"


USING_ERRORLOG


//The path to the dll
extern string dllPath;

///////////////////////////////////////////////////////////////////////////////
//
GLContext::GLContext(HGLRC rcHandle, const ConfigData &configData, GLDriver *glDriver, FunctionTable *functionTable):
glRCHandle(rcHandle),
cachedError(GL_NO_ERROR),
contextThreadID(0),
interceptImage(NULL),
interceptShader(NULL),
interceptShaderGLSL(NULL),
interceptFrame(NULL),
interceptList(NULL)
{

  //Create the new intercept image
  if(configData.imageLogEnabled)
  {
    interceptImage = new InterceptImage(glDriver,functionTable,configData);
  }

  //Create the new intercept shader
  if(configData.shaderLogEnabled)
  {
    interceptShader = new InterceptShader(glDriver,functionTable,configData);

    //Due to the uniqeness of GLSL, these shaders have their own logger
    interceptShaderGLSL = new InterceptShaderGLSL(glDriver,functionTable,configData);
  }

  //Create a new intercept display list
  if(configData.displayListLogEnabled)
  {
    interceptList = new InterceptDisplayList(glDriver,functionTable,configData);
  }

  //Create the new intercept frame
  if(configData.frameLogEnabled)
  {
    interceptFrame = new InterceptFrame(glDriver,functionTable,configData);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
GLContext::~GLContext()
{
  //Delete the image log
  if(interceptImage)
  {
    interceptImage->ReleaseReference();
  }

  //Delete the shader log
  if(interceptShader)
  {
    interceptShader->ReleaseReference();
  }

  //Delete the GLSL shader log
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->ReleaseReference();
  }

  //Delete the frame logger
  if(interceptFrame)
  {
    interceptFrame->ReleaseReference();
  }

  //Delete the list logger
  if(interceptList)
  {
    interceptList->ReleaseReference();
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::LogFunctionPre(const FunctionData *funcData,uint index, const FunctionArgs & args)
{
  //Do frame log first
  if(interceptFrame)
  {
    interceptFrame->LogFunctionPre(funcData,index,args);
  }

  //Do the image log 
  if(interceptImage)
  {
    interceptImage->LogFunctionPre(funcData,index,args);
  }

  //Do the shader log
  if(interceptShader)
  {
    interceptShader->LogFunctionPre(funcData,index,args);
  }
  
  //Do the GLSL shader log
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->LogFunctionPre(funcData,index,args);
  }

  //Do the list log
  if(interceptList)
  {
    interceptList->LogFunctionPre(funcData,index,args);
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void GLContext::LogFunctionPost(const FunctionData *funcData,uint index, const FunctionRetValue & retVal)
{
  //Do frame log first
  if(interceptFrame)
  {
    interceptFrame->LogFunctionPost(funcData,index,retVal);
  }

  //Do the image log 
  if(interceptImage)
  {
    interceptImage->LogFunctionPost(funcData,index,retVal);
  }

  //Do the shader log
  if(interceptShader)
  {
    interceptShader->LogFunctionPost(funcData,index,retVal);
  }

  //Do the GLSL shader log
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->LogFunctionPost(funcData,index,retVal);
  }

  //Do the list log
  if(interceptList)
  {
    interceptList->LogFunctionPost(funcData,index,retVal);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
bool GLContext::ShareLists(GLContext *shareContext) const
{
  // Check the context
  if(shareContext == NULL)
  {
    return false;
  }
  if(shareContext == this)
  {
    return true;
  }

  //Delete existing context data
  if(shareContext->interceptImage)
  {
    shareContext->interceptImage->ReleaseReference();
    shareContext->interceptImage = NULL;
  }
  if(shareContext->interceptShader)
  {
    shareContext->interceptShader->ReleaseReference();
    shareContext->interceptShader = NULL;
  }
  if(shareContext->interceptShaderGLSL)
  {
    shareContext->interceptShaderGLSL->ReleaseReference();
    shareContext->interceptShaderGLSL = NULL;
  }

  if(shareContext->interceptList)
  {
    shareContext->interceptList->ReleaseReference();
    shareContext->interceptList = NULL;
  }


  //Assign our lists
  if(interceptImage)
  {
    interceptImage->AddReference();
    shareContext->interceptImage = interceptImage;
  }
  if(interceptShader)
  {
    interceptShader->AddReference();
    shareContext->interceptShader = interceptShader;
  }
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->AddReference();
    shareContext->interceptShaderGLSL = interceptShaderGLSL;
  }

  if(interceptList)
  {
    interceptList->AddReference();
    shareContext->interceptList = interceptList;
  }


  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::ActivateLoggers(const string &logPath)
{
  //DT_TODO: Simplify this method

  //Activate the image logger
  if(interceptImage)
  {
    //Set the image saving path
    interceptImage->SetDataSavingPath(logPath);

    //Activate the image saving
    interceptImage->SetDataSaving(true);
  }
  if(interceptShader)
  {
    //Set the shader saving path
    interceptShader->SetDataSavingPath(logPath);

    //Activate the shader saving
    interceptShader->SetDataSaving(true);
  }
  if(interceptShaderGLSL)
  {
    //Set the shader saving path
    interceptShaderGLSL->SetDataSavingPath(logPath);

    //Activate the shader saving
    interceptShaderGLSL->SetDataSaving(true);
  }


  if(interceptList)
  {
    //Set the display list saving path
    interceptList->SetDataSavingPath(logPath);

    //Activate the display list saving
    interceptList->SetDataSaving(true);
  }


  //Activate the frame logger
  if(interceptFrame)
  {
    //Set the frame saving path
    interceptFrame->SetDataSavingPath(logPath);

    //Activate the frame saving
    interceptFrame->SetDataSaving(true);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::SuspendLoggers()
{
  if(interceptImage)
  {
    interceptImage->SetDataSaving(false);
  }
  if(interceptShader)
  {
    interceptShader->SetDataSaving(false);
  }
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->SetDataSaving(false);
  }

  if(interceptList)
  {
    interceptList->SetDataSaving(false);
  }
  if(interceptFrame)
  {
    interceptFrame->SetDataSaving(false);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::SetLoggerDataDirty()
{
  //Set all images dirty
  if(interceptImage)
  {
    interceptImage->SetAllDataDirty();
  }

  //Set all shaders dirty
  if(interceptShader)
  {
    interceptShader->SetAllDataDirty();
  }
  if(interceptShaderGLSL)
  {
    interceptShaderGLSL->SetAllDataDirty();
  }

  //Set all lists dirty
  if(interceptList)
  {
    interceptList->SetAllDataDirty();
  }

}



