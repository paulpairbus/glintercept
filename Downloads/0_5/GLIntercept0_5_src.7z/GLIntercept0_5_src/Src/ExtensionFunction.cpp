/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "ExtensionFunction.h"
#include "GLDriver.h"
#include <stdarg.h>

//The driver to log calls by
extern GLDriver glDriver;

USING_ERRORLOG

//NOTE: This implementation is OS/Platform spacific 
#include "ExtensionFunctionStubs.cpp"

void * extFunctions[MAX_WRAPPER_FUNCTIONS];
uint   wrapperIndex[MAX_WRAPPER_FUNCTIONS];

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::ExtensionFunction(FunctionTable * functionTable):
currExtensionIndex(0),
functionTable(functionTable)
{

}

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::~ExtensionFunction()
{

}

///////////////////////////////////////////////////////////////////////////////
//
void * ExtensionFunction::AddFunction(const string & funcName,void * functionPtr)
{

  //Check for an existing function of that name
  int funcIndex = functionTable->FindFunction(funcName);
  if(funcIndex != -1)
  {
    //DT_TODO: If a user calls wglGetProcAddress on a non-OpenGL 1.0 but OpenGL 1.1 (eg glDeleteTextures)
    //         function in windows, it will fail to log correctly as the below 
    //         error condition is hit. However, this is rare as most (all?) OpenGL
    //         apps link against the opengl32.lib and only use wglGetProcAddress  
    //         for 1.2+ or and extensions. Possibly fix in future by "isBuiltIn" flag to the function table?

#ifdef GLI_BUILD_WINDOWS

    //Sanity check for multiple different lookups
    if(functionTable->GetFunctionData(funcIndex)->origionalInternalPtr != functionPtr)
    {
      //Log an error if there is a current context
      if(glDriver.GetCurrentContext() != NULL && functionPtr != NULL)
      {
        LOGERR(("ExtensionFunction::AddFunction - Function %s does not match previous lookup (multiple OpenGL devices?)",funcName.c_str()));
      }

      //Just return the "new" pointer
      return functionPtr;
    }

#endif //GLI_BUILD_WINDOWS

    //Get the function pointer to return
    return functionTable->GetFunctionData(funcIndex)->wrappedFunctionPtr;
  }

  //Catch bad function lookups 
  if(functionPtr == NULL)
  {
    return NULL;
  }

  //Check if we can add another extension function
  if(currExtensionIndex >= MAX_WRAPPER_FUNCTIONS)
  {
    //LOG an error
    LOGERR(("ExtensionFunction::AddFunction -Unable to log function %s exceeded %u num of wrapper functions",funcName.c_str(),MAX_WRAPPER_FUNCTIONS));

    //Else just return the pointer
    return functionPtr;
  }

  //Get the next available wrapper
  void *retPtr = (void*)wrapperFunctions[currExtensionIndex];
  
  //Add the data to the table and get the index
  funcIndex = functionTable->AddFunction(funcName,retPtr,functionPtr,&extFunctions[currExtensionIndex]);

  //Assign the index to the lookup table
  wrapperIndex[currExtensionIndex] = funcIndex;
  extFunctions[currExtensionIndex] = functionPtr;

  //Increment the wrapper counter
  currExtensionIndex++;

  //Return the wrapper pointer
  return retPtr;
}


///////////////////////////////////////////////////////////////////////////////
//
bool ExtensionFunction::AddOverrideFunction(const string & funcName, void * overrideFunctionPtr, void *origFuncPtr)
{
  //Check in incomming pointer
  if(overrideFunctionPtr == NULL)
  {
    return false;
  }

  //Check for an existing function of that name
  int funcIndex = functionTable->FindFunction(funcName);
  if(funcIndex != -1)
  {
    const FunctionData *foundFunc = functionTable->GetFunctionData(funcIndex);

#ifdef GLI_BUILD_WINDOWS

    //Sanity check for multiple different lookups
    if(foundFunc->origionalInternalPtr != origFuncPtr)
    {
      LOGERR(("ExtensionFunction::AddOverrideFunction - Function %s does not have the same internal lookup value",funcName.c_str()));
      return false;
    }

#endif //GLI_BUILD_WINDOWS

    //Check if an override already exists
    if(foundFunc->origionalInternalPtr != *foundFunc->internalFunctionDataPtr)
    {
      LOGERR(("ExtensionFunction::AddOverrideFunction - Function %s already has an override",funcName.c_str()));
      return false;
    }

    //Assign the override
    *foundFunc->internalFunctionDataPtr = overrideFunctionPtr;
    return true;
  }


  //If this is a new function, generate a wrapper around the override

  //Check if we can add another extension function
  if(currExtensionIndex >= MAX_WRAPPER_FUNCTIONS)
  {
    LOGERR(("ExtensionFunction::AddOverrideFunction -Unable to override function %s exceeded %u num of wrapper functions",funcName.c_str(),MAX_WRAPPER_FUNCTIONS));
    return false;
  }

  //Get the next available wrapper
  void *retPtr = (void*)wrapperFunctions[currExtensionIndex];
  
  //Add the data to the table and get the index
  funcIndex = functionTable->AddFunction(funcName,retPtr,origFuncPtr,&extFunctions[currExtensionIndex]);

  //Assign the index to the lookup table
  wrapperIndex[currExtensionIndex] = funcIndex;
  extFunctions[currExtensionIndex] = overrideFunctionPtr; //NOTE: Assigning override function here

  //Increment the wrapper counter
  currExtensionIndex++;

  return true;
}









