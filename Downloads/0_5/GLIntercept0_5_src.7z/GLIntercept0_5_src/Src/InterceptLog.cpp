/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLog.h"
#include "ErrorLog.h"
#include "GLDriver.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::InterceptLog(FunctionTable * functionTable):
logEnabled(false),
functionTable(functionTable),
glGetErrorFuncData(NULL)
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::Init()
{
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::~InterceptLog()
{
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::GetFunctionString(const FunctionData *funcData,uint index, const FunctionArgs & args, string &retString)
{
  //Append the function name first
  retString = funcData->functionName + "(";

  //Get a copy of the arguments
  FunctionArgs newArgs(args);

  //Loop for all the parameters
  for(uint i=0;i<funcData->parameterArray.size();i++)
  {
    //Get the parameter
    const ParameterData * paramData = &funcData->parameterArray[i];

    //Determine if we are processing pointers
    bool isPointer=false;
    if(paramData->pointerCount > 0 || paramData->length != -1)
    {
      isPointer=true;
    }

    //Get the value
    ParamValue value;
    if(!GetNextValue(paramData->GetGLType(),newArgs,isPointer, value))
    {
      break;
    }

    //Test if this is an array value
    if(paramData->length != -1)
    {
      bool isArrayOfPointers = false;

      //Test for an array of pointers
      if(paramData->pointerCount > 0)
      {
        isArrayOfPointers = true;
      }

      //Assign the array
      void * array =  value.pointerValue;

      //Loop and print the array
      retString += "[";
      for(uint i2=0;i2<(uint)paramData->length;i2++)
      {
        //Get the value from the array
        if(!GetNextArrayValue(paramData->GetGLType(),&array,isArrayOfPointers, value))
        {
          break;
        }
      
        //Convert and print the value
        retString += ConvertParam(value,isArrayOfPointers,paramData);
        
        //Add a comma
        if(i2 != (uint)(paramData->length - 1))
        {
          retString += ",";
        }
      }
      retString += "]";
    }
    else
    {
      //Just get the single value
      retString += ConvertParam(value,isPointer,paramData);
    }

    //Add a comma if there are more parameters
    if(i != funcData->parameterArray.size() - 1)
    {
      retString += ",";
    }
  }

  //If there are no parameters (unknown function)
  if(funcData->parameterArray.size() == 0)
  {
    retString += " ??? ";
  }

  //Close the bracket
  retString += ")";
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::GetReturnString(const FunctionData *funcData,uint index, const FunctionRetValue & retVal, string &retString)
{
  //Empty the return string
  retString = "";

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLog::GetReturnString - Function data for index %u is NULL",index)); 
    return;
  }

  //Get the return parameter
  const ParameterData * returnData = &funcData->returnType;

  //Determine if we are processing pointers
  bool isPointer=false;
  if(returnData->pointerCount > 0 || returnData->length != -1)
  {
    isPointer=true;
  }

  //Check the return value
  if(isPointer ||
     returnData->type != PT_void)
  {
    //Look up the data
    ParamValue value;
    if(GetReturnValue(returnData->type, retVal, isPointer, value))
    {
      retString = ConvertParam(value, isPointer, returnData);
    }
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::GetErrorStringValue(uint errorCode, string &retString)
{
  //If we do no have a pointer to glGetError yet, get it
  if(glGetErrorFuncData == NULL)
  {
    //Get the index of the function
    int index =functionTable->FindFunction("glGetError");
    if(index != -1)
    {
      //Get the function data
      glGetErrorFuncData = functionTable->GetFunctionData(index);
    }
  }

  //If the function is still not found, just log the number
  if(glGetErrorFuncData == NULL || glGetErrorFuncData->returnType.type != PT_enum)
  {
    StringPrintF(retString,"0x%04x",errorCode);
  }
  else
  {
    //Get the return parameter
    const ParameterData * returnData = &glGetErrorFuncData->returnType;

    //Get the string version
    ParamValue value;
    value.enumValue = errorCode;
    retString = ConvertParam(value, false, returnData);
  }

}


///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextValue(ParameterType pType, FunctionArgs &args, bool isPointer, ParamValue &value)
{
  //Test if we are getting a pointer
  if(isPointer)
  {
    //Get the pointer value
    args.Get(value.pointerValue);

    //Return true
    return true;
  }

  //Determine the type to return
  switch(pType)
  {
    case(PT_enum):
      args.Get(value.enumValue);
      break;
    case(PT_bitfield):
      args.Get(value.bitfieldValue);
      break;

    case(PT_void):
      break;

    case(PT_byte):
      args.Get(value.byteValue);
      break;
    case(PT_short):
      args.Get(value.shortValue);
      break;

    case(PT_int):
      args.Get(value.intValue);
      break;
    case(PT_sizei):
      args.Get(value.sizeiValue);
      break;

    case(PT_ubyte):
      args.Get(value.ubyteValue);
      break;

    case(PT_char):
      args.Get(value.charValue);
      break;

    case(PT_boolean):
      args.Get(value.booleanValue);
      break;

    case(PT_ushort):
      args.Get(value.ushortValue);
      break;

    case(PT_uint):
      args.Get(value.uintValue);
      break;
    case(PT_handle):
      args.Get(value.uintValue);
      break;

    case(PT_float):
    case(PT_clampf):
      args.Get(value.floatValue);
      break;

    case(PT_double):
    case(PT_clampd):
      args.Get(value.doubleValue);
      break;

    default:
      LOGERR(("InterceptLog::GetNextValue - Unhandled parameter in function of type %d",(int)pType));
      return false;
  }
 

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextArrayValue(ParameterType pType, void **array, bool isPointer, ParamValue &value)
{
  //The value to increment the array by
  uint arrayInc;

  //Check for NULL arrays
  if(*array == NULL)
  {
    LOGERR(("InterceptLog::GetNextArrayValue - Passing NULL as array parameter?"));
    return false;
  }

  //Test if we are getting a pointer (is an array of pointers)
  if(isPointer)
  {
    arrayInc = sizeof(void *);
    value.pointerValue = *((void**)(*array)); 
  }
  else
  {

    //Determine the type to return
    switch(pType)
    {
      case(PT_enum):
        value.enumValue = *((GLenum*)(*array));
        arrayInc = sizeof(GLenum);
        break;

      case(PT_bitfield):
        value.bitfieldValue = *((GLbitfield*)(*array));
        arrayInc = sizeof(GLbitfield);
        break;

      case(PT_void):
        arrayInc = 0;
        break;

      case(PT_byte):
        value.byteValue = *((GLbyte*)(*array));
        arrayInc = sizeof(GLbyte);
        break;

      case(PT_short):
        value.shortValue = *((GLshort*)(*array));
        arrayInc = sizeof(GLshort);
        break;

      case(PT_int):
        value.intValue = *((GLint*)(*array));
        arrayInc = sizeof(GLint);
        break;

      case(PT_sizei):
        value.sizeiValue = *((GLsizei*)(*array));
        arrayInc = sizeof(GLsizei);
        break;

      case(PT_ubyte):
        value.ubyteValue = *((GLubyte*)(*array));
        arrayInc = sizeof(GLubyte);
        break;

      case(PT_char):
        value.charValue = *((GLchar*)(*array));
        arrayInc = sizeof(GLchar);
        break;

      case(PT_boolean):
        value.booleanValue = *((GLboolean*)(*array));
        arrayInc = sizeof(GLboolean);
        break;

      case(PT_ushort):
        value.ushortValue = *((GLushort*)(*array));
        arrayInc = sizeof(GLushort);
        break;

      case(PT_uint):
      case(PT_handle): 
        value.uintValue = *((GLuint*)(*array));
        arrayInc = sizeof(GLuint);
        break;

      case(PT_float):
      case(PT_clampf):
        value.floatValue = *((GLfloat*)(*array));
        arrayInc = sizeof(GLfloat);
        break;

      case(PT_double):
      case(PT_clampd):
        value.doubleValue = *((GLdouble*)(*array));
        arrayInc = sizeof(GLdouble);
        break;

      default:
        LOGERR(("InterceptLog::GetNextArrayValue - Unhandled parameter in function of type %d",(int)pType));
        return false;
    }
  } 

  //Increment the array
  *array = ((char *)(*array) + arrayInc);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetReturnValue(ParameterType pType, const FunctionRetValue & retVal, bool isPointer, ParamValue &value)
{
  //Test if we are getting a pointer
  if(isPointer)
  {
    //Get the pointer value
    retVal.Get(value.pointerValue);

    //Return true
    return true;
  }

  //Determine the type to return
  switch(pType)
  {
    case(PT_enum):
      retVal.Get(value.enumValue);
      break;
    case(PT_bitfield):
      retVal.Get(value.bitfieldValue);
      break;

    case(PT_void):
      break;

    case(PT_byte):
      retVal.Get(value.byteValue);
      break;
    case(PT_short):
      retVal.Get(value.shortValue);
      break;

    case(PT_int):
      retVal.Get(value.intValue);
      break;
    case(PT_sizei):
      retVal.Get(value.sizeiValue);
      break;

    case(PT_ubyte):
      retVal.Get(value.ubyteValue);
      break;
    case(PT_boolean):
      retVal.Get(value.booleanValue);
      break;

    case(PT_ushort):
      retVal.Get(value.ushortValue);
      break;

    case(PT_uint):
      retVal.Get(value.uintValue);
      break;
    case(PT_handle):
      retVal.Get(value.uintValue);
      break;

    case(PT_char):
      retVal.Get(value.charValue);
      break;

/*
    case(PT_float):
    case(PT_clampf):
      retVal.Get(value.floatValue);
      break;

    case(PT_double):
    case(PT_clampd):
      retVal.Get(value.doubleValue);
      break;
*/
    default:
      LOGERR(("InterceptLog::GetReturnValue - Unhandled return value in function of type %d",(int)pType));
      return false;
  }
 

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
string InterceptLog::ConvertParam(const ParamValue &data, bool isPointer,const ParameterData *paramData)
{
  string retString;

  //If the data is a custom type, attempt to handle it
  if(paramData->IsCustomType() && 
     ConvertCustomParam(data,isPointer,paramData,retString))
  {
    return retString;
  }

  //If this is a pointer, out-put the address
  if(isPointer)
  {
    //Just get the pointer's address 
    // (should probably use %p here (and other places), but different libraries handle it differently - may have to on 64 bit)
    StringPrintF(retString,"0x%04x",(uint)data.pointerValue);
  }
  else
  {

    //Do a big switch statement
    ParameterType pType=paramData->GetGLType();
    switch(pType)
    {
      case(PT_enum):
        {
          //Get the enum data
          const EnumData * enumData=functionTable->GetEnumData(paramData->index);

          //If the index is invalid, Just print the hex values
          if(enumData ==NULL)
          {
            StringPrintF(retString,"0x%04x", data.enumValue);
          }
          else
          {
            retString = enumData->GetDisplayString(data.enumValue);
          }
        }
        break;

      case(PT_bitfield):
        {
          //Get the enum data
          const EnumData * enumData=functionTable->GetEnumData(paramData->index);

          //If the index is invalid, Just print the hex values
          if(enumData ==NULL)
          {
            StringPrintF(retString,"0x%04x", data.bitfieldValue);
          }
          else
          {
            retString = enumData->GetDisplayString(data.bitfieldValue);
          }
        }
        break;

      case(PT_boolean):
        {
          int num = data.booleanValue;

          //Check the value
          if(num == 0)
          {
            retString = "false";
          }
          else if(num == 1)
          {
            retString = "true";
          }
          else
          {
            StringPrintF(retString,"Invalid boolean %u",num);
          }
          break;
        }

      case(PT_void):
        break;

      case(PT_byte):
        {
          StringPrintF(retString,"%d",data.byteValue);
          break;
        }

      case(PT_short):
        {
          StringPrintF(retString,"%d",data.shortValue);
          break;
        }

      case(PT_int):
        {
          StringPrintF(retString,"%d",data.intValue);
          break;
        }

      case(PT_sizei):
        {
          StringPrintF(retString,"%d",data.sizeiValue);
          break;
        }

      case(PT_ubyte):
        {
          StringPrintF(retString,"%u",data.ubyteValue);
          break;
        }

      case(PT_char):
        {
          StringPrintF(retString,"%c",data.charValue);
          break;
        }

      case(PT_ushort):
        {
          StringPrintF(retString,"%u",data.ushortValue);
          break;
        }

      case(PT_uint):
      case(PT_handle):
        {
          StringPrintF(retString,"%u",data.uintValue);
          break;
        }

      case(PT_float):
      case(PT_clampf):
        {
          StringPrintF(retString,"%f",data.floatValue);

          //Check clamped values
          if(pType == PT_clampf && (data.floatValue < 0.0f || data.floatValue > 1.0f))
          {
            retString = retString + "- Invalid clamped value";
          }
          break;
        }

      case(PT_double):
      case(PT_clampd):
        {
          StringPrintF(retString,"%f",data.doubleValue);

          //Check clamped values
          if(pType == PT_clampd && (data.doubleValue < 0.0 || data.doubleValue > 1.0))
          {
            retString = retString + "- Invalid clamped value";
          }

          break;
        }

      default:
        LOGERR(("InterceptLog::ConvertParam - Unhandled parameter in function of type %d",(int)pType));
    }
  }

  return retString;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::ConvertCustomParam(const ParamValue &data, bool isPointer,const ParameterData *paramData,string &retString)
{
  //Handle pointer types first
  if(isPointer)
  {
    //If the pointer is to an array of characters, get the characters
    if(paramData->type == PT_ascii_string && paramData->pointerCount == 1)
    {
      char * charArray = (char *)data.pointerValue;
     
      //If it is a NULL string, the user has an error
      if (charArray == NULL)
      {
        retString = "<nul>";
      } 
      //If the string length is greater than 25 charcters, append it
      else if(strlen(charArray) > 25)
      {
        //Assign the buffer data
        retString.assign(charArray,25);
        retString = "\"" + retString + "...\"";
      }
      else
      {
        //Assign the entire character array
        retString = charArray;
        retString = "\"" + retString + "\"";
      }

      return true;
    }
  }

  /*
  //Determine the type
  switch(paramData->type)
  {



  }
  */

  return false;
}


