

#include <string>

using namespace std;

//Exported functions
extern "C" {
__declspec(dllexport) uint GLIAPI GetFunctionLogPluginVersion();
__declspec(dllexport) InterceptPluginInterface * GLIAPI CreateFunctionLogPlugin(const char *pluginName, InterceptPluginCallbacks * callBacks);
__declspec(dllexport) bool GLIAPI RegisterDLLEventHandler(DLLEventHandler *eventHandler);
__declspec(dllexport) bool GLIAPI UnRegisterDLLEventHandler(DLLEventHandler *eventHandler);
}

//The dll event handler (if any)
DLLEventHandler * dllEventHandler = NULL;

//The error logger
LOGERRPROC errorLog = NULL;

//The path to the DLL (including trailing slash)
string dllPath;

//The Instance that was passed on DllMain
HINSTANCE dllInstance = NULL;

///////////////////////////////////////////////////////////////////////////////
//
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
  //Assign the instance
  dllInstance = (HINSTANCE)hModule;

  switch (ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
    { 
      //Get the module's file name
      static char dllName[1024];
      GetModuleFileName((HMODULE)hModule,dllName,1023);
 
      //Get the path
      dllPath = dllName;
      int pathEnd = dllPath.rfind("\\");
      if(pathEnd != string::npos)
      {
        //Remove the file name part
        dllPath.erase(pathEnd+1,dllPath.size()-pathEnd-1);
      }
      else
      { 
        //Just use the current working directory
        dllPath = "";
      }

      break;
    }

    //NOTE: GLIntercept does not currently support multiple threads
    case DLL_THREAD_ATTACH:
    {
      break;
    }
    case DLL_THREAD_DETACH:
    {
      break;
    }
    case DLL_PROCESS_DETACH:
    {
      //If there is an event handler, flag that the plugin is being deleted
      if(dllEventHandler)
      {
        dllEventHandler->OnDLLDelete();
      }
      break;
    }
  }

  return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//
uint GLIAPI GetFunctionLogPluginVersion()
{
  return __GLI_INTERCEPT_PLUGIN_VER;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLIAPI RegisterDLLEventHandler(DLLEventHandler *eventHandler)
{
  //Check for an existing handler
  if(dllEventHandler)
  {
    return false;
  }

  //Assign the event handler
  dllEventHandler = eventHandler;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLIAPI UnRegisterDLLEventHandler(DLLEventHandler *eventHandler)
{
  if(dllEventHandler != eventHandler)
  {
    return false;
  }

  //Unset the event handler
  dllEventHandler = NULL;
  return true;
}



