/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2005  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __OS_DEFINES_H_
#define __OS_DEFINES_H_

//Typedef the 32 bit type (unsigned double word)
typedef unsigned int udword;

///////////////////////////////////////////////////////////////////////////////
//Windows defines
///////////////////////////////////////////////////////////////////////////////
#ifdef GLI_BUILD_WINDOWS

#define GLI_STDCALL __stdcall
#define GLI_CDECL   __cdecl
#define __attribute__(X) 

typedef unsigned int uint;
typedef signed   __int64  int64;
typedef unsigned __int64 uint64;

#endif //GLI_BUILD_WINDOWS

///////////////////////////////////////////////////////////////////////////////
//Linux defines
///////////////////////////////////////////////////////////////////////////////
#ifdef GLI_BUILD_LINUX

#define GLI_STDCALL 
#define GLI_CDECL   

typedef unsigned  int  uint;
typedef long long int  int64;
typedef unsigned long long uint64;

#define HGLRC       GLXContext

#include <X11/Xlib.h>
#include <X11/Xutil.h>
typedef struct __GLXcontextRec *GLXContext;
typedef struct __GLXFBConfigRec *GLXFBConfig;
typedef XID GLXDrawable;
typedef XID GLXPixmap;
typedef XID GLXWindow;
typedef XID GLXPbuffer;
typedef XID GLXContextID;

#endif //GLI_BUILD_LINUX

#endif // __OS_DEFINES_H_
