
#ifndef GLI_AFX_STDAFX_H_INCLUDED_
#define GLI_AFX_STDAFX_H_INCLUDED_

//Windows specific define
#ifdef GLI_BUILD_WINDOWS

#define _WIN32_WINDOWS 0x0410 //Assume at least win98 support

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Insert your headers here
#define WIN32_LEAN_AND_MEAN   // Exclude rarely-used stuff from Windows headers

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include <windows.h>

#endif // GLI_BUILD_WINDOWS

#endif // !GLI_AFX_STDAFX_H_INCLUDED_
