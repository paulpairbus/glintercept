/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptShaderGLSL.h"
#include "GLDriver.h"
#include "ConfigData.h"

USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLSaveManager::ShaderGLSLSaveManager(const ConfigData &configData)
{
}

///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLSaveManager::~ShaderGLSLSaveManager()
{
}


///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLSaveManager::SaveShader(const string &fileName, const ShaderGLSLData *shaderData, string &retFileName) const
{
  //Init the return values
  bool retValue = false;
  retFileName = "";

  //Save the shaders based on the different types
  switch(shaderData->GetGLType())
  {
    case(GL_VERTEX_SHADER_ARB):
    case(GL_FRAGMENT_SHADER_ARB):
      retValue = SaveFragmentVertexShaderData(fileName,shaderData,retFileName);
      break;
    case(GL_PROGRAM_OBJECT_ARB):
      retValue = SaveProgramData(fileName,shaderData,retFileName);
      break;

    //For a new type, just write it out
    default:
      LOGERR(("ShaderGLSLSaveManager::ShaderGLSLData - Unknown shader type %x",shaderData->GetGLType()));
      retValue = WriteShaderFile(fileName,shaderData->GetShaderSource().c_str(),
                                          shaderData->GetShaderSource().length(),retFileName);
  }

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLSaveManager::SaveFragmentVertexShaderData(const string &fileName, const ShaderGLSLData *shaderData,string &retFileName) const
{

  //Future formatting options?

  // Add log info 
  string writeString = shaderData->GetShaderLog() + shaderData->GetShaderSource();

  //Write the sahder to disk
  return WriteShaderFile(fileName,writeString.c_str(),
                                  writeString.length(),retFileName);
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLSaveManager::SaveProgramData(const string &fileName, const ShaderGLSLData *programData, string &retFileName) const
{
  //Future formatting options?
  
  // Add log info 
  string writeString = programData->GetShaderLog() + programData->GetShaderSource();

  return WriteShaderFile(fileName,writeString.c_str(),
                                  writeString.length(),retFileName);

}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLSaveManager::WriteShaderFile(const string &fileName,const char * shaderSrc,uint shaderLength, string &retFileName) const
{

  //Add a .txt to the end
  retFileName = fileName + ".txt";

  //Open the file
  FILE * file = fopen(retFileName.c_str(),"wt");
  if(!file)
  {
    LOGERR(("ShaderGLSLSaveManager::WriteShaderFile - Unable to open file %s",retFileName.c_str()));
    retFileName = "";
    return false;
  }

  //Write the string to the file
  if(fwrite(shaderSrc,1,shaderLength,file) != shaderLength)
  {
    LOGERR(("ShaderGLSLSaveManager::WriteShaderFile - Unable to write to file %s",retFileName.c_str()));
    fclose(file);  
    retFileName = "";
    return false;
  }

  //Close the file
  fclose(file);
  return true;
}


