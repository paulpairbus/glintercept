/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2005  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __FUNCTION_RET_VALUE_H
#define __FUNCTION_RET_VALUE_H

#include "gl.h"
#include <MiscUtils.h>

//@
//  Summary:
//    This class provides a way to access the return value from a 
//    arbitary function call. 
//
//  Note:
//    This class is very platform specific. Ensure to test return 
//    types from built-in to extension types
//
class FunctionRetValue 
{
public:

  //Constructor
  inline FunctionRetValue(GLuint newIntValue);
  inline FunctionRetValue(const void *newValue);

  //@
  //  Summary:
  //    To get the specified return value.
  //  
  //  Parameters:
  //    value - The return value.
  //
  inline void Get(void *&value) const;
  inline void Get(GLuint &value) const;
  inline void Get(GLint  &value) const;
  inline void Get(GLbyte &value) const;
  inline void Get(GLshort &value) const;
  inline void Get(GLubyte &value) const;
  inline void Get(GLushort &value) const;

protected:

  GLuint intValue;                                //The integer return value 
};

///////////////////////////////////////////////////////////////////////////////
//
inline FunctionRetValue::FunctionRetValue(GLuint newIntValue)
{
  intValue = newIntValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline FunctionRetValue::FunctionRetValue(const void *newValue)
{
  CASSERT(sizeof(GLuint) == sizeof(void*), Pointers_and_uints_not_the_same_size);

  //This assumes pointers and ints have the same size
  intValue = (uint)(newValue);
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(void *&retValue) const
{
  retValue  = (void*)intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLuint &retValue) const
{
  retValue = intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLint &retValue) const
{
  retValue = intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLbyte &retValue) const
{
  retValue = intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLshort &retValue) const
{
  retValue = intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLubyte &retValue) const
{
  retValue = intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLushort &retValue) const
{
  retValue = intValue;
}



#endif // __FUNCTION_RET_VALUE_H
