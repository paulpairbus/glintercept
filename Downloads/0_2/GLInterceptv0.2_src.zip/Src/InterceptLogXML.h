/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __INTERCEPT_LOG_XML_H_
#define __INTERCEPT_LOG_XML_H_

#include "GLInterceptConfig.h"
#include <stdio.h>
#include <string>
#include "InterceptLog.h"

using namespace std;

class InterceptLogXML : public InterceptLog 
{
public:

  //@
  //  Summary:
  //    Constructor to set up the log file. The default loggig is to stdout.
  //  
  //  Parameters:
  //    fileName - A file to open and use for logging.
  //
  //    functionTable - The table of all functions that are known/are being logged.
  //
  //    configData    - The configuration options for logging.
  //
  //    xslFileName   - The xsl file name used to format this XML (if any - can be empty).
  //
  InterceptLogXML(const char *fileName,FunctionTable * functionTable,const ConfigData &configData,
                  const string &xslFileName);

  //@
  //  Summary:
  //    Destructor, completes the log.
  //  
	virtual ~InterceptLogXML();

  //@
  //  Summary:
  //    To initialise the loog for writing. (ie. writes headers etc)
  //
  //  Returns:
  //    True is returned on init success, false if not.
  //
  virtual bool Init();

  //@
  //  Summary:
  //    To log the passed function and function data 
  //    (Before the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  virtual void LogFunctionPre(const FunctionData *funcData,uint index, va_list args);

  //@
  //  Summary:
  //    To perform any post-call logging of a function.
  //    (After the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - Pointer to the return value (if any).
  //
  virtual void LogFunctionPost(const FunctionData *funcData,uint index, void * retVal);

  //@
  //  Summary:
  //    To log that a GL error has occured.
  //  
  //  Parameters:
  //    errorCode - The GL error code to log.
  //
  virtual void LogFunctionError(uint errorCode);

  //@
  //  Summary:
  //    To log that the current function has completed. 
  //    (ie. All data for the previous function has been processed)
  //  
  virtual void LogFunctionComplete();

protected:

  bool   frameRenderCallLog;                      // Flag to indicate if frame buffer logging is performed.
  string xslFileName;                             // The file name of the XSL file used to format this file (if any)

  //@
  //  Summary:
  //    If the type of the parameter is custom (ie. non-standard OpenGL)
  //    calling this method will attempt to handle the type.
  //  
  //  Parameters:
  //    data  - A pointer to the parameter.
  //
  //    isPointer - Flag to indicate if the value is a pointer
  //
  //    paramData  - A pointer to the current parameter data being processed.
  //
  //    retString  - If the data is handled, the data for the type is returned in the string.
  //
  //  Returns:
  //    If the parameter was converted, true is returned and the data is stored in retString.
  //    Else false is returned and retString is unchanged.
  //
  virtual bool ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString);

  //@
  //  Summary:
  //    To add a image tag using the passed texture ID.
  //  
  //  Parameters:
  //    texID  - The texture ID to add a tag for.
  //
  void AddImageTag(uint texID);

  //@
  //  Summary:
  //    To add a shader tag using the passed shader ID.
  //  
  //  Parameters:
  //    shaderID  - The shader ID to add a tag for.
  //
  //    type      - The type of the shader (can be empty for unknown)
  //
  void AddShaderTag(uint shaderID,string type="");

  //@
  //  Summary:
  //    To add a frame buffer tag using the passed tag ID.
  //  
  //  Parameters:
  //    tagID  - The ID of the tag.
  //
  //    filename - The filename of the tag. (if empty no tag will be written).
  //
  void AddFrameTag(const string &tagID, const string &filename);

  //@
  //  Summary:
  //    To convert the passed string to be valid for including in a XML 
  //    attribute data section.
  //  
  //  Parameters:
  //    convertStr  - The string to convert.
  //
  void ConvertStringXML(string &convertStr);

  //@
  //  Summary:
  //    To convert the passed path/filename string to be valid for including in a XML 
  //    attribute data section. (also if possible, makes the image relative to this log's path)
  //  
  //  Parameters:
  //    convertFileName  - The fileName string to convert.
  //
  void ConvertFileNameXML(string &convertFileName);

};

#endif // __INTERCEPT_LOG_XML_H_
