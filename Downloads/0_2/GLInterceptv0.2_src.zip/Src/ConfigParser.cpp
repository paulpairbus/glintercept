
#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "ConfigParser.h"

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
ConfigParser::ConfigParser():
inComment(false)
{

}

///////////////////////////////////////////////////////////////////////////////
//
ConfigParser::~ConfigParser()
{

}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigParser::Parse(string fName)
{
  //Init the variables
  inComment =false;

  //Assign file and line counters (Account for header)
  lineCounter=2;
  fileName = fName;

  //Open the file
  FILE * file = fopen(fileName.c_str(),"rt");
  if(!file)
  {
    LOGERR(("ConfigParser::Parse - Unable to open file %s",fileName.c_str()));
    return false;
  }

  char inputString[1024];
  vector<string> rawTokens;

  //Get a line from the input stream
  while(fgets(inputString,1024,file) != NULL)
  {
    //Parse the line - return false on an error
    if(!ParseLine(inputString,rawTokens))
    {
      LOGERR(("ConfigParser::Parse - Line error in file %s Line %d",fileName.c_str(),lineCounter));
      fclose(file);
      return false;
    }

    //Increment the line counter
    lineCounter++;
  }

  //Close the file
  fclose(file);

  //Pass the raw tokens to a syntax checker and extract "real" tokens
  uint tokenStart =0;
  return ExtractTokens(rawTokens,tokenStart,NULL);
}


///////////////////////////////////////////////////////////////////////////////
//
bool ConfigParser::ParseLine(string line, vector<string> &rawTokens)
{
  //Remove comments
  RemoveComments(line);

  string ignoreChars(" \r\n");
  string singleTokens("={}(),;");
  string rawToken;
  
  //Loop while there is still tokens to be parsed
  do
  {
    //Get a token
    rawToken = GetRawToken(line,ignoreChars,singleTokens);

    if(rawToken.length() > 0)
    {
      //Add the raw token to the array
      rawTokens.push_back(rawToken);   
    }
  } while (line.length() > 0);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigParser::RemoveComments(string & line)
{
  int commentPos  = -1;
  int commentPos2 = -1;

  //If in a comment, check for ending "*/"
  if(inComment)
  {
    commentPos = line.find("*/");

    //If the ending string has been found 
    if(commentPos != string::npos)
    {
      //Remove the all the comments
      line.erase(0,commentPos+2);
      inComment = false;
    }
    else
    {
      //Just return an empty string
      line = ""; 
      return;
    }
  }

  //Check for "//"
  commentPos = line.find("//");

  //If the ending string has been found 
  if(commentPos != string::npos)
  {
    //Remove the all the comments from the comment on
    line.erase(commentPos,string::npos);
  }

  //Loop and check for "/*"
  commentPos = line.find("/*");
  while(commentPos != string::npos)
  {
    //Attempt to find an ending comment
    commentPos2 = line.find("*/");
    
    //If there is no ending comment, just return an empty string
    if(commentPos2 == string::npos)
    {
      line = ""; 
      inComment = true;
      return;
    }

    //Erase the comment
    line.erase(commentPos,(commentPos2+2)-commentPos);   

    //Get the next comment position
    commentPos = line.find("/*");
  }
}

///////////////////////////////////////////////////////////////////////////////
//
string ConfigParser::GetRawToken(string &line, string &ignoreChars, string &singleTokens)
{
  string retString;

  //Skip any leading ignore characters
  int charOffset = line.find_first_not_of(ignoreChars.c_str());
  if(charOffset != string::npos)
  {
    line.erase(0,charOffset);
  }
  else
  {
    //If there are no characters, null out the line and return
    line = "";
  }
  
  //Return now if there exist no more valid characters
  if(line.length() == 0)
  {
    return retString;
  }

  //If the first character is a " search for a quoted string
  if(line[0] == '"')
  {
    int endQuote = line.find("\"",1);
    if(endQuote != string::npos)
    {
      //Extract the quote
      retString = line.substr(1,endQuote-1);

      //Erase from the line
      line.erase(0,endQuote+1);

      return retString;
    }     
  }

  //Assign a test string for the first character
  string testString=line;
  testString.erase(1,testString.length()-1);

  //If the first character is a single token, extract and return it
  if(testString.find_first_of(singleTokens.c_str()) != string::npos)
  {
    //Erase the token
    line.erase(0,1);

    return testString;
  }
  
  //Extract a standard token
  string stdIgnore = ignoreChars + singleTokens + "\"";
  int charEnd = line.find_first_of(stdIgnore.c_str());

  if(charEnd != string::npos)
  {
    //Extract the token
    retString = line.substr(0,charEnd);

    //Erase from the line
    line.erase(0,charEnd);
  }
  else
  {
    //If the token proceeds to the end of the line, assign the whole line as the token.
    retString = line;
    line ="";
  }

  return retString;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigParser::ExtractTokens(vector<string> &rawTokens, uint &tokenNum, ConfigToken *parent)
{
  ConfigToken *currToken=NULL;
  bool inbracket = false;
  bool assignment=false;

  //NOTE: May have to use "proper" parser recursion if this gets much more complex

  //Loop for all tokens
  for(;tokenNum<rawTokens.size();tokenNum++)
  {
    string & tokenString = rawTokens[tokenNum];

    if(tokenString == "{")
    {
      //Check that we are not in a bracket
      if(inbracket || !currToken || assignment)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected '{'"));
        return false;
      }

      //Recursive call
      tokenNum++;
      if(!ExtractTokens(rawTokens,tokenNum,currToken))
      {
        LOGERR(("ConfigParser::ExtractTokens - Error in child block"));
        return false;
      }
    }
    else if(tokenString == "}")
    {
      //Check that we are not in a bracket and that there was a '{'
      if(inbracket || !parent || assignment)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected '}'"));
        return false;
      }

      return true;
    }
    else if(tokenString == "(")
    {
      if(inbracket || !assignment || !currToken)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected '('"));
        return false;
      }

      //Set bracket flag
      inbracket = true;
    }
    else if(tokenString == ")")
    {
      //Check for missing opening bracket
      if(!inbracket || !assignment || !currToken)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected ')'"));
        return false;
      }

      //Un-set bracket flag
      inbracket = false;
      assignment= false;
    }
    else if(tokenString == ",")
    {
      //NOTE: does not check for excess comma's (ie double or extra trailing commas)
      //Check for missing previous child and in a bracket
      if(!inbracket || !currToken || currToken->GetNumValues() == 0)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected ','"));
        return false;
      }
    }
    else if(tokenString == "=")
    {
      //Check for current token
      if(!currToken || assignment || inbracket)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected '='"));
        return false;
      }

      assignment=true;
    }
    else if(tokenString == ";")
    {
      //Check for current token
      if(!currToken || assignment || inbracket)
      {
        LOGERR(("ConfigParser::ExtractTokens - Un-expected ';'"));
        return false;
      }
      
      //Reset the current token
      currToken = NULL;
    }
    else
    {
      //Else just create a new config token 
      if(inbracket && currToken)
      {
        //Add a new value to the config token
        currToken->values.push_back(tokenString);
      }
      else if(assignment)
      {
        //Add a new value to the config token
        currToken->values.push_back(tokenString);

        //Flag that the assignment is complete
        assignment =false;
      }
      else
      {
        //Create a new token
        ConfigToken newToken;
        newToken.name = tokenString;

        //Either add to the parent or root
        ConfigToken * addToToken = &rootToken;
        if(parent)
        {
          addToToken = parent;
        }

        //Test if the child already exists
        ConfigToken * existingToken = const_cast<ConfigToken *>(addToToken->GetChildToken(tokenString));
        if(existingToken == NULL)
        {
          //Add the token
          addToToken->children.push_back(newToken);
          currToken = &addToToken->children.back();
        }
        else
        {
          //Cannot simply ignore as there may be children or ther values associated with the token
          LOGERR(("ConfigParser::ExtractTokens - Extra %s token -using last value",tokenString.c_str()));
          
          //Reset the token
          existingToken->Reset();

          //Assign as the current token
          existingToken->name = tokenString;
          currToken = existingToken;
        }
      }
    }
  }


  //If this is not the root token, and we have processed all the data
  //  there is a missing closing bracket
  if((parent != NULL || inbracket || assignment) && tokenNum>=rawTokens.size())
  {
    //Missing closing bracket
    LOGERR(("ConfigParser::ExtractTokens - Un-expected end of tokens (end of file missing a '}' or a ')'?"));
    return false;
  }
/*
  //Debug
  for(uint i=0;i<parsedTokens.size();i++)
  {
    LOGERR(("%s",parsedTokens[i].name.c_str()));
  }
*/
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
const ConfigToken * ConfigParser::GetToken(const string & name) const
{
  return rootToken.GetChildToken(name);
}

///////////////////////////////////////////////////////////////////////////////
//
void ConfigParser::LogUnusedTokens(const ConfigToken * startToken, string tokenString) const
{
  //If the start token is NULL, use the root token
  if(startToken == NULL)
  {
    startToken = &rootToken;
    tokenString = "Token ";
  }

  //Loop for all children
  for(uint i=0;i<startToken->GetNumChildren();i++)
  {
    //Check if the token has been accessed
    if(!startToken->children[i].tokenAccessed)
    {
      LOGERR(("%s->%s not accessed in the configuration file",tokenString.c_str(),startToken->children[i].name.c_str()));
    }
    else
    {
      //Recurse and check children of the token
      LogUnusedTokens(&startToken->children[i],tokenString + "->" + startToken->children[i].name);
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//   ConfigToken
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::Get(bool &retValue,uint valueOffset) const
{
  //If the token just exists by itself, return true
  if(GetNumValues() == 0 && valueOffset == 0)
  {
    retValue = true;
    return true;
  }
  if(valueOffset >= GetNumValues())
  {
    LOGERR(("ConfigToken::Get - Invalid offset %d",valueOffset));
    return false;
  }

  //Get a lower case version of the value 
  string cmpStr = values[valueOffset];
  for(uint i=0;i<cmpStr.length();i++)
  {
    cmpStr[i] = tolower(cmpStr[i]);
  }

  //If the value is assigne to true
  if(cmpStr == "true" || cmpStr == "on" || cmpStr == "+")
  {
    retValue = true;
    return true;
  }

  //If the value is assigne to off
  else if(cmpStr == "false" || cmpStr == "off" || cmpStr == "-")
  {
    retValue = false;
    return true;
  }

  //In-determinite value
  return false;
}



///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::Get(int &retValue,uint valueOffset) const
{
  //Check that there is a value
  if(GetNumValues() == 0)
  {
    return false;
  }
  if(valueOffset >= GetNumValues())
  {
    LOGERR(("ConfigToken::Get - Invalid offset %d",valueOffset));
    return false;
  }

  //Get the integer version of the string
  char *endValue;
  const char * str    = values[valueOffset].c_str();
  const char * endStr = str + (sizeof(char) * values[valueOffset].length());
  long testValue = strtol(str,&endValue,10);
 
  //If there was some non-numeric values in the string report and return false
  if(endValue != endStr)
  {
    LOGERR(("ConfigToken::Get - Non integer values in config string %s",str));
    return false;
  }

  //Assign the return value
  retValue = testValue;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::Get(uint &retValue,uint valueOffset) const
{
  //Check that there is a value
  if(GetNumValues() == 0)
  {
    return false;
  }
  if(valueOffset >= GetNumValues())
  {
    LOGERR(("ConfigToken::Get - Invalid offset %d",valueOffset));
    return false;
  }

  //Get the integer version of the string
  char *endValue;
  const char * str    = values[valueOffset].c_str();
  const char * endStr = str + (sizeof(char) * values[valueOffset].length());
  long testValue = strtol(str,&endValue,10);
 
  //If there was some non-numeric values in the string report and return false
  if(endValue != endStr)
  {
    LOGERR(("ConfigToken::Get - Non integer values in config string %s",str));
    return false;
  }
  if(testValue < 0)
  {
    LOGERR(("ConfigToken::Get - Negative integer values in config string %s",str));
    return false;
  }

  //Assign the return value
  retValue = testValue;

  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::Get(float &retValue,uint valueOffset) const
{
  //Check that there is a value
  if(GetNumValues() == 0)
  {
    return false;
  }
  if(valueOffset >= GetNumValues())
  {
    LOGERR(("ConfigToken::Get - Invalid offset %d",valueOffset));
    return false;
  }

  //Get the float version of the string
  char *endValue;
  const char * str    = values[valueOffset].c_str();
  const char * endStr = str + (sizeof(char) * values[valueOffset].length());
  double testValue = strtod(str,&endValue);
 
  //If there was some non-numeric values in the string report and return false
  if(endValue != endStr)
  {
    LOGERR(("ConfigToken::Get - Non float values in config string %s",str));
    return false;
  }

  //Assign the return value
  retValue = testValue;

  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::Get(string &retValue,uint valueOffset) const
{
  if(GetNumValues() == 0)
  {
    return false;
  }
  if(valueOffset >= GetNumValues())
  {
    LOGERR(("ConfigToken::Get - Invalid offset %d",valueOffset));
    return false;
  }

  //Just return the first value
  retValue = values[valueOffset];
  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::GetArray(uint count,vector<bool> &retValue) const
{
  //Check the array size
  if(count > GetNumValues())
  {
    return false;
  }

  //Loop for the count
  vector<bool> tmpArray;
  for(uint i=0;i<count;i++)
  {
    //Get a single value
    bool value;
    if(Get(value,i))
    {
      tmpArray.push_back(value); 
    }
    else
    {
      return false;
    }
  }

  //Assign the array
  retValue = tmpArray;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::GetArray(uint count,vector<int> &retValue) const
{
  //Check the array size
  if(count > GetNumValues())
  {
    return false;
  }

  //Loop for the count
  vector<int> tmpArray;
  for(uint i=0;i<count;i++)
  {
    //Get a single value
    int value;
    if(Get(value,i))
    {
      tmpArray.push_back(value); 
    }
    else
    {
      return false;
    }
  }

  //Assign the array
  retValue = tmpArray;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::GetArray(uint count,vector<uint> &retValue) const
{
  //Check the array size
  if(count > GetNumValues())
  {
    return false;
  }

  //Loop for the count
  vector<uint> tmpArray;
  for(uint i=0;i<count;i++)
  {
    //Get a single value
    uint value;
    if(Get(value,i))
    {
      tmpArray.push_back(value); 
    }
    else
    {
      return false;
    }
  }

  //Assign the array
  retValue = tmpArray;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::GetArray(uint count,vector<float> &retValue) const
{
  //Check the array size
  if(count > GetNumValues())
  {
    return false;
  }

  //Loop for the count
  vector<float> tmpArray;
  for(uint i=0;i<count;i++)
  {
    //Get a single value
    float value;
    if(Get(value,i))
    {
      tmpArray.push_back(value); 
    }
    else
    {
      return false;
    }
  }

  //Assign the array
  retValue = tmpArray;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ConfigToken::GetArray(uint count,vector<string> &retValue) const
{
  //Check the array size
  if(count > GetNumValues())
  {
    return false;
  }

  //Loop for the count
  vector<string> tmpArray;
  for(uint i=0;i<count;i++)
  {
    //Get a single value
    string value;
    if(Get(value,i))
    {
      tmpArray.push_back(value); 
    }
    else
    {
      return false;
    }
  }

  //Assign the array
  retValue = tmpArray;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
const ConfigToken * ConfigToken::GetChildToken(const string & name) const
{
  //Loop and check all tokens
  for(uint i=0;i<children.size();i++)
  {
    //Check if the token value exists
    if(children[i].name == name)
    {
      //Flag that the child has been accessed
      children[i].tokenAccessed = true;

      //Return the child
      return &children[i];
    }
  }

  //Return NULL for no token
  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
const ConfigToken * ConfigToken::GetChildToken(uint childNum) const
{
  //Check the array size and return the child
  if(childNum < children.size())
  {
    //Flag that the child has been accessed
    children[childNum].tokenAccessed = true;

    //Return the child
    return &children[childNum];
  }

  return NULL;
}

