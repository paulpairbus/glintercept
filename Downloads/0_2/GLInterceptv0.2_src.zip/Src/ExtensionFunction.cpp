/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "ExtensionFunction.h"
#include "GLDriver.h"

//NOTE: This implementation is OS/Platform spacific 

#define MAX_WRAPPER_FUNCTIONS 1000

//Flags when a wrapper could not be init (cause is a typo)
bool   wrapperInitfailure=false;

//The number of wrapper functions 
uint   numWrapperFunctions=0;
void * wrapperFunctions[MAX_WRAPPER_FUNCTIONS];
void * extFunctions[MAX_WRAPPER_FUNCTIONS];
uint   wrapperIndex[MAX_WRAPPER_FUNCTIONS];


//The driver to log calls by
extern GLDriver glDriver;

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::ExtensionFunction(FunctionTable * functionTable):
currExtensionIndex(0),
functionTable(functionTable)
{

}

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::~ExtensionFunction()
{

}

///////////////////////////////////////////////////////////////////////////////
//
void * ExtensionFunction::AddFunction(const string & funcName,void * functionPtr)
{

  //Check for an existing function of that name (or alias)
  int funcIndex = functionTable->FindFunction(funcName);
  if(funcIndex != -1)
  {
    //Get the function pointer to return
    return functionTable->GetFunctionData(funcIndex)->functionPtr;
  }

  //Catch bad function lookups 
  if(functionPtr == NULL)
  {
    return NULL;
  }

  //Check if we can add another extension function
  if(currExtensionIndex >= numWrapperFunctions)
  {
    //LOG an error
    LOGERR(("ExtensionFunction::AddFunction -Unable to log function %s exceeded %d num of wrapper functions",funcName.c_str(),numWrapperFunctions));

    //Else just return the pointer
    return functionPtr;
  }

  //Get the next available wrapper
  void *retPtr = wrapperFunctions[currExtensionIndex];

  //Add the data to the table and get the index
  funcIndex = functionTable->AddFunction(funcName,retPtr);

  //Assign the index to the lookup table
  wrapperIndex[currExtensionIndex] = funcIndex;
  extFunctions[currExtensionIndex] = functionPtr;

  //Increment the wrapper counter
  currExtensionIndex++;

  //Return the wrapper pointer
  return retPtr;
}




///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//
//      Wrapper Functions
//
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//Helper class
class WrapperInit
{
public:

  WrapperInit(uint index,void * function)
  {
    //Ensure to cactch typos with the macros
    if(wrapperInitfailure || index >= MAX_WRAPPER_FUNCTIONS || index != numWrapperFunctions)
    {
      numWrapperFunctions = 0;
      wrapperInitfailure = true;
    }

    //Assign the function and set the index to an invalid value
    wrapperFunctions[index] = function;
    wrapperIndex    [index] = (uint)-1;

    //Check for bad code
    if(numWrapperFunctions < MAX_WRAPPER_FUNCTIONS)
    {
      numWrapperFunctions++;
    }
  }
};


///////////////////////////////////////////////////////////////////////////////
//
void __cdecl LogFunctionPre(uint first, ... )
{
  //Get the variable list
  va_list marker;
  va_start(marker,first);     

  //Call the proper log
  bool retVal=glDriver.LogFunctionPre(first,marker);

  //Gen the marker
  va_end(marker);
}

///////////////////////////////////////////////////////////////////////////////
//
void __cdecl LogFunctionPost(uint first, uint retVal)
{
  //Call the proper log
  glDriver.LogFunctionPost(first,&retVal);
}

///////////////////////////////////////////////////////////////////////////////
//

//Very un-thread safe
unsigned int saveAddress1;
unsigned int saveBP;
unsigned int saveEAX;
unsigned int saveEBX;

#define Naked   __declspec( naked )
/*
Naked void NakedCall()
{
  __asm
  {
    //Save the Base pointer
    mov saveBP,ebp
    mov saveEAX,eax
    mov saveEBX,ebx

    //Save the return address pointer
    mov ebx,dword ptr [esp+0]
    mov saveAddress1,ebx

    //Move the stack pointer
    add esp,4

    //Move the 32 bit value onto the stack (should learn how to push a 32 bit value)
    mov ebx, wrapperIndex[0] 
    push ebx
    call LogFunctionPre
    pop ebx

    //Make the function call (preserve eax for return value)
    mov ebx,extFunctions[0]
    mov eax,saveEAX
    call ebx

    //Restore the base pointer
    mov ebp, saveBP

    //Restore the address pointer
    mov  ebx,saveAddress1
    push ebx

    //Log the return value (if any)
    mov ebx, wrapperIndex[n*4]
    push eax                  
    push ebx                  
    call LogFunctionPost      
    pop ebx                   
    pop eax                   

    //Restore EBX
    mov  ebx,saveEBX

    //Return
    ret
  }
}
*/

#define WRAPPER_FUNCTION(n) \
Naked void WrapperCall##n()  \
{                        \
    /*Save the Base pointer*/ \
    __asm mov saveBP,ebp      \
    __asm mov saveEAX,eax     \
    __asm mov saveEBX,ebx     \
                              \
                              \
    /*Save the return address pointer*/ \
    __asm mov ebx,dword ptr [esp+0]     \
    __asm mov saveAddress1,ebx          \
                              \
    /*Move the stack pointer*/\
    __asm add esp,4           \
                              \
    /*Move the 32 bit value onto the stack */\
    __asm mov ebx, wrapperIndex[n*4] \
    __asm push ebx            \
    __asm call LogFunctionPre \
    __asm pop ebx             \
                              \
    /*Make the function call (preserve eax for return value)*/ \
    __asm mov ebx,extFunctions[n*4] \
    __asm mov eax,saveEAX     \
    __asm call ebx            \
                              \
                              \
    /*Restore the base pointer*/\
    __asm mov ebp, saveBP       \
                                \
    /*Restore the address pointer*/ \
    __asm mov  ebx,saveAddress1     \
    __asm push ebx                  \
                                    \
    /* Log the return value (if any)*/\
    __asm mov ebx, wrapperIndex[n*4]\
    __asm push eax                  \
    __asm push ebx                  \
    __asm call LogFunctionPost      \
    __asm pop ebx                   \
    __asm pop eax                   \
                                    \
                                    \
    /*Restore EBX*/                 \
    __asm mov  ebx,saveEBX          \
                                    \
    /*Return*/                      \
    __asm ret                       \
}                                   \
static WrapperInit wrapper##n(n,WrapperCall##n);


//The function wrappers
WRAPPER_FUNCTION(0);
WRAPPER_FUNCTION(1);
WRAPPER_FUNCTION(2);
WRAPPER_FUNCTION(3);
WRAPPER_FUNCTION(4);
WRAPPER_FUNCTION(5);
WRAPPER_FUNCTION(6);
WRAPPER_FUNCTION(7);
WRAPPER_FUNCTION(8);
WRAPPER_FUNCTION(9);
WRAPPER_FUNCTION(10);
WRAPPER_FUNCTION(11);
WRAPPER_FUNCTION(12);
WRAPPER_FUNCTION(13);
WRAPPER_FUNCTION(14);
WRAPPER_FUNCTION(15);
WRAPPER_FUNCTION(16);
WRAPPER_FUNCTION(17);
WRAPPER_FUNCTION(18);
WRAPPER_FUNCTION(19);
WRAPPER_FUNCTION(20);
WRAPPER_FUNCTION(21);
WRAPPER_FUNCTION(22);
WRAPPER_FUNCTION(23);
WRAPPER_FUNCTION(24);
WRAPPER_FUNCTION(25);
WRAPPER_FUNCTION(26);
WRAPPER_FUNCTION(27);
WRAPPER_FUNCTION(28);
WRAPPER_FUNCTION(29);
WRAPPER_FUNCTION(30);
WRAPPER_FUNCTION(31);
WRAPPER_FUNCTION(32);
WRAPPER_FUNCTION(33);
WRAPPER_FUNCTION(34);
WRAPPER_FUNCTION(35);
WRAPPER_FUNCTION(36);
WRAPPER_FUNCTION(37);
WRAPPER_FUNCTION(38);
WRAPPER_FUNCTION(39);
WRAPPER_FUNCTION(40);
WRAPPER_FUNCTION(41);
WRAPPER_FUNCTION(42);
WRAPPER_FUNCTION(43);
WRAPPER_FUNCTION(44);
WRAPPER_FUNCTION(45);
WRAPPER_FUNCTION(46);
WRAPPER_FUNCTION(47);
WRAPPER_FUNCTION(48);
WRAPPER_FUNCTION(49);

WRAPPER_FUNCTION(50);
WRAPPER_FUNCTION(51);
WRAPPER_FUNCTION(52);
WRAPPER_FUNCTION(53);
WRAPPER_FUNCTION(54);
WRAPPER_FUNCTION(55);
WRAPPER_FUNCTION(56);
WRAPPER_FUNCTION(57);
WRAPPER_FUNCTION(58);
WRAPPER_FUNCTION(59);
WRAPPER_FUNCTION(60);
WRAPPER_FUNCTION(61);
WRAPPER_FUNCTION(62);
WRAPPER_FUNCTION(63);
WRAPPER_FUNCTION(64);
WRAPPER_FUNCTION(65);
WRAPPER_FUNCTION(66);
WRAPPER_FUNCTION(67);
WRAPPER_FUNCTION(68);
WRAPPER_FUNCTION(69);
WRAPPER_FUNCTION(70);
WRAPPER_FUNCTION(71);
WRAPPER_FUNCTION(72);
WRAPPER_FUNCTION(73);
WRAPPER_FUNCTION(74);
WRAPPER_FUNCTION(75);
WRAPPER_FUNCTION(76);
WRAPPER_FUNCTION(77);
WRAPPER_FUNCTION(78);
WRAPPER_FUNCTION(79);
WRAPPER_FUNCTION(80);
WRAPPER_FUNCTION(81);
WRAPPER_FUNCTION(82);
WRAPPER_FUNCTION(83);
WRAPPER_FUNCTION(84);
WRAPPER_FUNCTION(85);
WRAPPER_FUNCTION(86);
WRAPPER_FUNCTION(87);
WRAPPER_FUNCTION(88);
WRAPPER_FUNCTION(89);
WRAPPER_FUNCTION(90);
WRAPPER_FUNCTION(91);
WRAPPER_FUNCTION(92);
WRAPPER_FUNCTION(93);
WRAPPER_FUNCTION(94);
WRAPPER_FUNCTION(95);
WRAPPER_FUNCTION(96);
WRAPPER_FUNCTION(97);
WRAPPER_FUNCTION(98);
WRAPPER_FUNCTION(99);


WRAPPER_FUNCTION(100);
WRAPPER_FUNCTION(101);
WRAPPER_FUNCTION(102);
WRAPPER_FUNCTION(103);
WRAPPER_FUNCTION(104);
WRAPPER_FUNCTION(105);
WRAPPER_FUNCTION(106);
WRAPPER_FUNCTION(107);
WRAPPER_FUNCTION(108);
WRAPPER_FUNCTION(109);
WRAPPER_FUNCTION(110);
WRAPPER_FUNCTION(111);
WRAPPER_FUNCTION(112);
WRAPPER_FUNCTION(113);
WRAPPER_FUNCTION(114);
WRAPPER_FUNCTION(115);
WRAPPER_FUNCTION(116);
WRAPPER_FUNCTION(117);
WRAPPER_FUNCTION(118);
WRAPPER_FUNCTION(119);
WRAPPER_FUNCTION(120);
WRAPPER_FUNCTION(121);
WRAPPER_FUNCTION(122);
WRAPPER_FUNCTION(123);
WRAPPER_FUNCTION(124);
WRAPPER_FUNCTION(125);
WRAPPER_FUNCTION(126);
WRAPPER_FUNCTION(127);
WRAPPER_FUNCTION(128);
WRAPPER_FUNCTION(129);
WRAPPER_FUNCTION(130);
WRAPPER_FUNCTION(131);
WRAPPER_FUNCTION(132);
WRAPPER_FUNCTION(133);
WRAPPER_FUNCTION(134);
WRAPPER_FUNCTION(135);
WRAPPER_FUNCTION(136);
WRAPPER_FUNCTION(137);
WRAPPER_FUNCTION(138);
WRAPPER_FUNCTION(139);
WRAPPER_FUNCTION(140);
WRAPPER_FUNCTION(141);
WRAPPER_FUNCTION(142);
WRAPPER_FUNCTION(143);
WRAPPER_FUNCTION(144);
WRAPPER_FUNCTION(145);
WRAPPER_FUNCTION(146);
WRAPPER_FUNCTION(147);
WRAPPER_FUNCTION(148);
WRAPPER_FUNCTION(149);

WRAPPER_FUNCTION(150);
WRAPPER_FUNCTION(151);
WRAPPER_FUNCTION(152);
WRAPPER_FUNCTION(153);
WRAPPER_FUNCTION(154);
WRAPPER_FUNCTION(155);
WRAPPER_FUNCTION(156);
WRAPPER_FUNCTION(157);
WRAPPER_FUNCTION(158);
WRAPPER_FUNCTION(159);
WRAPPER_FUNCTION(160);
WRAPPER_FUNCTION(161);
WRAPPER_FUNCTION(162);
WRAPPER_FUNCTION(163);
WRAPPER_FUNCTION(164);
WRAPPER_FUNCTION(165);
WRAPPER_FUNCTION(166);
WRAPPER_FUNCTION(167);
WRAPPER_FUNCTION(168);
WRAPPER_FUNCTION(169);
WRAPPER_FUNCTION(170);
WRAPPER_FUNCTION(171);
WRAPPER_FUNCTION(172);
WRAPPER_FUNCTION(173);
WRAPPER_FUNCTION(174);
WRAPPER_FUNCTION(175);
WRAPPER_FUNCTION(176);
WRAPPER_FUNCTION(177);
WRAPPER_FUNCTION(178);
WRAPPER_FUNCTION(179);
WRAPPER_FUNCTION(180);
WRAPPER_FUNCTION(181);
WRAPPER_FUNCTION(182);
WRAPPER_FUNCTION(183);
WRAPPER_FUNCTION(184);
WRAPPER_FUNCTION(185);
WRAPPER_FUNCTION(186);
WRAPPER_FUNCTION(187);
WRAPPER_FUNCTION(188);
WRAPPER_FUNCTION(189);
WRAPPER_FUNCTION(190);
WRAPPER_FUNCTION(191);
WRAPPER_FUNCTION(192);
WRAPPER_FUNCTION(193);
WRAPPER_FUNCTION(194);
WRAPPER_FUNCTION(195);
WRAPPER_FUNCTION(196);
WRAPPER_FUNCTION(197);
WRAPPER_FUNCTION(198);
WRAPPER_FUNCTION(199);


WRAPPER_FUNCTION(200);
WRAPPER_FUNCTION(201);
WRAPPER_FUNCTION(202);
WRAPPER_FUNCTION(203);
WRAPPER_FUNCTION(204);
WRAPPER_FUNCTION(205);
WRAPPER_FUNCTION(206);
WRAPPER_FUNCTION(207);
WRAPPER_FUNCTION(208);
WRAPPER_FUNCTION(209);
WRAPPER_FUNCTION(210);
WRAPPER_FUNCTION(211);
WRAPPER_FUNCTION(212);
WRAPPER_FUNCTION(213);
WRAPPER_FUNCTION(214);
WRAPPER_FUNCTION(215);
WRAPPER_FUNCTION(216);
WRAPPER_FUNCTION(217);
WRAPPER_FUNCTION(218);
WRAPPER_FUNCTION(219);
WRAPPER_FUNCTION(220);
WRAPPER_FUNCTION(221);
WRAPPER_FUNCTION(222);
WRAPPER_FUNCTION(223);
WRAPPER_FUNCTION(224);
WRAPPER_FUNCTION(225);
WRAPPER_FUNCTION(226);
WRAPPER_FUNCTION(227);
WRAPPER_FUNCTION(228);
WRAPPER_FUNCTION(229);
WRAPPER_FUNCTION(230);
WRAPPER_FUNCTION(231);
WRAPPER_FUNCTION(232);
WRAPPER_FUNCTION(233);
WRAPPER_FUNCTION(234);
WRAPPER_FUNCTION(235);
WRAPPER_FUNCTION(236);
WRAPPER_FUNCTION(237);
WRAPPER_FUNCTION(238);
WRAPPER_FUNCTION(239);
WRAPPER_FUNCTION(240);
WRAPPER_FUNCTION(241);
WRAPPER_FUNCTION(242);
WRAPPER_FUNCTION(243);
WRAPPER_FUNCTION(244);
WRAPPER_FUNCTION(245);
WRAPPER_FUNCTION(246);
WRAPPER_FUNCTION(247);
WRAPPER_FUNCTION(248);
WRAPPER_FUNCTION(249);

WRAPPER_FUNCTION(250);
WRAPPER_FUNCTION(251);
WRAPPER_FUNCTION(252);
WRAPPER_FUNCTION(253);
WRAPPER_FUNCTION(254);
WRAPPER_FUNCTION(255);
WRAPPER_FUNCTION(256);
WRAPPER_FUNCTION(257);
WRAPPER_FUNCTION(258);
WRAPPER_FUNCTION(259);
WRAPPER_FUNCTION(260);
WRAPPER_FUNCTION(261);
WRAPPER_FUNCTION(262);
WRAPPER_FUNCTION(263);
WRAPPER_FUNCTION(264);
WRAPPER_FUNCTION(265);
WRAPPER_FUNCTION(266);
WRAPPER_FUNCTION(267);
WRAPPER_FUNCTION(268);
WRAPPER_FUNCTION(269);
WRAPPER_FUNCTION(270);
WRAPPER_FUNCTION(271);
WRAPPER_FUNCTION(272);
WRAPPER_FUNCTION(273);
WRAPPER_FUNCTION(274);
WRAPPER_FUNCTION(275);
WRAPPER_FUNCTION(276);
WRAPPER_FUNCTION(277);
WRAPPER_FUNCTION(278);
WRAPPER_FUNCTION(279);
WRAPPER_FUNCTION(280);
WRAPPER_FUNCTION(281);
WRAPPER_FUNCTION(282);
WRAPPER_FUNCTION(283);
WRAPPER_FUNCTION(284);
WRAPPER_FUNCTION(285);
WRAPPER_FUNCTION(286);
WRAPPER_FUNCTION(287);
WRAPPER_FUNCTION(288);
WRAPPER_FUNCTION(289);
WRAPPER_FUNCTION(290);
WRAPPER_FUNCTION(291);
WRAPPER_FUNCTION(292);
WRAPPER_FUNCTION(293);
WRAPPER_FUNCTION(294);
WRAPPER_FUNCTION(295);
WRAPPER_FUNCTION(296);
WRAPPER_FUNCTION(297);
WRAPPER_FUNCTION(298);
WRAPPER_FUNCTION(299);

WRAPPER_FUNCTION(300);
WRAPPER_FUNCTION(301);
WRAPPER_FUNCTION(302);
WRAPPER_FUNCTION(303);
WRAPPER_FUNCTION(304);
WRAPPER_FUNCTION(305);
WRAPPER_FUNCTION(306);
WRAPPER_FUNCTION(307);
WRAPPER_FUNCTION(308);
WRAPPER_FUNCTION(309);
WRAPPER_FUNCTION(310);
WRAPPER_FUNCTION(311);
WRAPPER_FUNCTION(312);
WRAPPER_FUNCTION(313);
WRAPPER_FUNCTION(314);
WRAPPER_FUNCTION(315);
WRAPPER_FUNCTION(316);
WRAPPER_FUNCTION(317);
WRAPPER_FUNCTION(318);
WRAPPER_FUNCTION(319);
WRAPPER_FUNCTION(320);
WRAPPER_FUNCTION(321);
WRAPPER_FUNCTION(322);
WRAPPER_FUNCTION(323);
WRAPPER_FUNCTION(324);
WRAPPER_FUNCTION(325);
WRAPPER_FUNCTION(326);
WRAPPER_FUNCTION(327);
WRAPPER_FUNCTION(328);
WRAPPER_FUNCTION(329);
WRAPPER_FUNCTION(330);
WRAPPER_FUNCTION(331);
WRAPPER_FUNCTION(332);
WRAPPER_FUNCTION(333);
WRAPPER_FUNCTION(334);
WRAPPER_FUNCTION(335);
WRAPPER_FUNCTION(336);
WRAPPER_FUNCTION(337);
WRAPPER_FUNCTION(338);
WRAPPER_FUNCTION(339);
WRAPPER_FUNCTION(340);
WRAPPER_FUNCTION(341);
WRAPPER_FUNCTION(342);
WRAPPER_FUNCTION(343);
WRAPPER_FUNCTION(344);
WRAPPER_FUNCTION(345);
WRAPPER_FUNCTION(346);
WRAPPER_FUNCTION(347);
WRAPPER_FUNCTION(348);
WRAPPER_FUNCTION(349);

WRAPPER_FUNCTION(350);
WRAPPER_FUNCTION(351);
WRAPPER_FUNCTION(352);
WRAPPER_FUNCTION(353);
WRAPPER_FUNCTION(354);
WRAPPER_FUNCTION(355);
WRAPPER_FUNCTION(356);
WRAPPER_FUNCTION(357);
WRAPPER_FUNCTION(358);
WRAPPER_FUNCTION(359);
WRAPPER_FUNCTION(360);
WRAPPER_FUNCTION(361);
WRAPPER_FUNCTION(362);
WRAPPER_FUNCTION(363);
WRAPPER_FUNCTION(364);
WRAPPER_FUNCTION(365);
WRAPPER_FUNCTION(366);
WRAPPER_FUNCTION(367);
WRAPPER_FUNCTION(368);
WRAPPER_FUNCTION(369);
WRAPPER_FUNCTION(370);
WRAPPER_FUNCTION(371);
WRAPPER_FUNCTION(372);
WRAPPER_FUNCTION(373);
WRAPPER_FUNCTION(374);
WRAPPER_FUNCTION(375);
WRAPPER_FUNCTION(376);
WRAPPER_FUNCTION(377);
WRAPPER_FUNCTION(378);
WRAPPER_FUNCTION(379);
WRAPPER_FUNCTION(380);
WRAPPER_FUNCTION(381);
WRAPPER_FUNCTION(382);
WRAPPER_FUNCTION(383);
WRAPPER_FUNCTION(384);
WRAPPER_FUNCTION(385);
WRAPPER_FUNCTION(386);
WRAPPER_FUNCTION(387);
WRAPPER_FUNCTION(388);
WRAPPER_FUNCTION(389);
WRAPPER_FUNCTION(390);
WRAPPER_FUNCTION(391);
WRAPPER_FUNCTION(392);
WRAPPER_FUNCTION(393);
WRAPPER_FUNCTION(394);
WRAPPER_FUNCTION(395);
WRAPPER_FUNCTION(396);
WRAPPER_FUNCTION(397);
WRAPPER_FUNCTION(398);
WRAPPER_FUNCTION(399);


WRAPPER_FUNCTION(400);
WRAPPER_FUNCTION(401);
WRAPPER_FUNCTION(402);
WRAPPER_FUNCTION(403);
WRAPPER_FUNCTION(404);
WRAPPER_FUNCTION(405);
WRAPPER_FUNCTION(406);
WRAPPER_FUNCTION(407);
WRAPPER_FUNCTION(408);
WRAPPER_FUNCTION(409);
WRAPPER_FUNCTION(410);
WRAPPER_FUNCTION(411);
WRAPPER_FUNCTION(412);
WRAPPER_FUNCTION(413);
WRAPPER_FUNCTION(414);
WRAPPER_FUNCTION(415);
WRAPPER_FUNCTION(416);
WRAPPER_FUNCTION(417);
WRAPPER_FUNCTION(418);
WRAPPER_FUNCTION(419);
WRAPPER_FUNCTION(420);
WRAPPER_FUNCTION(421);
WRAPPER_FUNCTION(422);
WRAPPER_FUNCTION(423);
WRAPPER_FUNCTION(424);
WRAPPER_FUNCTION(425);
WRAPPER_FUNCTION(426);
WRAPPER_FUNCTION(427);
WRAPPER_FUNCTION(428);
WRAPPER_FUNCTION(429);
WRAPPER_FUNCTION(430);
WRAPPER_FUNCTION(431);
WRAPPER_FUNCTION(432);
WRAPPER_FUNCTION(433);
WRAPPER_FUNCTION(434);
WRAPPER_FUNCTION(435);
WRAPPER_FUNCTION(436);
WRAPPER_FUNCTION(437);
WRAPPER_FUNCTION(438);
WRAPPER_FUNCTION(439);
WRAPPER_FUNCTION(440);
WRAPPER_FUNCTION(441);
WRAPPER_FUNCTION(442);
WRAPPER_FUNCTION(443);
WRAPPER_FUNCTION(444);
WRAPPER_FUNCTION(445);
WRAPPER_FUNCTION(446);
WRAPPER_FUNCTION(447);
WRAPPER_FUNCTION(448);
WRAPPER_FUNCTION(449);

WRAPPER_FUNCTION(450);
WRAPPER_FUNCTION(451);
WRAPPER_FUNCTION(452);
WRAPPER_FUNCTION(453);
WRAPPER_FUNCTION(454);
WRAPPER_FUNCTION(455);
WRAPPER_FUNCTION(456);
WRAPPER_FUNCTION(457);
WRAPPER_FUNCTION(458);
WRAPPER_FUNCTION(459);
WRAPPER_FUNCTION(460);
WRAPPER_FUNCTION(461);
WRAPPER_FUNCTION(462);
WRAPPER_FUNCTION(463);
WRAPPER_FUNCTION(464);
WRAPPER_FUNCTION(465);
WRAPPER_FUNCTION(466);
WRAPPER_FUNCTION(467);
WRAPPER_FUNCTION(468);
WRAPPER_FUNCTION(469);
WRAPPER_FUNCTION(470);
WRAPPER_FUNCTION(471);
WRAPPER_FUNCTION(472);
WRAPPER_FUNCTION(473);
WRAPPER_FUNCTION(474);
WRAPPER_FUNCTION(475);
WRAPPER_FUNCTION(476);
WRAPPER_FUNCTION(477);
WRAPPER_FUNCTION(478);
WRAPPER_FUNCTION(479);
WRAPPER_FUNCTION(480);
WRAPPER_FUNCTION(481);
WRAPPER_FUNCTION(482);
WRAPPER_FUNCTION(483);
WRAPPER_FUNCTION(484);
WRAPPER_FUNCTION(485);
WRAPPER_FUNCTION(486);
WRAPPER_FUNCTION(487);
WRAPPER_FUNCTION(488);
WRAPPER_FUNCTION(489);
WRAPPER_FUNCTION(490);
WRAPPER_FUNCTION(491);
WRAPPER_FUNCTION(492);
WRAPPER_FUNCTION(493);
WRAPPER_FUNCTION(494);
WRAPPER_FUNCTION(495);
WRAPPER_FUNCTION(496);
WRAPPER_FUNCTION(497);
WRAPPER_FUNCTION(498);
WRAPPER_FUNCTION(499);

