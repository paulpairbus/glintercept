/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __SHADER_MANAGER_H_
#define __SHADER_MANAGER_H_

#include "GLInterceptConfig.h"
#include "gl.h"
#include "FunctionTable.h"

#include <string>
#include <vector>

using namespace std;

class GLDriver;


//@
//  Summary:
//    Structure of data about a OpenGL shader
//  
class ShaderData
{
friend class ShaderManager;
public:

  //@
  //  Summary:
  //    To return true if the shader is dirty. 
  //    (ie. has changed since last save)
  //  
  inline bool IsDirty() const;

  //@
  //  Summary:
  //    To return true if the shader is ready to be saved. 
  //    (ie. has been initilized with some data)
  //  
  inline bool IsReady() const;

  //@
  //  Summary:
  //    To flag the shader as ready and sets that the shader can now be saved.
  //    (This call also flags the shader as dirty)
  //  
  //  Parameters:
  //    type  - The type of the shader that is now ready.
  //
  inline void SetReady(GLenum type);

  //@
  //  Summary:
  //    To set if the shader is dirty or not. This flag should be set when the 
  //    OpenGL shader changes and un-set when the shader is written out.
  //    (Each time the flag changes to true, the save count/dirty count of this
  //     shader is incremented)
  //  
  //  Parameters:
  //    flag  - Flag to indicate if this OpenGL shader is now dirty or not.
  //
  inline void SetDirty(bool flag);

  //@
  //  Summary:
  //    To get the OpenGL shader ID of this shader. Ensure the shader is ready
  //    (IsReady()) before calling. 
  //  
  //  Returns:
  //    The OpenGL shader ID assigned to this shader data is returned.
  //
  inline uint GetGLID() const;

  //@
  //  Summary:
  //    To get the OpenGL shader type. Ensure the shader is ready
  //    (IsReady()) before calling or 0 will be returned. 
  //  
  //  Returns:
  //    The OpenGL shader type assigned is returned.
  //
  inline GLenum GetGLType() const;

  //@
  //  Summary:
  //    To get a unique shader filename (including type,shaderID and savecount)
  //    without any extension. 
  //  
  //  Parameters:
  //    retString  - The string to return the unique name in.
  //
  //  Returns:
  //    If a unique string could be generated, true is returned. 
  //    Else false is returned.
  //
  bool GetUniqueFileName(string &retString) const;

  //@
  //  Summary:
  //    To get a reference to the filename that was used to save the 
  //    shader data out previously.
  //  
  //  Returns:
  //    A reference to the filename of saved shader data is returned.
  //
  inline string & GetShaderSaveFileName();


  //@
  //  Summary:
  //    To get the shaders' source string.
  //  
  //  Returns:
  //    The string containing the shaders' source is returned.
  //
  inline string & GetShaderSource();
  inline const string & GetShaderSource() const;

private:

  uint   id;         // The OpenGL ID
  GLenum glType;     // The OpenGL type of the shader

  bool   ready;      // Flag to indicate if the shader is ready (ie. has been uploaded)  
  bool   dirty;      // Flag to indicate if the shader data is dirty 
 
  bool   validID;    // Flag to indicate if the above OpenGL ID is to be considered valid. (ie. valid in the OpenGL state)

  string saveFileName; // File name that was used when the shader was last saved.

  string shaderSource; // The source string of the shader

  //@
  //  Summary:
  //    Constructor, inits all data to default values.
  //  
  ShaderData();

  //@
  //  Summary:
  //    To reset the shader to an not-ready and dirty state
  //    (does not reset the save count or shader ID)
  //  
  Reset();

};

//@
//  Summary:
//    This class maintains a list of shader data and controls 
//    adding/deleting and retrival of shader data.
//  
class ShaderManager
{
public:

  //@
  //  Summary:
  //    Constructor, inits all data to default values.
  //  
	ShaderManager();

  //@
  //  Summary:
  //    Destructor, destroys all array data and reports shader memory leaks.
  //  
  virtual ~ShaderManager();

  //@
  //  Summary:
  //    To get all the shaders that have been flagged as valid,ready and dirty. 
  //  
  //  Parameters:
  //    dirtyShaders  -  The array to return all the dirty shaders in.
  //
  void GetAllDirtyShaders(vector<ShaderData *> &dirtyShaders);

  //@
  //  Summary:
  //    To set all the shaders that are currently being tracked, as 
  //    dirty. (ie. needs saving)
  //  
  void SetAllShadersDirty();

  //@
  //  Summary:
  //    To add a new OpenGL shader ID to the list. The shader 
  //    added needs to be set to a "ready" state before it can be used.
  //  
  //  Parameters:
  //    glId  -  The OpenGL shader ID of the shader to add.
  //
  void AddShaderData(uint glId);

  //@
  //  Summary:
  //    To remove a shader from the shader list.
  //  
  //  Parameters:
  //    glId  -  The OpenGL shader ID of the shader to remove.
  //
  bool RemoveShaderData(uint glId);

  //@
  //  Summary:
  //    To get the shader data of the passed OpenGL shader ID.
  //  
  //  Parameters:
  //    shaderID  -  The OpenGL shader ID of the shader to find.
  //
  //  Returns:
  //    If the shader is found, it is returned. Else NULL is returned.
  //
  ShaderData * GetShaderData(GLint shaderID);

protected:

  vector<ShaderData> shaderDataArray;               // Array of shaders already loaded

};




///////////////////////////////////////////////////////////////////////////////
//
inline void ShaderData::SetReady(GLenum type)
{
  ready  = true;
  glType = type;

  //Set as dirty
  SetDirty(true);
}

///////////////////////////////////////////////////////////////////////////////
//
inline void ShaderData::SetDirty(bool flag)
{
  //Chcek if the flag is different
  if(flag != dirty && ready)
  {
    //Assign the dirty flag
    dirty = flag;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline uint ShaderData::GetGLID() const
{
  return id;
}

///////////////////////////////////////////////////////////////////////////////
//
inline GLenum ShaderData::GetGLType() const
{
  //Only return the stored type if a type has been set
  if(IsReady())
  {
    return glType;
  }

  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool ShaderData::IsDirty() const
{
  return dirty;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool ShaderData::IsReady() const
{
  return ready;
}


///////////////////////////////////////////////////////////////////////////////
//
inline string & ShaderData::GetShaderSaveFileName()
{
  return saveFileName;
}

///////////////////////////////////////////////////////////////////////////////
//
inline string & ShaderData::GetShaderSource()
{
  return shaderSource;
}

///////////////////////////////////////////////////////////////////////////////
//
inline const string & ShaderData::GetShaderSource() const
{
  return shaderSource;
}


#endif // __SHADER_MANAGER_H_
