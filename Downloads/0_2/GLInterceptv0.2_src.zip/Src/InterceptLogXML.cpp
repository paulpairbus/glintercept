/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLogXML.h"
#include "GLDriver.h"
#include "FileUtils.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;


///////////////////////////////////////////////////////////////////////////////
//
InterceptLogXML::InterceptLogXML(const char *fileName,FunctionTable * functionTable,const ConfigData &configData, 
                                 const string &newXSLFileName):
InterceptLog(fileName,functionTable,configData),
frameRenderCallLog(configData.frameLogEnabled),
xslFileName(newXSLFileName)
{

}



///////////////////////////////////////////////////////////////////////////////
//
InterceptLogXML::~InterceptLogXML()
{

  //Write the closing tags
  fprintf(logFile,"</FUNCTIONS>\n");
  fprintf(logFile,"</GLINTERCEPT>\n");
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLogXML::Init()
{
  //Attempt to open the file
  logFile = fopen(logFileName.c_str(),"wt");

  //Prevent NULL file settings
  if(logFile == NULL)
  {
    LOGERR(("InterceptLogXML - Unable to open log file %s",logFileName.c_str()));
    return false;
  }

  //Write the XML version info
  fprintf(logFile,"<?xml version='1.0'?>\n");

  //Add the XSL file name if applicable
  if(xslFileName.size() > 0)
  {
    fprintf(logFile,"<?xml-stylesheet type=\"text/xsl\" href=\"%s\"?>",xslFileName.c_str());
  }

  //Write the header
  fprintf(logFile,"<GLINTERCEPT>\n");

  //Write the header data
  fprintf(logFile,"<HEADER>\n");

  //Write the version
  fprintf(logFile,"<VERSION>%s</VERSION>\n",__GLI_BUILD_VER_STR);

  //Write the time stamp
  struct tm *newtime;
  time_t     aclock;

  //Get the current time
  time( &aclock );

  //Convert it
  newtime = localtime( &aclock );
  fprintf(logFile,"<TIMESTAMP>%s</TIMESTAMP>\n",asctime(newtime));

  //Close the header
  fprintf(logFile,"</HEADER>\n");

  //Open the function data
  fprintf(logFile,"<FUNCTIONS>\n");

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogXML::LogFunctionPre - Function data for index %d is NULL",index)); 
    return;
  }

  //Write the starting tag
  fprintf(logFile,"<FUNCTION>\n");

  //Write the name
  fprintf(logFile,"<NAME>%s</NAME>\n",funcData->functionName.c_str());

  //Loop for all the parameters
  for(uint i=0;i<funcData->parameterArray.size();i++)
  {
    //Get the parameter
    const ParameterData * paramData = &funcData->parameterArray[i];

    //Determine if we are processing pointers
    bool isPointer=false;
    if(paramData->pointerCount > 0 || paramData->length != -1)
    {
      isPointer=true;
    }

    //Get the value
    void *value;
    if(!GetNextValue(paramData->GetGLType(),&args,isPointer,&value))
    {
      break;
    }

    //Write the parameter tag
    fprintf(logFile,"<PARAM name=\"%s\" type=\"%s\">",paramData->paramName.c_str(),paramData->GetDisplayString().c_str());

    //Test if this is an array value
    if(paramData->length != -1)
    {
      bool isArrayOfPointers = false;

      //Test for an array of pointers
      if(paramData->pointerCount > 0)
      {
        isArrayOfPointers = true;
      }

      //Assign the array
      void * array =  *((void **)value);

      //Loop and print the array
      for(uint i2=0;i2<paramData->length;i2++)
      {
        //Get the value from the array
        if(!GetNextArrayValue(paramData->GetGLType(),&array,isArrayOfPointers,&value))
        {
          break;
        }
      
        //Convert and print the value
        string out=ConvertParam(value,isArrayOfPointers,paramData);
        fprintf(logFile,"<VALUE data=\"%s\"/>",out.c_str());
      }
      fprintf(logFile,"</PARAM>\n");
    }
    else
    {
      //Just get the single value
      string out=ConvertParam(value,isPointer,paramData);
      fprintf(logFile,"<VALUE data=\"%s\"/></PARAM>",out.c_str());
    }

  }

  //Start a new line
  fprintf(logFile,"\n");

  //Reset the argument list
  va_end(args);


  //If this is an rendering function
  if(funcData->functionFlags & FDF_RENDER_FUNC)
  {
    //If we log shaders on render calls, log them
    if(shaderRenderCallLog)
    {
      //Get the bound shaders
      uint vertexShader,fragmentShader;
      glDriver.GetBoundShaders(vertexShader,fragmentShader);

      //If a valid vertex shader, log it
      if(vertexShader != 0)
      {
        AddShaderTag(vertexShader,"VP");
      }

      if(fragmentShader != 0)
      {
        AddShaderTag(fragmentShader,"FP");
      }
    }

    //If we log images on render calls, log them
    if(imageRenderCallLog)
    {
      //Get the bound textures
      BoundTextureArray boundTextures;
      glDriver.GetBoundTextures(boundTextures);

      //If there are any textures
      if(boundTextures.size() > 0)
      {
        //Loop for all textures and log the stage and texture number
        for(uint i=0;i<boundTextures.size();i++)
        {
          fprintf(logFile,"<TEXSTAGE number=\"%u\">",boundTextures[i].texStage);
          AddImageTag(boundTextures[i].texID);
          fprintf(logFile,"</TEXSTAGE>",boundTextures[i].texStage);
        }
      }
    }

    // Register frame buffer images if requested
    if(frameRenderCallLog)
    {
      //Get the frame file names
      FrameInterceptFileNames frameFileNames;
      if(glDriver.GetFrameFileNames(frameFileNames))
      {
        //Add all valid tags
        fprintf(logFile,"<FRAMEBUFFER>");
        AddFrameTag("PRE",frameFileNames.preColorName);
        AddFrameTag("POST",frameFileNames.postColorName);
        AddFrameTag("DIFF",frameFileNames.diffColorName);

        AddFrameTag("PRE",frameFileNames.preZName);
        AddFrameTag("POST",frameFileNames.postZName);   
        AddFrameTag("DIFF",frameFileNames.diffZName);   
        fprintf(logFile,"</FRAMEBUFFER>");
      }
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{

  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogXML::LogFunctionPost - Function data for index %d is NULL",index)); 
    return;
  }

  //Get the return parameter
  const ParameterData * returnData = &funcData->returnType;

  //Determine if we are processing pointers
  bool isPointer=false;
  if(returnData->pointerCount > 0)
  {
    isPointer=true;
  }

  //Check for a return value of a supported type
  // NOTE: Does not currently support arrays
  if(isPointer || 
     returnData->type == PT_enum     ||
     returnData->type == PT_boolean  ||
     returnData->type == PT_bitfield ||
     returnData->type == PT_byte     ||
     returnData->type == PT_short    ||
     returnData->type == PT_int      || 
     returnData->type == PT_ubyte    ||
     returnData->type == PT_ushort   ||
     returnData->type == PT_uint     ||
     returnData->type == PT_handle   ||
     returnData->type == PT_sizei    ||
     returnData->type == PT_float    ||
     returnData->type == PT_clampf)
  {
    //Check the return value
    if(retVal != NULL)
    {
      //Look up the data
      string out = ConvertParam(retVal, isPointer, returnData);

      //Log the result
      fprintf(logFile,"<RETURN type=\"%s\">",returnData->GetDisplayString().c_str());
      fprintf(logFile,"<VALUE data=\"%s\"/></RETURN>\n",out.c_str());
    }
  }


}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionError(uint errorCode)
{
  //If the log is not writing or the error code is 0, return
  if(!logEnabled || errorCode == 0x0)
  {
    return;
  }

  //If we do no have a pointer to glGetError yet, get it
  if(glGetErrorFuncData == NULL)
  {
    //Get the index of the function
    int index =functionTable->FindFunction("glGetError");
    if(index != -1)
    {
      //Get the function data
      glGetErrorFuncData = functionTable->GetFunctionData(index);
    }
  }

  //Log that an error has occured
  fprintf(logFile,"<ERROR>");

  //If the function is still not found, just log the number
  if(glGetErrorFuncData == NULL || glGetErrorFuncData->returnType.type != PT_enum)
  {
    fprintf(logFile,"<VALUE data=\"0x%04x\"/>",errorCode);
  }
  else
  {
    //Get the return parameter
    const ParameterData * returnData = &glGetErrorFuncData->returnType;

    //Get the string version    
    string out = ConvertParam(&errorCode, false, returnData);

    //Log the result
    fprintf(logFile,"<VALUE data=\"%s\"/>",out.c_str());
  }

  fprintf(logFile,"</ERROR>");

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::LogFunctionComplete()
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Complete the function
  fprintf(logFile,"</FUNCTION>\n"); 
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLogXML::ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString)
{
  //A character buffer
  static char buffer[100];

  //Determine the type
  switch(paramData->type)
  {
    case(PT_image_index):
      {
        //Get the index number
        uint num = *((uint*)data);
        sprintf(buffer,"%u",num);
        retString = buffer;

        //Add the image tag
        AddImageTag(num);
        break;
      }

    case(PT_shader_index):
      {
        //Get the index number
        uint num = *((uint*)data);
        sprintf(buffer,"%u",num);
        retString = buffer;

        //Get the associated shader
        AddShaderTag(num);
        break;
      }
  }


  //Call base class
  if(InterceptLog::ConvertCustomParam(data,isPointer,paramData,retString))
  {
    //Strip the returned string of inavlid characters 
    ConvertStringXML(retString);
    return true;
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddImageTag(uint texID)
{
  //Get the file names for the texture
  ImageSaveFiles imageFiles;
  if(glDriver.GetTextureFileNames(texID,imageFiles))
  {
    //Write out an image tag
    fprintf(logFile,"<IMAGE id=\"%u\"",texID);

    //Write the file name
    if(imageFiles.imageFileNames.size() > 0)
    {
      //Format the image name and print it
      ConvertFileNameXML(imageFiles.imageFileNames[0]);
      fprintf(logFile," name=\"%s\" ",imageFiles.imageFileNames[0].c_str()); 
    }

    //Write the icon name
    if(imageFiles.iconName.length() > 0)
    {
      //Format the icon name and print it
      ConvertFileNameXML(imageFiles.iconName);
      fprintf(logFile," icon=\"%s\" ",imageFiles.iconName.c_str());
    }

    fprintf(logFile,"/>"); 

    //Additional images are saved without the icon
    for(uint i=1;i<imageFiles.imageFileNames.size();i++)
    {
      //Format the icon name and print it
      ConvertFileNameXML(imageFiles.imageFileNames[i]);
      fprintf(logFile,"<IMAGE name=\"%s\" />",imageFiles.imageFileNames[i].c_str()); 
    }
  }
  else
  {
    //Write out an image tag with only the ID
    fprintf(logFile,"<IMAGE id=\"%u\" />",texID);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddShaderTag(uint shaderID,string type)
{
  string shaderName;
  if(glDriver.GetShaderFileName(shaderID,shaderName))
  {
    //Convert the file name 
    ConvertFileNameXML(shaderName);
    if(shaderName.length() > 0)
    {
      //Check for a known type
      if(type != "")
      {
        //Write out a shader tag
        fprintf(logFile,"<SHADER id=\"%u\" type=\"%s\" name=\"%s\"/>",shaderID,type.c_str(),shaderName.c_str());
      }
      else
      {
        //Write out a shader tag
        fprintf(logFile,"<SHADER id=\"%u\" name=\"%s\"/>",shaderID,shaderName.c_str());
      }
    }
  }
  else
  {
    //Check for a known type
    if(type != "")
    {
      //Write out an shader tag with type and ID
      fprintf(logFile,"<SHADER id=\"%u\"  />",shaderID,type.c_str());
    }
    else
    {
      //Write out an shader tag with only the ID
      fprintf(logFile,"<SHADER id=\"%u\" />",shaderID);
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::AddFrameTag(const string &tagID, const string &filename)
{
  //Only proceed if the file name has a length
  if(filename.length() > 0)
  {
    //Convert the file name and write it out
    string convertName = filename;
    ConvertFileNameXML(convertName);
    fprintf(logFile,"<%s image=\"%s\" />",tagID.c_str(),convertName.c_str());    
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::ConvertStringXML(string &convertStr)
{
  string retString;
  retString.reserve(convertStr.length()+5);

  //Loop for all characters
  for(uint i=0;i<convertStr.length();i++)
  {
    //Replace all quotes with a XML quote tag
    if(convertStr[i] == '"')
    {
      retString+="&quot;";  
    }
    else
    {
      retString+=convertStr[i];  
    }
  }

  convertStr = retString;
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogXML::ConvertFileNameXML(string &convertFileName)
{
  //Get the path of this string
  int pathEnd = logFileName.rfind(FileUtils::dirSeparator);
  if(pathEnd != string::npos)
  {
    //Get the path
    string filePath = logFileName;
    filePath.erase(pathEnd+1,filePath.size()-pathEnd-1);

    //If the entire path is at the start of this string
    if(convertFileName.find(filePath,0) == 0)
    {
      //Strip the path
      convertFileName.erase(0,filePath.size());
    }
  }

  //Convert all back slashes to forward slashes
  //  (some XML browsers do not like back slashes)
  for(uint i=0;i<convertFileName.size();i++)
  {
    if(convertFileName[i] == '\\')
    {
      convertFileName[i] = '/';
    }
  }

}

