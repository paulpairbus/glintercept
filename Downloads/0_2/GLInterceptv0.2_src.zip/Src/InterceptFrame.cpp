/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptFrame.h"
#include "GLDriver.h"



USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
FrameInterceptFileNames::FrameInterceptFileNames()
{
  //Reset
  Reset();
}

///////////////////////////////////////////////////////////////////////////////
//
void FrameInterceptFileNames::Reset()
{
  //Set all file names to be empty
  preColorName  = "";
  postColorName = "";
  diffColorName = "";

  preZName  = "";
  postZName = "";
  diffZName = "";
}


///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::InterceptFrame(GLDriver *ogldriver,FunctionTable * functionTable,const ConfigData &configData):
driver(ogldriver),
frameSavingEnabled(false),
frameSavePath(""),
inBeginEndSection(false),
preColorData(NULL),
postColorData(NULL),
diffColorData(NULL),
preZData(NULL),
postZData(NULL),
diffZData(NULL),

imageExtension(configData.frameImageFormat),

savePreColor(configData.framePreColorSave),
savePostColor(configData.framePostColorSave),
saveDiffColor(configData.frameDiffColorSave),

savePreDepth(configData.framePreDepthSave),
savePostDepth(configData.framePostDepthSave),
saveDiffDepth(configData.frameDiffDepthSave)

{

}

///////////////////////////////////////////////////////////////////////////////
//
InterceptFrame::~InterceptFrame()
{
  //Delete any buffers
  ResetBuffers();
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::ResetBuffers()
{
  //Delete any outstanding data
  if(preColorData)
  { 
    delete preColorData;
    preColorData = NULL;
  }
  if(postColorData)
  { 
    delete postColorData;
    postColorData = NULL;
  }
  if(diffColorData)
  {
    delete diffColorData;
    diffColorData = NULL;
  }

  if(preZData)
  { 
    delete preZData;
    preZData = NULL;
  }
  if(postZData)
  { 
    delete postZData;
    postZData = NULL;
  }
  if(diffZData)
  {
    delete diffZData;
    diffZData = NULL;
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //A character buffer
  static char buffer[100];

  //Return if GL calls cannot be made  or it is not a render function
  if(!driver->GetInternalGLCallMode() || !(funcData->functionFlags & FDF_RENDER_FUNC))
  {
    return;
  }

  //Clear old file names
  saveFileNames.Reset();

  //Only proceed if frame saving is enabled
  if(!frameSavingEnabled)
  {
    return;
  }

  //If in a begin/end block, set the flag
  if(funcData->functionName == "glBegin")
  {
    inBeginEndSection = true;
  }
  
  //Store a unique save count number
  static uint saveCount=0;
  saveCount++;
  sprintf(buffer,"%04u_%04u_",driver->GetFrameNumber(),saveCount);

  //Assign color buffer names
  if(savePreColor)
  {
    saveFileNames.preColorName  = frameSavePath + "Frame_" + buffer + "Pre." + imageExtension;
  }
  if(savePostColor)
  {
    saveFileNames.postColorName = frameSavePath + "Frame_" + buffer + "Post." + imageExtension;
  }
  if(saveDiffColor)
  {
    saveFileNames.diffColorName = frameSavePath + "Frame_" + buffer + "Diff." + imageExtension;
  }

  //Assign z buffer names
  if(savePreDepth)
  {
    saveFileNames.preZName  = frameSavePath + "Frame_Z_" + buffer + "Pre." + imageExtension;
  }
  if(savePostDepth)
  {
    saveFileNames.postZName = frameSavePath + "Frame_Z_" + buffer + "Post." + imageExtension;
  }
  if(saveDiffDepth)
  {
    saveFileNames.diffZName = frameSavePath + "Frame_Z_" + buffer + "Diff." + imageExtension;
  }

  //Get the pre-buffers
  if(savePreColor || saveDiffColor)
  {
    preColorData = GetBuffer(GL_RGBA);
  }
  if(savePreDepth || saveDiffDepth)
  {
    preZData = GetBuffer(GL_DEPTH_COMPONENT);
  }



  //Save the pre-buffers
  if(preColorData && saveFileNames.preColorName.length() > 0)
  {
    SaveBuffer(saveFileNames.preColorName,preColorData);
  }
  if(preZData && saveFileNames.preZName.length() > 0)
  {
    SaveBuffer(saveFileNames.preZName,preZData);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptFrame::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{
  //Return if GL calls cannot be made 
  if(!driver->GetInternalGLCallMode())
  {
    return;  
  }

  //Only proceed if frame saving is enabled
  if(!frameSavingEnabled)
  {
    return;
  }

  //Return now if not a render function or not a ending begin/end section
  if(!((funcData->functionFlags & FDF_RENDER_FUNC) || 
       (inBeginEndSection && funcData->functionName == "glEnd")))
  {
    return;
  }

  //Reset the flag
  inBeginEndSection = false;

  //Get the post buffers
  if(savePostColor || saveDiffColor)
  {
    postColorData = GetBuffer(GL_RGBA);
  }
  if(savePostDepth || saveDiffDepth)
  {
    postZData = GetBuffer(GL_DEPTH_COMPONENT);
  }


  //Calculate the diffs
  if(saveDiffColor)
  {
    diffColorData = CalculateImageDiff(preColorData,postColorData);
  }
  if(saveDiffDepth)
  {
    diffZData = CalculateImageDiff(preZData,postZData);
  }


  //Save post buffers
  if(postColorData && saveFileNames.postColorName.length() > 0)
  {
    SaveBuffer(saveFileNames.postColorName,postColorData);
  }
  if(postZData && saveFileNames.postZName.length() > 0)
  {
    SaveBuffer(saveFileNames.postZName,postZData);
  }



  //Save diffs
  if(diffColorData && saveFileNames.diffColorName.length() > 0)
  {
    SaveBuffer(saveFileNames.diffColorName,diffColorData);
  }
  if(diffZData && saveFileNames.diffZName.length() > 0)
  {
    SaveBuffer(saveFileNames.diffZName,diffZData);
  }

  //Reset all buffers
  ResetBuffers();
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptFrame::SaveBuffer(const string &fileName,corona::Image * saveBuffer) const
{
  //Write the file out
  if(!corona::SaveImage(fileName.c_str(),corona::FF_AUTODETECT,saveBuffer))
  {
    LOGERR(("InterceptFrame::SaveBuffer - Unable to save image %s",fileName.c_str()));
    return false;
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
corona::Image *InterceptFrame::GetBuffer(GLenum bufType) const
{
  //Get the size of the viewport
  GLint viewSize[4];
  GLV.glGetIntegerv(GL_VIEWPORT,&viewSize[0]);

  //If the viewport does not have a size, return NULL
  if(viewSize[2] == 0 || viewSize[3] == 0)
  {
    return NULL;
  }

  //Allocate the return image
  corona::Image * newImage = corona::CreateImage(viewSize[2],viewSize[3],corona::PF_R8G8B8A8);
  if(!newImage)
  {
    return NULL;
  }

  //Get the current read buffer type

  //TODO: Set the back buffer if necessary

  //TODO: what about stereo or single buffered displays?

  //Set pixel transfer modes
  GLV.glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);

  //Set the required pack operations
  GLV.glPixelStorei(GL_PACK_ALIGNMENT,  1); 
  GLV.glPixelStorei(GL_PACK_LSB_FIRST,  0); 

  GLV.glPixelStorei(GL_PACK_ROW_LENGTH, 0); 
  GLV.glPixelStorei(GL_PACK_SKIP_PIXELS,0); 
  
  GLV.glPixelStorei(GL_PACK_SKIP_ROWS,  0); 
  GLV.glPixelStorei(GL_PACK_SWAP_BYTES, 0); 

  //Read the data based on the buffer type
  if(bufType == GL_RGBA)
  {
    //Read the pixels //TODO: What about ARB imaging modifying the return values?
    GLV.glReadPixels(viewSize[0],viewSize[1],viewSize[2],viewSize[3],bufType,GL_UNSIGNED_BYTE,newImage->getPixels());
  }
  else if(bufType == GL_DEPTH_COMPONENT)
  {
    //Allocate a retrieval array
    GLubyte * depthBuffer = new GLubyte[(viewSize[2] *viewSize[3])];
    
    //Read the pixels 
    GLV.glReadPixels(viewSize[0],viewSize[1],viewSize[2],viewSize[3],bufType,GL_UNSIGNED_BYTE,&depthBuffer[0]);

    //Pack the return data into the array
    GLubyte * srcImg   = &depthBuffer[0];
    GLubyte * dstImg   = (GLubyte *)newImage->getPixels();
    for(uint i=0;i<newImage->getWidth()*newImage->getHeight();i++)
    {
      //Copy the data
      dstImg[0] = *srcImg;
      dstImg[1] = *srcImg;
      dstImg[2] = *srcImg;
      dstImg[3] = 0xFF;

      //Increment the counters
      dstImg+=4;
      srcImg++;
    }

    //Delete the array
    delete [] depthBuffer;
  }

  //Restore transfer mode
  GLV.glPopClientAttrib();

  //TODO: Restore the read buffer


  //Flip the image 
  corona::FlipImage(newImage,corona::CA_X);

  //Return the image
  return newImage;

}

///////////////////////////////////////////////////////////////////////////////
//
corona::Image *InterceptFrame::CalculateImageDiff(corona::Image * src1,corona::Image * src2) const
{
  //If the image sizes are not the same, return 
  if(!src1 || !src2 ||
     src1->getWidth() != src2->getWidth() ||
     src1->getHeight() != src2->getHeight() ||
     src1->getFormat() != corona::PF_R8G8B8A8 || src2->getFormat() != corona::PF_R8G8B8A8)
  {
    LOGERR(("InterceptFrame::CalculateImageDiff - Invalid width/height/format"));
    return NULL;
  }

  //Create a new image of the requested dimensions
  corona::Image * newImage = corona::CreateImage(src1->getWidth(),src1->getHeight(),corona::PF_R8G8B8A8);
  if(!newImage)
  {
    return NULL;
  }

  //Flag to indcate if the images are identical
  bool noDiff = true;

  //Get the starting pointers
  udword * src1Img  = (udword *)src1->getPixels();
  udword * src2Img  = (udword *)src2->getPixels();
  udword * dstImg   = (udword *)newImage->getPixels();

  //Loop for all image elements
  for(uint i=0; i<newImage->getWidth()*newImage->getHeight();i++)
  {
    //Check if the images are different
    if(*src1Img != *src2Img)
    {
      //Assign the destination from the second image for a difference
      *dstImg = *src2Img;
      noDiff  = false;
    }
    else
    {
      //Just assign green 
      *dstImg =  0x0000FF00;
    }

    //Increment counters
    src1Img++; 
    src2Img++;
    dstImg++; 
  } 

  //If there was no difference, assign all red
  if(noDiff)
  {
    //Reset the counter and loop for all pixels
    udword * dstImg = (udword *)newImage->getPixels();
    for(uint i=0; i<newImage->getWidth()*newImage->getHeight();i++)
    {
      //Just assign red
      *dstImg =  0x000000FF;
      dstImg++; 
    }
  }
  
  return newImage;
}

