/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __INTERCEPT_FRAME_H_
#define __INTERCEPT_FRAME_H_

#include "GLInterceptConfig.h"
#include "gl.h"
#include "FunctionTable.h"
#include "ReferenceCount.h"
#include "ConfigData.h"
#include <Corona.h>

#include <string>
#include <vector>

using namespace std;


class GLDriver;

//@
//  Summary:
//    This structure holds the filnames of files saved by InterceptFrame
//  
struct FrameInterceptFileNames
{

  //@
  //  Summary:
  //    Constructor 
  //  
  FrameInterceptFileNames();

  //@
  //  Summary:
  //    Resets all filename to the emoty string
  //  
  void Reset();

  string preColorName;                            // The file name of the "pre" image from the color buffer
  string postColorName;                           // The file name of the "post" image from the color buffer 
  string diffColorName;                           // The file name of the "diff" image from the color buffer

  string preZName;                                // The file name of the "pre" image from the z buffer
  string postZName;                               // The file name of the "post" image from the z buffer
  string diffZName;                               // The file name of the "diff" image from the z buffer
 
};



//@
//  Summary:
//    This class intercepts OpenGL render calls and saves the frame buffer, 
//    into pre/post/diff images
//  
class InterceptFrame : public ReferenceCount
{
public:

  //@
  //  Summary:
  //    Constructor 
  //  
  //  Parameters:
  //    driver  - The driver used to make queries on the OpenGL state.
  //
  //    functionTable - The table of all functions that are known/are being logged.
  //
  //    configData    - The configuration options for frame interception.
  //
	InterceptFrame(GLDriver *driver,FunctionTable * functionTable,const ConfigData &configData);

  //@
  //  Summary:
  //    To log the passed function and function data 
  //    (Before the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  virtual void LogFunctionPre(const FunctionData *funcData,uint index, va_list args);

  //@
  //  Summary:
  //    To perform any post-call logging of a function.
  //    (After the actual function is called)
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - Pointer to the return value (if any).
  //
  virtual void LogFunctionPost(const FunctionData *funcData,uint index, void * retVal);
  
  //@
  //  Summary:
  //    To enable/disable frame saving. Ensure frame path is set before
  //    enabling.
  //  
  //  Parameters:
  //    flag - Flag to enable/disable frame saving.
  //
  inline void SetFrameSaving(bool flag);

  //@
  //  Summary:
  //    To get the frame saving state.
  //  
  //  Returns:
  //    The state of frame saving is returned.
  //
  inline bool GetFrameSaving();

  //@
  //  Summary:
  //    To set the path where frame images are saved (including trailing seperator)
  //  
  //  Parameters:
  //    newPath - The new path to save frame images to.
  //
  inline SetFrameSavingPath(const string &newPath);

  //@
  //  Summary:
  //    To get the path where frame images are saved (including trailing seperator)
  //  
  //  Returns:
  //    The path where frame images are saved is returned.
  //
  inline const string & GetFrameSavingPath()const;

  //@
  //  Summary:
  //    To get the last images saved by the previous render call. If a render 
  //    call was just made (and LogFunctionPre has been called), the file 
  //    names returned will be for the images to be saved. If the image name
  //    is empty, no image for that option is being saved.
  //  
  //  Parameters:
  //    fileNames  - The return structure of file name.
  //
  //  Returns:
  //    If frame saving is enabled, the file names and true are returned. 
  //    Else false is returned.
  //
  inline bool GetFrameFileNames(FrameInterceptFileNames &retFileNames);


protected:

  GLDriver *driver;                               // The OpenGL driver

  bool      frameSavingEnabled;                   // Flag to indicate if we are saving the frame buffer
  string    frameSavePath;                        // The path to save the frame buffer to (Including trailing seperator)
  string    imageExtension;                       // The extension of the file format to savine images in (ie jpg/tga/png)  
  bool      inBeginEndSection;                    // Flag to indicate if the current frame is from a begin/end section

  FrameInterceptFileNames saveFileNames;          // The structure of files to use when saving

  bool savePreColor;                              // Save pre-color frame images
  bool savePostColor;                             // Save post-color frame images
  bool saveDiffColor;                             // Save diff-color frame images

  bool savePreDepth;                              // Save pre-depth frame images
  bool savePostDepth;                             // Save post-depth frame images
  bool saveDiffDepth;                             // Save diff-depth frame images

  corona::Image *preColorData;                    // The "pre" render color buffer data
  corona::Image *postColorData;                   // The "post" render color buffer data
  corona::Image *diffColorData;                   // The diff color data

  corona::Image *preZData;                        // The "pre" render Z buffer data
  corona::Image *postZData;                       // The "post" render Z buffer data 
  corona::Image *diffZData;                       // The "diff" render Z buffer data 

  //@
  //  Summary:
  //    Destructor.
  // 
  virtual ~InterceptFrame();

  //@
  //  Summary:
  //    To get the OpenGL frame buffer for the specified option.
  //    If retrieval was successful, a image the size of the current
  //    viewport is returned.
  //  
  //  Parameters:
  //    bufType  - The buffer type to get. (ie GL_RGBA, GL_DEPTH_COMPONENT)
  //
  //  Returns:
  //    If the frame buffer for the specific type could be retrieved,
  //    it is returned. Else NULL is returned.
  //
  corona::Image *GetBuffer(GLenum bufType) const;

  //@
  //  Summary:
  //    To get save the passed image buffer to the specified filename.
  //  
  //  Parameters:
  //    fileName  - The file name (and extension) to save the buffer to.
  //
  //    saveBuffer  - The image buffer to write to the file name.
  //
  //  Returns:
  //    If saving was successful, true is returned. Else false is returned. 
  //
  bool SaveBuffer(const string &fileName,corona::Image * saveBuffer) const; 

  //@
  //  Summary:
  //    To get the difference between the passed image buffers.
  //  
  //  Parameters:
  //    src1  - The first compare buffer.
  //
  //    src2  - The second compare buffer.
  //
  //  Returns:
  //    If a difference image can be calculated, a new image containing 
  //    the differences is returned. Else NULL is returned.
  //
  corona::Image *CalculateImageDiff(corona::Image * src1,corona::Image * src2) const;

  //@
  //  Summary:
  //    To delete and reset all current frame image buffers.
  //  
  void ResetBuffers();

};


///////////////////////////////////////////////////////////////////////////////
//
inline bool InterceptFrame::GetFrameSaving()
{
  return frameSavingEnabled;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void InterceptFrame::SetFrameSaving(bool flag)
{
  //Test for flag change
  if(frameSavingEnabled != flag)
  {
    //Assign the flag
    frameSavingEnabled = flag;

    //Reset other flags
    inBeginEndSection = false;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline InterceptFrame::SetFrameSavingPath(const string &newPath)
{
  frameSavePath = newPath;
}

///////////////////////////////////////////////////////////////////////////////
//
inline const string & InterceptFrame::GetFrameSavingPath()const
{
  return frameSavePath;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool InterceptFrame::GetFrameFileNames(FrameInterceptFileNames &fileNames)
{
  //Only return true if we are frame saving
  if(frameSavingEnabled)
  {
    fileNames = saveFileNames;
    return true;
  }
  
  return false;
}


#endif // __INTERCEPT_FRAME_H_
