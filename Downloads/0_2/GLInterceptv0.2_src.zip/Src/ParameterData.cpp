/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "ParameterData.h"

//A look-up structure
struct LookupData
{
  LookupData(string strType,ParameterType glT):stringVersion(strType),glType(glT) {}

  string        stringVersion;                    // The string version of the type
  ParameterType glType;                           // The parameter version of the type 
};

LookupData ParamLookupArray[PT_Max_Params] =
{
  LookupData("GLenum",PT_enum),
  LookupData("GLboolean",PT_boolean),
  LookupData("GLbitfield",PT_bitfield),
  LookupData("GLvoid",PT_void),
  LookupData("GLbyte",PT_byte),
  LookupData("GLshort",PT_short),
  LookupData("GLint",PT_int),
  LookupData("GLubyte",PT_ubyte),
  LookupData("GLushort",PT_ushort),
  LookupData("GLuint",PT_uint),
  LookupData("GLsizei",PT_sizei),
  LookupData("GLfloat",PT_float),
  LookupData("GLclampf",PT_clampf),
  LookupData("GLdouble",PT_double),
  LookupData("GLclampd",PT_clampd),
  LookupData("GLhandle",PT_handle),

  //Custom types
  LookupData("GLasciistring",PT_ubyte),
  LookupData("GLimageindex",PT_uint),
  LookupData("GLshaderindex",PT_uint),
};


///////////////////////////////////////////////////////////////////////////////
//
ParameterData::ParameterData():
pointerCount(0),
type(PT_void),
length(-1),
index(-1)
{

}

///////////////////////////////////////////////////////////////////////////////
//
ParameterData::~ParameterData()
{

}

///////////////////////////////////////////////////////////////////////////////
//
bool ParameterData::AssignType(string typeStr)
{
  //"void" is a special type
  if(typeStr == "void")
  {
    type = PT_void;
    return true;
  }

  //TODO: make this a in-built type
  if(typeStr == "GLchar")
  {
    type = PT_ubyte;
    return true;
  }


  //Loop for all types
  for(uint i=0;i<PT_Max_Params;i++)
  {
    //Check for a match
    if(ParamLookupArray[i].stringVersion == typeStr)
    {
      //Assign the internal type
      type = (ParameterType)i;
      return true;
    }

  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
ParameterType ParameterData::GetGLType(ParameterType getType)
{
  //Return the OpenGL type
  return ParamLookupArray[getType].glType;
}


///////////////////////////////////////////////////////////////////////////////
//
string ParameterData::GetTypeString(ParameterType getType) const
{
  //Return a string version
  return ParamLookupArray[getType].stringVersion;
}


///////////////////////////////////////////////////////////////////////////////
//
string ParameterData::GetDisplayString() const
{
  //Get the OpenGL type
  ParameterType glType = GetGLType(type);

  //Get the type string
  string retString = GetTypeString(glType);

  //Get the pointer count
  for(uint i=0;i<pointerCount;i++)
  {
    retString = retString + "*";
  }

  //If there exists and array length, that is an additional pointer
  if(length != -1)
  {
    char buffer[100];
    retString = retString + string("[") + itoa(length,buffer,10) + string("]");
  }

  return retString;
}