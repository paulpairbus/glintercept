/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "GLInterceptConfig.h"
#include "GLDriver.h"


USING_ERRORLOG

#define DUMMY_LOG(name) LOGERR(("Call to %s made outside of context/init",#name));


///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglAccum (GLenum op, GLfloat value)
{
  DUMMY_LOG(glAccum);
}


///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglAlphaFunc (GLenum func, GLclampf ref)
{
  DUMMY_LOG(glAlphaFunc);
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY DummyglAreTexturesResident (GLsizei n, const GLuint *textures, GLboolean *residences)
{
  DUMMY_LOG(glAreTexturesResident);

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglArrayElement (GLint i)
{
  DUMMY_LOG(glArrayElement);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglBegin (GLenum mode)
{
  DUMMY_LOG(glBegin);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglBindTexture (GLenum target, GLuint texture)
{
  DUMMY_LOG(glBindTexture);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglBitmap (GLsizei width, GLsizei height, GLfloat xorig, GLfloat yorig, GLfloat xmove, GLfloat ymove, const GLubyte *bitmap)
{
  DUMMY_LOG(glBitmap);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglBlendFunc (GLenum sfactor, GLenum dfactor)
{
  DUMMY_LOG(glBlendFunc);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCallList (GLuint list)
{
  DUMMY_LOG(glCallList);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCallLists (GLsizei n, GLenum type, const GLvoid *lists)
{
  DUMMY_LOG(glCallLists);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClear (GLbitfield mask)
{
  DUMMY_LOG(glClear);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClearAccum (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
  DUMMY_LOG(glClearAccum);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClearColor (GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
{
  DUMMY_LOG(glClearColor);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClearDepth (GLclampd depth)
{
  DUMMY_LOG(glClearDepth);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClearIndex (GLfloat c)
{
  DUMMY_LOG(glClearIndex);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClearStencil (GLint s)
{
  DUMMY_LOG(glClearStencil);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglClipPlane (GLenum plane, const GLdouble *equation)
{
  DUMMY_LOG(glClipPlane);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3b (GLbyte red, GLbyte green, GLbyte blue)
{
  DUMMY_LOG(glColor3b);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3bv (const GLbyte *v)
{
  DUMMY_LOG(glColor3bv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3d (GLdouble red, GLdouble green, GLdouble blue)
{
  DUMMY_LOG(glColor3d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3dv (const GLdouble *v)
{
  DUMMY_LOG(glColor3dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3f (GLfloat red, GLfloat green, GLfloat blue)
{
  DUMMY_LOG(glColor3f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3fv (const GLfloat *v)
{
  DUMMY_LOG(glColor3fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3i (GLint red, GLint green, GLint blue)
{
  DUMMY_LOG(glColor3i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3iv (const GLint *v)
{
  DUMMY_LOG(glColor3iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3s (GLshort red, GLshort green, GLshort blue)
{
  DUMMY_LOG(glColor3s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3sv (const GLshort *v)
{
  DUMMY_LOG(glColor3sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3ub (GLubyte red, GLubyte green, GLubyte blue)
{
  DUMMY_LOG(glColor3ub);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3ubv (const GLubyte *v)
{
  DUMMY_LOG(glColor3ubv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3ui (GLuint red, GLuint green, GLuint blue)
{
  DUMMY_LOG(glColor3ui);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3uiv (const GLuint *v)
{
  DUMMY_LOG(glColor3uiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3us (GLushort red, GLushort green, GLushort blue)
{
  DUMMY_LOG(glColor3us);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor3usv (const GLushort *v)
{
  DUMMY_LOG(glColor3usv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4b (GLbyte red, GLbyte green, GLbyte blue, GLbyte alpha)
{
  DUMMY_LOG(glColor4b);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4bv (const GLbyte *v)
{
  DUMMY_LOG(glColor4bv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4d (GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha)
{
  DUMMY_LOG(glColor4d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4dv (const GLdouble *v)
{
  DUMMY_LOG(glColor4dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4f (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
  DUMMY_LOG(glColor4f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4fv (const GLfloat *v)
{
  DUMMY_LOG(glColor4fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4i (GLint red, GLint green, GLint blue, GLint alpha)
{
  DUMMY_LOG(glColor4i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4iv (const GLint *v)
{                  
  DUMMY_LOG(glColor4iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4s (GLshort red, GLshort green, GLshort blue, GLshort alpha)
{
  DUMMY_LOG(glColor4s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4sv (const GLshort *v)
{
  DUMMY_LOG(glColor4sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4ub (GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha)
{
  DUMMY_LOG(glColor4ub);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4ubv (const GLubyte *v)
{
  DUMMY_LOG(glColor4ubv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4ui (GLuint red, GLuint green, GLuint blue, GLuint alpha)
{
  DUMMY_LOG(glColor4ui);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4uiv (const GLuint *v)
{
  DUMMY_LOG(glColor4uiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4us (GLushort red, GLushort green, GLushort blue, GLushort alpha)
{
  DUMMY_LOG(glColor4us);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColor4usv (const GLushort *v)
{
  DUMMY_LOG(glColor4usv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha)
{
  DUMMY_LOG(glColorMask);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColorMaterial (GLenum face, GLenum mode)
{
  DUMMY_LOG(glColorMaterial);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglColorPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glColorPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCopyPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum type)
{
  DUMMY_LOG(glCopyPixels);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCopyTexImage1D (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border)
{
  DUMMY_LOG(glCopyTexImage1D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCopyTexImage2D (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border)
{
  DUMMY_LOG(glCopyTexImage2D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width)
{
  DUMMY_LOG(glCopyTexSubImage1D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height)
{
  DUMMY_LOG(glCopyTexSubImage2D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglCullFace (GLenum mode)
{
  DUMMY_LOG(glCullFace);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDeleteLists (GLuint list, GLsizei range)
{
  DUMMY_LOG(glDeleteLists);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDeleteTextures (GLsizei n, const GLuint *textures)
{
  DUMMY_LOG(glDeleteTextures);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDepthFunc (GLenum func)
{
  DUMMY_LOG(glDepthFunc);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDepthMask (GLboolean flag)
{
  DUMMY_LOG(glDepthMask);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDepthRange (GLclampd zNear, GLclampd zFar)
{
  DUMMY_LOG(glDepthRange);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDisable (GLenum cap)
{
  DUMMY_LOG(glDisable);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDisableClientState (GLenum array)
{
  DUMMY_LOG(glDisableClientState);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDrawArrays (GLenum mode, GLint first, GLsizei count)
{
  DUMMY_LOG(glDrawArrays);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDrawBuffer (GLenum mode)
{
  DUMMY_LOG(glDrawBuffer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDrawElements (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices)
{
  DUMMY_LOG(glDrawElements);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglDrawPixels (GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
  DUMMY_LOG(glDrawPixels);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEdgeFlag (GLboolean flag)
{
  DUMMY_LOG(glEdgeFlag);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEdgeFlagPointer (GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glEdgeFlagPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEdgeFlagv (const GLboolean *flag)
{
  DUMMY_LOG(glEdgeFlagv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEnable (GLenum cap)
{
  DUMMY_LOG(glEnable);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEnableClientState (GLenum array)
{
  DUMMY_LOG(glEnableClientState);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEnd ()
{
  DUMMY_LOG(glEnd);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEndList ()
{
  DUMMY_LOG(glEndList);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord1d (GLdouble u)
{
  DUMMY_LOG(glEvalCoord1d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord1dv (const GLdouble *u)
{
  DUMMY_LOG(glEvalCoord1dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord1f (GLfloat u)
{
  DUMMY_LOG(glEvalCoord1f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord1fv (const GLfloat *u)
{
  DUMMY_LOG(glEvalCoord1fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord2d (GLdouble u, GLdouble v)
{
  DUMMY_LOG(glEvalCoord2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord2dv (const GLdouble *u)
{
  DUMMY_LOG(glEvalCoord2dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord2f (GLfloat u, GLfloat v)
{
  DUMMY_LOG(glEvalCoord2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalCoord2fv (const GLfloat *u)
{
  DUMMY_LOG(glEvalCoord2fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalMesh1 (GLenum mode, GLint i1, GLint i2)
{
  DUMMY_LOG(glEvalMesh1);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalMesh2 (GLenum mode, GLint i1, GLint i2, GLint j1, GLint j2)
{
  DUMMY_LOG(glEvalMesh2);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalPoint1 (GLint i)
{
  DUMMY_LOG(glEvalPoint1);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglEvalPoint2 (GLint i, GLint j)
{
  DUMMY_LOG(glEvalPoint2);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFeedbackBuffer (GLsizei size, GLenum type, GLfloat *buffer)
{
  DUMMY_LOG(glFeedbackBuffer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFinish ()
{
  DUMMY_LOG(glFinish);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFlush ()
{
  DUMMY_LOG(glFlush);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFogf (GLenum pname, GLfloat param)
{
  DUMMY_LOG(glFogf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFogfv (GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glFogfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFogi (GLenum pname, GLint param)
{
  DUMMY_LOG(glFogi);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFogiv (GLenum pname, const GLint *params)
{
  DUMMY_LOG(glFogiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFrontFace (GLenum mode)
{
  DUMMY_LOG(glFrontFace);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglFrustum (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar)
{
  DUMMY_LOG(glFrustum);
}

///////////////////////////////////////////////////////////////////////////////
//
GLuint GLAPIENTRY DummyglGenLists (GLsizei range)
{
  DUMMY_LOG(glGenLists);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGenTextures (GLsizei n, GLuint *textures)
{
  DUMMY_LOG(glGenTextures);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetBooleanv (GLenum pname, GLboolean *params)
{
  DUMMY_LOG(glGetBooleanv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetClipPlane (GLenum plane, GLdouble *equation)
{
  DUMMY_LOG(glGetClipPlane);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetDoublev (GLenum pname, GLdouble *params)
{
  DUMMY_LOG(glGetDoublev);
}

///////////////////////////////////////////////////////////////////////////////
//
GLenum GLAPIENTRY DummyglGetError ()
{
  DUMMY_LOG(glGetError);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetFloatv (GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetFloatv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetIntegerv (GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetIntegerv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetLightfv (GLenum light, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetLightfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetLightiv (GLenum light, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetLightiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetMapdv (GLenum target, GLenum query, GLdouble *v)
{
  DUMMY_LOG(glGetMapdv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetMapfv (GLenum target, GLenum query, GLfloat *v)
{
  DUMMY_LOG(glGetMapfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetMapiv (GLenum target, GLenum query, GLint *v)
{
  DUMMY_LOG(glGetMapiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetMaterialfv (GLenum face, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetMaterialfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetMaterialiv (GLenum face, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetMaterialiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetPixelMapfv (GLenum map, GLfloat *values)
{
  DUMMY_LOG(glGetPixelMapfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetPixelMapuiv (GLenum map, GLuint *values)
{
  DUMMY_LOG(glGetPixelMapuiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetPixelMapusv (GLenum map, GLushort *values)
{
  DUMMY_LOG(glGetPixelMapusv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetPointerv (GLenum pname, GLvoid* *params)
{
  DUMMY_LOG(glGetPointerv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetPolygonStipple (GLubyte *mask)
{
  DUMMY_LOG(glGetPolygonStipple);
}

///////////////////////////////////////////////////////////////////////////////
//
const GLubyte* GLAPIENTRY DummyglGetString (GLenum name)
{
  DUMMY_LOG(glGetString);
  static GLubyte Dummystring[] = "Dummy String";
  return Dummystring;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexEnvfv (GLenum target, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetTexEnvfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexEnviv (GLenum target, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetTexEnviv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexGendv (GLenum coord, GLenum pname, GLdouble *params)
{
  DUMMY_LOG(glGetTexGendv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexGenfv (GLenum coord, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetTexGenfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexGeniv (GLenum coord, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetTexGeniv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, GLvoid *pixels)
{
  DUMMY_LOG(glGetTexImage);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetTexLevelParameterfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetTexLevelParameteriv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params)
{
  DUMMY_LOG(glGetTexParameterfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglGetTexParameteriv (GLenum target, GLenum pname, GLint *params)
{
  DUMMY_LOG(glGetTexParameteriv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglHint (GLenum target, GLenum mode)
{
  DUMMY_LOG(glHint);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexMask (GLuint mask)
{
  DUMMY_LOG(glIndexMask);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexPointer (GLenum type, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glIndexPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexd (GLdouble c)
{
  DUMMY_LOG(glIndexd);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexdv (const GLdouble *c)
{
  DUMMY_LOG(glIndexdv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexf (GLfloat c)
{
  DUMMY_LOG(glIndexf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexfv (const GLfloat *c)
{
  DUMMY_LOG(glIndexfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexi (GLint c)
{
  DUMMY_LOG(glIndexi);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexiv (const GLint *c)
{
  DUMMY_LOG(glIndexiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexs (GLshort c)
{
  DUMMY_LOG(glIndexs);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexsv (const GLshort *c)
{
  DUMMY_LOG(glIndexsv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexub (GLubyte c)
{
  DUMMY_LOG(glIndexub);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglIndexubv (const GLubyte *c)
{
  DUMMY_LOG(glIndexubv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglInitNames ()
{
  DUMMY_LOG(glInitNames);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglInterleavedArrays (GLenum format, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glInterleavedArrays);
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY DummyglIsEnabled (GLenum cap)
{
  DUMMY_LOG(glIsEnabled);
  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY DummyglIsList (GLuint list)
{
  DUMMY_LOG(glIsList);
  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY DummyglIsTexture (GLuint texture)
{
  DUMMY_LOG(glIsTexture);
  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightModelf (GLenum pname, GLfloat param)
{
  DUMMY_LOG(glLightModelf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightModelfv (GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glLightModelfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightModeli (GLenum pname, GLint param)
{
  DUMMY_LOG(glLightModeli);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightModeliv (GLenum pname, const GLint *params)
{
  DUMMY_LOG(glLightModeliv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightf (GLenum light, GLenum pname, GLfloat param)
{
  DUMMY_LOG(glLightf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightfv (GLenum light, GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glLightfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLighti (GLenum light, GLenum pname, GLint param)
{
  DUMMY_LOG(glLighti);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLightiv (GLenum light, GLenum pname, const GLint *params)
{
  DUMMY_LOG(glLightiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLineStipple (GLint factor, GLushort pattern)
{
  DUMMY_LOG(glLineStipple);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLineWidth (GLfloat width)
{
  DUMMY_LOG(glLineWidth);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglListBase (GLuint base)
{
  DUMMY_LOG(glListBase);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLoadIdentity ()
{
  DUMMY_LOG(glLoadIdentity);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLoadMatrixd (const GLdouble *m)
{
  DUMMY_LOG(glLoadMatrixd);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLoadMatrixf (const GLfloat *m)
{
  DUMMY_LOG(glLoadMatrixf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLoadName (GLuint name)
{
  DUMMY_LOG(glLoadName);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglLogicOp (GLenum opcode)
{
  DUMMY_LOG(glLogicOp);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMap1d (GLenum target, GLdouble u1, GLdouble u2, GLint stride, GLint order, const GLdouble *points)
{
  DUMMY_LOG(glMap1d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMap1f (GLenum target, GLfloat u1, GLfloat u2, GLint stride, GLint order, const GLfloat *points)
{
  DUMMY_LOG(glMap1f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMap2d (GLenum target, GLdouble u1, GLdouble u2, GLint ustride, GLint uorder, GLdouble v1, GLdouble v2, GLint vstride, GLint vorder, const GLdouble *points)
{
  DUMMY_LOG(glMap2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMap2f (GLenum target, GLfloat u1, GLfloat u2, GLint ustride, GLint uorder, GLfloat v1, GLfloat v2, GLint vstride, GLint vorder, const GLfloat *points)
{
  DUMMY_LOG(glMap2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMapGrid1d (GLint un, GLdouble u1, GLdouble u2)
{
  DUMMY_LOG(glMapGrid1d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMapGrid1f (GLint un, GLfloat u1, GLfloat u2)
{
  DUMMY_LOG(glMapGrid1f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMapGrid2d (GLint un, GLdouble u1, GLdouble u2, GLint vn, GLdouble v1, GLdouble v2)
{
  DUMMY_LOG(glMapGrid2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMapGrid2f (GLint un, GLfloat u1, GLfloat u2, GLint vn, GLfloat v1, GLfloat v2)
{
  DUMMY_LOG(glMapGrid2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMaterialf (GLenum face, GLenum pname, GLfloat param)
{
  DUMMY_LOG(glMaterialf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMaterialfv (GLenum face, GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glMaterialfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMateriali (GLenum face, GLenum pname, GLint param)
{
  DUMMY_LOG(glMateriali);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMaterialiv (GLenum face, GLenum pname, const GLint *params)
{
  DUMMY_LOG(glMaterialiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMatrixMode (GLenum mode)
{
  DUMMY_LOG(glMatrixMode);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMultMatrixd (const GLdouble *m)
{
  DUMMY_LOG(glMultMatrixd);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglMultMatrixf (const GLfloat *m)
{
  DUMMY_LOG(glMultMatrixf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNewList (GLuint list, GLenum mode)
{
  DUMMY_LOG(glNewList);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3b (GLbyte nx, GLbyte ny, GLbyte nz)
{
  DUMMY_LOG(glNormal3b);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3bv (const GLbyte *v)
{
  DUMMY_LOG(glNormal3bv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3d (GLdouble nx, GLdouble ny, GLdouble nz)
{
  DUMMY_LOG(glNormal3d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3dv (const GLdouble *v)
{
  DUMMY_LOG(glNormal3dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3f (GLfloat nx, GLfloat ny, GLfloat nz)
{
  DUMMY_LOG(glNormal3f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3fv (const GLfloat *v)
{
  DUMMY_LOG(glNormal3fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3i (GLint nx, GLint ny, GLint nz)
{
  DUMMY_LOG(glNormal3i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3iv (const GLint *v)
{
  DUMMY_LOG(glNormal3iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3s (GLshort nx, GLshort ny, GLshort nz)
{
  DUMMY_LOG(glNormal3s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormal3sv (const GLshort *v)
{
  DUMMY_LOG(glNormal3sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglNormalPointer (GLenum type, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glNormalPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglOrtho (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar)
{
  DUMMY_LOG(glOrtho);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPassThrough (GLfloat token)
{
  DUMMY_LOG(glPassThrough);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelMapfv (GLenum map, GLsizei mapsize, const GLfloat *values)
{
  DUMMY_LOG(glPixelMapfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelMapuiv (GLenum map, GLsizei mapsize, const GLuint *values)
{
  DUMMY_LOG(glPixelMapuiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelMapusv (GLenum map, GLsizei mapsize, const GLushort *values)
{
  DUMMY_LOG(glPixelMapusv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelStoref (GLenum pname, GLfloat param)
{
  DUMMY_LOG(glPixelStoref);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelStorei (GLenum pname, GLint param)
{
  DUMMY_LOG(glPixelStorei);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelTransferf (GLenum pname, GLfloat param)
{
  DUMMY_LOG(glPixelTransferf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelTransferi (GLenum pname, GLint param)
{
  DUMMY_LOG(glPixelTransferi);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPixelZoom (GLfloat xfactor, GLfloat yfactor)
{
  DUMMY_LOG(glPixelZoom);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPointSize (GLfloat size)
{
  DUMMY_LOG(glPointSize);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPolygonMode (GLenum face, GLenum mode)
{
  DUMMY_LOG(glPolygonMode);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPolygonOffset (GLfloat factor, GLfloat units)
{
  DUMMY_LOG(glPolygonOffset);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPolygonStipple (const GLubyte *mask)
{
  DUMMY_LOG(glPolygonStipple);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPopAttrib ()
{
  DUMMY_LOG(glPopAttrib);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPopClientAttrib ()
{
  DUMMY_LOG(glPopClientAttrib);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPopMatrix ()
{
  DUMMY_LOG(glPopMatrix);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPopName ()
{
  DUMMY_LOG(glPopName);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPrioritizeTextures (GLsizei n, const GLuint *textures, const GLclampf *priorities)
{
  DUMMY_LOG(glPrioritizeTextures);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPushAttrib (GLbitfield mask)
{
  DUMMY_LOG(glPushAttrib);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPushClientAttrib (GLbitfield mask)
{
  DUMMY_LOG(glPushClientAttrib);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPushMatrix ()
{
  DUMMY_LOG(glPushMatrix);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglPushName (GLuint name)
{
  DUMMY_LOG(glPushName);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2d (GLdouble x, GLdouble y)
{
  DUMMY_LOG(glRasterPos2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2dv (const GLdouble *v)
{
  DUMMY_LOG(glRasterPos2dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2f (GLfloat x, GLfloat y)
{
  DUMMY_LOG(glRasterPos2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2fv (const GLfloat *v)
{
  DUMMY_LOG(glRasterPos2fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2i (GLint x, GLint y)
{
  DUMMY_LOG(glRasterPos2i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2iv (const GLint *v)
{
  DUMMY_LOG(glRasterPos2iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2s (GLshort x, GLshort y)
{
  DUMMY_LOG(glRasterPos2s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos2sv (const GLshort *v)
{
  DUMMY_LOG(glRasterPos2sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3d (GLdouble x, GLdouble y, GLdouble z)
{
  DUMMY_LOG(glRasterPos3d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3dv (const GLdouble *v)
{
  DUMMY_LOG(glRasterPos3dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3f (GLfloat x, GLfloat y, GLfloat z)
{
  DUMMY_LOG(glRasterPos3f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3fv (const GLfloat *v)
{
  DUMMY_LOG(glRasterPos3fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3i (GLint x, GLint y, GLint z)
{
  DUMMY_LOG(glRasterPos3i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3iv (const GLint *v)
{
  DUMMY_LOG(glRasterPos3iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3s (GLshort x, GLshort y, GLshort z)
{
  DUMMY_LOG(glRasterPos3s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos3sv (const GLshort *v)
{
  DUMMY_LOG(glRasterPos3sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4d (GLdouble x, GLdouble y, GLdouble z, GLdouble w)
{
  DUMMY_LOG(glRasterPos4d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4dv (const GLdouble *v)
{
  DUMMY_LOG(glRasterPos4dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4f (GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
  DUMMY_LOG(glRasterPos4f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4fv (const GLfloat *v)
{
  DUMMY_LOG(glRasterPos4fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4i (GLint x, GLint y, GLint z, GLint w)
{
  DUMMY_LOG(glRasterPos4i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4iv (const GLint *v)
{
  DUMMY_LOG(glRasterPos4iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4s (GLshort x, GLshort y, GLshort z, GLshort w)
{
  DUMMY_LOG(glRasterPos4s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRasterPos4sv (const GLshort *v)
{
  DUMMY_LOG(glRasterPos4sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglReadBuffer (GLenum mode)
{
  DUMMY_LOG(glReadBuffer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, GLvoid *pixels)
{
  DUMMY_LOG(glReadPixels);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectd (GLdouble x1, GLdouble y1, GLdouble x2, GLdouble y2)
{
  DUMMY_LOG(glRectd);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectdv (const GLdouble *v1, const GLdouble *v2)
{
  DUMMY_LOG(glRectdv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectf (GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2)
{
  DUMMY_LOG(glRectf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectfv (const GLfloat *v1, const GLfloat *v2)
{
  DUMMY_LOG(glRectfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRecti (GLint x1, GLint y1, GLint x2, GLint y2)
{
  DUMMY_LOG(glRecti);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectiv (const GLint *v1, const GLint *v2)
{
  DUMMY_LOG(glRectiv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRects (GLshort x1, GLshort y1, GLshort x2, GLshort y2)
{
  DUMMY_LOG(glRects);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRectsv (const GLshort *v1, const GLshort *v2)
{
  DUMMY_LOG(glRectsv);
}

///////////////////////////////////////////////////////////////////////////////
//
GLint GLAPIENTRY DummyglRenderMode (GLenum mode)
{
  DUMMY_LOG(glRenderMode);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRotated (GLdouble angle, GLdouble x, GLdouble y, GLdouble z)
{
  DUMMY_LOG(glRotated);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglRotatef (GLfloat angle, GLfloat x, GLfloat y, GLfloat z)
{
  DUMMY_LOG(glRotatef);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglScaled (GLdouble x, GLdouble y, GLdouble z)
{
  DUMMY_LOG(glScaled);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglScalef (GLfloat x, GLfloat y, GLfloat z)
{
  DUMMY_LOG(glScalef);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglScissor (GLint x, GLint y, GLsizei width, GLsizei height)
{
  DUMMY_LOG(glScissor);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglSelectBuffer (GLsizei size, GLuint *buffer)
{
  DUMMY_LOG(glSelectBuffer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglShadeModel (GLenum mode)
{
  DUMMY_LOG(glShadeModel);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglStencilFunc (GLenum func, GLint ref, GLuint mask)
{
  DUMMY_LOG(glStencilFunc);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglStencilMask (GLuint mask)
{
  DUMMY_LOG(glStencilMask);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglStencilOp (GLenum fail, GLenum zfail, GLenum zpass)
{
  DUMMY_LOG(glStencilOp);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1d (GLdouble s)
{
  DUMMY_LOG(glTexCoord1d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1dv (const GLdouble *v)
{
  DUMMY_LOG(glTexCoord1dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1f (GLfloat s)
{
  DUMMY_LOG(glTexCoord1f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1fv (const GLfloat *v)
{
  DUMMY_LOG(glTexCoord1fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1i (GLint s)
{
  DUMMY_LOG(glTexCoord1i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1iv (const GLint *v)
{
  DUMMY_LOG(glTexCoord1iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1s (GLshort s)
{
  DUMMY_LOG(glTexCoord1s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord1sv (const GLshort *v)
{
  DUMMY_LOG(glTexCoord1sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2d (GLdouble s, GLdouble t)
{
  DUMMY_LOG(glTexCoord2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2dv (const GLdouble *v)
{
  DUMMY_LOG(glTexCoord2dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2f (GLfloat s, GLfloat t)
{
  DUMMY_LOG(glTexCoord2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2fv (const GLfloat *v)
{
  DUMMY_LOG(glTexCoord2fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2i (GLint s, GLint t)
{
  DUMMY_LOG(glTexCoord2i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2iv (const GLint *v)
{
  DUMMY_LOG(glTexCoord2iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2s (GLshort s, GLshort t)
{
  DUMMY_LOG(glTexCoord2s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord2sv (const GLshort *v)
{
  DUMMY_LOG(glTexCoord2sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3d (GLdouble s, GLdouble t, GLdouble r)
{
  DUMMY_LOG(glTexCoord3d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3dv (const GLdouble *v)
{
  DUMMY_LOG(glTexCoord3dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3f (GLfloat s, GLfloat t, GLfloat r)
{
  DUMMY_LOG(glTexCoord3f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3fv (const GLfloat *v)
{
  DUMMY_LOG(glTexCoord3fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3i (GLint s, GLint t, GLint r)
{
  DUMMY_LOG(glTexCoord3i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3iv (const GLint *v)
{
  DUMMY_LOG(glTexCoord3iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3s (GLshort s, GLshort t, GLshort r)
{
  DUMMY_LOG(glTexCoord3s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord3sv (const GLshort *v)
{
  DUMMY_LOG(glTexCoord3sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4d (GLdouble s, GLdouble t, GLdouble r, GLdouble q)
{
  DUMMY_LOG(glTexCoord4d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4dv (const GLdouble *v)
{
  DUMMY_LOG(glTexCoord4dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4f (GLfloat s, GLfloat t, GLfloat r, GLfloat q)
{
  DUMMY_LOG(glTexCoord4f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4fv (const GLfloat *v)
{
  DUMMY_LOG(glTexCoord4fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4i (GLint s, GLint t, GLint r, GLint q)
{
  DUMMY_LOG(glTexCoord4i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4iv (const GLint *v)
{
  DUMMY_LOG(glTexCoord4iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4s (GLshort s, GLshort t, GLshort r, GLshort q)
{
  DUMMY_LOG(glTexCoord4s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoord4sv (const GLshort *v)
{
  DUMMY_LOG(glTexCoord4sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexCoordPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glTexCoordPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexEnvf (GLenum target, GLenum pname, GLfloat param)
{
  DUMMY_LOG(glTexEnvf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexEnvfv (GLenum target, GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glTexEnvfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexEnvi (GLenum target, GLenum pname, GLint param)
{
  DUMMY_LOG(glTexEnvi);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexEnviv (GLenum target, GLenum pname, const GLint *params)
{
  DUMMY_LOG(glTexEnviv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGend (GLenum coord, GLenum pname, GLdouble param)
{
  DUMMY_LOG(glTexGend);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGendv (GLenum coord, GLenum pname, const GLdouble *params)
{
  DUMMY_LOG(glTexGendv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGenf (GLenum coord, GLenum pname, GLfloat param)
{
  DUMMY_LOG(glTexGenf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGenfv (GLenum coord, GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glTexGenfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGeni (GLenum coord, GLenum pname, GLint param)
{
  DUMMY_LOG(glTexGeni);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexGeniv (GLenum coord, GLenum pname, const GLint *params)
{
  DUMMY_LOG(glTexGeniv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
  DUMMY_LOG(glTexImage1D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
  DUMMY_LOG(glTexImage2D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexParameterf (GLenum target, GLenum pname, GLfloat param)
{
  DUMMY_LOG(glTexParameterf);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexParameterfv (GLenum target, GLenum pname, const GLfloat *params)
{
  DUMMY_LOG(glTexParameterfv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexParameteri (GLenum target, GLenum pname, GLint param)
{
  DUMMY_LOG(glTexParameteri);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexParameteriv (GLenum target, GLenum pname, const GLint *params)
{
  DUMMY_LOG(glTexParameteriv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels)
{
  DUMMY_LOG(glTexSubImage1D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
  DUMMY_LOG(glTexSubImage2D);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTranslated (GLdouble x, GLdouble y, GLdouble z)
{
  DUMMY_LOG(glTranslated);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglTranslatef (GLfloat x, GLfloat y, GLfloat z)
{
  DUMMY_LOG(glTranslatef);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2d (GLdouble x, GLdouble y)
{
  DUMMY_LOG(glVertex2d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2dv (const GLdouble *v)
{
  DUMMY_LOG(glVertex2dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2f (GLfloat x, GLfloat y)
{
  DUMMY_LOG(glVertex2f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2fv (const GLfloat *v)
{
  DUMMY_LOG(glVertex2fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2i (GLint x, GLint y)
{
  DUMMY_LOG(glVertex2i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2iv (const GLint *v)
{
  DUMMY_LOG(glVertex2iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2s (GLshort x, GLshort y)
{
  DUMMY_LOG(glVertex2s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex2sv (const GLshort *v)
{
  DUMMY_LOG(glVertex2sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3d (GLdouble x, GLdouble y, GLdouble z)
{
  DUMMY_LOG(glVertex3d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3dv (const GLdouble *v)
{
  DUMMY_LOG(glVertex3dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3f (GLfloat x, GLfloat y, GLfloat z)
{
  DUMMY_LOG(glVertex3f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3fv (const GLfloat *v)
{
  DUMMY_LOG(glVertex3fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3i (GLint x, GLint y, GLint z)
{
  DUMMY_LOG(glVertex3i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3iv (const GLint *v)
{
  DUMMY_LOG(glVertex3iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3s (GLshort x, GLshort y, GLshort z)
{
  DUMMY_LOG(glVertex3s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex3sv (const GLshort *v)
{
  DUMMY_LOG(glVertex3sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4d (GLdouble x, GLdouble y, GLdouble z, GLdouble w)
{
  DUMMY_LOG(glVertex4d);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4dv (const GLdouble *v)
{
  DUMMY_LOG(glVertex4dv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4f (GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
  DUMMY_LOG(glVertex4f);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4fv (const GLfloat *v)
{
  DUMMY_LOG(glVertex4fv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4i (GLint x, GLint y, GLint z, GLint w)
{
  DUMMY_LOG(glVertex4i);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4iv (const GLint *v)
{
  DUMMY_LOG(glVertex4iv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4s (GLshort x, GLshort y, GLshort z, GLshort w)
{
  DUMMY_LOG(glVertex4s);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertex4sv (const GLshort *v)
{
  DUMMY_LOG(glVertex4sv);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglVertexPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  DUMMY_LOG(glVertexPointer);
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY DummyglViewport (GLint x, GLint y, GLsizei width, GLsizei height)
{
  DUMMY_LOG(glViewport);
}

//Initialize with stubs
GLCoreDriver GLV=
{
  //Core methods
  DummyglAccum,
  DummyglAlphaFunc,
  DummyglAreTexturesResident,
  DummyglArrayElement,
  DummyglBegin,
  DummyglBindTexture,
  DummyglBitmap,
  DummyglBlendFunc,
  DummyglCallList,
  DummyglCallLists,
  DummyglClear,
  DummyglClearAccum,
  DummyglClearColor,
  DummyglClearDepth,
  DummyglClearIndex,
  DummyglClearStencil,
  DummyglClipPlane,
  DummyglColor3b,
  DummyglColor3bv,
  DummyglColor3d,
  DummyglColor3dv,
  DummyglColor3f,
  DummyglColor3fv,
  DummyglColor3i,
  DummyglColor3iv,
  DummyglColor3s,
  DummyglColor3sv,
  DummyglColor3ub,
  DummyglColor3ubv,
  DummyglColor3ui,
  DummyglColor3uiv,
  DummyglColor3us,
  DummyglColor3usv,
  DummyglColor4b,
  DummyglColor4bv,
  DummyglColor4d,
  DummyglColor4dv,
  DummyglColor4f,
  DummyglColor4fv,
  DummyglColor4i,
  DummyglColor4iv,
  DummyglColor4s,
  DummyglColor4sv,
  DummyglColor4ub,
  DummyglColor4ubv,
  DummyglColor4ui,
  DummyglColor4uiv,
  DummyglColor4us,
  DummyglColor4usv,
  DummyglColorMask,
  DummyglColorMaterial,
  DummyglColorPointer,
  DummyglCopyPixels,
  DummyglCopyTexImage1D,
  DummyglCopyTexImage2D,
  DummyglCopyTexSubImage1D,
  DummyglCopyTexSubImage2D,
  DummyglCullFace,
  DummyglDeleteLists,
  DummyglDeleteTextures,
  DummyglDepthFunc,
  DummyglDepthMask,
  DummyglDepthRange,
  DummyglDisable,
  DummyglDisableClientState,
  DummyglDrawArrays,
  DummyglDrawBuffer,
  DummyglDrawElements,
  DummyglDrawPixels,
  DummyglEdgeFlag,
  DummyglEdgeFlagPointer,
  DummyglEdgeFlagv,
  DummyglEnable,
  DummyglEnableClientState,
  DummyglEnd,
  DummyglEndList,
  DummyglEvalCoord1d,
  DummyglEvalCoord1dv,
  DummyglEvalCoord1f,
  DummyglEvalCoord1fv,
  DummyglEvalCoord2d,
  DummyglEvalCoord2dv,
  DummyglEvalCoord2f,
  DummyglEvalCoord2fv,
  DummyglEvalMesh1,
  DummyglEvalMesh2,
  DummyglEvalPoint1,
  DummyglEvalPoint2,
  DummyglFeedbackBuffer,
  DummyglFinish,
  DummyglFlush,
  DummyglFogf,
  DummyglFogfv,
  DummyglFogi,
  DummyglFogiv,
  DummyglFrontFace,
  DummyglFrustum,
  DummyglGenLists,
  DummyglGenTextures,
  DummyglGetBooleanv,
  DummyglGetClipPlane,
  DummyglGetDoublev,
  DummyglGetError,
  DummyglGetFloatv,
  DummyglGetIntegerv,
  DummyglGetLightfv,
  DummyglGetLightiv,
  DummyglGetMapdv,
  DummyglGetMapfv,
  DummyglGetMapiv,
  DummyglGetMaterialfv,
  DummyglGetMaterialiv,
  DummyglGetPixelMapfv,
  DummyglGetPixelMapuiv,
  DummyglGetPixelMapusv,
  DummyglGetPointerv,
  DummyglGetPolygonStipple,
  DummyglGetString,
  DummyglGetTexEnvfv,
  DummyglGetTexEnviv,
  DummyglGetTexGendv,
  DummyglGetTexGenfv,
  DummyglGetTexGeniv,
  DummyglGetTexImage,
  DummyglGetTexLevelParameterfv,
  DummyglGetTexLevelParameteriv,
  DummyglGetTexParameterfv,
  DummyglGetTexParameteriv,
  DummyglHint,
  DummyglIndexMask,
  DummyglIndexPointer,
  DummyglIndexd,
  DummyglIndexdv,
  DummyglIndexf,
  DummyglIndexfv,
  DummyglIndexi,
  DummyglIndexiv,
  DummyglIndexs,
  DummyglIndexsv,
  DummyglIndexub,
  DummyglIndexubv,
  DummyglInitNames,
  DummyglInterleavedArrays,
  DummyglIsEnabled,
  DummyglIsList,
  DummyglIsTexture,
  DummyglLightModelf,
  DummyglLightModelfv,
  DummyglLightModeli,
  DummyglLightModeliv,
  DummyglLightf,
  DummyglLightfv,
  DummyglLighti,
  DummyglLightiv,
  DummyglLineStipple,
  DummyglLineWidth,
  DummyglListBase,
  DummyglLoadIdentity,
  DummyglLoadMatrixd,
  DummyglLoadMatrixf,
  DummyglLoadName,
  DummyglLogicOp,
  DummyglMap1d,
  DummyglMap1f,
  DummyglMap2d,
  DummyglMap2f,
  DummyglMapGrid1d,
  DummyglMapGrid1f,
  DummyglMapGrid2d,
  DummyglMapGrid2f,
  DummyglMaterialf,
  DummyglMaterialfv,
  DummyglMateriali,
  DummyglMaterialiv,
  DummyglMatrixMode,
  DummyglMultMatrixd,
  DummyglMultMatrixf,
  DummyglNewList,
  DummyglNormal3b,
  DummyglNormal3bv,
  DummyglNormal3d,
  DummyglNormal3dv,
  DummyglNormal3f,
  DummyglNormal3fv,
  DummyglNormal3i,
  DummyglNormal3iv,
  DummyglNormal3s,
  DummyglNormal3sv,
  DummyglNormalPointer,
  DummyglOrtho,
  DummyglPassThrough,
  DummyglPixelMapfv,
  DummyglPixelMapuiv,
  DummyglPixelMapusv,
  DummyglPixelStoref,
  DummyglPixelStorei,
  DummyglPixelTransferf,
  DummyglPixelTransferi,
  DummyglPixelZoom,
  DummyglPointSize,
  DummyglPolygonMode,
  DummyglPolygonOffset,
  DummyglPolygonStipple,
  DummyglPopAttrib,
  DummyglPopClientAttrib,
  DummyglPopMatrix,
  DummyglPopName,
  DummyglPrioritizeTextures,
  DummyglPushAttrib,
  DummyglPushClientAttrib,
  DummyglPushMatrix,
  DummyglPushName,
  DummyglRasterPos2d,
  DummyglRasterPos2dv,
  DummyglRasterPos2f,
  DummyglRasterPos2fv,
  DummyglRasterPos2i,
  DummyglRasterPos2iv,
  DummyglRasterPos2s,
  DummyglRasterPos2sv,
  DummyglRasterPos3d,
  DummyglRasterPos3dv,
  DummyglRasterPos3f,
  DummyglRasterPos3fv,
  DummyglRasterPos3i,
  DummyglRasterPos3iv,
  DummyglRasterPos3s,
  DummyglRasterPos3sv,
  DummyglRasterPos4d,
  DummyglRasterPos4dv,
  DummyglRasterPos4f,
  DummyglRasterPos4fv,
  DummyglRasterPos4i,
  DummyglRasterPos4iv,
  DummyglRasterPos4s,
  DummyglRasterPos4sv,
  DummyglReadBuffer,
  DummyglReadPixels,
  DummyglRectd,
  DummyglRectdv,
  DummyglRectf,
  DummyglRectfv,
  DummyglRecti,
  DummyglRectiv,
  DummyglRects,
  DummyglRectsv,
  DummyglRenderMode,
  DummyglRotated,
  DummyglRotatef,
  DummyglScaled,
  DummyglScalef,
  DummyglScissor,
  DummyglSelectBuffer,
  DummyglShadeModel,
  DummyglStencilFunc,
  DummyglStencilMask,
  DummyglStencilOp,
  DummyglTexCoord1d,
  DummyglTexCoord1dv,
  DummyglTexCoord1f,
  DummyglTexCoord1fv,
  DummyglTexCoord1i,
  DummyglTexCoord1iv,
  DummyglTexCoord1s,
  DummyglTexCoord1sv,
  DummyglTexCoord2d,
  DummyglTexCoord2dv,
  DummyglTexCoord2f,
  DummyglTexCoord2fv,
  DummyglTexCoord2i,
  DummyglTexCoord2iv,
  DummyglTexCoord2s,
  DummyglTexCoord2sv,
  DummyglTexCoord3d,
  DummyglTexCoord3dv,
  DummyglTexCoord3f,
  DummyglTexCoord3fv,
  DummyglTexCoord3i,
  DummyglTexCoord3iv,
  DummyglTexCoord3s,
  DummyglTexCoord3sv,
  DummyglTexCoord4d,
  DummyglTexCoord4dv,
  DummyglTexCoord4f,
  DummyglTexCoord4fv,
  DummyglTexCoord4i,
  DummyglTexCoord4iv,
  DummyglTexCoord4s,
  DummyglTexCoord4sv,
  DummyglTexCoordPointer,
  DummyglTexEnvf,
  DummyglTexEnvfv,
  DummyglTexEnvi,
  DummyglTexEnviv,
  DummyglTexGend,
  DummyglTexGendv,
  DummyglTexGenf,
  DummyglTexGenfv,
  DummyglTexGeni,
  DummyglTexGeniv,
  DummyglTexImage1D,
  DummyglTexImage2D,
  DummyglTexParameterf,
  DummyglTexParameterfv,
  DummyglTexParameteri,
  DummyglTexParameteriv,
  DummyglTexSubImage1D,
  DummyglTexSubImage2D,
  DummyglTranslated,
  DummyglTranslatef,
  DummyglVertex2d,
  DummyglVertex2dv,
  DummyglVertex2f,
  DummyglVertex2fv,
  DummyglVertex2i,
  DummyglVertex2iv,
  DummyglVertex2s,
  DummyglVertex2sv,
  DummyglVertex3d,
  DummyglVertex3dv,
  DummyglVertex3f,
  DummyglVertex3fv,
  DummyglVertex3i,
  DummyglVertex3iv,
  DummyglVertex3s,
  DummyglVertex3sv,
  DummyglVertex4d,
  DummyglVertex4dv,
  DummyglVertex4f,
  DummyglVertex4fv,
  DummyglVertex4i,
  DummyglVertex4iv,
  DummyglVertex4s,
  DummyglVertex4sv,
  DummyglVertexPointer,
  DummyglViewport
};
  
  
  
  
  
  
  



