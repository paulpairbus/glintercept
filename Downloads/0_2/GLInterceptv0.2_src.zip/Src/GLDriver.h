/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  Parts of this file may be derived from GLTrace version 2.3
  by Phil Frisbie, Jr. (phil@hawksoft.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __GL_DRIVER_H_
#define __GL_DRIVER_H_

#include "GLInterceptConfig.h"
#include "gl.h"
#include "DLLLoader.h"
#include "InterceptLog.h"
#include "InterceptImage.h"
#include "InterceptShader.h"
#include "InterceptFrame.h"
#include "ConfigData.h"

#include <string>

using namespace std;

class ExtensionFunction;

//@
//  Summary:
//    This class holds the internal data required for a OpenGL context.
//  
class GLContext
{
public:

  //@
  //  Summary:
  //    Constructor
  //
  //  Parameters:
  //    rcHandle  - The handle to the OpenGL context.
  //
  GLContext(HGLRC rcHandle);
  virtual ~GLContext();
  
  //@
  //  Summary:
  //    To share this classes' internal data with the passed context.
  //
  //  Parameters:
  //    shareContext  - The context to share data with.
  //
  //  Returns:
  //    True is returned on successful sharing, false if otherwise.
  //
  bool ShareLists(GLContext *shareContext) const;

  //@
  //  Summary:
  //    To activate the internal loggers with the passed directory name.
  //
  //  Parameters:
  //    logPath  - The directory to activate the internal loggers with.
  //
  void ActivateLoggers(const string &logPath);

  //@
  //  Summary:
  //    To suspend the internal loggers from logging.
  //
  void SuspendLoggers();

protected:
  friend class GLDriver;
  
  HGLRC   glRCHandle;                             // The openGL rendering context handle
  GLenum  cachedError;                            // The cached error code

  InterceptImage    *interceptImage;              // The class used to log image calls
  InterceptShader   *interceptShader;             // The class used to log shader calls
  InterceptFrame    *interceptFrame;              // The class used to save the frame buffer
};


//@
//  Summary:
//    This class creates and init's the OpenGL driver. It is responsible for 
//    opening and storing function pointers to the OpenGL libraries.
//  
class GLDriver
{
public:

  //Constructor/destructor
  GLDriver();
  virtual ~GLDriver();

  //@
  //  Summary:
  //    Inits the driver with the passed dll name.
  //  
  //  Returns:
  //    True is returned on success, false if otherwise. (Cannot use this class
  //    if Init fails)
  //
  bool Init();

  //@
  //  Summary:
  //    Inits the function table ready for use. 
  //    (Needs to be static as it can be called before and object of this class is init)
  //  
  static void InitFunctionTable();

  //@
  //  Summary:
  //    Logs that a function call of the type at index is about to be made.
  //  
  //  Parameters:
  //    index  - The index of the function call (in the function table) about to be made.
  //
  //    args   - The list of arguments for this function
  //
  //  Returns:
  //    True is returned on successful logging , false if otherwise
  //
  bool LogFunctionPre(uint index, va_list args);

  //@
  //  Summary:
  //    Logs that a function call has just been made (post function call).
  //  
  //  Parameters:
  //    index  - The index of the function call (in the function table) that was made.
  //
  //    returnVal - The return value (if any) of the function call.
  //
  //  Returns:
  //    True is returned on successful logging , false if otherwise
  //
  bool LogFunctionPost(uint index, void *returnVal);

  //@
  //  Summary:
  //    Adds a new extension function to the tables for logging
  //  
  //  Parameters:
  //    funcName  - The name of the new function to log.
  //
  //    functionPtr - The pointer to the function to log. 
  //
  //  Returns:
  //    The pointer to be used for the function call is returned. 
  //    (If a entry cannot be made, the passed function ptr is returned.)
  //
  void * AddExtensionFunction(const string & funcName,void * functionPtr);  

  //@
  //  Summary:
  //    Returns the cached eroor code (if any)
  //  
  //  Returns:
  //    The cached error code (if any) is returned.
  //
  inline GLenum GetCachedErrorCode();

  //@
  //  Summary:
  //    Reset the cached error code to the default no-error state.
  //    This method is usually called from the glGetError method once 
  //    the user has received an error.
  //  
  inline void ResetCachedErrorCode();

  //@
  //  Summary:
  //    To set the state if extra function calls to the GL state can be made
  //    internally. (ie. these call cannot be made between a glBegin()..glEnd())
  //    The mode is actually set by a counter (To allow multiple disables to 
  //    not over-ride each other)
  //  
  //  Parameters:
  //    mode  - Mode to enable/disable extra GL calls.
  //
  void SetInternalGLCallMode(bool mode);

  //@
  //  Summary:
  //    To get the state if extra function calls to the GL state can be made
  //    internally.
  //  
  //  Returns:
  //    The internal call mode is returned.
  //
  inline bool GetInternalGLCallMode() const;
  
  //@
  //  Summary:
  //    To set if we are in a glBegin/glEnd set of function calls.
  //  
  //  Parameters:
  //    mode  - The mode to set
  //
  void SetBeginEndState(bool mode);

  //@
  //  Summary:
  //    Returns if we are in a glBegin/glEnd segment.
  //  
  //  Returns:
  //    The state of the glBegin/glEnd mode is returned. 
  //
  inline bool GetBeginEndState() const;
 
  //@
  //  Summary:
  //    To set if we are in a glNewList/glEndList set of function calls.
  //  
  //  Parameters:
  //    mode  - The mode to set
  //
  void SetNewListState(bool mode);

  //@
  //  Summary:
  //    Returns if we are in a glNewList/glEndList segment.
  //  
  //  Returns:
  //    The state of the glNewList/glEndList mode is returned. 
  //
  inline bool GetNewListState() const;

  //@
  //  Summary:
  //    To return the OpenGL version number.
  //  
  //  Returns:
  //    A float value in the form <major num>.<minor num><release num> is
  //    returned. If the version cannot be determined, 1.0 is returned.
  //
  float GetOpenGLVersion();

  //@
  //  Summary:
  //    Determines if the passed OpenGL extension is supported.
  //  
  //  Returns:
  //    If the OpenGL extension is supported, true is returned.
  //    If the extension is not supported (or it could not be determined)
  //    false is returned.
  //
  bool IsExtensionSupported(const char *extension);

  //@
  //  Summary:
  //    To get the image saved filenames for a passed texture ID
  //  
  //  Parameters:
  //    texId  - The openGL texture ID to get the images for.
  //
  //    retSaveFiles - The files to be returned.
  //
  //  Returns:
  //    If the images could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetTextureFileNames(GLint texId, ImageSaveFiles &retSaveFiles);

  //@
  //  Summary:
  //    To get the shader saved filename for a passed shader ID
  //  
  //  Parameters:
  //    id  - The openGL shader (ARB program) ID to get the shader for.
  //
  //    retShaderName - The shader name to be returned.
  //
  //  Returns:
  //    If the shader file name could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetShaderFileName(GLint id,string &retShaderName);

  //@
  //  Summary:
  //    To get the filenames for frame buffer logging images.
  //  
  //  Parameters:
  //    retShaderName - The file name to be retrieved.
  //
  //  Returns:
  //    If the file names could be retrieved, true is returned. 
  //    Else false is returned.
  //
  inline bool GetFrameFileNames(FrameInterceptFileNames & retFrameFileNames);

  //@
  //  Summary:
  //    To get an array of texture IDs that are bound. 
  //  
  //  Parameters:
  //    retArray  - The return array of texture IDs (and the stages) that are bound.
  //
  inline void GetBoundTextures(BoundTextureArray &retArray);

  //@
  //  Summary:
  //    To get the id's of the bound vertex and fragment shader
  //  
  //  Parameters:
  //    vertexShaderID  - The returned shader ID of the bound vertex shader.
  //                      (returns 0 for no bound vertex shader)
  //
  //    fragmentShaderID  - The returned shader ID of the bound fragment shader.
  //                        (returns 0 for no bound fragment shader)
  inline void GetBoundShaders(uint &vertexShaderID,uint &fragmentShaderID);

  //@
  //  Summary:
  //    To get the current frame number.
  //  
  //  Returns:
  //    The current frame number is returned.
  //
  inline uint GetFrameNumber() const;

  //@
  //  Summary:
  //    To create a new structure to hold OpenGL the new OpenGL context.
  //  
  //  Parameters:
  //    rcHandle  - The new OpenGL context handle.
  //
  //  Returns:
  //    Returns true on success, false on failure. 
  //    
  bool CreateOpenGLContext(HGLRC rcHandle);

  //@
  //  Summary:
  //    To delete the structure that holds a OpenGL context.
  //  
  //  Parameters:
  //    rcHandle  - The OpenGL context handle of the data to delete.
  //
  //  Returns:
  //    Returns true on success, false on failure. 
  //    
  bool DeleteOpenGLContext(HGLRC rcHandle);

  //@
  //  Summary:
  //    To set the currently active OpenGL context. 
  //    Ensure the previous context is shut down first before the 
  //    actual OpenGL context switch occurs. (This is due to some 
  //    context data may need to be saved)
  //  
  //  Parameters:
  //    rcHandle  - The OpenGL context handle to switch to. (Can be NULL)
  //
  //  Returns:
  //    Returns true on success, false on failure. 
  //    
  bool SetOpenGLContext(HGLRC rcHandle);

  //@
  //  Summary:
  //    To get the OpenGL context structre for the passed handle. 
  //  
  //  Parameters:
  //    rcHandle  - The OpenGL context handle to retrieve data for
  //
  //  Returns:
  //    If the handle could be found, the structure is returned else
  //    NULL is returned.
  //    
  GLContext *GetOpenGLContext(HGLRC rcHandle) const;

  //@
  //  Summary:
  //    To get the OpenGL current OpenGL context structure. 
  //  
  //  Returns:
  //    If there is a current context, the structure is returned else
  //    NULL is returned.
  //    
  inline const GLContext * GetCurrentContext() const;

protected:
  bool       isInit;                              // Has Init() been called successfully
  DLLLoader  openGLLib;                           // The OpenGL library
  ConfigData configData;                          // The configuration data

  uint       frameNumber;                         // The rendering frame number
  string     currLogDir;                          // The current logging directory
  bool       loggingEnabled;                      // Flag to indicate if logging is currently enabled

  ExtensionFunction *extensionFunction;           // The class used to register extension functions 
  InterceptLog      *interceptLog;                // The class used to log function calls

  GLContext         *glContext;                   // The current OpenGL context
  vector<GLContext *> glContextArray;             // The array of all the OpenGL contexts

  uint   internalCallModeCount;                   // Counter to indicate if we can make extra GL function calls internally. (non-zero is false)
  bool   glBeginEndState;                         // Flag to indicate if we are currently processing a glBegin/glEnd block
  bool   glNewListState;                          // Flag to indicate if we are currently processing a glNewList/glEndList block


  //@
  //  Summary:
  //    To init the function logger.
  //  
  //  Returns:
  //    True is returned on success, false is otherwise
  //
  bool InitFunctionLog();

  //@
  //  Summary:
  //    Perform the function lookup of core OpenGL functions.
  //  
  //  Returns:
  //    True is returned on success, false is otherwise
  //
  bool MapCoreOpenGLFunctions();

  //@
  //  Summary:
  //    Perform the function lookup of windows GL functions.
  //  
  //  Returns:
  //    True is returned on success, false is otherwise
  //
  bool MapWGLFunctions();

  //@
  //  Summary:
  //    To handle the end of frame event.
  //  
  void ProcessFrameEnd();

};

///////////////////////////////////////////////////////////////////////////////
//
inline GLenum GLDriver::GetCachedErrorCode()
{
  if(glContext)
  {
    return glContext->cachedError;
  }
 
  return GL_NO_ERROR;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void GLDriver::ResetCachedErrorCode()
{
  if(glContext)
  {
    glContext->cachedError = GL_NO_ERROR;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetBeginEndState() const
{
  return glBeginEndState;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetNewListState() const
{
  return glNewListState;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetInternalGLCallMode() const
{
  //Determine if the call count is ok for internal OpenGL calls
  //  (and we have a OpenGL context)
  if(glContext && internalCallModeCount == 0 )
  {
    return true;
  }
  else
  {
    return false;
  } 
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetTextureFileNames(GLint texId, ImageSaveFiles &retSaveFiles)
{
  //If we have the image logger, query the logger
  if(glContext && glContext->interceptImage)
  {
    return glContext->interceptImage->GetTextureFileNames(texId,retSaveFiles);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetShaderFileName(GLint id,string &retShaderName)
{
  //If we have the shader logger, query the logger
  if(glContext && glContext->interceptShader)
  {
    return glContext->interceptShader->GetShaderFileName(id,retShaderName);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline bool GLDriver::GetFrameFileNames(FrameInterceptFileNames &retFrameFileNames)
{
  // If there exists a frame logger, get the images
  if(glContext && glContext->interceptFrame)
  {
    return glContext->interceptFrame->GetFrameFileNames(retFrameFileNames);
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void GLDriver::GetBoundTextures(BoundTextureArray &retArray)
{
  //If we have the image logger, query the logger
  if(glContext && glContext->interceptImage)
  {
    glContext->interceptImage->GetBoundTextures(retArray);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline void GLDriver::GetBoundShaders(uint &vertexShaderID,uint &fragmentShaderID)
{
  vertexShaderID = 0;
  fragmentShaderID = 0;

  //If we have the shader logger, query the logger
  if(glContext && glContext->interceptShader)
  {
    glContext->interceptShader->GetBoundShaders(vertexShaderID,fragmentShaderID);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
inline uint GLDriver::GetFrameNumber() const
{
  return frameNumber;
}

///////////////////////////////////////////////////////////////////////////////
//
inline const GLContext * GLDriver::GetCurrentContext() const
{
  return glContext;
}


//Direct function core methods
struct GLCoreDriver
{

  //Core methods
  void (GLAPIENTRY *glAccum) (GLenum op, GLfloat value);
  void (GLAPIENTRY *glAlphaFunc) (GLenum func, GLclampf ref);
  GLboolean (GLAPIENTRY *glAreTexturesResident) (GLsizei n, const GLuint *textures, GLboolean *residences);
  void (GLAPIENTRY *glArrayElement) (GLint i);
  void (GLAPIENTRY *glBegin) (GLenum mode);
  void (GLAPIENTRY *glBindTexture) (GLenum target, GLuint texture);
  void (GLAPIENTRY *glBitmap) (GLsizei width, GLsizei height, GLfloat xorig, GLfloat yorig, GLfloat xmove, GLfloat ymove, const GLubyte *bitmap);
  void (GLAPIENTRY *glBlendFunc) (GLenum sfactor, GLenum dfactor);
  void (GLAPIENTRY *glCallList) (GLuint list);
  void (GLAPIENTRY *glCallLists) (GLsizei n, GLenum type, const GLvoid *lists);
  void (GLAPIENTRY *glClear) (GLbitfield mask);
  void (GLAPIENTRY *glClearAccum) (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
  void (GLAPIENTRY *glClearColor) (GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
  void (GLAPIENTRY *glClearDepth) (GLclampd depth);
  void (GLAPIENTRY *glClearIndex) (GLfloat c);
  void (GLAPIENTRY *glClearStencil) (GLint s);
  void (GLAPIENTRY *glClipPlane) (GLenum plane, const GLdouble *equation);
  void (GLAPIENTRY *glColor3b) (GLbyte red, GLbyte green, GLbyte blue);
  void (GLAPIENTRY *glColor3bv) (const GLbyte *v);
  void (GLAPIENTRY *glColor3d) (GLdouble red, GLdouble green, GLdouble blue);
  void (GLAPIENTRY *glColor3dv) (const GLdouble *v);
  void (GLAPIENTRY *glColor3f) (GLfloat red, GLfloat green, GLfloat blue);
  void (GLAPIENTRY *glColor3fv) (const GLfloat *v);
  void (GLAPIENTRY *glColor3i) (GLint red, GLint green, GLint blue);
  void (GLAPIENTRY *glColor3iv) (const GLint *v);
  void (GLAPIENTRY *glColor3s) (GLshort red, GLshort green, GLshort blue);
  void (GLAPIENTRY *glColor3sv) (const GLshort *v);
  void (GLAPIENTRY *glColor3ub) (GLubyte red, GLubyte green, GLubyte blue);
  void (GLAPIENTRY *glColor3ubv) (const GLubyte *v);
  void (GLAPIENTRY *glColor3ui) (GLuint red, GLuint green, GLuint blue);
  void (GLAPIENTRY *glColor3uiv) (const GLuint *v);
  void (GLAPIENTRY *glColor3us) (GLushort red, GLushort green, GLushort blue);
  void (GLAPIENTRY *glColor3usv) (const GLushort *v);
  void (GLAPIENTRY *glColor4b) (GLbyte red, GLbyte green, GLbyte blue, GLbyte alpha);
  void (GLAPIENTRY *glColor4bv) (const GLbyte *v);
  void (GLAPIENTRY *glColor4d) (GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha);
  void (GLAPIENTRY *glColor4dv) (const GLdouble *v);
  void (GLAPIENTRY *glColor4f) (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
  void (GLAPIENTRY *glColor4fv) (const GLfloat *v);
  void (GLAPIENTRY *glColor4i) (GLint red, GLint green, GLint blue, GLint alpha);
  void (GLAPIENTRY *glColor4iv) (const GLint *v);
  void (GLAPIENTRY *glColor4s) (GLshort red, GLshort green, GLshort blue, GLshort alpha);
  void (GLAPIENTRY *glColor4sv) (const GLshort *v);
  void (GLAPIENTRY *glColor4ub) (GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha);
  void (GLAPIENTRY *glColor4ubv) (const GLubyte *v);
  void (GLAPIENTRY *glColor4ui) (GLuint red, GLuint green, GLuint blue, GLuint alpha);
  void (GLAPIENTRY *glColor4uiv) (const GLuint *v);
  void (GLAPIENTRY *glColor4us) (GLushort red, GLushort green, GLushort blue, GLushort alpha);
  void (GLAPIENTRY *glColor4usv) (const GLushort *v);
  void (GLAPIENTRY *glColorMask) (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha);
  void (GLAPIENTRY *glColorMaterial) (GLenum face, GLenum mode);
  void (GLAPIENTRY *glColorPointer) (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glCopyPixels) (GLint x, GLint y, GLsizei width, GLsizei height, GLenum type);
  void (GLAPIENTRY *glCopyTexImage1D) (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border);
  void (GLAPIENTRY *glCopyTexImage2D) (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
  void (GLAPIENTRY *glCopyTexSubImage1D) (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width);
  void (GLAPIENTRY *glCopyTexSubImage2D) (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
  void (GLAPIENTRY *glCullFace) (GLenum mode);
  void (GLAPIENTRY *glDeleteLists) (GLuint list, GLsizei range);
  void (GLAPIENTRY *glDeleteTextures) (GLsizei n, const GLuint *textures);
  void (GLAPIENTRY *glDepthFunc) (GLenum func);
  void (GLAPIENTRY *glDepthMask) (GLboolean flag);
  void (GLAPIENTRY *glDepthRange) (GLclampd zNear, GLclampd zFar);
  void (GLAPIENTRY *glDisable) (GLenum cap);
  void (GLAPIENTRY *glDisableClientState) (GLenum array);
  void (GLAPIENTRY *glDrawArrays) (GLenum mode, GLint first, GLsizei count);
  void (GLAPIENTRY *glDrawBuffer) (GLenum mode);
  void (GLAPIENTRY *glDrawElements) (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices);
  void (GLAPIENTRY *glDrawPixels) (GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels);
  void (GLAPIENTRY *glEdgeFlag) (GLboolean flag);
  void (GLAPIENTRY *glEdgeFlagPointer) (GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glEdgeFlagv) (const GLboolean *flag);
  void (GLAPIENTRY *glEnable) (GLenum cap);
  void (GLAPIENTRY *glEnableClientState) (GLenum array);
  void (GLAPIENTRY *glEnd) (void);
  void (GLAPIENTRY *glEndList) (void);
  void (GLAPIENTRY *glEvalCoord1d) (GLdouble u);
  void (GLAPIENTRY *glEvalCoord1dv) (const GLdouble *u);
  void (GLAPIENTRY *glEvalCoord1f) (GLfloat u);
  void (GLAPIENTRY *glEvalCoord1fv) (const GLfloat *u);
  void (GLAPIENTRY *glEvalCoord2d) (GLdouble u, GLdouble v);
  void (GLAPIENTRY *glEvalCoord2dv) (const GLdouble *u);
  void (GLAPIENTRY *glEvalCoord2f) (GLfloat u, GLfloat v);
  void (GLAPIENTRY *glEvalCoord2fv) (const GLfloat *u);
  void (GLAPIENTRY *glEvalMesh1) (GLenum mode, GLint i1, GLint i2);
  void (GLAPIENTRY *glEvalMesh2) (GLenum mode, GLint i1, GLint i2, GLint j1, GLint j2);
  void (GLAPIENTRY *glEvalPoint1) (GLint i);
  void (GLAPIENTRY *glEvalPoint2) (GLint i, GLint j);
  void (GLAPIENTRY *glFeedbackBuffer) (GLsizei size, GLenum type, GLfloat *buffer);
  void (GLAPIENTRY *glFinish) (void);
  void (GLAPIENTRY *glFlush) (void);
  void (GLAPIENTRY *glFogf) (GLenum pname, GLfloat param);
  void (GLAPIENTRY *glFogfv) (GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glFogi) (GLenum pname, GLint param);
  void (GLAPIENTRY *glFogiv) (GLenum pname, const GLint *params);
  void (GLAPIENTRY *glFrontFace) (GLenum mode);
  void (GLAPIENTRY *glFrustum) (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar);
  GLuint (GLAPIENTRY *glGenLists) (GLsizei range);
  void (GLAPIENTRY *glGenTextures) (GLsizei n, GLuint *textures);
  void (GLAPIENTRY *glGetBooleanv) (GLenum pname, GLboolean *params);
  void (GLAPIENTRY *glGetClipPlane) (GLenum plane, GLdouble *equation);
  void (GLAPIENTRY *glGetDoublev) (GLenum pname, GLdouble *params);
  GLenum (GLAPIENTRY *glGetError) (void);
  void (GLAPIENTRY *glGetFloatv) (GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetIntegerv) (GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetLightfv) (GLenum light, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetLightiv) (GLenum light, GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetMapdv) (GLenum target, GLenum query, GLdouble *v);
  void (GLAPIENTRY *glGetMapfv) (GLenum target, GLenum query, GLfloat *v);
  void (GLAPIENTRY *glGetMapiv) (GLenum target, GLenum query, GLint *v);
  void (GLAPIENTRY *glGetMaterialfv) (GLenum face, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetMaterialiv) (GLenum face, GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetPixelMapfv) (GLenum map, GLfloat *values);
  void (GLAPIENTRY *glGetPixelMapuiv) (GLenum map, GLuint *values);
  void (GLAPIENTRY *glGetPixelMapusv) (GLenum map, GLushort *values);
  void (GLAPIENTRY *glGetPointerv) (GLenum pname, GLvoid* *params);
  void (GLAPIENTRY *glGetPolygonStipple) (GLubyte *mask);
  const GLubyte* (GLAPIENTRY *glGetString) (GLenum name);
  void (GLAPIENTRY *glGetTexEnvfv) (GLenum target, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetTexEnviv) (GLenum target, GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetTexGendv) (GLenum coord, GLenum pname, GLdouble *params);
  void (GLAPIENTRY *glGetTexGenfv) (GLenum coord, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetTexGeniv) (GLenum coord, GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetTexImage) (GLenum target, GLint level, GLenum format, GLenum type, GLvoid *pixels);
  void (GLAPIENTRY *glGetTexLevelParameterfv) (GLenum target, GLint level, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetTexLevelParameteriv) (GLenum target, GLint level, GLenum pname, GLint *params);
  void (GLAPIENTRY *glGetTexParameterfv) (GLenum target, GLenum pname, GLfloat *params);
  void (GLAPIENTRY *glGetTexParameteriv) (GLenum target, GLenum pname, GLint *params);
  void (GLAPIENTRY *glHint) (GLenum target, GLenum mode);
  void (GLAPIENTRY *glIndexMask) (GLuint mask);
  void (GLAPIENTRY *glIndexPointer) (GLenum type, GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glIndexd) (GLdouble c);
  void (GLAPIENTRY *glIndexdv) (const GLdouble *c);
  void (GLAPIENTRY *glIndexf) (GLfloat c);
  void (GLAPIENTRY *glIndexfv) (const GLfloat *c);
  void (GLAPIENTRY *glIndexi) (GLint c);
  void (GLAPIENTRY *glIndexiv) (const GLint *c);
  void (GLAPIENTRY *glIndexs) (GLshort c);
  void (GLAPIENTRY *glIndexsv) (const GLshort *c);
  void (GLAPIENTRY *glIndexub) (GLubyte c);
  void (GLAPIENTRY *glIndexubv) (const GLubyte *c);
  void (GLAPIENTRY *glInitNames) (void);
  void (GLAPIENTRY *glInterleavedArrays) (GLenum format, GLsizei stride, const GLvoid *pointer);
  GLboolean (GLAPIENTRY *glIsEnabled) (GLenum cap);
  GLboolean (GLAPIENTRY *glIsList) (GLuint list);
  GLboolean (GLAPIENTRY *glIsTexture) (GLuint texture);
  void (GLAPIENTRY *glLightModelf) (GLenum pname, GLfloat param);
  void (GLAPIENTRY *glLightModelfv) (GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glLightModeli) (GLenum pname, GLint param);
  void (GLAPIENTRY *glLightModeliv) (GLenum pname, const GLint *params);
  void (GLAPIENTRY *glLightf) (GLenum light, GLenum pname, GLfloat param);
  void (GLAPIENTRY *glLightfv) (GLenum light, GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glLighti) (GLenum light, GLenum pname, GLint param);
  void (GLAPIENTRY *glLightiv) (GLenum light, GLenum pname, const GLint *params);
  void (GLAPIENTRY *glLineStipple) (GLint factor, GLushort pattern);
  void (GLAPIENTRY *glLineWidth) (GLfloat width);
  void (GLAPIENTRY *glListBase) (GLuint base);
  void (GLAPIENTRY *glLoadIdentity) (void);
  void (GLAPIENTRY *glLoadMatrixd) (const GLdouble *m);
  void (GLAPIENTRY *glLoadMatrixf) (const GLfloat *m);
  void (GLAPIENTRY *glLoadName) (GLuint name);
  void (GLAPIENTRY *glLogicOp) (GLenum opcode);
  void (GLAPIENTRY *glMap1d) (GLenum target, GLdouble u1, GLdouble u2, GLint stride, GLint order, const GLdouble *points);
  void (GLAPIENTRY *glMap1f) (GLenum target, GLfloat u1, GLfloat u2, GLint stride, GLint order, const GLfloat *points);
  void (GLAPIENTRY *glMap2d) (GLenum target, GLdouble u1, GLdouble u2, GLint ustride, GLint uorder, GLdouble v1, GLdouble v2, GLint vstride, GLint vorder, const GLdouble *points);
  void (GLAPIENTRY *glMap2f) (GLenum target, GLfloat u1, GLfloat u2, GLint ustride, GLint uorder, GLfloat v1, GLfloat v2, GLint vstride, GLint vorder, const GLfloat *points);
  void (GLAPIENTRY *glMapGrid1d) (GLint un, GLdouble u1, GLdouble u2);
  void (GLAPIENTRY *glMapGrid1f) (GLint un, GLfloat u1, GLfloat u2);
  void (GLAPIENTRY *glMapGrid2d) (GLint un, GLdouble u1, GLdouble u2, GLint vn, GLdouble v1, GLdouble v2);
  void (GLAPIENTRY *glMapGrid2f) (GLint un, GLfloat u1, GLfloat u2, GLint vn, GLfloat v1, GLfloat v2);
  void (GLAPIENTRY *glMaterialf) (GLenum face, GLenum pname, GLfloat param);
  void (GLAPIENTRY *glMaterialfv) (GLenum face, GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glMateriali) (GLenum face, GLenum pname, GLint param);
  void (GLAPIENTRY *glMaterialiv) (GLenum face, GLenum pname, const GLint *params);
  void (GLAPIENTRY *glMatrixMode) (GLenum mode);
  void (GLAPIENTRY *glMultMatrixd) (const GLdouble *m);
  void (GLAPIENTRY *glMultMatrixf) (const GLfloat *m);
  void (GLAPIENTRY *glNewList) (GLuint list, GLenum mode);
  void (GLAPIENTRY *glNormal3b) (GLbyte nx, GLbyte ny, GLbyte nz);
  void (GLAPIENTRY *glNormal3bv) (const GLbyte *v);
  void (GLAPIENTRY *glNormal3d) (GLdouble nx, GLdouble ny, GLdouble nz);
  void (GLAPIENTRY *glNormal3dv) (const GLdouble *v);
  void (GLAPIENTRY *glNormal3f) (GLfloat nx, GLfloat ny, GLfloat nz);
  void (GLAPIENTRY *glNormal3fv) (const GLfloat *v);
  void (GLAPIENTRY *glNormal3i) (GLint nx, GLint ny, GLint nz);
  void (GLAPIENTRY *glNormal3iv) (const GLint *v);
  void (GLAPIENTRY *glNormal3s) (GLshort nx, GLshort ny, GLshort nz);
  void (GLAPIENTRY *glNormal3sv) (const GLshort *v);
  void (GLAPIENTRY *glNormalPointer) (GLenum type, GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glOrtho) (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar);
  void (GLAPIENTRY *glPassThrough) (GLfloat token);
  void (GLAPIENTRY *glPixelMapfv) (GLenum map, GLsizei mapsize, const GLfloat *values);
  void (GLAPIENTRY *glPixelMapuiv) (GLenum map, GLsizei mapsize, const GLuint *values);
  void (GLAPIENTRY *glPixelMapusv) (GLenum map, GLsizei mapsize, const GLushort *values);
  void (GLAPIENTRY *glPixelStoref) (GLenum pname, GLfloat param);
  void (GLAPIENTRY *glPixelStorei) (GLenum pname, GLint param);
  void (GLAPIENTRY *glPixelTransferf) (GLenum pname, GLfloat param);
  void (GLAPIENTRY *glPixelTransferi) (GLenum pname, GLint param);
  void (GLAPIENTRY *glPixelZoom) (GLfloat xfactor, GLfloat yfactor);
  void (GLAPIENTRY *glPointSize) (GLfloat size);
  void (GLAPIENTRY *glPolygonMode) (GLenum face, GLenum mode);
  void (GLAPIENTRY *glPolygonOffset) (GLfloat factor, GLfloat units);
  void (GLAPIENTRY *glPolygonStipple) (const GLubyte *mask);
  void (GLAPIENTRY *glPopAttrib) (void);
  void (GLAPIENTRY *glPopClientAttrib) (void);
  void (GLAPIENTRY *glPopMatrix) (void);
  void (GLAPIENTRY *glPopName) (void);
  void (GLAPIENTRY *glPrioritizeTextures) (GLsizei n, const GLuint *textures, const GLclampf *priorities);
  void (GLAPIENTRY *glPushAttrib) (GLbitfield mask);
  void (GLAPIENTRY *glPushClientAttrib) (GLbitfield mask);
  void (GLAPIENTRY *glPushMatrix) (void);
  void (GLAPIENTRY *glPushName) (GLuint name);
  void (GLAPIENTRY *glRasterPos2d) (GLdouble x, GLdouble y);
  void (GLAPIENTRY *glRasterPos2dv) (const GLdouble *v);
  void (GLAPIENTRY *glRasterPos2f) (GLfloat x, GLfloat y);
  void (GLAPIENTRY *glRasterPos2fv) (const GLfloat *v);
  void (GLAPIENTRY *glRasterPos2i) (GLint x, GLint y);
  void (GLAPIENTRY *glRasterPos2iv) (const GLint *v);
  void (GLAPIENTRY *glRasterPos2s) (GLshort x, GLshort y);
  void (GLAPIENTRY *glRasterPos2sv) (const GLshort *v);
  void (GLAPIENTRY *glRasterPos3d) (GLdouble x, GLdouble y, GLdouble z);
  void (GLAPIENTRY *glRasterPos3dv) (const GLdouble *v);
  void (GLAPIENTRY *glRasterPos3f) (GLfloat x, GLfloat y, GLfloat z);
  void (GLAPIENTRY *glRasterPos3fv) (const GLfloat *v);
  void (GLAPIENTRY *glRasterPos3i) (GLint x, GLint y, GLint z);
  void (GLAPIENTRY *glRasterPos3iv) (const GLint *v);
  void (GLAPIENTRY *glRasterPos3s) (GLshort x, GLshort y, GLshort z);
  void (GLAPIENTRY *glRasterPos3sv) (const GLshort *v);
  void (GLAPIENTRY *glRasterPos4d) (GLdouble x, GLdouble y, GLdouble z, GLdouble w);
  void (GLAPIENTRY *glRasterPos4dv) (const GLdouble *v);
  void (GLAPIENTRY *glRasterPos4f) (GLfloat x, GLfloat y, GLfloat z, GLfloat w);
  void (GLAPIENTRY *glRasterPos4fv) (const GLfloat *v);
  void (GLAPIENTRY *glRasterPos4i) (GLint x, GLint y, GLint z, GLint w);
  void (GLAPIENTRY *glRasterPos4iv) (const GLint *v);
  void (GLAPIENTRY *glRasterPos4s) (GLshort x, GLshort y, GLshort z, GLshort w);
  void (GLAPIENTRY *glRasterPos4sv) (const GLshort *v);
  void (GLAPIENTRY *glReadBuffer) (GLenum mode);
  void (GLAPIENTRY *glReadPixels) (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, GLvoid *pixels);
  void (GLAPIENTRY *glRectd) (GLdouble x1, GLdouble y1, GLdouble x2, GLdouble y2);
  void (GLAPIENTRY *glRectdv) (const GLdouble *v1, const GLdouble *v2);
  void (GLAPIENTRY *glRectf) (GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2);
  void (GLAPIENTRY *glRectfv) (const GLfloat *v1, const GLfloat *v2);
  void (GLAPIENTRY *glRecti) (GLint x1, GLint y1, GLint x2, GLint y2);
  void (GLAPIENTRY *glRectiv) (const GLint *v1, const GLint *v2);
  void (GLAPIENTRY *glRects) (GLshort x1, GLshort y1, GLshort x2, GLshort y2);
  void (GLAPIENTRY *glRectsv) (const GLshort *v1, const GLshort *v2);
  GLint (GLAPIENTRY *glRenderMode) (GLenum mode);
  void (GLAPIENTRY *glRotated) (GLdouble angle, GLdouble x, GLdouble y, GLdouble z);
  void (GLAPIENTRY *glRotatef) (GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
  void (GLAPIENTRY *glScaled) (GLdouble x, GLdouble y, GLdouble z);
  void (GLAPIENTRY *glScalef) (GLfloat x, GLfloat y, GLfloat z);
  void (GLAPIENTRY *glScissor) (GLint x, GLint y, GLsizei width, GLsizei height);
  void (GLAPIENTRY *glSelectBuffer) (GLsizei size, GLuint *buffer);
  void (GLAPIENTRY *glShadeModel) (GLenum mode);
  void (GLAPIENTRY *glStencilFunc) (GLenum func, GLint ref, GLuint mask);
  void (GLAPIENTRY *glStencilMask) (GLuint mask);
  void (GLAPIENTRY *glStencilOp) (GLenum fail, GLenum zfail, GLenum zpass);
  void (GLAPIENTRY *glTexCoord1d) (GLdouble s);
  void (GLAPIENTRY *glTexCoord1dv) (const GLdouble *v);
  void (GLAPIENTRY *glTexCoord1f) (GLfloat s);
  void (GLAPIENTRY *glTexCoord1fv) (const GLfloat *v);
  void (GLAPIENTRY *glTexCoord1i) (GLint s);
  void (GLAPIENTRY *glTexCoord1iv) (const GLint *v);
  void (GLAPIENTRY *glTexCoord1s) (GLshort s);
  void (GLAPIENTRY *glTexCoord1sv) (const GLshort *v);
  void (GLAPIENTRY *glTexCoord2d) (GLdouble s, GLdouble t);
  void (GLAPIENTRY *glTexCoord2dv) (const GLdouble *v);
  void (GLAPIENTRY *glTexCoord2f) (GLfloat s, GLfloat t);
  void (GLAPIENTRY *glTexCoord2fv) (const GLfloat *v);
  void (GLAPIENTRY *glTexCoord2i) (GLint s, GLint t);
  void (GLAPIENTRY *glTexCoord2iv) (const GLint *v);
  void (GLAPIENTRY *glTexCoord2s) (GLshort s, GLshort t);
  void (GLAPIENTRY *glTexCoord2sv) (const GLshort *v);
  void (GLAPIENTRY *glTexCoord3d) (GLdouble s, GLdouble t, GLdouble r);
  void (GLAPIENTRY *glTexCoord3dv) (const GLdouble *v);
  void (GLAPIENTRY *glTexCoord3f) (GLfloat s, GLfloat t, GLfloat r);
  void (GLAPIENTRY *glTexCoord3fv) (const GLfloat *v);
  void (GLAPIENTRY *glTexCoord3i) (GLint s, GLint t, GLint r);
  void (GLAPIENTRY *glTexCoord3iv) (const GLint *v);
  void (GLAPIENTRY *glTexCoord3s) (GLshort s, GLshort t, GLshort r);
  void (GLAPIENTRY *glTexCoord3sv) (const GLshort *v);
  void (GLAPIENTRY *glTexCoord4d) (GLdouble s, GLdouble t, GLdouble r, GLdouble q);
  void (GLAPIENTRY *glTexCoord4dv) (const GLdouble *v);
  void (GLAPIENTRY *glTexCoord4f) (GLfloat s, GLfloat t, GLfloat r, GLfloat q);
  void (GLAPIENTRY *glTexCoord4fv) (const GLfloat *v);
  void (GLAPIENTRY *glTexCoord4i) (GLint s, GLint t, GLint r, GLint q);
  void (GLAPIENTRY *glTexCoord4iv) (const GLint *v);
  void (GLAPIENTRY *glTexCoord4s) (GLshort s, GLshort t, GLshort r, GLshort q);
  void (GLAPIENTRY *glTexCoord4sv) (const GLshort *v);
  void (GLAPIENTRY *glTexCoordPointer) (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glTexEnvf) (GLenum target, GLenum pname, GLfloat param);
  void (GLAPIENTRY *glTexEnvfv) (GLenum target, GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glTexEnvi) (GLenum target, GLenum pname, GLint param);
  void (GLAPIENTRY *glTexEnviv) (GLenum target, GLenum pname, const GLint *params);
  void (GLAPIENTRY *glTexGend) (GLenum coord, GLenum pname, GLdouble param);
  void (GLAPIENTRY *glTexGendv) (GLenum coord, GLenum pname, const GLdouble *params);
  void (GLAPIENTRY *glTexGenf) (GLenum coord, GLenum pname, GLfloat param);
  void (GLAPIENTRY *glTexGenfv) (GLenum coord, GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glTexGeni) (GLenum coord, GLenum pname, GLint param);
  void (GLAPIENTRY *glTexGeniv) (GLenum coord, GLenum pname, const GLint *params);
  void (GLAPIENTRY *glTexImage1D) (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
  void (GLAPIENTRY *glTexImage2D) (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
  void (GLAPIENTRY *glTexParameterf) (GLenum target, GLenum pname, GLfloat param);
  void (GLAPIENTRY *glTexParameterfv) (GLenum target, GLenum pname, const GLfloat *params);
  void (GLAPIENTRY *glTexParameteri) (GLenum target, GLenum pname, GLint param);
  void (GLAPIENTRY *glTexParameteriv) (GLenum target, GLenum pname, const GLint *params);
  void (GLAPIENTRY *glTexSubImage1D) (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels);
  void (GLAPIENTRY *glTexSubImage2D) (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels);
  void (GLAPIENTRY *glTranslated) (GLdouble x, GLdouble y, GLdouble z);
  void (GLAPIENTRY *glTranslatef) (GLfloat x, GLfloat y, GLfloat z);
  void (GLAPIENTRY *glVertex2d) (GLdouble x, GLdouble y);
  void (GLAPIENTRY *glVertex2dv) (const GLdouble *v);
  void (GLAPIENTRY *glVertex2f) (GLfloat x, GLfloat y);
  void (GLAPIENTRY *glVertex2fv) (const GLfloat *v);
  void (GLAPIENTRY *glVertex2i) (GLint x, GLint y);
  void (GLAPIENTRY *glVertex2iv) (const GLint *v);
  void (GLAPIENTRY *glVertex2s) (GLshort x, GLshort y);
  void (GLAPIENTRY *glVertex2sv) (const GLshort *v);
  void (GLAPIENTRY *glVertex3d) (GLdouble x, GLdouble y, GLdouble z);
  void (GLAPIENTRY *glVertex3dv) (const GLdouble *v);
  void (GLAPIENTRY *glVertex3f) (GLfloat x, GLfloat y, GLfloat z);
  void (GLAPIENTRY *glVertex3fv) (const GLfloat *v);
  void (GLAPIENTRY *glVertex3i) (GLint x, GLint y, GLint z);
  void (GLAPIENTRY *glVertex3iv) (const GLint *v);
  void (GLAPIENTRY *glVertex3s) (GLshort x, GLshort y, GLshort z);
  void (GLAPIENTRY *glVertex3sv) (const GLshort *v);
  void (GLAPIENTRY *glVertex4d) (GLdouble x, GLdouble y, GLdouble z, GLdouble w);
  void (GLAPIENTRY *glVertex4dv) (const GLdouble *v);
  void (GLAPIENTRY *glVertex4f) (GLfloat x, GLfloat y, GLfloat z, GLfloat w);
  void (GLAPIENTRY *glVertex4fv) (const GLfloat *v);
  void (GLAPIENTRY *glVertex4i) (GLint x, GLint y, GLint z, GLint w);
  void (GLAPIENTRY *glVertex4iv) (const GLint *v);
  void (GLAPIENTRY *glVertex4s) (GLshort x, GLshort y, GLshort z, GLshort w);
  void (GLAPIENTRY *glVertex4sv) (const GLshort *v);
  void (GLAPIENTRY *glVertexPointer) (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer);
  void (GLAPIENTRY *glViewport) (GLint x, GLint y, GLsizei width, GLsizei height);
};

//Windows OpenGL API methods
struct WGLDriver
{
  int   (GLAPIENTRY *wglChoosePixelFormat)       (HDC a, CONST PIXELFORMATDESCRIPTOR *b);
  BOOL  (GLAPIENTRY *wglCopyContext)             (HGLRC a, HGLRC b, UINT c);
  HGLRC (GLAPIENTRY *wglCreateContext)           (HDC a);
  HGLRC (GLAPIENTRY *wglCreateLayerContext)      (HDC a, int b);
  BOOL  (GLAPIENTRY *wglDeleteContext)           (HGLRC a);
  BOOL  (GLAPIENTRY *wglDescribeLayerPlane)      (HDC a, int b, int c, UINT d, LPLAYERPLANEDESCRIPTOR e);
  int   (GLAPIENTRY *wglDescribePixelFormat)     (HDC a, int b, UINT c, LPPIXELFORMATDESCRIPTOR d);
  HGLRC (GLAPIENTRY *wglGetCurrentContext)       (void);
  HDC   (GLAPIENTRY *wglGetCurrentDC)            (void);
  PROC  (GLAPIENTRY *wglGetDefaultProcAddress)   (LPCSTR a);
  int   (GLAPIENTRY *wglGetLayerPaletteEntries)  (HDC a, int b, int c, int d, COLORREF *e);
  int   (GLAPIENTRY *wglGetPixelFormat)          (HDC a);
  PROC  (GLAPIENTRY *wglGetProcAddress)          (LPCSTR a);
  BOOL  (GLAPIENTRY *wglMakeCurrent)             (HDC a, HGLRC b);
  BOOL  (GLAPIENTRY *wglRealizeLayerPalette)     (HDC a, int b, BOOL c);
  int   (GLAPIENTRY *wglSetLayerPaletteEntries)  (HDC a, int b, int c, int d, CONST COLORREF *e);
  BOOL  (GLAPIENTRY *wglSetPixelFormat)          (HDC a, int b, CONST PIXELFORMATDESCRIPTOR *c);
  BOOL  (GLAPIENTRY *wglShareLists)              (HGLRC a, HGLRC b);
  BOOL  (GLAPIENTRY *wglSwapBuffers)             (HDC a);
  BOOL  (GLAPIENTRY *wglSwapLayerBuffers)        (HDC a, UINT b);
  BOOL  (GLAPIENTRY *wglUseFontBitmapsA)         (HDC a, DWORD b, DWORD c, DWORD d);
  BOOL  (GLAPIENTRY *wglUseFontBitmapsW)         (HDC a, DWORD b, DWORD c, DWORD d);
  BOOL  (GLAPIENTRY *wglUseFontOutlinesA)        (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);
  BOOL  (GLAPIENTRY *wglUseFontOutlinesW)        (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);
};

//The OpenGL drivers
extern GLCoreDriver GLV;
extern WGLDriver    GLW;

#endif // __GL_DRIVER_H_
