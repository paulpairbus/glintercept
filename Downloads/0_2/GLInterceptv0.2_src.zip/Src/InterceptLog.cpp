/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLog.h"
#include "GLDriver.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::InterceptLog(const char *fileName,FunctionTable * functionTable,const ConfigData &configData):
logFileName(fileName),
logFile(NULL),
functionTable(functionTable),
glGetErrorFuncData(NULL),
shaderRenderCallLog(configData.shaderRenderCallStateLog),
imageRenderCallLog(configData.imageRenderCallStateLog)
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::Init()
{
  //Write the log header
  struct tm *newtime;
  time_t     aclock;

  //Attempt to open the file
  logFile = fopen(logFileName.c_str(),"wt");

  //Prevent NULL file settings
  if(logFile == NULL)
  {
    LOGERR(("InterceptLog - Unable to open log file %s",logFileName.c_str()));
    return false;
  }

  //Get the current time
  time( &aclock );

  //Convert it
  newtime = localtime( &aclock );

  fprintf(logFile,
    "===============================================================================\n"
    " GLIntercept version %s Log generated on: %s \n"
    "===============================================================================\n",__GLI_BUILD_VER_STR,asctime(newtime));


  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptLog::~InterceptLog()
{
  //Close the log file
  if(logFile)
  {
    fclose(logFile);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLog::LogFunctionPre - Function data for index %d is NULL",index)); 
    return;
  }

  //Start the functio on a newline
  fprintf(logFile,"\n");

  //Log the name
  fprintf(logFile,"%s",funcData->functionName.c_str());

  //Open the bracket
  fprintf(logFile,"(");

  //Loop for all the parameters
  for(uint i=0;i<funcData->parameterArray.size();i++)
  {
    //Get the parameter
    const ParameterData * paramData = &funcData->parameterArray[i];


    //Determine if we are processing pointers
    bool isPointer=false;
    if(paramData->pointerCount > 0 || paramData->length != -1)
    {
      isPointer=true;
    }

    //Get the value
    void *value;
    if(!GetNextValue(paramData->GetGLType(),&args,isPointer,&value))
    {
      break;
    }

    //Test if this is an array value
    if(paramData->length != -1)
    {
      bool isArrayOfPointers = false;

      //Test for an array of pointers
      if(paramData->pointerCount > 0)
      {
        isArrayOfPointers = true;
      }

      //Assign the array
      void * array =  *((void **)value);

      //Loop and print the array
      fprintf(logFile,"[");
      for(uint i2=0;i2<paramData->length;i2++)
      {
        //Get the value from the array
        if(!GetNextArrayValue(paramData->GetGLType(),&array,isArrayOfPointers,&value))
        {
          break;
        }
      
        //Convert and print the value
        string out=ConvertParam(value,isArrayOfPointers,paramData);
        fprintf(logFile,"%s",out.c_str());

        //Add a comma
        if(i2 != paramData->length - 1)
        {
          fprintf(logFile,",");
        }
      }
      fprintf(logFile,"]");
    }
    else
    {
      //Just get the single value
      string out=ConvertParam(value,isPointer,paramData);
      fprintf(logFile,"%s",out.c_str());
    }

    //Add a comma
    if(i != funcData->parameterArray.size() - 1)
    {
      fprintf(logFile,",");
    }
  }

  //If there are no parameters (unknown function)
  if(funcData->parameterArray.size() == 0)
  {
    fprintf(logFile," ??? ");
  }

  //Close the bracket
  fprintf(logFile,")");

  //Reset the argument list
  va_end(args);

  //If this is an rendering function
  if(funcData->functionFlags & FDF_RENDER_FUNC)
  {
    //If we log shaders on render calls, log them
    if(shaderRenderCallLog)
    {
      //Get the bound shaders
      uint vertexShader,fragmentShader;
      glDriver.GetBoundShaders(vertexShader,fragmentShader);

      //If a valid vertex shader, log it
      if(vertexShader != 0)
      {
        fprintf(logFile," VP=%u ",vertexShader);
      }

      if(fragmentShader != 0)
      {
        fprintf(logFile," FP=%u ",fragmentShader);
      }
    }

    //If we log images on render calls, log them
    if(imageRenderCallLog)
    {
      //Get the bound textures
      BoundTextureArray boundTextures;
      glDriver.GetBoundTextures(boundTextures);

      //If there are any textures
      if(boundTextures.size() > 0)
      {
        fprintf(logFile," Textures[ ");
        
        //Loop for all textures and log the stage and texture number
        for(uint i=0;i<boundTextures.size();i++)
        {
          fprintf(logFile,"(%u,%u) ",boundTextures[i].texStage,boundTextures[i].texID);
        }

        fprintf(logFile,"] ");
      }
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLog::LogFunctionPost - Function data for index %d is NULL",index)); 
    return;
  }

  //Get the return parameter
  const ParameterData * returnData = &funcData->returnType;

  //Determine if we are processing pointers
  bool isPointer=false;
  if(returnData->pointerCount > 0)
  {
    isPointer=true;
  }

  //Check for a return value of a supported type
  // NOTE: Does not currently support arrays
  if(isPointer || 
     returnData->type == PT_enum     ||
     returnData->type == PT_boolean  ||
     returnData->type == PT_bitfield ||
     returnData->type == PT_byte     ||
     returnData->type == PT_short    ||
     returnData->type == PT_int      || 
     returnData->type == PT_ubyte    ||
     returnData->type == PT_ushort   ||
     returnData->type == PT_uint     ||
     returnData->type == PT_handle   ||
     returnData->type == PT_sizei    ||
     returnData->type == PT_float    ||
     returnData->type == PT_clampf)
  {
    //Check the return value
    if(retVal != NULL)
    {
      //Look up the data
      string out = ConvertParam(retVal, isPointer, returnData);

      //Log the result
      fprintf(logFile,"=%s ",out.c_str());
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::LogFunctionError(uint errorCode)
{
  //If the log is not writing or the error code is 0, return
  if(!logEnabled || errorCode == 0x0)
  {
    return;
  }

  //If we do no have a pointer to glGetError yet, get it
  if(glGetErrorFuncData == NULL)
  {
    //Get the index of the function
    int index =functionTable->FindFunction("glGetError");
    if(index != -1)
    {
      //Get the function data
      glGetErrorFuncData = functionTable->GetFunctionData(index);
    }
  }

  //Log that an error has occured
  fprintf(logFile," glGetError() =");

  //If the function is still not found, just log the number
  if(glGetErrorFuncData == NULL || glGetErrorFuncData->returnType.type != PT_enum)
  {
    fprintf(logFile,"0x%04x",errorCode);
  }
  else
  {
    //Get the return parameter
    const ParameterData * returnData = &glGetErrorFuncData->returnType;

    //Get the string version    
    string out = ConvertParam(&errorCode, false, returnData);

    //Log the result
    fprintf(logFile,"%s",out.c_str());
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLog::LogFunctionComplete()
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Do nothing for now
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextValue(ParameterType pType, va_list *args, bool isPointer,void **value)
{
  //Test if we are getting a pointer
  if(isPointer)
  {
    //Get the pointer value
    *value = &va_arg(*args,void *);

    //Return true
    return true;
  }

  //Determine the type to return
  switch(pType)
  {
    case(PT_enum):
    case(PT_bitfield):
      //Get the value
      *value = &va_arg(*args,unsigned int);
      break;

    case(PT_void):
      *value = NULL;
      break;

    case(PT_byte):
      //Get the value
      *value = &va_arg(*args,unsigned char);
      break;
    case(PT_short):
      //Get the value
      *value = &va_arg(*args,short);
      break;

    case(PT_int):
    case(PT_sizei):
      //Get the value
      *value = &va_arg(*args,int);
      break;

    case(PT_ubyte):
    case(PT_boolean):
      //Get the value
      *value = &va_arg(*args,unsigned char);
      break;

    case(PT_ushort):
      //Get the value
      *value = &va_arg(*args,unsigned short);
      break;

    case(PT_uint):
    case(PT_handle):
      //Get the value
      *value = &va_arg(*args,unsigned int);
      break;

    case(PT_float):
    case(PT_clampf):
      //Get the value
      *value = &va_arg(*args,float);
      break;

    case(PT_double):
    case(PT_clampd):
      //Get the value
      *value = &va_arg(*args,double);
      break;

    default:
      LOGERR(("InterceptLog::GetNextValue - Unhandled parameter in function of type %d",(int)pType));
      return false;
  }
 

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::GetNextArrayValue(ParameterType pType, void **array, bool isPointer,void **value)
{
  //The value to increment the array by
  uint arrayInc;

  //Test if we are getting a pointer
  if(isPointer)
  {
    arrayInc = sizeof(void *);
  }
  else
  {

    //Determine the type to return
    switch(pType)
    {
      case(PT_enum):
      case(PT_bitfield):
        //Get the value
        arrayInc = sizeof(unsigned int);
        break;

      case(PT_void):
        arrayInc = 0;
        break;

      case(PT_byte):
        //Get the value
        arrayInc = sizeof(unsigned char);
        break;
      case(PT_short):
        //Get the value
        arrayInc = sizeof(short);
        break;

      case(PT_int):
      case(PT_sizei):
        //Get the value
        arrayInc = sizeof(int);
        break;

      case(PT_ubyte):
      case(PT_boolean):
        //Get the value
        arrayInc = sizeof(unsigned char);
        break;

      case(PT_ushort):
        //Get the value
        arrayInc = sizeof(unsigned short);
        break;

      case(PT_uint):
      case(PT_handle): 
        //Get the value
        arrayInc = sizeof(unsigned int);
        break;

      case(PT_float):
      case(PT_clampf):
        //Get the value
        arrayInc = sizeof(float);
        break;

      case(PT_double):
      case(PT_clampd):
        //Get the value
        arrayInc = sizeof(double);
        break;

      default:
        LOGERR(("InterceptLog::GetNextArrayValue - Unhandled parameter in function of type %d",(int)pType));
        return false;
    }
  } 

  //Assign the value
  *value = *array;

  //Increment the array
  *array = ((char *)(*array) + arrayInc);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
string InterceptLog::ConvertParam(void *data, bool isPointer,const ParameterData *paramData)
{
  string retString;

  //A character buffer
  static char buffer[100];

  //If the data is a custom type, attempt to handle it
  if(paramData->IsCustomType() && 
     ConvertCustomParam(data,isPointer,paramData,retString))
  {
    return retString;
  }

  //If this is a pointer, out-put the address
  if(isPointer)
  {
    //Just get the pointer's address
    sprintf(buffer,"0x%04x",*((int*)data));
    retString = buffer;
  }
  else
  {

    //Do a big switch statement
    ParameterType pType=paramData->GetGLType();
    switch(pType)
    {
      case(PT_enum):
      case(PT_bitfield):
        {
          //Get the enum data
          const EnumData * enumData=functionTable->GetEnumData(paramData->index);

          //If the index is invalid, Just print the hex values
          if(enumData ==NULL)
          {
            sprintf(buffer,"0x%04x",*((uint*)data));
            retString = buffer;
          }
          else
          {
            retString = enumData->GetDisplayString(*((uint*)data));
          }
        }
        break;

      case(PT_boolean):
        {
          int num = *((unsigned char*)data);

          //Check the value
          if(num == 0)
          {
            retString = "false";
          }
          else if(num == 1)
          {
            retString = "true";
          }
          else
          {
            sprintf(buffer,"Invalid boolean %u",num);
            retString = buffer;
          }
          break;
        }

      case(PT_void):
        break;

      case(PT_byte):
        {
          int num = *((signed char*)data);
          sprintf(buffer,"%d",num);
          retString = buffer;
          break;
        }

      case(PT_short):
        {
          int num = *((short*)data);
          sprintf(buffer,"%d",num);
          retString = buffer;
          break;
        }

      case(PT_int):
      case(PT_sizei):
        {
          int num = *((int*)data);
          sprintf(buffer,"%d",num);
          retString = buffer;
          break;
        }

      case(PT_ubyte):
        {
          uint num = *((unsigned char*)data);
          sprintf(buffer,"%u",num);
          retString = buffer;
          break;
        }

      case(PT_ushort):
        {
          uint num = *((unsigned short*)data);
          sprintf(buffer,"%u",num);
          retString = buffer;
          break;
        }

      case(PT_uint):
      case(PT_handle):
        {
          uint num = *((unsigned int*)data);
          sprintf(buffer,"%u",num);
          retString = buffer;
          break;
        }

      case(PT_float):
      case(PT_clampf):
        {
          float num = *((float*)data);
          sprintf(buffer,"%f",num);
          retString = buffer;

          //Check clamped values
          if(pType == PT_clampf && (num < 0.0f || num > 1.0f))
          {
            retString = retString + "- Invalid clamped value";
          }
          break;
        }

      case(PT_double):
      case(PT_clampd):
        {
          double num = *((double*)data);
          sprintf(buffer,"%f",num);
          retString = buffer;

          //Check clamped values
          if(pType == PT_clampd && (num < 0.0 || num > 1.0))
          {
            retString = retString + "- Invalid clamped value";
          }

          break;
        }

      default:
        LOGERR(("InterceptLog::ConvertParam - Unhandled parameter in function of type %d",(int)pType));
    }
  }

  return retString;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLog::ConvertCustomParam(void *data, bool isPointer,const ParameterData *paramData,string &retString)
{
  //A character buffer
  static char buffer[100];

  //Handle pointer types first
  if(isPointer)
  {
    //If the pointer is to an array of characters, get the characters
    if(paramData->type == PT_ascii_string && paramData->pointerCount == 1)
    {
      char * charArray = *((char **)data);
      
      //If the string length is greater than 25 charcters, append it
      if(strlen(charArray) > 25)
      {
        strncpy(buffer,charArray,25);
        buffer[25] = '\0';
        
        //Assign the buffer data
        retString = buffer;
        retString = "\"" + retString + "...\"";
      }
      else
      {
        //Assign the entire character array
        retString = charArray;
        retString = "\"" + retString + "\"";
      }

      return true;
    }
  }

  /*
  //Determine the type
  switch(paramData->type)
  {



  }
  */

  return false;
}


