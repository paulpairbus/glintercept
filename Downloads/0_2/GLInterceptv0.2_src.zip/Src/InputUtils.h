/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __INPUT_UTILS_H__
#define __INPUT_UTILS_H__

#include "GLInterceptConfig.h"

#include <string>
#include <vector>

using namespace std;

//@
//  Summary:
//    Input utility functions that are OS specific
// 
class InputUtils
{
public:

  //@
  //  Summary:
  //    To determine if a key is currently down or up.
  //  
  //  Parameters:
  //    keyCode  - The OS specific key code to check. (use GetKeyCode)
  //
  //  Returns:
  //    If the key is down, true is returned. If the keycode is unknown
  //    or the key is up, false is returned.
  //
  static bool IsKeyDown(uint keyCode);

  //@
  //  Summary:
  //    To if all the passed keys are down.
  //  
  //  Parameters:
  //    keyCodes - The array of key codes to check.
  //
  //  Returns:
  //    If all the passed keycodes are down, true is returned. 
  //    Else false is returned. (false is returned if no keys are passed)
  //
  static bool IsAllKeyDown(vector<uint> keyCodes);

  //@
  //  Summary:
  //    To get the OS specific key code for the passed string.
  //  
  //  Parameters:
  //    keyString  - The passed string to get the keycode for. Values can be
  //                 a single letter or number or a string like "ctrl","alt",
  //                 "shift","num1","tab" etc.
  //
  //  Returns:
  //    If zero is returned, the keycode for the string could not be found. 
  //    Else, the keycode is returned.
  //
  static uint GetKeyCode(const string & keyString);

};








#endif //__INPUT_UTILS_H__
