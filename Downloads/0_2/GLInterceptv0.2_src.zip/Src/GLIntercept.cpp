/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
// GLIntercept.cpp : Defines the entry point for the DLL application.

#include "stdafx.h"
#include "GLIntercept.h"
#include "GLDriver.h"
#include <string>
#include "FileUtils.h"
#include <direct.h>
#include <time.h>

using namespace std;

//The main error log
ErrorLog *gliLog=NULL;

//The main OpenGL driver 
GLDriver glDriver;

//The path to the dll location (including trailing seperator)
string dllPath;

///////////////////////////////////////////////////////////////////////////////
//
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved)
{

  switch (ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
    { 
      //Get the module's file name
      static char dllName[1024];
      GetModuleFileName((HMODULE)hModule,dllName,1023);
 
      //Get the path
      dllPath = dllName;
      int pathEnd = dllPath.rfind(FileUtils::dirSeparator);
      if(pathEnd != string::npos)
      {
        //Remove the file name part
        dllPath.erase(pathEnd+1,dllPath.size()-pathEnd-1);
      }
      else
      {
        //If we could not even find a back slash, just set the path as the current directory
        if(_getcwd( dllName, 1024 ) != NULL)
        {
          //Assign the path and a trailing seperator
          dllPath = dllName;
          dllPath = dllPath + FileUtils::dirSeparator;
        }
        else
        {
          dllPath = "";
        }
      }

      //Create the log
      gliLog = new ErrorLog((dllPath + "gliLog.txt").c_str());

      //Get the current time
      time_t aclock;
      time( &aclock );

      //Convert it
      struct tm *newtime = localtime( &aclock );

      //Set the error log to always flush
      gliLog->SetLogFlush(true);
      gliLog->LogError("GL Intercept Log. Version : %s    Compile Date: %s    Run on: %s",__GLI_BUILD_VER_STR,__DATE__,asctime(newtime));
      gliLog->LogError("===================================================");
      gliLog->SetDebuggerLogEnabled(true);

      break;
    }

    //NOTE: GLIntercept does not currently support multiple threads
    case DLL_THREAD_ATTACH:
      break;
    case DLL_THREAD_DETACH:
      break;
    case DLL_PROCESS_DETACH:
    {
      break;
    }
  }
  return TRUE;
}

