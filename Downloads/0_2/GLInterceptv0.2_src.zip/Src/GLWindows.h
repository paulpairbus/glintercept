/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __GL_WINDOWS_H_
#define __GL_WINDOWS_H_

#include "GLInterceptConfig.h"
#include "GLDriver.h"

#ifdef _MSC_VER
#pragma warning (disable:4273)   // No complaints about DLL linkage.
#endif // _MSC_VER 


#define WGLAPI __declspec(dllexport)
#define WGLAPIENTRY __stdcall

WGLAPI int   WGLAPIENTRY wglChoosePixelFormat     (HDC a, CONST PIXELFORMATDESCRIPTOR *b);
WGLAPI BOOL  WGLAPIENTRY wglCopyContext           (HGLRC a, HGLRC b, UINT c);
WGLAPI HGLRC WGLAPIENTRY wglCreateContext         (HDC a);
WGLAPI HGLRC WGLAPIENTRY wglCreateLayerContext    (HDC a, int b);
WGLAPI BOOL  WGLAPIENTRY wglDeleteContext         (HGLRC a);
WGLAPI BOOL  WGLAPIENTRY wglDescribeLayerPlane    (HDC a, int b, int c, UINT d, LPLAYERPLANEDESCRIPTOR e);
WGLAPI int   WGLAPIENTRY wglDescribePixelFormat   (HDC a, int b, UINT c, LPPIXELFORMATDESCRIPTOR d);
WGLAPI HGLRC WGLAPIENTRY wglGetCurrentContext     (void);
WGLAPI HDC   WGLAPIENTRY wglGetCurrentDC          (void);
WGLAPI PROC  WGLAPIENTRY wglGetDefaultProcAddress (LPCSTR a);
WGLAPI int   WGLAPIENTRY wglGetLayerPaletteEntries(HDC a, int b, int c, int d, COLORREF *e);
WGLAPI int   WGLAPIENTRY wglGetPixelFormat        (HDC a);
WGLAPI PROC  WGLAPIENTRY wglGetProcAddress        (LPCSTR a);
WGLAPI BOOL  WGLAPIENTRY wglMakeCurrent           (HDC a, HGLRC b);
WGLAPI BOOL  WGLAPIENTRY wglRealizeLayerPalette   (HDC a, int b, BOOL c);
WGLAPI int   WGLAPIENTRY wglSetLayerPaletteEntries(HDC a, int b, int c, int d, CONST COLORREF *e);
WGLAPI BOOL  WGLAPIENTRY wglSetPixelFormat        (HDC a, int b, CONST PIXELFORMATDESCRIPTOR *c);
WGLAPI BOOL  WGLAPIENTRY wglShareLists            (HGLRC a, HGLRC b);
WGLAPI BOOL  WGLAPIENTRY wglSwapBuffers           (HDC a);
WGLAPI BOOL  WGLAPIENTRY wglSwapLayerBuffers      (HDC a, UINT b);
WGLAPI BOOL  WGLAPIENTRY wglUseFontBitmapsA       (HDC a, DWORD b, DWORD c, DWORD d);
WGLAPI BOOL  WGLAPIENTRY wglUseFontBitmapsW       (HDC a, DWORD b, DWORD c, DWORD d);
WGLAPI BOOL  WGLAPIENTRY wglUseFontOutlinesA      (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);
WGLAPI BOOL  WGLAPIENTRY wglUseFontOutlinesW      (HDC a, DWORD b, DWORD c, DWORD d, FLOAT e, FLOAT f, int g, LPGLYPHMETRICSFLOAT h);


#endif // __GL_WINDOWS_H_

