/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __FUNCTION_DATA_H_
#define __FUNCTION_DATA_H_
#include "GLInterceptConfig.h"
#include "ParameterData.h"
#include <string>
#include <vector>

using namespace std;


enum FunctionDataFlags
{
  FDF_LOG_IGNORE  = 0x0001,  // Ignore this function when logging (only file logging is ignored)
  FDF_IMAGE_LOG   = 0x0002,  // This function is used by the image logger
  FDF_SHADER_LOG  = 0x0004,  // This function is used by the shader logger
  FDF_RENDER_FUNC = 0x0008,  // This function is a render call
  FDF_FRAME_FUNC  = 0x0010,  // This function is a end of frame function
};

//@
//  Summary:
//    This class provides simple storage of data required by a GL function
//  
class FunctionData  
{
public:

  //Constructor/ Destructor
  FunctionData();
  virtual ~FunctionData();

public:
  string  functionName;                           // The function's name
  void   *functionPtr;                            // A pointer to the function

  ParameterData      returnType;                  // The return type of this function
  ParameterDataArray parameterArray;              // The parameters of this function
  
  uint    functionFlags;                          // Flags associated with this function

};
typedef vector<FunctionData> FunctionDataArray;

#endif // __FUNCTION_DATA_H_
