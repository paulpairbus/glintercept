/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptImage.h"
#include "GLDriver.h"


USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
ImageData::ImageData():
id(0),
validID(false),
ready(false),
dirty(false),
sizeEstimate(0),
pBufferBound(false),
pBufferHandle(NULL),
pBufferBufType(0)
{
}

///////////////////////////////////////////////////////////////////////////////
//
ImageData::Reset()
{

  //Reset all variable but the texture ID and the save count
  validID = false;
  ready =false;
  
  //Note that the dirty flag has to be set to false
  dirty =false;
  sizeEstimate =0;

  //Reset the p-buffer flags
  pBufferBound    = false;
  pBufferHandle   = NULL;
  pBufferBufType  = 0;
}

///////////////////////////////////////////////////////////////////////////////
//
bool ImageData::GetUniqueFileName(string &retString) const
{
  //A character buffer
  static char buffer[100];

  if(!validID)
  {
    LOGERR(("ImageData::GetUniqueFileName - Getting name for invalid texture"));
    return false;
  }

  //Set the initial image name
  retString = "Image_";

  //Append the image type
  switch(glType)
  {
    case(GL_TEXTURE_1D):
      retString = retString + "1D_";
      break;
    case(GL_TEXTURE_2D):
      retString = retString + "2D_";
      break;
    case(GL_TEXTURE_3D):
      retString = retString + "3D_";
      break;
    case(GL_TEXTURE_CUBE_MAP):
      retString = retString + "CUBE_";
      break;
    case(GL_TEXTURE_RECTANGLE_NV):
      retString = retString + "NVRECT_";
      break;
    default:
      retString = retString + "UNKNOWN_";
      break;
  }

  //Add an extra flag for p-buffers
  if(IsPBufferBound())
  {
    retString = retString + "PBuf_";
  }

  //Add the texture ID
  sprintf(buffer,"%04u_",id);
  retString = retString + buffer;
  
  //Add the save count
  static uint saveCount=0;
  saveCount++;
  sprintf(buffer,"%04u",saveCount);
  retString = retString + buffer;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
ImageManager::ImageManager()
{

  //Add a texture image (the zero image always exists)
  AddImageData(0);
}

///////////////////////////////////////////////////////////////////////////////
//
ImageManager::~ImageManager()
{
  //Loop for all images and log all images still active
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //If the image is valid,ready and dirty, save it
    if(imageDataArray[i].validID && imageDataArray[i].id != 0)
    { 
      LOGERR(("ImageManager::Destructor - Texture id %d is still active. (Texture Memory leak?)",imageDataArray[i].id));
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ImageManager::GetAllDirtyImages(vector<ImageData *> &dirtyImages) 
{
  //Empty the array
  dirtyImages.clear();

  //Loop for all images
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //If the image is valid,ready and dirty, save it
    if(imageDataArray[i].validID && imageDataArray[i].IsReady() &&
       imageDataArray[i].IsDirty())
    { 
      //Add the image to the dirty array
      dirtyImages.push_back(&imageDataArray[i]);
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ImageManager::GetPBufferImages(HPBUFFERARB handle,vector<ImageData *> &pBufferImages)
{
  //Empty the array
  pBufferImages.clear();

  //Loop for all images
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //If the image is valid,ready and dirty, save it
    if(imageDataArray[i].validID && imageDataArray[i].IsReady() &&
       imageDataArray[i].IsPBufferBound() && imageDataArray[i].pBufferHandle == handle)
    { 
      //Add the image to the return array
      pBufferImages.push_back(&imageDataArray[i]);
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ImageManager::AddImageData(uint glId)
{
  //Check that the ID is not already in use
  ImageData * currImageData = NULL;

  //Loop and get the texture index for the passed id
  //Note: Cannot use GetImageData here as we don't want to test for valid id's
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //Test if the ID matches
    if(imageDataArray[i].id == glId)
    { 
      currImageData = &imageDataArray[i];
      break;
    }
  }

  //If there is a existing entry in the array, modify it
  if(currImageData)
  {
    //Check the valid ID (should be false)
    if(!currImageData->validID)
    {
      currImageData->validID = true;
      currImageData->ready = false;
    }
    else
    {
      LOGERR(("ImageManager::AddImageData - Existing texture ID %d",glId));
      currImageData->ready = false;
    }
  }
  else
  {
    //Add a new ID to the array
    ImageData newImage;
    newImage.id      = glId;
    newImage.validID = true;
    imageDataArray.push_back(newImage);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
bool ImageManager::RemoveImageData(uint glId)
{
  //Never delete 0
  if(glId != 0)
  {
    //Get the index of the image
    ImageData * currImageData = GetImageData(glId);
    if(currImageData)
    {
      //Delete the texture by flagging it as "not ready" 
      currImageData->Reset();
    }
    else
    {
      LOGERR(("ImageManager::RemoveImageData - Attempting to delete unknwon texture ID %d",glId));
      return false;
    }
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
ImageData * ImageManager::GetImageData(GLint texID)
{
  //Loop and get the texture index for the passed id
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //Test if the ID matches
    if(imageDataArray[i].id == texID)
    { 
      //Test if the ID is currently valid
      if(imageDataArray[i].validID)
      {
        return &imageDataArray[i];
      }
      else
      {
        return NULL;
      }
    }
  }

  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
void ImageManager::SetAllImagesDirty()
{
  //Loop for all images/textures
  for(uint i=0;i<imageDataArray.size();i++)
  {
    //If the image is valid and ready set it as dirty
    if(imageDataArray[i].validID && imageDataArray[i].IsReady())
    {
      imageDataArray[i].SetDirty(true); 
    }
  }

}