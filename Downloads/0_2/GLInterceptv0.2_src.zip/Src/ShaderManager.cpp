/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "InterceptShader.h"
#include "GLDriver.h"


USING_ERRORLOG


///////////////////////////////////////////////////////////////////////////////
//
ShaderData::ShaderData():
id(0),
glType(0),
validID(false),
ready(false),
dirty(false),
saveFileName(""),
shaderSource("")
{
}


///////////////////////////////////////////////////////////////////////////////
//
ShaderData::Reset()
{
  //Reset all variable but the shader ID and the save count
  validID = false;
  ready =false;
  
  //Note that the dirty flag has to be set to false
  dirty =false;

  //Set the shader source to empty
  shaderSource = "";
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderData::GetUniqueFileName(string &retString) const
{
  //A character buffer
  static char buffer[100];

  if(!validID)
  {
    LOGERR(("ShaderData::GetUniqueFileName - Getting name for invalid shader"));
    return false;
  }

  //Set the initial shader name
  retString = "Shader_";

  //Append the shader type
  switch(glType)
  {
    //NV vertex programs have the same token
    case(GL_VERTEX_PROGRAM_ARB):
      retString = retString + "VPARB_";
      break;
    case(GL_FRAGMENT_PROGRAM_ARB):
      retString = retString + "FPARB_";
      break;
    case(GL_FRAGMENT_PROGRAM_NV):
      retString = retString + "FPNV_";
      break;
    case(GL_VERTEX_STATE_PROGRAM_NV):
      retString = retString + "VPSTATENV_";
      break;
    default:
      retString = retString + "UNKNOWN_";
      break;
  }

  //Add the shader ID
  sprintf(buffer,"%04u_",id);
  retString = retString + buffer;
  
  //Add the save count
  static uint saveCount=0;
  saveCount++;
  sprintf(buffer,"%04u",saveCount);
  retString = retString + buffer;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
ShaderManager::ShaderManager()
{
  //Add a shader (the zero shader always exists)
  AddShaderData(0);

}

///////////////////////////////////////////////////////////////////////////////
//
ShaderManager::~ShaderManager()
{
  //Loop for all shader and log all shader still active
  for(uint i=0;i<shaderDataArray.size();i++)
  {
    //If the shader is valid,ready and dirty, save it
    if(shaderDataArray[i].validID && shaderDataArray[i].id != 0)
    { 
      LOGERR(("ShaderManager::Destructor - Shader id %d is still active. (Shader Memory leak?)",shaderDataArray[i].id));
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void ShaderManager::GetAllDirtyShaders(vector<ShaderData *> &dirtyShaders) 
{
  
  //Empty the array
  dirtyShaders.clear();

  //Loop for all shaders
  for(uint i=0;i<shaderDataArray.size();i++)
  {
    //If the shader is valid,ready and dirty, save it
    if(shaderDataArray[i].validID && shaderDataArray[i].IsReady() &&
       shaderDataArray[i].IsDirty())
    { 
      //Add the shader to the dirty array
      dirtyShaders.push_back(&shaderDataArray[i]);
    }
  }
  
}


///////////////////////////////////////////////////////////////////////////////
//
void ShaderManager::AddShaderData(uint glId)
{
  //Check that the ID is not already in use
  ShaderData * currShaderData = NULL;

  //Loop and get the shader index for the passed id
  //Note: Cannot use GetShaderData here as we don't want to test for valid id's
  for(uint i=0;i<shaderDataArray.size();i++)
  {
    //Test if the ID matches
    if(shaderDataArray[i].id == glId)
    { 
      currShaderData = &shaderDataArray[i];
      break;
    }
  }

  //If there is a existing entry in the array, modify it
  if(currShaderData)
  {
    //Check the valid ID (should be false)
    if(!currShaderData->validID)
    {
      currShaderData->validID = true;
      currShaderData->ready = false;
    }
    else
    {
      LOGERR(("ShaderManager::AddShaderData - Existing shader ID %d",glId));
      currShaderData->ready = false;
    }
  }
  else
  {
    //Add a new ID to the array
    ShaderData newShader;
    newShader.id      = glId;
    newShader.validID = true;
    shaderDataArray.push_back(newShader);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderManager::RemoveShaderData(uint glId)
{
  //Never delete 0
  if(glId != 0)
  {
    //Get the index of the shader
    ShaderData * currShaderData = GetShaderData(glId);
    if(currShaderData)
    {
      //Delete the shader by flagging it as "not ready" 
      currShaderData->Reset();
    }
    else
    {
      LOGERR(("ShaderManager::RemoveShaderData - Attempting to delete unknwon shader ID %d",glId));
      return false;
    }
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
ShaderData * ShaderManager::GetShaderData(GLint shaderID)
{

  //Loop and get the shader index for the passed id
  for(uint i=0;i<shaderDataArray.size();i++)
  {
    //Test if the ID matches
    if(shaderDataArray[i].id == shaderID)
    { 
      //Test if the ID is currently valid
      if(shaderDataArray[i].validID)
      {
        return &shaderDataArray[i];
      }
      else
      {
        return NULL;
      }
    }
  }

  return NULL;
}

///////////////////////////////////////////////////////////////////////////////
//
void ShaderManager::SetAllShadersDirty()
{
  //Loop for all shaders
  for(uint i=0;i<shaderDataArray.size();i++)
  {
    //If the image is valid and ready set it as dirty
    if(shaderDataArray[i].validID && shaderDataArray[i].IsReady())
    {
      shaderDataArray[i].SetDirty(true); 
    }
  }
}


