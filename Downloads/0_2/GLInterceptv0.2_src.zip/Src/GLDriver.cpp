/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "GLDriver.h"
#include "FunctionTable.h"
#include "ExtensionFunction.h"
#include "FunctionParser.h"
#include "InterceptLogXML.h"
#include "FileUtils.h"
#include "InputUtils.h"

USING_ERRORLOG

//The function table lookup
FunctionTable * functionTable=NULL;

//The path to the dll
extern string dllPath;

///////////////////////////////////////////////////////////////////////////////
//
GLContext::GLContext(HGLRC rcHandle):
glRCHandle(rcHandle),
interceptImage(NULL),
interceptShader(NULL),
interceptFrame(NULL),
cachedError(GL_NO_ERROR)
{
}

///////////////////////////////////////////////////////////////////////////////
//
GLContext::~GLContext()
{
  //Delete the image log
  if(interceptImage)
  {
    interceptImage->ReleaseReference();
  }

  //Delete the shader log
  if(interceptShader)
  {
    interceptShader->ReleaseReference();
  }

  //Delete the frame logger
  if(interceptFrame)
  {
    interceptFrame->ReleaseReference();
  }

}

///////////////////////////////////////////////////////////////////////////////
//
bool GLContext::ShareLists(GLContext *shareContext) const
{
  // Check the context
  if(shareContext == NULL)
  {
    return false;
  }
  if(shareContext == this)
  {
    return true;
  }

  //Delete existing context data
  if(shareContext->interceptImage)
  {
    shareContext->interceptImage->ReleaseReference();
  }
  if(shareContext->interceptShader)
  {
    shareContext->interceptShader->ReleaseReference();
  }

  //Assign our lists
  if(interceptImage)
  {
    interceptImage->AddReference();
    shareContext->interceptImage = interceptImage;
  }
  if(interceptShader)
  {
    interceptShader->AddReference();
    shareContext->interceptShader = interceptShader;
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::ActivateLoggers(const string &logPath)
{
  //Activate the image logger
  if(interceptImage)
  {
    //Create the new image logging directory
    string newPath = logPath + "Images" + FileUtils::dirSeparator;
    if(!FileUtils::CreateFullDirectory(newPath.c_str()))
    {
      LOGERR(("GLContext::ActivateLoggers - Unable to create directory %s ",newPath.c_str())); 

      //If could not create the new directory, just use the current directory
      newPath = "";
    }

    //Set the image saving path
    interceptImage->SetImageSavingPath(newPath);

    //Activate the image saving
    interceptImage->SetImageSaving(true);
  }
  if(interceptShader)
  {
    //Create the new shader logging directory
    string newPath = logPath + "Shaders" + FileUtils::dirSeparator;
    if(!FileUtils::CreateFullDirectory(newPath.c_str()))
    {
      LOGERR(("GLDriver::ActivateLoggers - Unable to create directory %s ",newPath.c_str())); 

      //If could not create the new directory, just use the current directory
      newPath = "";
    }

    //Set the shader saving path
    interceptShader->SetShaderSavingPath(newPath);

    //Activate the shader saving
    interceptShader->SetShaderSaving(true);
  }

  //Activate the frame logger
  if(interceptFrame)
  {
    //Create the new frame logging directory
    string newPath = logPath + "FrameBuffer" + FileUtils::dirSeparator;
    if(!FileUtils::CreateFullDirectory(newPath.c_str()))
    {
      LOGERR(("GLContext::ActivateLoggers - Unable to create directory %s ",newPath.c_str())); 

      //If could not create the new directory, just use the current directory
      newPath = "";
    }

    //Set the frame saving path
    interceptFrame->SetFrameSavingPath(newPath);

    //Activate the frame saving
    interceptFrame->SetFrameSaving(true);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void GLContext::SuspendLoggers()
{
  if(interceptImage)
  {
    interceptImage->SetImageSaving(false);
  }
  if(interceptShader)
  {
    interceptShader->SetShaderSaving(false);
  }
  if(interceptFrame)
  {
    interceptFrame->SetFrameSaving(false);
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void GLDriver::InitFunctionTable()
{
  //Test if we are already init.
  if(functionTable)
  { 
    return;
  }

  //Create the function table
  functionTable = new FunctionTable;

}

///////////////////////////////////////////////////////////////////////////////
//
GLDriver::GLDriver():
isInit(false),
extensionFunction(NULL),
interceptLog(NULL),
glContext(NULL),
internalCallModeCount(0),
glBeginEndState(false),
glNewListState(false),
frameNumber(0),
currLogDir(""),
loggingEnabled(true)
{

}

///////////////////////////////////////////////////////////////////////////////
//
GLDriver::~GLDriver()
{
  //Delete the function table if it was active
  if(functionTable)
  {
    delete functionTable;
    functionTable = NULL;
  }

  //Delete the extension function loader
  if(extensionFunction)
  {
    delete extensionFunction;
  }

  //Delete the log
  if(interceptLog)
  {
    delete interceptLog;
  }

  //If there exists a current GL context on shutdown, something was wrong
  if(glContext != NULL)
  {
    LOGERR(("GLDriver - Shutdown - Current OpenGL context 0x%x?",glContext->glRCHandle));
    glContext = NULL;
  }

  //Destroy any outstanding OpenGL contexts
  for(uint i=0;i<glContextArray.size();i++)
  {
    LOGERR(("GLDriver - Shutdown - Outstanding OpenGL context 0x%x ?",glContextArray[i]->glRCHandle));

    //Delete the context
    delete glContextArray[i];
  }

  //Shut the error logger down here
  if(gliLog)
  {
    //Turn of debugger logger for the ending tags
    gliLog->SetDebuggerLogEnabled(false);

    //Write a log ending tag
    gliLog->LogError("===================================================");
    gliLog->LogError("Log End.");

    //Delete the error log
    delete gliLog;
    gliLog = NULL;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::Init()
{
  //Read in the configuration data
  configData.ReadConfigData();

  //Set if the logger mirrors to the debugger
  if(gliLog)
  {
    gliLog->SetDebuggerLogEnabled(configData.errorDebuggerErrorLog);
  }

  //Attempt to open the driver
  if(!openGLLib.Init(configData.openGLFileName.c_str()))
  {
    LOGERR(("GLDriver::Init - Unable to open OpenGL lib file %s",configData.openGLFileName.c_str())); 
    return false;
  }

  //Do the core OpenGL function mapping
  if(!MapCoreOpenGLFunctions())
  {
    LOGERR(("GLDriver::Init - Unable to map core OpenGL functions")); 
    return false;
  }

  //Do the windows OpenGL function mapping
  if(!MapWGLFunctions())
  {
    LOGERR(("GLDriver::Init - Unable to map windows OpenGL functions")); 
    return false;
  }

  //Create the function table if necessary
  if(!functionTable)
  { 
    InitFunctionTable();
  }


  //Create the extension function handler
  extensionFunction = new ExtensionFunction(functionTable);

  //Parse the include files
  FunctionParser parser;
  
  //If parsing was successful, add the data to the function table
  if(parser.Parse(configData.functionDataFileName.c_str()))
  {
    FunctionDataArray funcArray;
    EnumDataArray     enumArray;

    //Get the data from the parser (A double copy, slow -may need to speed up)
    if(parser.GetFunctionData(funcArray,enumArray))
    {
      //Pass it to the table
      functionTable->InitKnownFunctionTable(funcArray,enumArray);
    }
  }
  
  //Assign the current logging directory
  currLogDir = configData.logPath;

  //Set if the any logging is enabled
  loggingEnabled = !configData.logPerFrame;

  //If we are not-perframe logging, create the initial logger here
  if(loggingEnabled && configData.logEnabled)
  {
    //Init the initial function log
    if(!InitFunctionLog())
    {
      return false;
    }
  }

  //Register the rendering functions. (TODO:Move? from config file? config can add to this list?)
  //TODO: What if a display list has a render call?
  functionTable->SetFunctionFlag("glEvalMesh1",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glEvalMesh2",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glBegin",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glDrawArrays",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glDrawElements",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glDrawRangeElements",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glDrawRangeElementsEXT",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glMultiDrawArrays",FDF_RENDER_FUNC);  
  functionTable->SetFunctionFlag("glMultiDrawArraysEXT",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glMultiDrawElements",FDF_RENDER_FUNC);
  functionTable->SetFunctionFlag("glMultiDrawElementsEXT",FDF_RENDER_FUNC);

  //Set the buffer swap call
  functionTable->SetFunctionFlag("wglSwapBuffers",FDF_FRAME_FUNC);
  functionTable->SetFunctionFlag("wglSwapLayerBuffers",FDF_FRAME_FUNC);

  //Flag that we are now init
  isInit = true;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLDriver::SetBeginEndState(bool mode)
{
  //Only set when there is a valid context
  if(glContext)
  {
    glBeginEndState = mode;

    //Enable/disable based on if we are enabling or disabling the mode
    SetInternalGLCallMode(!mode);
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void GLDriver::SetNewListState(bool mode)
{
  //Only set inside a valid context
  if(glContext)
  {
    //Cannot enable/disable a list while in a glBegin/glEnd block
    if(glBeginEndState)
    {
      if(mode)
      {
        LOGERR(("GLDriver::SetNewListState - Enabling a list in a glBegin/glEnd block?"));
      }
      else
      {
        LOGERR(("GLDriver::SetNewListState - Ending a list while in a glBegin/glEnd block?"));
      }
    }
    else
    {
      glNewListState = mode;

      //Enable/disable based on if we are enabling or disabling the mode
      SetInternalGLCallMode(!mode);
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void GLDriver::SetInternalGLCallMode(bool mode)
{
  if(mode)
  {
    //Check the value to catch bad calls
    if(internalCallModeCount >0)
    {
      internalCallModeCount--;
    }
    else
    {
      LOGERR(("GLDriver::SetInternalGLCallMode - INTERNAL ERROR -Inconsistent call mode"));
    }
  }
  else
  {
    internalCallModeCount++;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void * GLDriver::AddExtensionFunction(const string & funcName,void * functionPtr)
{
  //Check that we are init.
  if(!extensionFunction)
  {
    LOGERR(("GLDriver::AddExtensionFunction - No extension function interceptor for function %s",funcName.c_str())); 
    return functionPtr;
  }

  //Pass off to the extension function class
  return extensionFunction->AddFunction(funcName,functionPtr);
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::LogFunctionPre(uint index, va_list args)
{
  //Check the function table
  if(!functionTable)
  {
    LOGERR(("GLDriver::LogFunctionPre - FunctionTable is NULL")); 
    return false;
  }

  //Get the function data
  const FunctionData *funcData = functionTable->GetFunctionData(index);

  //Check the function data
  if(!funcData)
  {
    LOGERR(("GLDriver::LogFunctionPre - Function data for index %d is NULL",index)); 
    return false;
  }

  //If this is being called before init, indicates no context
  if(!isInit)
  {
    LOGERR(("Function %s is being called before context creation",funcData->functionName.c_str()));
    return false;
  }

  //If we have a context, perform context logging
  if(glContext)
  {
    //Do frame log first
    if(glContext->interceptFrame)
    {
      glContext->interceptFrame->LogFunctionPre(funcData,index,args);
    }

    //Do the image log (Do before function log)
    if(glContext->interceptImage)
    {
      glContext->interceptImage->LogFunctionPre(funcData,index,args);
    }

    //Do the shader log
    if(glContext->interceptShader)
    {
      glContext->interceptShader->LogFunctionPre(funcData,index,args);
    }

  }

  //Log the function
  if(interceptLog)
  {
    interceptLog->LogFunctionPre(funcData, index, args);
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::LogFunctionPost(uint index, void *returnVal)
{
  //Return now if not init
  if(!isInit)
  {
    return false;
  }

  //Check the function table
  if(!functionTable)
  {
    LOGERR(("GLDriver::LogFunctionPost - FunctionTable is NULL")); 
    return false;
  }

  //Get the function data
  const FunctionData *funcData = functionTable->GetFunctionData(index);

  //Check the function data
  if(!funcData)
  {
    LOGERR(("GLDriver::LogFunctionPost - Function data for index %d is NULL",index)); 
    return false;
  }

  //If we have a context, perform context logging
  if(glContext)
  {
    //Do frame log first
    if(glContext->interceptFrame)
    {
      glContext->interceptFrame->LogFunctionPost(funcData,index,returnVal);
    }

    //Do the image log (Must be done before logging)
    if(glContext->interceptImage)
    {
      glContext->interceptImage->LogFunctionPost(funcData,index,returnVal);
    }

    //Do the shader log
    if(glContext->interceptShader)
    {
      glContext->interceptShader->LogFunctionPost(funcData,index,returnVal);
    }

  }

  //Log the function
  if(interceptLog)
  {
    interceptLog->LogFunctionPost(funcData, index, returnVal);
  }

  //Check if we can log internal calls and get error checks are requested
  if(GetInternalGLCallMode() && configData.errorGetOpenGLChecks)
  {
    //Get Error code
    GLenum newError;
    newError = GLV.glGetError();

    //If there is an error log and cache it
    if(newError != GL_NO_ERROR)
    {
      //Log the error
      if(interceptLog)
      {
        interceptLog->LogFunctionError(newError);
      }

      //Log if requested
      if(configData.errorLogOnError)
      {
        //Flag a break point //TODO: Lookup error code
        LOGERR(("GL ERROR - Function %s generated error 0x%x",funcData->functionName.c_str(),newError));
      }

      //Break if requested
      if(configData.errorBreakOnError)
      {
        //Flag a break point
        ErrorLog::IssueDebuggerBreak();
      }

      //If the cached error is no-error, assign this error as the new error
      if(glContext && glContext->cachedError == GL_NO_ERROR)
      {
        glContext->cachedError = newError;
      }
    }
  }

  //Flag that all processing on the current function is complete
  if(interceptLog)
  {
    interceptLog->LogFunctionComplete();
  }

  //If this function is a end of frame function, process it
  //TODO: ensure we are on the main frame an not a p-buffer?
  if(funcData->functionFlags & FDF_FRAME_FUNC)
  {
    ProcessFrameEnd();
  }

  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
float GLDriver::GetOpenGLVersion()
{
  //Return now if not init
  if(!isInit)
  {
    LOGERR(("GLDriver::GetOpenGLVersion - Unable to determine version number - Not initialized/no context")); 
    return false;
  }

  //If GL calls cannot be made, flag a error and return
  if(!GetInternalGLCallMode())
  {
    LOGERR(("GLDriver::GetOpenGLVersion - Unable to determine version number")); 
    return false;
  }
  
  //Get the version string
  char * versionString = (char*)GLV.glGetString(GL_VERSION);
  if(!versionString || strlen(versionString) == 0)
  {
    LOGERR(("GLDriver::GetOpenGLVersion - Unable to determine version number")); 
    return false;
  }

  uint majorNum  =1;
  uint minorNum  =0;
  uint releaseNum=0;

  //Get the version number
  sscanf(versionString,"%d.%d.%d",&majorNum,&minorNum,&releaseNum);

  //Minor sanity checks
  if(minorNum > 9)
  {
    minorNum = 9;
  }
  if(releaseNum > 9)
  {
    releaseNum = 9;
  }

  //Merge the versions into one float string
  return ((float)majorNum) + (((float)minorNum) / 10.0f) + (((float)releaseNum) / 100.0f);
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::IsExtensionSupported(const char *extension)
{
  const GLubyte *extensionString = NULL;
  const GLubyte *start;
  GLubyte *where, *terminator;

  //Return now if not init
  if(!isInit)
  {
    LOGERR(("GLDriver::IsExtensionSupported - Unable to determine if a extension is supported - Not initialized/no context")); 
    return false;
  }

  //If GL calls cannot be made, flag a error and return
  if(!GetInternalGLCallMode())
  {
    LOGERR(("GLDriver::IsExtensionSupported - Unable to determine if a extension is supported")); 
    return false;
  }

  if(extension == NULL)
  {
    LOGERR(("GLDriver::IsExtensionSupported - Invalid extension")); 
    return false;
  }

  // Extension names should not have spaces.
  where = (GLubyte *) strchr(extension, ' ');
  if (where || *extension == '\0')
  {
    LOGERR(("GLDriver::IsExtensionSupported - Invalid extension")); 
    return false;
  }

  //Get the extensions
  extensionString = GLV.glGetString(GL_EXTENSIONS);

  //Loop and check for the extension string
  start = extensionString;
  for (;;)
  {
    //Search for the extension
    where = (GLubyte *) strstr((const char *) start, extension);
    if (!where)
    {
      break;
    }

    //Get where the extension should start and end to make sure we don't get a sub-string
    terminator = where + strlen(extension);
    if (where == start || *(where - 1) == ' ')
    {
      if (*terminator == ' ' || *terminator == '\0')
      {
        return true;
      }
    }
    start = terminator;
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::InitFunctionLog()
{
  //Delete the existing logger (if any)
  if(interceptLog)
  {
    delete interceptLog;
    interceptLog = NULL;
  }

  //Create the log path if necessary
  if(!FileUtils::CreateFullDirectory(currLogDir.c_str()))
  {
    LOGERR(("GLDriver::InitFunctionLog - Unable to create directory %s ",currLogDir.c_str())); 

    //If could not create the new directory, just use the dll directory
    currLogDir = dllPath;
  }

  //Create the logger for function output
  if(configData.logXMLFormat)
  {
    //Attempt to copy the xsl file
    if(configData.logXSLFile.length() > 0)
    {
      //Attempt to copy the file
      if(FileUtils::CopyFile(configData.logXSLBaseDir + configData.logXSLFile ,currLogDir + configData.logXSLFile, true))
      {
        interceptLog = new InterceptLogXML((currLogDir + configData.logName+".xml").c_str(),functionTable,configData,configData.logXSLFile);  
      }
      else
      {
        //Don't use XSL if the file could not be copied
        LOGERR(("Failed to copy XSL file %s",(configData.logXSLBaseDir + configData.logXSLFile).c_str()));
        interceptLog = new InterceptLogXML((currLogDir + configData.logName+".xml").c_str(),functionTable,configData,"");  
      }
    }
    else
    {
      interceptLog = new InterceptLogXML((currLogDir + configData.logName+".xml").c_str(),functionTable,configData,"");
    }
  }
  else
  {
    interceptLog = new InterceptLog((currLogDir + configData.logName+".txt").c_str(),functionTable,configData);
  }

  //Init the log
  if(!interceptLog->Init())
  {
    LOGERR(("GLDriver::InitFunctionLog - Unable to init the intercept log")); 
    return false;
  }

  //Set the initial log state
  interceptLog->SetLogEnabled(configData.logEnabled);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLDriver::ProcessFrameEnd()
{
  //A character buffer
  static char buffer[65];

  //Increment the frame number
  frameNumber++;

  //Check if we log per-frame
  bool logStateChange =false;
  if(configData.logPerFrame)
  {
    static bool previousState=false;

    //Check if the key state has changed
    if(InputUtils::IsAllKeyDown(configData.logFrameKeys) != previousState)
    {
      logStateChange = true;
      previousState = !previousState;
    }

    //If we are only logging one frame at a time
    if(configData.logOneFrameOnly)
    {
      //Don't allow key up events to change the logging state
      if(logStateChange && !previousState)
      {
        logStateChange = false;
      }

      //Disable the logger if it was enabled from a pervious frame
      if(loggingEnabled)
      {
        logStateChange = true;
      }
    }
  }

  //If a change in per-frame saving occured
  if(logStateChange)
  {
    //If the log is not currently enabled
    if(!loggingEnabled)
    {
      //Flag logging as enabled
      loggingEnabled = true;

      //Assign the current logging directory
      sprintf(buffer,"Frame_%06u",frameNumber);
      currLogDir = configData.logPath + buffer + FileUtils::dirSeparator;

      //Loop through all the contexts and set all data as dirty
      for(uint i=0;i<glContextArray.size();i++)
      {
        if(glContextArray[i]->interceptImage)
        {
          glContextArray[i]->interceptImage->SetAllImagesDirty();
        }
        if(glContextArray[i]->interceptShader)
        {
          glContextArray[i]->interceptShader->SetAllShadersDirty();
        }
      }

      //Init the logger
      if(configData.logEnabled)
      {
        InitFunctionLog();
      }

      //Activate the context
      if(glContext)
      {
        glContext->ActivateLoggers(currLogDir);
      }
    }
    else
    {
      // Flag logging as disabled
      loggingEnabled = false;

      //Delete the existing logger (if any)
      if(interceptLog)
      {
        delete interceptLog;
        interceptLog = NULL;
      }

      //Suspend the context
      if(glContext)
      {
        glContext->SuspendLoggers();
      }
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::CreateOpenGLContext(HGLRC rcHandle)
{
  //Check the handle
  if(rcHandle == NULL)
  {
    LOGERR(("GLDriver::CreateOpenGLContext - Attempt to create a NULL context")); 
    return false;
  }

  //Attempt to find an existing context
  if(GetOpenGLContext(rcHandle) != NULL)
  {
    LOGERR(("GLDriver::CreateOpenGLContext - Attempt to create an existing context 0x%x",rcHandle)); 
    return false;
  }

  //Create the new context
  GLContext *newContext = new GLContext(rcHandle);

  //Create the new intercept image
  if(configData.imageLogEnabled)
  {
    newContext->interceptImage = new InterceptImage(this,functionTable,configData);
  }

  //Create the new intercept shader
  if(configData.shaderLogEnabled)
  {
    newContext->interceptShader = new InterceptShader(this,functionTable,configData);
  }
  
  //Create the new intercept frame
  if(configData.frameLogEnabled)
  {
    newContext->interceptFrame = new InterceptFrame(this,functionTable,configData);
  }

  //Add the new context to the array
  glContextArray.push_back(newContext);
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::DeleteOpenGLContext(HGLRC rcHandle)
{
  //Attempt to get the context
  GLContext *delContext = GetOpenGLContext(rcHandle);
  if(!delContext)
  {
    LOGERR(("GLDriver::DeleteOpenGLContext - Attempt to delete unknown context 0x%x",rcHandle)); 
    return false;
  }

  //Check if we are deleting the current context
  if(delContext == glContext)
  {
    LOGERR(("GLDriver::DeleteOpenGLContext - Deleting current context 0x%x?",rcHandle)); 

    //Do not perform correct shutdown (as the GL context is not valid)
    glContext = NULL;
  }

  //Remove it from the array
  for(uint i=0;i<glContextArray.size();i++)
  {
    //If the handles match, remove the context
    if(glContextArray[i]->glRCHandle == rcHandle)
    {
      glContextArray.erase(glContextArray.begin() + i);
      break;
    }
  }

  //Delete it
  delete delContext;
  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::SetOpenGLContext(HGLRC rcHandle)
{
  //Check that existing contexts are shut down before enabling the new context.
  if(glContext && rcHandle)
  {
    LOGERR(("GLDriver::SetOpenGLContext - Context should only go from NULL->valid and valid->NULL")); 
  }

  //Shutdown existing context
  if(glContext)
  {
    //Check when the state change occurs
    if(internalCallModeCount > 0 || glBeginEndState || glNewListState)
    {
      LOGERR(("GLDriver::SetOpenGLContext - Changing context in the middle of a glBegin/glNewList block?")); 
    }

    //Disable logging
    glContext->SuspendLoggers();
  }

  //Attempt to get the context
  if(rcHandle != NULL)
  {
    GLContext *newContext = GetOpenGLContext(rcHandle);
    if(!newContext)
    {
      LOGERR(("GLDriver::SetOpenGLContext - Attempt to set unknown context 0x%x?",rcHandle)); 
      return false;
    }

    //Assign the new context
    glContext = newContext;

    //If logging is enabled, activate the loggers
    if(loggingEnabled)
    {
      glContext->ActivateLoggers(currLogDir);
    }
  }
  else
  {
    glContext = NULL;
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
GLContext *GLDriver::GetOpenGLContext(HGLRC rcHandle) const
{
  //Loop for the entire vector
  for(uint i=0;i<glContextArray.size();i++)
  {
    //If the handles match, return the context
    if(glContextArray[i]->glRCHandle == rcHandle)
    {
      return glContextArray[i];
    }
  }

  return NULL;
}


///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::MapCoreOpenGLFunctions()
{
  void **tempfunc;

#define GLC_FUNC_LOOKUP(string)                 \
  tempfunc = (void**)(&GLV.##string);           \
  (*tempfunc) = openGLLib.GetFunction(#string); \
  if(GLV.##string == NULL)                      \
  {LOGERR(("Function %s unable to be mapped",#string)) return false;}

  GLC_FUNC_LOOKUP(glAccum);
  GLC_FUNC_LOOKUP(glAlphaFunc)
  GLC_FUNC_LOOKUP(glAreTexturesResident)
  GLC_FUNC_LOOKUP(glArrayElement)
  GLC_FUNC_LOOKUP(glBegin)
  GLC_FUNC_LOOKUP(glBindTexture)
  GLC_FUNC_LOOKUP(glBitmap)
  GLC_FUNC_LOOKUP(glBlendFunc)
  GLC_FUNC_LOOKUP(glCallList)
  GLC_FUNC_LOOKUP(glCallLists)
  GLC_FUNC_LOOKUP(glClear)
  GLC_FUNC_LOOKUP(glClearAccum)
  GLC_FUNC_LOOKUP(glClearColor)
  GLC_FUNC_LOOKUP(glClearDepth)
  GLC_FUNC_LOOKUP(glClearIndex)
  GLC_FUNC_LOOKUP(glClearStencil)
  GLC_FUNC_LOOKUP(glClipPlane)
  GLC_FUNC_LOOKUP(glColor3b)
  GLC_FUNC_LOOKUP(glColor3bv)
  GLC_FUNC_LOOKUP(glColor3d)
  GLC_FUNC_LOOKUP(glColor3dv)
  GLC_FUNC_LOOKUP(glColor3f)
  GLC_FUNC_LOOKUP(glColor3fv)
  GLC_FUNC_LOOKUP(glColor3i)
  GLC_FUNC_LOOKUP(glColor3iv)
  GLC_FUNC_LOOKUP(glColor3s)
  GLC_FUNC_LOOKUP(glColor3sv)
  GLC_FUNC_LOOKUP(glColor3ub)
  GLC_FUNC_LOOKUP(glColor3ubv)
  GLC_FUNC_LOOKUP(glColor3ui)
  GLC_FUNC_LOOKUP(glColor3uiv)
  GLC_FUNC_LOOKUP(glColor3us)
  GLC_FUNC_LOOKUP(glColor3usv)
  GLC_FUNC_LOOKUP(glColor4b)
  GLC_FUNC_LOOKUP(glColor4bv)
  GLC_FUNC_LOOKUP(glColor4d)
  GLC_FUNC_LOOKUP(glColor4dv)
  GLC_FUNC_LOOKUP(glColor4f)
  GLC_FUNC_LOOKUP(glColor4fv)
  GLC_FUNC_LOOKUP(glColor4i)
  GLC_FUNC_LOOKUP(glColor4iv)
  GLC_FUNC_LOOKUP(glColor4s)
  GLC_FUNC_LOOKUP(glColor4sv)
  GLC_FUNC_LOOKUP(glColor4ub)
  GLC_FUNC_LOOKUP(glColor4ubv)
  GLC_FUNC_LOOKUP(glColor4ui)
  GLC_FUNC_LOOKUP(glColor4uiv)
  GLC_FUNC_LOOKUP(glColor4us)
  GLC_FUNC_LOOKUP(glColor4usv)
  GLC_FUNC_LOOKUP(glColorMask)
  GLC_FUNC_LOOKUP(glColorMaterial)
  GLC_FUNC_LOOKUP(glColorPointer)
  GLC_FUNC_LOOKUP(glCopyPixels)
  GLC_FUNC_LOOKUP(glCopyTexImage1D)
  GLC_FUNC_LOOKUP(glCopyTexImage2D)
  GLC_FUNC_LOOKUP(glCopyTexSubImage1D)
  GLC_FUNC_LOOKUP(glCopyTexSubImage2D)
  GLC_FUNC_LOOKUP(glCullFace)
  GLC_FUNC_LOOKUP(glDeleteLists)
  GLC_FUNC_LOOKUP(glDeleteTextures)
  GLC_FUNC_LOOKUP(glDepthFunc)
  GLC_FUNC_LOOKUP(glDepthMask)
  GLC_FUNC_LOOKUP(glDepthRange)
  GLC_FUNC_LOOKUP(glDisable)
  GLC_FUNC_LOOKUP(glDisableClientState)
  GLC_FUNC_LOOKUP(glDrawArrays)
  GLC_FUNC_LOOKUP(glDrawBuffer)
  GLC_FUNC_LOOKUP(glDrawElements)
  GLC_FUNC_LOOKUP(glDrawPixels)
  GLC_FUNC_LOOKUP(glEdgeFlag)
  GLC_FUNC_LOOKUP(glEdgeFlagPointer)
  GLC_FUNC_LOOKUP(glEdgeFlagv)
  GLC_FUNC_LOOKUP(glEnable)
  GLC_FUNC_LOOKUP(glEnableClientState)
  GLC_FUNC_LOOKUP(glEnd)
  GLC_FUNC_LOOKUP(glEndList)
  GLC_FUNC_LOOKUP(glEvalCoord1d)
  GLC_FUNC_LOOKUP(glEvalCoord1dv)
  GLC_FUNC_LOOKUP(glEvalCoord1f)
  GLC_FUNC_LOOKUP(glEvalCoord1fv)
  GLC_FUNC_LOOKUP(glEvalCoord2d)
  GLC_FUNC_LOOKUP(glEvalCoord2dv)
  GLC_FUNC_LOOKUP(glEvalCoord2f)
  GLC_FUNC_LOOKUP(glEvalCoord2fv)
  GLC_FUNC_LOOKUP(glEvalMesh1)
  GLC_FUNC_LOOKUP(glEvalMesh2)
  GLC_FUNC_LOOKUP(glEvalPoint1)
  GLC_FUNC_LOOKUP(glEvalPoint2)
  GLC_FUNC_LOOKUP(glFeedbackBuffer)
  GLC_FUNC_LOOKUP(glFinish)
  GLC_FUNC_LOOKUP(glFlush)
  GLC_FUNC_LOOKUP(glFogf)
  GLC_FUNC_LOOKUP(glFogfv)
  GLC_FUNC_LOOKUP(glFogi)
  GLC_FUNC_LOOKUP(glFogiv)
  GLC_FUNC_LOOKUP(glFrontFace)
  GLC_FUNC_LOOKUP(glFrustum)
  GLC_FUNC_LOOKUP(glGenLists)
  GLC_FUNC_LOOKUP(glGenTextures)
  GLC_FUNC_LOOKUP(glGetBooleanv)
  GLC_FUNC_LOOKUP(glGetClipPlane)
  GLC_FUNC_LOOKUP(glGetDoublev)
  GLC_FUNC_LOOKUP(glGetError)
  GLC_FUNC_LOOKUP(glGetFloatv)
  GLC_FUNC_LOOKUP(glGetIntegerv)
  GLC_FUNC_LOOKUP(glGetLightfv)
  GLC_FUNC_LOOKUP(glGetLightiv)
  GLC_FUNC_LOOKUP(glGetMapdv)
  GLC_FUNC_LOOKUP(glGetMapfv)
  GLC_FUNC_LOOKUP(glGetMapiv)
  GLC_FUNC_LOOKUP(glGetMaterialfv)
  GLC_FUNC_LOOKUP(glGetMaterialiv)
  GLC_FUNC_LOOKUP(glGetPixelMapfv)
  GLC_FUNC_LOOKUP(glGetPixelMapuiv)
  GLC_FUNC_LOOKUP(glGetPixelMapusv)
  GLC_FUNC_LOOKUP(glGetPointerv)
  GLC_FUNC_LOOKUP(glGetPolygonStipple)
  GLC_FUNC_LOOKUP(glGetString)
  GLC_FUNC_LOOKUP(glGetTexEnvfv)
  GLC_FUNC_LOOKUP(glGetTexEnviv)
  GLC_FUNC_LOOKUP(glGetTexGendv)
  GLC_FUNC_LOOKUP(glGetTexGenfv)
  GLC_FUNC_LOOKUP(glGetTexGeniv)
  GLC_FUNC_LOOKUP(glGetTexImage)
  GLC_FUNC_LOOKUP(glGetTexLevelParameterfv)
  GLC_FUNC_LOOKUP(glGetTexLevelParameteriv)
  GLC_FUNC_LOOKUP(glGetTexParameterfv)
  GLC_FUNC_LOOKUP(glGetTexParameteriv)
  GLC_FUNC_LOOKUP(glHint)
  GLC_FUNC_LOOKUP(glIndexMask)
  GLC_FUNC_LOOKUP(glIndexPointer)
  GLC_FUNC_LOOKUP(glIndexd)
  GLC_FUNC_LOOKUP(glIndexdv)
  GLC_FUNC_LOOKUP(glIndexf)
  GLC_FUNC_LOOKUP(glIndexfv)
  GLC_FUNC_LOOKUP(glIndexi)
  GLC_FUNC_LOOKUP(glIndexiv)
  GLC_FUNC_LOOKUP(glIndexs)
  GLC_FUNC_LOOKUP(glIndexsv)
  GLC_FUNC_LOOKUP(glIndexub)
  GLC_FUNC_LOOKUP(glIndexubv)
  GLC_FUNC_LOOKUP(glInitNames)
  GLC_FUNC_LOOKUP(glInterleavedArrays)
  GLC_FUNC_LOOKUP(glIsEnabled)
  GLC_FUNC_LOOKUP(glIsList)
  GLC_FUNC_LOOKUP(glIsTexture)
  GLC_FUNC_LOOKUP(glLightModelf)
  GLC_FUNC_LOOKUP(glLightModelfv)
  GLC_FUNC_LOOKUP(glLightModeli)
  GLC_FUNC_LOOKUP(glLightModeliv)
  GLC_FUNC_LOOKUP(glLightf)
  GLC_FUNC_LOOKUP(glLightfv)
  GLC_FUNC_LOOKUP(glLighti)
  GLC_FUNC_LOOKUP(glLightiv)
  GLC_FUNC_LOOKUP(glLineStipple)
  GLC_FUNC_LOOKUP(glLineWidth)
  GLC_FUNC_LOOKUP(glListBase)
  GLC_FUNC_LOOKUP(glLoadIdentity)
  GLC_FUNC_LOOKUP(glLoadMatrixd)
  GLC_FUNC_LOOKUP(glLoadMatrixf)
  GLC_FUNC_LOOKUP(glLoadName)
  GLC_FUNC_LOOKUP(glLogicOp)
  GLC_FUNC_LOOKUP(glMap1d)
  GLC_FUNC_LOOKUP(glMap1f)
  GLC_FUNC_LOOKUP(glMap2d)
  GLC_FUNC_LOOKUP(glMap2f)
  GLC_FUNC_LOOKUP(glMapGrid1d)
  GLC_FUNC_LOOKUP(glMapGrid1f)
  GLC_FUNC_LOOKUP(glMapGrid2d)
  GLC_FUNC_LOOKUP(glMapGrid2f)
  GLC_FUNC_LOOKUP(glMaterialf)
  GLC_FUNC_LOOKUP(glMaterialfv)
  GLC_FUNC_LOOKUP(glMateriali)
  GLC_FUNC_LOOKUP(glMaterialiv)
  GLC_FUNC_LOOKUP(glMatrixMode)
  GLC_FUNC_LOOKUP(glMultMatrixd)
  GLC_FUNC_LOOKUP(glMultMatrixf)
  GLC_FUNC_LOOKUP(glNewList)
  GLC_FUNC_LOOKUP(glNormal3b)
  GLC_FUNC_LOOKUP(glNormal3bv)
  GLC_FUNC_LOOKUP(glNormal3d)
  GLC_FUNC_LOOKUP(glNormal3dv)
  GLC_FUNC_LOOKUP(glNormal3f)
  GLC_FUNC_LOOKUP(glNormal3fv)
  GLC_FUNC_LOOKUP(glNormal3i)
  GLC_FUNC_LOOKUP(glNormal3iv)
  GLC_FUNC_LOOKUP(glNormal3s)
  GLC_FUNC_LOOKUP(glNormal3sv)
  GLC_FUNC_LOOKUP(glNormalPointer)
  GLC_FUNC_LOOKUP(glOrtho)
  GLC_FUNC_LOOKUP(glPassThrough)
  GLC_FUNC_LOOKUP(glPixelMapfv)
  GLC_FUNC_LOOKUP(glPixelMapuiv)
  GLC_FUNC_LOOKUP(glPixelMapusv)
  GLC_FUNC_LOOKUP(glPixelStoref)
  GLC_FUNC_LOOKUP(glPixelStorei)
  GLC_FUNC_LOOKUP(glPixelTransferf)
  GLC_FUNC_LOOKUP(glPixelTransferi)
  GLC_FUNC_LOOKUP(glPixelZoom)
  GLC_FUNC_LOOKUP(glPointSize)
  GLC_FUNC_LOOKUP(glPolygonMode)
  GLC_FUNC_LOOKUP(glPolygonOffset)
  GLC_FUNC_LOOKUP(glPolygonStipple)
  GLC_FUNC_LOOKUP(glPopAttrib)
  GLC_FUNC_LOOKUP(glPopClientAttrib)
  GLC_FUNC_LOOKUP(glPopMatrix)
  GLC_FUNC_LOOKUP(glPopName)
  GLC_FUNC_LOOKUP(glPrioritizeTextures)
  GLC_FUNC_LOOKUP(glPushAttrib)
  GLC_FUNC_LOOKUP(glPushClientAttrib)
  GLC_FUNC_LOOKUP(glPushMatrix)
  GLC_FUNC_LOOKUP(glPushName)
  GLC_FUNC_LOOKUP(glRasterPos2d)
  GLC_FUNC_LOOKUP(glRasterPos2dv)
  GLC_FUNC_LOOKUP(glRasterPos2f)
  GLC_FUNC_LOOKUP(glRasterPos2fv)
  GLC_FUNC_LOOKUP(glRasterPos2i)
  GLC_FUNC_LOOKUP(glRasterPos2iv)
  GLC_FUNC_LOOKUP(glRasterPos2s)
  GLC_FUNC_LOOKUP(glRasterPos2sv)
  GLC_FUNC_LOOKUP(glRasterPos3d)
  GLC_FUNC_LOOKUP(glRasterPos3dv)
  GLC_FUNC_LOOKUP(glRasterPos3f)
  GLC_FUNC_LOOKUP(glRasterPos3fv)
  GLC_FUNC_LOOKUP(glRasterPos3i)
  GLC_FUNC_LOOKUP(glRasterPos3iv)
  GLC_FUNC_LOOKUP(glRasterPos3s)
  GLC_FUNC_LOOKUP(glRasterPos3sv)
  GLC_FUNC_LOOKUP(glRasterPos4d)
  GLC_FUNC_LOOKUP(glRasterPos4dv)
  GLC_FUNC_LOOKUP(glRasterPos4f)
  GLC_FUNC_LOOKUP(glRasterPos4fv)
  GLC_FUNC_LOOKUP(glRasterPos4i)
  GLC_FUNC_LOOKUP(glRasterPos4iv)
  GLC_FUNC_LOOKUP(glRasterPos4s)
  GLC_FUNC_LOOKUP(glRasterPos4sv)
  GLC_FUNC_LOOKUP(glReadBuffer)
  GLC_FUNC_LOOKUP(glReadPixels)
  GLC_FUNC_LOOKUP(glRectd)
  GLC_FUNC_LOOKUP(glRectdv)
  GLC_FUNC_LOOKUP(glRectf)
  GLC_FUNC_LOOKUP(glRectfv)
  GLC_FUNC_LOOKUP(glRecti)
  GLC_FUNC_LOOKUP(glRectiv)
  GLC_FUNC_LOOKUP(glRects)
  GLC_FUNC_LOOKUP(glRectsv)
  GLC_FUNC_LOOKUP(glRenderMode)
  GLC_FUNC_LOOKUP(glRotated)
  GLC_FUNC_LOOKUP(glRotatef)
  GLC_FUNC_LOOKUP(glScaled)
  GLC_FUNC_LOOKUP(glScalef)
  GLC_FUNC_LOOKUP(glScissor)
  GLC_FUNC_LOOKUP(glSelectBuffer)
  GLC_FUNC_LOOKUP(glShadeModel)
  GLC_FUNC_LOOKUP(glStencilFunc)
  GLC_FUNC_LOOKUP(glStencilMask)
  GLC_FUNC_LOOKUP(glStencilOp)
  GLC_FUNC_LOOKUP(glTexCoord1d)
  GLC_FUNC_LOOKUP(glTexCoord1dv)
  GLC_FUNC_LOOKUP(glTexCoord1f)
  GLC_FUNC_LOOKUP(glTexCoord1fv)
  GLC_FUNC_LOOKUP(glTexCoord1i)
  GLC_FUNC_LOOKUP(glTexCoord1iv)
  GLC_FUNC_LOOKUP(glTexCoord1s)
  GLC_FUNC_LOOKUP(glTexCoord1sv)
  GLC_FUNC_LOOKUP(glTexCoord2d)
  GLC_FUNC_LOOKUP(glTexCoord2dv)
  GLC_FUNC_LOOKUP(glTexCoord2f)
  GLC_FUNC_LOOKUP(glTexCoord2fv)
  GLC_FUNC_LOOKUP(glTexCoord2i)
  GLC_FUNC_LOOKUP(glTexCoord2iv)
  GLC_FUNC_LOOKUP(glTexCoord2s)
  GLC_FUNC_LOOKUP(glTexCoord2sv)
  GLC_FUNC_LOOKUP(glTexCoord3d)
  GLC_FUNC_LOOKUP(glTexCoord3dv)
  GLC_FUNC_LOOKUP(glTexCoord3f)
  GLC_FUNC_LOOKUP(glTexCoord3fv)
  GLC_FUNC_LOOKUP(glTexCoord3i)
  GLC_FUNC_LOOKUP(glTexCoord3iv)
  GLC_FUNC_LOOKUP(glTexCoord3s)
  GLC_FUNC_LOOKUP(glTexCoord3sv)
  GLC_FUNC_LOOKUP(glTexCoord4d)
  GLC_FUNC_LOOKUP(glTexCoord4dv)
  GLC_FUNC_LOOKUP(glTexCoord4f)
  GLC_FUNC_LOOKUP(glTexCoord4fv)
  GLC_FUNC_LOOKUP(glTexCoord4i)
  GLC_FUNC_LOOKUP(glTexCoord4iv)
  GLC_FUNC_LOOKUP(glTexCoord4s)
  GLC_FUNC_LOOKUP(glTexCoord4sv)
  GLC_FUNC_LOOKUP(glTexCoordPointer)
  GLC_FUNC_LOOKUP(glTexEnvf)
  GLC_FUNC_LOOKUP(glTexEnvfv)
  GLC_FUNC_LOOKUP(glTexEnvi)
  GLC_FUNC_LOOKUP(glTexEnviv)
  GLC_FUNC_LOOKUP(glTexGend)
  GLC_FUNC_LOOKUP(glTexGendv)
  GLC_FUNC_LOOKUP(glTexGenf)
  GLC_FUNC_LOOKUP(glTexGenfv)
  GLC_FUNC_LOOKUP(glTexGeni)
  GLC_FUNC_LOOKUP(glTexGeniv)
  GLC_FUNC_LOOKUP(glTexImage1D)
  GLC_FUNC_LOOKUP(glTexImage2D)
  GLC_FUNC_LOOKUP(glTexParameterf)
  GLC_FUNC_LOOKUP(glTexParameterfv)
  GLC_FUNC_LOOKUP(glTexParameteri)
  GLC_FUNC_LOOKUP(glTexParameteriv)
  GLC_FUNC_LOOKUP(glTexSubImage1D)
  GLC_FUNC_LOOKUP(glTexSubImage2D)
  GLC_FUNC_LOOKUP(glTranslated)
  GLC_FUNC_LOOKUP(glTranslatef)
  GLC_FUNC_LOOKUP(glVertex2d)
  GLC_FUNC_LOOKUP(glVertex2dv)
  GLC_FUNC_LOOKUP(glVertex2f)
  GLC_FUNC_LOOKUP(glVertex2fv)
  GLC_FUNC_LOOKUP(glVertex2i)
  GLC_FUNC_LOOKUP(glVertex2iv)
  GLC_FUNC_LOOKUP(glVertex2s)
  GLC_FUNC_LOOKUP(glVertex2sv)
  GLC_FUNC_LOOKUP(glVertex3d)
  GLC_FUNC_LOOKUP(glVertex3dv)
  GLC_FUNC_LOOKUP(glVertex3f)
  GLC_FUNC_LOOKUP(glVertex3fv)
  GLC_FUNC_LOOKUP(glVertex3i)
  GLC_FUNC_LOOKUP(glVertex3iv)
  GLC_FUNC_LOOKUP(glVertex3s)
  GLC_FUNC_LOOKUP(glVertex3sv)
  GLC_FUNC_LOOKUP(glVertex4d)
  GLC_FUNC_LOOKUP(glVertex4dv)
  GLC_FUNC_LOOKUP(glVertex4f)
  GLC_FUNC_LOOKUP(glVertex4fv)
  GLC_FUNC_LOOKUP(glVertex4i)
  GLC_FUNC_LOOKUP(glVertex4iv)
  GLC_FUNC_LOOKUP(glVertex4s)
  GLC_FUNC_LOOKUP(glVertex4sv)
  GLC_FUNC_LOOKUP(glVertexPointer)
  GLC_FUNC_LOOKUP(glViewport)

#undef GLC_FUNC_LOOKUP

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLDriver::MapWGLFunctions()
{
  void **tempfunc;

#define GLW_FUNC_LOOKUP(string)                 \
  tempfunc = (void**)(&GLW.##string);           \
  (*tempfunc) = openGLLib.GetFunction(#string); \
  if(GLW.##string == NULL)                      \
  {LOGERR(("Function %s unable to be mapped",#string)) return false;}

  GLW_FUNC_LOOKUP(wglChoosePixelFormat)
  GLW_FUNC_LOOKUP(wglCopyContext)
  GLW_FUNC_LOOKUP(wglCreateContext)
  GLW_FUNC_LOOKUP(wglCreateLayerContext)
  GLW_FUNC_LOOKUP(wglDeleteContext)
  GLW_FUNC_LOOKUP(wglDescribeLayerPlane)
  GLW_FUNC_LOOKUP(wglDescribePixelFormat)
  GLW_FUNC_LOOKUP(wglGetCurrentContext)
  GLW_FUNC_LOOKUP(wglGetCurrentDC)
  GLW_FUNC_LOOKUP(wglGetDefaultProcAddress)
  GLW_FUNC_LOOKUP(wglGetLayerPaletteEntries)
  GLW_FUNC_LOOKUP(wglGetPixelFormat)
  GLW_FUNC_LOOKUP(wglGetProcAddress)
  GLW_FUNC_LOOKUP(wglMakeCurrent)
  GLW_FUNC_LOOKUP(wglRealizeLayerPalette)
  GLW_FUNC_LOOKUP(wglSetLayerPaletteEntries)
  GLW_FUNC_LOOKUP(wglSetPixelFormat)
  GLW_FUNC_LOOKUP(wglShareLists)
  GLW_FUNC_LOOKUP(wglSwapBuffers)
  GLW_FUNC_LOOKUP(wglSwapLayerBuffers)
  GLW_FUNC_LOOKUP(wglUseFontBitmapsA)
  GLW_FUNC_LOOKUP(wglUseFontBitmapsW)
  GLW_FUNC_LOOKUP(wglUseFontOutlinesA)
  GLW_FUNC_LOOKUP(wglUseFontOutlinesW)

#undef GLW_FUNC_LOOKUP

  return true;
}
