/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/

#include "stdafx.h"
#ifdef _MSC_VER
#pragma warning (disable:4786)   // No complaints about debug symbol length
#endif // _MSC_VER 

#include "FileUtils.h"
#include <winbase.h>
#include <imagehlp.h>

USING_ERRORLOG


//The OS specific directory separator
char FileUtils::dirSeparator = '\\';


///////////////////////////////////////////////////////////////////////////////
//
bool FileUtils::CreateFullDirectory(const char *directory)
{
  //Perhaps do string conversion?

  //Call built in function
  // (perhaps in future remove dependency on imagehlp.h?)
  if(MakeSureDirectoryPathExists(directory))
  {
    return true;
  }

/*
  //Create the directory
  if(CreateDirectory(directory,NULL))
  {
    return true;
  }
*/
  return false;
}

///////////////////////////////////////////////////////////////////////////////
//
bool FileUtils::CopyFile(const string &srcFile,const string &dstFile, bool overwrite)
{
  return (::CopyFile(srcFile.c_str(),dstFile.c_str(),(BOOL)(!overwrite)) != 0);
}
