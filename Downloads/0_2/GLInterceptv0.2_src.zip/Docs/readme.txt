============================================================
  
  GLIntercept v0.2 

  Copyright (c) 2004  Damian Trebilco  All rights reserved.

============================================================

Contents:
  1) Quick start guide
  2) Output
    2.1) Function Log
    2.2) Error Log
    2.3) Image Log
    2.4) Shader Log
    2.5) Frame/Render Log
  3) Known bugs
  4) Adding OpenGL extensions
  5) Contact
  6) Disclaimer


============================================================
1) Quick start guide

After installation, simply copy the opengl32.dll and gliConfig.ini file from 
the install directory to the executable folder of the application you want to
intercept OpenGL calls. 

Then edit the gliConfig.ini file and enable the options required then run the 
application.

If the interception was successful, a gliLog.txt will be generated in the same
directory as the opengl32.dll. (this is the error log). The results of the 
interception are also stored in the same directory by default. 
(ie. gliInterceptLog.txt)

============================================================
2) Output

2.1) Function Log

The GLIntercept function log simply records incoming OpenGL calls and saves 
them to a file. The logger can store functions in flat .txt files or in a .xml
format that can use a xsl file to present the data in a web browser.

Only OpenGL functions known by GLIntercept will have parameters of the function
logged. Unknown functions will have a ???? in the parameter field.

2.2) Error Log

Every execution of GLIntercept produces a gliLog.txt file in the directory of
the opengl32.dll. This file contains a record of any abnormal states or errors
that are detected during execution. If the image or shader logs are enabled, 
texture and shader memory leaks are also recorded here.

2.3) Image Log

The image log enables the saving of any OpenGL textures that are used in the 
application. Texture types include 1D,2D,3D,CUBE,NV_RECT and p-buffer bound 
textures. See the gliConfig.ini file for full options. 

2.4) Shader Log

The shader log enables the saving of OpenGL shaders/programs that are used 
in the application. Only ARB/NV vertex and fragment programs are currently 
supported. (GLSL support to be added soon). See the gliConfig.ini file for 
full options. 


2.5) Frame/Render Log
  
The frame log enables the saving of the OpenGL frame buffer pre and post 
render calls. The ability to save the "diff" of pre and post images is also 
available. See the gliConfig.ini file for full options. 

============================================================
3) Known bugs

There are currently no known bugs in GLIntercept, however, the advanced 
loggers (ie.image,shader) assume that all function calls are valid. For this 
reason, ensure the application is free of OpenGL errors for correct usage of 
these loggers.

GLIntercept also relies on a conformant OpenGL implementation. Current known
driver issues are:

ATI Radeon Cat 4.1:
- glGetTexImage does not return the correct faces when retrieving cube maps.

- when using WGL_ARB_render_texture, calls to 
  glGetIntegerv(GL_TEXTURE_BINDING_2D,&retVal); 
  do not return the currently bound texture id when the texture is bound to
  a p-buffer. It seems the driver is allocating a new texture internally when
  the texture is bound to a p-buffer. GlIntercept will complain about a 
  texture ID that is being used that was not created. The state of what 
  textures are bound during a render call is also wrong in the log output 
  because of this.

============================================================
4) Adding OpenGL extensions

While GLIntercept does cover most common extensions, adding new extensions 
is trivial.

To add a new OpenGL extension, access the GLFunctions folder in the install 
directory and add a file containing the new tokens/functions to the folder. 
The syntax of these files is very close to standard C so reference the 
existing files for syntax. Then add a #include directive to the gliIncludes.h 
file. 

GLIntercept will log any parse errors in the file to the gliLog.txt file next
time you run a OpenGL app.

============================================================
5) Contact

Any questions/bug reports/feature requests can be sent to:

dtrebilco@techie.com

This account is usually only checked on weekends so allow about a week if you
expect a reply.

============================================================
6) Disclaimer

 The free software programs provided by Damian Trebilco may be freely  
 distributed, provided that no charge above the cost of distribution is 
 levied, and that the disclaimer below is always attached to it.


 THIS SOFTWARE IS PROVIDED BY DAMIAN TREBILCO ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL DAMIAN TREBILCO BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

