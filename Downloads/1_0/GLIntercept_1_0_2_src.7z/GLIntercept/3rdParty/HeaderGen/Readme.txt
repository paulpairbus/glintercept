This folder contains scripts used to help generate the extension loader header files.

  XMLGenGLI.py - Used to generate headers from the XML specs file (from https://bitbucket.org/alfonse/gl-xml-specs)
  
  GLLoadeGenGLI.py -  Used to generate headers from the XML files used in GLLoader (http://sourceforge.net/projects/klayge/files/GLLoader/)
                      NOTE: do not trust GLLoader extension XML! - it is riddled with bugs.