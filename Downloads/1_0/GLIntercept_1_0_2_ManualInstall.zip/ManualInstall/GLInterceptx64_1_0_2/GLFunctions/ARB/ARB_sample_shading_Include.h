#define GLI_INCLUDE_GL_ARB_SAMPLE_SHADING

enum Main {

  //GL_SAMPLE_SHADING_ARB                 = 0x8C36,
  //GL_MIN_SAMPLE_SHADING_VALUE_ARB       = 0x8C37,

};

void glMinSampleShadingARB(GLclampf value);
