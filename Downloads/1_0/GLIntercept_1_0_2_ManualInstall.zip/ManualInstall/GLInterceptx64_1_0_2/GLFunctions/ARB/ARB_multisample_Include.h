#define GLI_INCLUDE_ARB_MULTISAMPLE

enum Main {

  //GLX_SAMPLE_BUFFERS_ARB                =  100000,
	//GLX_SAMPLES_ARB			                  =  100001,


	//WGL_SAMPLE_BUFFERS_ARB		            =  0x2041,
	//WGL_SAMPLES_ARB			                  =  0x2042,
};


void glSampleCoverageARB(GLclampf value,GLboolean invert);

