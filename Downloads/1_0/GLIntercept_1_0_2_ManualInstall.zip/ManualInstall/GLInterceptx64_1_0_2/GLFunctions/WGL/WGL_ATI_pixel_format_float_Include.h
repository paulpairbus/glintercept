#define GLI_INCLUDE_WGL_ATI_PIXEL_FORMAT_FLOAT

enum Main {

  //GL_RGBA_FLOAT_MODE_ATI              =  0x8820,
  GL_COLOR_CLEAR_UNCLAMPED_VALUE_ATI  =  0x8835,

  //Should this be in a seperate WGL name space?
  //WGL_TYPE_RGBA_FLOAT_ATI             =  0x21A0,
};





      
