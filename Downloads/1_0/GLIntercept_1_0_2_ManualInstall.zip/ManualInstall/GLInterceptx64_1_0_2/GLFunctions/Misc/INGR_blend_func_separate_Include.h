#define GLI_INCLUDE_GL_INGR_BLEND_FUNC_SEPARATE

void glBlendFuncSeparateINGR(GLenum[Main] sfactorRGB, GLenum[Main] dfactorRGB, GLenum[Main] sfactorAlpha, GLenum[Main] dfactorAlpha);
