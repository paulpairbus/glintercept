#define GLI_INCLUDE_GL_SGIX_TAG_SAMPLE_BUFFER

void glTagSampleBufferSGIX(void);
