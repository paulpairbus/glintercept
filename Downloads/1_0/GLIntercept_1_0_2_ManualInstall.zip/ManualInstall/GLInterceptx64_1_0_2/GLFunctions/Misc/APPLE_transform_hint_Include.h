#define GLI_INCLUDE_GL_APPLE_TRANSFORM_HINT

enum Main {

  GL_TRANSFORM_HINT_APPLE       = 0x85B1,

};

