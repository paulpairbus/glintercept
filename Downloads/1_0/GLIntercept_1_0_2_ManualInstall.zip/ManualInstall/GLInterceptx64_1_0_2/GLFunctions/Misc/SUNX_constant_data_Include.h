#define GLI_INCLUDE_GL_SUNX_CONSTANT_DATA

enum Main {

  GL_UNPACK_CONSTANT_DATA_SUNX        = 0x81D5,
  GL_TEXTURE_CONSTANT_DATA_SUNX       = 0x81D6,

};

void glFinishTextureSUNX(void);
