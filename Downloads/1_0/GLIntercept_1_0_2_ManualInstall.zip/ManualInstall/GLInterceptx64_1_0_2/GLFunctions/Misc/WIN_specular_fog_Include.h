#define GLI_INCLUDE_GL_WIN_SPECULAR_FOG

enum Main {

  GL_FOG_SPECULAR_TEXTURE_WIN       = 0x80EC,

};

