#define GLI_INCLUDE_GL_SGIX_FLUSH_RASTER

void glFlushRasterSGIX(void);
