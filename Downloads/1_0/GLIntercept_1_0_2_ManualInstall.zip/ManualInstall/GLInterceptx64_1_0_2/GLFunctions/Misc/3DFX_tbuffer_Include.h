#define GLI_INCLUDE_GL_3DFX_TBUFFER

void glTbufferMask3DFX(GLuint mask);
