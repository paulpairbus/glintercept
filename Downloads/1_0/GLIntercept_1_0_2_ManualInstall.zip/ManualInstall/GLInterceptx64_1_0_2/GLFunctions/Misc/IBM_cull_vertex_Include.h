#define GLI_INCLUDE_GL_IBM_CULL_VERTEX

enum Main {

//  GL_CULL_VERTEX_IBM       = 103050,

};

