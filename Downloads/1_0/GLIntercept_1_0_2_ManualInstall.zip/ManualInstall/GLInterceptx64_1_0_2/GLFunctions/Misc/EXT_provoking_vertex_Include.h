#define GLI_INCLUDE_EXT_PROVOKING_VERTEX

enum Main {

  //GL_FIRST_VERTEX_CONVENTION_EXT                  =  0x8E4D,
  //GL_LAST_VERTEX_CONVENTION_EXT                   =  0x8E4E,

  //GL_PROVOKING_VERTEX_EXT                         =  0x8E4F,
  //GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT =  0x8E4C,

};

void glProvokingVertexEXT(GLenum[Main] mode);
