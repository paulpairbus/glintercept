#define GLI_INCLUDE_GL_GREMEDY_FRAME_TERMINATOR

void glFrameTerminatorGREMEDY(void);
