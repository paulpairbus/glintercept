#define GLI_INCLUDE_GL_SGIX_INTERLACE

enum Main {

  GL_INTERLACE_SGIX       = 0x8094,

};

