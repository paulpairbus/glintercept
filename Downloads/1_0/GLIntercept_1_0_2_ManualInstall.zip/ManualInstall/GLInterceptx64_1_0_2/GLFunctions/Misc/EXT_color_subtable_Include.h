#define GLI_INCLUDE_GL_EXT_COLOR_SUBTABLE

void glColorSubTableEXT(GLenum[Main] target, GLsizei start, GLsizei count, GLenum[Main] format, GLenum[Main] type, const GLvoid * data);
void glCopyColorSubTableEXT(GLenum[Main] target, GLsizei start, GLint x, GLint y, GLsizei width);
