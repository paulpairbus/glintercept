#define GLI_INCLUDE_GL_SGIX_BLEND_ALPHA_MINMAX

enum Main {

  GL_ALPHA_MIN_SGIX       = 0x8320,
  GL_ALPHA_MAX_SGIX       = 0x8321,

};

