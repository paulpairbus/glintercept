#define GLI_INCLUDE_EXT_GPU_PROGRAM_PARAMETERS


void glProgramEnvParameters4fvEXT(GLenum[Main] target, GLuint index, GLsizei count, const GLfloat *params); 

void glProgramLocalParameters4fvEXT(GLenum[Main] target, GLuint index, GLsizei count, const GLfloat *params); 
