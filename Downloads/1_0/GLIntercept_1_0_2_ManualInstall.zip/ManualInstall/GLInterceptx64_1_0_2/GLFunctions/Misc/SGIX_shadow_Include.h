#define GLI_INCLUDE_GL_SGIX_SHADOW

enum Main {

  GL_TEXTURE_COMPARE_SGIX                = 0x819A,
  GL_TEXTURE_COMPARE_OPERATOR_SGIX       = 0x819B,
  GL_TEXTURE_LEQUAL_R_SGIX               = 0x819C,
  GL_TEXTURE_GEQUAL_R_SGIX               = 0x819D,

};

