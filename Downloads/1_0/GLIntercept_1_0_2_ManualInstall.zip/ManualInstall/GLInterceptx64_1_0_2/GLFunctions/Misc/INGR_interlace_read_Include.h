#define GLI_INCLUDE_GL_INGR_INTERLACE_READ

enum Main {

  GL_INTERLACE_READ_INGR       = 0x8568,

};

