#define GLI_INCLUDE_GL_IBM_MULTIMODE_DRAW_ARRAYS

void glMultiModeDrawArraysIBM(const GLenum * mode, const GLint * first, const GLsizei * count, GLsizei primcount, GLint modestride);
void glMultiModeDrawElementsIBM(const GLenum * mode, const GLsizei * count, GLenum[Main] type, const GLvoid* const * indices, GLsizei primcount, GLint modestride);
