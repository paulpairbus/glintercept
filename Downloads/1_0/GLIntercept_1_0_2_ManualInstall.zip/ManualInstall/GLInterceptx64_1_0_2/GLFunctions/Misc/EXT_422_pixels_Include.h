#define GLI_INCLUDE_GL_EXT_422_PIXELS

enum Main {

  GL_422_EXT                   = 0x80CC,
  GL_422_REV_EXT               = 0x80CD,
  GL_422_AVERAGE_EXT           = 0x80CE,
  GL_422_REV_AVERAGE_EXT       = 0x80CF,

};

