#define GLI_INCLUDE_EXT_FOG_COORD

void glFogCoordfEXT (GLfloat coord);

void glFogCoordfvEXT (const GLfloat *coord);

void glFogCoorddEXT (GLdouble coord);

void glFogCoorddvEXT (const GLdouble *coord);

void glFogCoordPointerEXT (GLenum[Main] type, GLsizei stride, const GLvoid *pointer);



