#define GLI_INCLUDE_EXT_TEXTURE_BUFFER_OBJECT


enum Main {
  
  //GL_TEXTURE_BUFFER_EXT                    = 0x8C2A,
  //GL_MAX_TEXTURE_BUFFER_SIZE_EXT           = 0x8C2B,
  //GL_TEXTURE_BINDING_BUFFER_EXT            = 0x8C2C,
  //GL_TEXTURE_BUFFER_DATA_STORE_BINDING_EXT = 0x8C2D,
  //GL_TEXTURE_BUFFER_FORMAT_EXT             = 0x8C2E,

};

void glTexBufferEXT(GLenum[Main] target, GLenum[Main] internalformat, GLuint buffer);
