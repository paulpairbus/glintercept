/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2005  Damian Trebilco

  Licensed under the MIT license - See Docs\license.txt for details.
=============================================================================*/
#ifndef __FUNCTION_RET_VALUE_H
#define __FUNCTION_RET_VALUE_H

#include "GLDefines.h"
#include <MiscUtils.h>

//@
//  Summary:
//    This class provides a way to access the return value from a 
//    arbitary function call. 
//
//  Note:
//    This class is very platform specific. Ensure to test return 
//    types from built-in to extension types
//
class FunctionRetValue 
{
public:

  //Constructor
  inline FunctionRetValue(uintptr_t newIntValue);
  inline FunctionRetValue(const void *newValue);

  //@
  //  Summary:
  //    To get the specified return value.
  //  
  //  Parameters:
  //    value - The return value.
  //
  inline void Get(void *&value) const;
  inline void Get(GLuint &value) const;
  inline void Get(GLint  &value) const;
  inline void Get(GLbyte &value) const;
  inline void Get(GLshort &value) const;
  inline void Get(GLubyte &value) const;
  inline void Get(GLushort &value) const;
  inline void Get(GLsync &value) const;
#ifdef OS_ARCH_x64
  inline void Get(GLintptr &value) const;
#endif

protected:

  uintptr_t intValue;                                //The return value 

};

///////////////////////////////////////////////////////////////////////////////
//
inline FunctionRetValue::FunctionRetValue(uintptr_t newIntValue)
{
  intValue = newIntValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline FunctionRetValue::FunctionRetValue(const void *newValue)
{
  CASSERT(sizeof(uintptr_t) == sizeof(void*), Pointers_and_uintptr_ts_not_the_same_size);

  //This assumes pointers and ints have the same size
  intValue = (uintptr_t)(newValue);
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(void *&retValue) const
{
  retValue  = (void*)intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLuint &retValue) const
{
  retValue = (GLuint) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLint &retValue) const
{
  retValue = (GLint) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLbyte &retValue) const
{
  retValue = (GLbyte) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLshort &retValue) const
{
  retValue = (GLshort) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLubyte &retValue) const
{
  retValue = (GLubyte) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLushort &retValue) const
{
  retValue = (GLushort) intValue;
}

///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLsync &retValue) const
{
  //CASSERT(sizeof(GLuint) == sizeof(GLsync), GLSync_and_uints_not_the_same_size);

  retValue = (GLsync) intValue;
}

#ifdef OS_ARCH_x64
///////////////////////////////////////////////////////////////////////////////
//
inline void FunctionRetValue::Get(GLintptr &retValue) const
{
  retValue = (GLintptr) intValue;
}
#endif

#endif // __FUNCTION_RET_VALUE_H
