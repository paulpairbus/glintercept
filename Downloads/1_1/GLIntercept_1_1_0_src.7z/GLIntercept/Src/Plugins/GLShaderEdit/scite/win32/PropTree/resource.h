
//PropTree resources (only the 700 range is reserved)
#define IDS_TRUE                        700
#define IDS_FALSE                       701
#define IDS_NOITEMSEL                   702
#define IDS_SELFORINFO                  703
#define IDC_SPLITTER                    704
#define IDC_FPOINT                      705

