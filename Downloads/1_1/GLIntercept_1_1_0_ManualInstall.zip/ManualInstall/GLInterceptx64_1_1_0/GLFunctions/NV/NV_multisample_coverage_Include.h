#define GLI_INCLUDE_GL_NV_MULTISAMPLE_COVERAGE

enum Main {

  //GL_COVERAGE_SAMPLES_NV       = 0x80A9,
  GL_COLOR_SAMPLES_NV          = 0x8E20,

};

