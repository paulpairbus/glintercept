#define GLI_INCLUDE_WGL_NV_RENDER_DEPTH_TEXTURE

enum Main {

  WGL_BIND_TO_TEXTURE_DEPTH_NV                 = 0x20A3,
  WGL_BIND_TO_TEXTURE_RECTANGLE_DEPTH_NV       = 0x20A4,
  WGL_DEPTH_TEXTURE_FORMAT_NV                  = 0x20A5,
  WGL_TEXTURE_DEPTH_COMPONENT_NV               = 0x20A6,
  WGL_DEPTH_COMPONENT_NV                       = 0x20A7,

};

