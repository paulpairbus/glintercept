#define GLI_INCLUDE_ARB_POINT_PARAMETERS


void glPointParameterfARB(GLenum[Main] pname, GLfloat param);
void glPointParameterfvARB(GLenum[Main] pname, const GLfloat *params);




