#define GLI_INCLUDE_GL_WIN_PHONG_SHADING

enum Main {

  GL_PHONG_WIN            = 0x80EA,
  GL_PHONG_HINT_WIN       = 0x80EB,

};

