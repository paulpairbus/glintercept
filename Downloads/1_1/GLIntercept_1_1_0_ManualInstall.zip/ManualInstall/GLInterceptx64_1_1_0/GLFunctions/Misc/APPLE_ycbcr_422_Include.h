#define GLI_INCLUDE_GL_APPLE_YCBCR_422

enum Main {

  GL_YCBCR_422_APPLE                    = 0x85B9,
  GL_UNSIGNED_SHORT_8_8_APPLE           = 0x85BA,
  GL_UNSIGNED_SHORT_8_8_REV_APPLE       = 0x85BB,

};

