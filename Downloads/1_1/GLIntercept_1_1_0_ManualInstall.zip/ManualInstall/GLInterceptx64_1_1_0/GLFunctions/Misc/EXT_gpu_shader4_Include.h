#define GLI_INCLUDE_EXT_GPU_SHADER4


enum Main {
  
  //GL_VERTEX_ATTRIB_ARRAY_INTEGER_EXT = 0x88FD,

  //GL_SAMPLER_1D_ARRAY_EXT          = 0x8DC0,
  //GL_SAMPLER_2D_ARRAY_EXT          = 0x8DC1,
  //GL_SAMPLER_BUFFER_EXT            = 0x8DC2,
  //GL_SAMPLER_1D_ARRAY_SHADOW_EXT   = 0x8DC3,
  //GL_SAMPLER_2D_ARRAY_SHADOW_EXT   = 0x8DC4,
  //GL_SAMPLER_CUBE_SHADOW_EXT       = 0x8DC5,
  //GL_UNSIGNED_INT_VEC2_EXT         = 0x8DC6,
  //GL_UNSIGNED_INT_VEC3_EXT         = 0x8DC7,
  //GL_UNSIGNED_INT_VEC4_EXT         = 0x8DC8,
  //GL_INT_SAMPLER_1D_EXT            = 0x8DC9,
  //GL_INT_SAMPLER_2D_EXT            = 0x8DCA,
  //GL_INT_SAMPLER_3D_EXT            = 0x8DCB,
  //GL_INT_SAMPLER_CUBE_EXT          = 0x8DCC,
  //GL_INT_SAMPLER_2D_RECT_EXT       = 0x8DCD,
  //GL_INT_SAMPLER_1D_ARRAY_EXT      = 0x8DCE,
  //GL_INT_SAMPLER_2D_ARRAY_EXT      = 0x8DCF,
  //GL_INT_SAMPLER_BUFFER_EXT        = 0x8DD0,
  //GL_UNSIGNED_INT_SAMPLER_1D_EXT   = 0x8DD1,
  //GL_UNSIGNED_INT_SAMPLER_2D_EXT   = 0x8DD2,
  //GL_UNSIGNED_INT_SAMPLER_3D_EXT   = 0x8DD3,
  //GL_UNSIGNED_INT_SAMPLER_CUBE_EXT = 0x8DD4,
  //GL_UNSIGNED_INT_SAMPLER_2D_RECT_EXT  = 0x8DD5,
  //GL_UNSIGNED_INT_SAMPLER_1D_ARRAY_EXT = 0x8DD6,
  //GL_UNSIGNED_INT_SAMPLER_2D_ARRAY_EXT = 0x8DD7,
  //GL_UNSIGNED_INT_SAMPLER_BUFFER_EXT   = 0x8DD8,

  //GL_MIN_PROGRAM_TEXEL_OFFSET_EXT      = 0x8904,
  //GL_MAX_PROGRAM_TEXEL_OFFSET_EXT      = 0x8905,

};

void glVertexAttribI1iEXT(GLuint  index, GLint  x);
void glVertexAttribI2iEXT(GLuint  index, GLint  x, GLint  y);
void glVertexAttribI3iEXT(GLuint  index, GLint  x, GLint  y, GLint  z);
void glVertexAttribI4iEXT(GLuint  index, GLint  x, GLint  y, GLint  z, GLint  w);

void glVertexAttribI1uiEXT(GLuint  index, GLuint  x);
void glVertexAttribI2uiEXT(GLuint  index, GLuint  x, GLuint  y);
void glVertexAttribI3uiEXT(GLuint  index, GLuint  x, GLuint  y, GLuint  z);
void glVertexAttribI4uiEXT(GLuint  index, GLuint  x, GLuint  y, GLuint  z, GLuint  w);

void glVertexAttribI1ivEXT(GLuint  index, const GLint * v);
void glVertexAttribI2ivEXT(GLuint  index, const GLint * v);
void glVertexAttribI3ivEXT(GLuint  index, const GLint * v);
void glVertexAttribI4ivEXT(GLuint  index, const GLint * v);

void glVertexAttribI1uivEXT(GLuint  index, const GLuint * v);
void glVertexAttribI2uivEXT(GLuint  index, const GLuint * v);
void glVertexAttribI3uivEXT(GLuint  index, const GLuint * v);
void glVertexAttribI4uivEXT(GLuint  index, const GLuint * v);

void glVertexAttribI4bvEXT(GLuint  index, const GLbyte *v);
void glVertexAttribI4svEXT(GLuint  index, const GLshort *v);
void glVertexAttribI4ubvEXT(GLuint  index, const GLubyte *v);
void glVertexAttribI4usvEXT(GLuint  index, const GLushort *v);

void glVertexAttribIPointerEXT(GLuint  index, GLint  size, GLenum[Main] type, GLsizei stride, const GLvoid * pointer);

void glGetVertexAttribIivEXT(GLuint  index, GLenum[Main] pname, GLint  *params);
void glGetVertexAttribIuivEXT(GLuint  index, GLenum[Main] pname, GLuint  *params);

void glUniform1uiEXT(GLint location, GLuint  v0);
void glUniform2uiEXT(GLint location, GLuint  v0, GLuint  v1);
void glUniform3uiEXT(GLint location, GLuint  v0, GLuint  v1, GLuint  v2);
void glUniform4uiEXT(GLint location, GLuint  v0, GLuint  v1, GLuint  v2, GLuint  v3);

void glUniform1uivEXT(GLint location, GLsizei count, const GLuint * value);
void glUniform2uivEXT(GLint location, GLsizei count, const GLuint * value);
void glUniform3uivEXT(GLint location, GLsizei count, const GLuint * value);
void glUniform4uivEXT(GLint location, GLsizei count, const GLuint * value);

void glGetUniformuivEXT(GLuint  program, GLint  location, GLuint  *params);

void glBindFragDataLocationEXT(GLuint  program, GLuint colorNumber, const GLchar * name);
GLint glGetFragDataLocationEXT(GLuint  program, const GLchar *name);