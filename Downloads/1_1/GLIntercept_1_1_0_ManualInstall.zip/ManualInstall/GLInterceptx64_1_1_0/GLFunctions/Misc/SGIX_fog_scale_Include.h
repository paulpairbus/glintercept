#define GLI_INCLUDE_GL_SGIX_FOG_SCALE

enum Main {

  GL_FOG_SCALE_SGIX             = 0x81FC,
  GL_FOG_SCALE_VALUE_SGIX       = 0x81FD,

};

