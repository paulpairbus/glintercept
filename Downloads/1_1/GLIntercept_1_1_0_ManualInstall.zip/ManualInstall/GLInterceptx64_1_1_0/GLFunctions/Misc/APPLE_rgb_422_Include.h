#define GLI_INCLUDE_GL_APPLE_RGB_422

enum Main {

  GL_RGB_422_APPLE       = 0x8A1F,

};

