#define GLI_INCLUDE_GL_EXT_CMYKA

enum Main {

  GL_CMYK_EXT                   = 0x800C,
  GL_CMYKA_EXT                  = 0x800D,
  GL_PACK_CMYK_HINT_EXT         = 0x800E,
  GL_UNPACK_CMYK_HINT_EXT       = 0x800F,

};

