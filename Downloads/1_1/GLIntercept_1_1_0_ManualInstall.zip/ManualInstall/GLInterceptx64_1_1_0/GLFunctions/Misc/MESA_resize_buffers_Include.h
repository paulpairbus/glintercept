#define GLI_INCLUDE_GL_MESA_RESIZE_BUFFERS

void glResizeBuffersMESA(void);
