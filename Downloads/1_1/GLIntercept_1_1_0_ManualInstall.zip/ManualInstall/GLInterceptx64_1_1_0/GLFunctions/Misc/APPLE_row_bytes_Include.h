#define GLI_INCLUDE_GL_APPLE_ROW_BYTES

enum Main {

  GL_PACK_ROW_BYTES_APPLE         = 0x8A15,
  GL_UNPACK_ROW_BYTES_APPLE       = 0x8A16,

};

