#define GLI_INCLUDE_GL_EXT_ABGR

enum Main {

  GL_ABGR_EXT       = 0x8000,

};

