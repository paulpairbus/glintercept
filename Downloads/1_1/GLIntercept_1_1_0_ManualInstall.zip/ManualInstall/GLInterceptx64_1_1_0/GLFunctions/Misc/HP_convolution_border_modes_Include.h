#define GLI_INCLUDE_GL_HP_CONVOLUTION_BORDER_MODES

enum Main {

  GL_IGNORE_BORDER_HP                  = 0x8150,
  //GL_CONSTANT_BORDER_HP                = 0x8151,
  //GL_REPLICATE_BORDER_HP               = 0x8153,
  //GL_CONVOLUTION_BORDER_COLOR_HP       = 0x8154,

};

