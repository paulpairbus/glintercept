#define GLI_INCLUDE_GL_SGIX_PIXEL_TEXTURE

enum Main {

  GL_PIXEL_TEX_GEN_SGIX            = 0x8139,
  GL_PIXEL_TEX_GEN_MODE_SGIX       = 0x832B,

};

void glPixelTexGenSGIX(GLenum[Main] mode);
