#define GLI_INCLUDE_GL_EXT_TEXTURE_SRGB_DECODE

enum Main {

  GL_TEXTURE_SRGB_DECODE_EXT       = 0x8A48,
  GL_DECODE_EXT                    = 0x8A49,
  GL_SKIP_DECODE_EXT               = 0x8A4A,

};

