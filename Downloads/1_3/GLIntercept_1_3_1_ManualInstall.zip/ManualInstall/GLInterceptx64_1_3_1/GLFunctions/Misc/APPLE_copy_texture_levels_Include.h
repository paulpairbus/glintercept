#define GLI_INCLUDE_GL_APPLE_COPY_TEXTURE_LEVELS

void glCopyTextureLevelsAPPLE(GLuint destinationTexture, GLuint sourceTexture, GLint sourceBaseLevel, GLsizei sourceLevelCount);
