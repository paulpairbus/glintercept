#define GLI_INCLUDE_GL_OES_QUERY_MATRIX

GLbitfield glQueryMatrixxOES(GLfixed *mantissa, GLint *exponent);
