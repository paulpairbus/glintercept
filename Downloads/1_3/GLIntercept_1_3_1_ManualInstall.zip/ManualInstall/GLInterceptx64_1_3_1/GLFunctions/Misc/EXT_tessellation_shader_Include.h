#define GLI_INCLUDE_GL_EXT_TESSELLATION_SHADER

void glPatchParameteriEXT(GLenum[Main] pname, GLint value);
