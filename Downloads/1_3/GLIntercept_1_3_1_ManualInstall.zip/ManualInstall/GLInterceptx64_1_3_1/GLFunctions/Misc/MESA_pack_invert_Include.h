#define GLI_INCLUDE_GL_MESA_PACK_INVERT

enum Main {

  GL_PACK_INVERT_MESA       = 0x8758,

};

