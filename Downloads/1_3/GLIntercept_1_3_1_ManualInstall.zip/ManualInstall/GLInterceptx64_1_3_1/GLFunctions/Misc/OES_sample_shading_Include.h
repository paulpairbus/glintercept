#define GLI_INCLUDE_GL_OES_SAMPLE_SHADING

enum Main {

  //GL_SAMPLE_SHADING_OES                 = 0x8C36,
  //GL_MIN_SAMPLE_SHADING_VALUE_OES       = 0x8C37,

};

void glMinSampleShadingOES(GLfloat value);
