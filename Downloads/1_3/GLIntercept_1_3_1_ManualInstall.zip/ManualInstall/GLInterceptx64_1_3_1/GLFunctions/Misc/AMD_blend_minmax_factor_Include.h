#define GLI_INCLUDE_GL_AMD_BLEND_MINMAX_FACTOR

enum Main {

  GL_FACTOR_MIN_AMD       = 0x901C,
  GL_FACTOR_MAX_AMD       = 0x901D,

};

