#define GLI_INCLUDE_GL_EXT_POLYGON_OFFSET_CLAMP

enum Main {

  GL_POLYGON_OFFSET_CLAMP_EXT       = 0x8E1B,

};

void glPolygonOffsetClampEXT(GLfloat factor, GLfloat units, GLfloat clamp);
