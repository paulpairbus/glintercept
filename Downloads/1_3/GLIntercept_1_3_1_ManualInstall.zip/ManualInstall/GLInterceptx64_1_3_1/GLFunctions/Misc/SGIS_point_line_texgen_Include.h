#define GLI_INCLUDE_GL_SGIS_POINT_LINE_TEXGEN

enum Main {

  GL_EYE_DISTANCE_TO_POINT_SGIS          = 0x81F0,
  GL_OBJECT_DISTANCE_TO_POINT_SGIS       = 0x81F1,
  GL_EYE_DISTANCE_TO_LINE_SGIS           = 0x81F2,
  GL_OBJECT_DISTANCE_TO_LINE_SGIS        = 0x81F3,
  GL_EYE_POINT_SGIS                      = 0x81F4,
  GL_OBJECT_POINT_SGIS                   = 0x81F5,
  GL_EYE_LINE_SGIS                       = 0x81F6,
  GL_OBJECT_LINE_SGIS                    = 0x81F7,

};

