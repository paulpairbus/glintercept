#define GLI_INCLUDE_GL_3DFX_MULTISAMPLE

enum Main {

  GL_MULTISAMPLE_3DFX           = 0x86B2,
  GL_SAMPLE_BUFFERS_3DFX        = 0x86B3,
  GL_SAMPLES_3DFX               = 0x86B4,
  //GL_MULTISAMPLE_BIT_3DFX       = 0x20000000,

};

