#define GLI_INCLUDE_WGL_ARB_PIXEL_FORMAT_FLOAT

enum Main {

  WGL_TYPE_RGBA_FLOAT_ARB       = 0x21A0,

};

