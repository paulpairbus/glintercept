#define GLI_INCLUDE_WGL_EXT_DEPTH_FLOAT

enum Main {

  WGL_DEPTH_FLOAT_EXT       = 0x2040,

};

