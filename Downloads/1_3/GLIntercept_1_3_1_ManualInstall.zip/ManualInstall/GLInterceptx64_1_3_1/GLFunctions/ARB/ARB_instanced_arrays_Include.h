#define GLI_INCLUDE_GL_ARB_INSTANCED_ARRAYS

enum Main {

  //GL_VERTEX_ATTRIB_ARRAY_DIVISOR_ARB       = 0x88FE,

};

void glVertexAttribDivisorARB(GLuint index, GLuint divisor);
