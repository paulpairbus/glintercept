#define GLI_INCLUDE_ARB_TEXTURE_BUFFER_OBJECT

enum Main {

  //GL_TEXTURE_BUFFER_ARB                     = 0x8C2A,

  //GL_MAX_TEXTURE_BUFFER_SIZE_ARB            = 0x8C2B,
  //GL_TEXTURE_BINDING_BUFFER_ARB             = 0x8C2C,
  //GL_TEXTURE_BUFFER_DATA_STORE_BINDING_ARB  = 0x8C2D,
  //GL_TEXTURE_BUFFER_FORMAT_ARB              = 0x8C2E,

};

void glTexBufferARB(GLenum[Main] target, GLenum[Main] internalformat, GLuint buffer);
