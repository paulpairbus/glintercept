#define GLI_INCLUDE_GL_NV_INSTANCED_ARRAYS

enum Main {

  //GL_VERTEX_ATTRIB_ARRAY_DIVISOR_NV       = 0x88FE,

};

void glVertexAttribDivisorNV(GLuint index, GLuint divisor);
