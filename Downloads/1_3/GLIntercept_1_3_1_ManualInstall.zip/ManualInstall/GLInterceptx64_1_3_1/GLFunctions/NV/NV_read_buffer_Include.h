#define GLI_INCLUDE_GL_NV_READ_BUFFER

enum Main {

  //GL_READ_BUFFER_NV       = 0x0C02,

};

void glReadBufferNV(GLenum[Main] mode);
