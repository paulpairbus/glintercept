#define GLI_INCLUDE_GL_NV_FRAGMENT_COVERAGE_TO_COLOR

enum Main {

  GL_FRAGMENT_COVERAGE_TO_COLOR_NV       = 0x92DD,
  GL_FRAGMENT_COVERAGE_COLOR_NV          = 0x92DE,

};

void glFragmentCoverageColorNV(GLuint color);
