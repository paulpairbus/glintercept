#define GLI_INCLUDE_GL_NVX_CONDITIONAL_RENDER

void glBeginConditionalRenderNVX(GLuint id);
void glEndConditionalRenderNVX(void);
