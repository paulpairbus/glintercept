#define GLI_INCLUDE_ARB_DRAW_INSTANCED

void glDrawArraysInstancedARB(GLenum[Primitives] mode, GLint first, GLsizei count, GLsizei primcount);
void glDrawElementsInstancedARB(GLenum[Primitives] mode, GLsizei count, GLenum[Main] type, void *indices, GLsizei primcount);
