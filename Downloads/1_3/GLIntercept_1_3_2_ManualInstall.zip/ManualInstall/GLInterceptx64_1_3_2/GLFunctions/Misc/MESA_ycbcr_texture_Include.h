#define GLI_INCLUDE_GL_MESA_YCBCR_TEXTURE

enum Main {

  //GL_UNSIGNED_SHORT_8_8_MESA           = 0x85BA,
  //GL_UNSIGNED_SHORT_8_8_REV_MESA       = 0x85BB,
  GL_YCBCR_MESA                        = 0x8757,

};

