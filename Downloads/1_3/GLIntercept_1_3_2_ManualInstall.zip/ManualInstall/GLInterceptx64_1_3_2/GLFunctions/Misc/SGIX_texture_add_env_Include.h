#define GLI_INCLUDE_GL_SGIX_TEXTURE_ADD_ENV

enum Main {

  GL_TEXTURE_ENV_BIAS_SGIX       = 0x80BE,

};

