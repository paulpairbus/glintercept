#define GLI_INCLUDE_GL_IMG_PROGRAM_BINARY

enum Main {

  GL_SGX_PROGRAM_BINARY_IMG       = 0x9130,

};

