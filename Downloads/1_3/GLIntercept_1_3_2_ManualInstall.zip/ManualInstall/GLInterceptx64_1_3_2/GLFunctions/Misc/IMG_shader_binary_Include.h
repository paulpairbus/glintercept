#define GLI_INCLUDE_GL_IMG_SHADER_BINARY

enum Main {

  GL_SGX_BINARY_IMG       = 0x8C0A,

};

