#define GLI_INCLUDE_GL_OES_COPY_IMAGE

void glCopyImageSubDataOES(GLuint srcName, GLenum[Main] srcTarget, GLint srcLevel, GLint srcX, GLint srcY, GLint srcZ, GLuint dstName, GLenum[Main] dstTarget, GLint dstLevel, GLint dstX, GLint dstY, GLint dstZ, GLsizei srcWidth, GLsizei srcHeight, GLsizei srcDepth);
