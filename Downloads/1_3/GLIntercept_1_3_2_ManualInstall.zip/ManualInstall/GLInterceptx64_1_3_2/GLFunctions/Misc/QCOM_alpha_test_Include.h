#define GLI_INCLUDE_GL_QCOM_ALPHA_TEST

enum Main {

  //GL_ALPHA_TEST_QCOM            = 0x0BC0,
  //GL_ALPHA_TEST_FUNC_QCOM       = 0x0BC1,
  //GL_ALPHA_TEST_REF_QCOM        = 0x0BC2,

};

void glAlphaFuncQCOM(GLenum[Main] func, GLfloat ref);
