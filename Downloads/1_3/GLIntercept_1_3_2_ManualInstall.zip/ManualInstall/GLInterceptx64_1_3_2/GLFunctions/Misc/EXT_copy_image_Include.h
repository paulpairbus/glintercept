#define GLI_INCLUDE_GL_EXT_COPY_IMAGE

void glCopyImageSubDataEXT(GLuint srcName, GLenum[Main] srcTarget, GLint srcLevel, GLint srcX, GLint srcY, GLint srcZ, GLuint dstName, GLenum[Main] dstTarget, GLint dstLevel, GLint dstX, GLint dstY, GLint dstZ, GLsizei srcWidth, GLsizei srcHeight, GLsizei srcDepth);
