#define GLI_INCLUDE_GL_OML_INTERLACE

enum Main {

  GL_INTERLACE_OML            = 0x8980,
  GL_INTERLACE_READ_OML       = 0x8981,

};

