#define GLI_INCLUDE_GL_OES_PRIMITIVE_BOUNDING_BOX

enum Main {

  //GL_PRIMITIVE_BOUNDING_BOX_OES       = 0x92BE,

};

void glPrimitiveBoundingBoxOES(GLfloat minX, GLfloat minY, GLfloat minZ, GLfloat minW, GLfloat maxX, GLfloat maxY, GLfloat maxZ, GLfloat maxW);
