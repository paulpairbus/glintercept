#define GLI_INCLUDE_GL_OES_BLEND_EQUATION_SEPARATE

enum Main {

  //GL_BLEND_EQUATION_RGB_OES         = 0x8009,
  //GL_BLEND_EQUATION_ALPHA_OES       = 0x883D,

};

void glBlendEquationSeparateOES(GLenum[Main] modeRGB, GLenum[Main] modeAlpha);
