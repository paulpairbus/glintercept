#define GLI_INCLUDE_GL_EXT_DEBUG_MARKER

void glInsertEventMarkerEXT(GLsizei length, const GLchar *marker);
void glPushGroupMarkerEXT(GLsizei length, const GLchar *marker);
void glPopGroupMarkerEXT(void);
