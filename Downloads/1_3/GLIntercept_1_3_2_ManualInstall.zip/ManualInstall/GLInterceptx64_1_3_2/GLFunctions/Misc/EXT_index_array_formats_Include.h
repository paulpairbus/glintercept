#define GLI_INCLUDE_GL_EXT_INDEX_ARRAY_FORMATS

enum Main {

  GL_IUI_V2F_EXT               = 0x81AD,
  GL_IUI_V3F_EXT               = 0x81AE,
  GL_IUI_N3F_V2F_EXT           = 0x81AF,
  GL_IUI_N3F_V3F_EXT           = 0x81B0,
  GL_T2F_IUI_V2F_EXT           = 0x81B1,
  GL_T2F_IUI_V3F_EXT           = 0x81B2,
  GL_T2F_IUI_N3F_V2F_EXT       = 0x81B3,
  GL_T2F_IUI_N3F_V3F_EXT       = 0x81B4,

};

