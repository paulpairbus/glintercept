#define GLI_INCLUDE_GL_OES_VERTEX_TYPE_10_10_10_2

enum Main {

  GL_UNSIGNED_INT_10_10_10_2_OES       = 0x8DF6,
  GL_INT_10_10_10_2_OES                = 0x8DF7,

};

