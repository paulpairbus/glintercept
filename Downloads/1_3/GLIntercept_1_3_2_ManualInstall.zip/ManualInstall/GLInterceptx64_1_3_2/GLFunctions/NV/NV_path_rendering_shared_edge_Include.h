#define GLI_INCLUDE_GL_NV_PATH_RENDERING_SHARED_EDGE

enum Main {

  GL_SHARED_EDGE_NV       = 0xC0,

};

