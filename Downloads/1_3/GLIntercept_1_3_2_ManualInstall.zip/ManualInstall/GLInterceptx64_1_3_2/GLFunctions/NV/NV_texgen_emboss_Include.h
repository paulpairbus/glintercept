#define GLI_INCLUDE_GL_NV_TEXGEN_EMBOSS

enum Main {

  GL_EMBOSS_LIGHT_NV          = 0x855D,
  GL_EMBOSS_CONSTANT_NV       = 0x855E,
  GL_EMBOSS_MAP_NV            = 0x855F,

};

