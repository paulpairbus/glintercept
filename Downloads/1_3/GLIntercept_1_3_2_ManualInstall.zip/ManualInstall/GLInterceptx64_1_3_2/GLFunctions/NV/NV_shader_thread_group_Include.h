#define GLI_INCLUDE_GL_NV_SHADER_THREAD_GROUP

enum Main {

  GL_WARP_SIZE_NV          = 0x9339,
  GL_WARPS_PER_SM_NV       = 0x933A,
  GL_SM_COUNT_NV           = 0x933B,

};

