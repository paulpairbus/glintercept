#define GLI_INCLUDE_GL_NV_LIGHT_MAX_EXPONENT

enum Main {

  GL_MAX_SHININESS_NV           = 0x8504,
  GL_MAX_SPOT_EXPONENT_NV       = 0x8505,

};

