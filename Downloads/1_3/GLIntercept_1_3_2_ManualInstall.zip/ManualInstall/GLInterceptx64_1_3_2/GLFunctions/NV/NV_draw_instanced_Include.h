#define GLI_INCLUDE_GL_NV_DRAW_INSTANCED

void glDrawArraysInstancedNV(GLenum[Main] mode, GLint first, GLsizei count, GLsizei primcount);
void glDrawElementsInstancedNV(GLenum[Main] mode, GLsizei count, GLenum[Main] type, const void *indices, GLsizei primcount);
