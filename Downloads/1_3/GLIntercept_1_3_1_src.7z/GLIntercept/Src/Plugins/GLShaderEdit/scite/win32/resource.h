//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SciTERes.rc
//
#define IDD_GLISHADERDEBUG              101
#define IDC_EDIT3                       1001
#define IDC_CHECK1                      1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1010
#define IDC_RADIO3                      1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_COMBO1                      1014
#define IDC_EDIT2                       1015
#define IDC_TAB1                        1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
