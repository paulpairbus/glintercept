/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  Licensed under the MIT license - See Docs\license.txt for details.
=============================================================================*/
#ifndef __GLCORE_1_1
#define __GLCORE_1_1

#include "GLInterceptConfig.h"
#include "GLDriver.h"

#endif // __GLCORE_1_1
