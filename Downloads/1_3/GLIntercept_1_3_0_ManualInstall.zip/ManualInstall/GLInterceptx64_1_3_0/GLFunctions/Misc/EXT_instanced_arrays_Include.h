#define GLI_INCLUDE_GL_EXT_INSTANCED_ARRAYS

enum Main {

  //GL_VERTEX_ATTRIB_ARRAY_DIVISOR_EXT       = 0x88FE,

};

void glVertexAttribDivisorEXT(GLuint index, GLuint divisor);
