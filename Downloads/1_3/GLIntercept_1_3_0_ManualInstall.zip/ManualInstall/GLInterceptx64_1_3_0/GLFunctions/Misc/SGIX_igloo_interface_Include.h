#define GLI_INCLUDE_GL_SGIX_IGLOO_INTERFACE

void glIglooInterfaceSGIX(GLenum[Main] pname, const GLvoid * params);
