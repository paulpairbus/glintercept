#define GLI_INCLUDE_EXT_STENCIL_TWO_SIDE

enum Main {

  GL_STENCIL_TEST_TWO_SIDE_EXT    = 0x8910,
  GL_ACTIVE_STENCIL_FACE_EXT      = 0x8911,
};


void glActiveStencilFaceEXT(GLenum[Main] face);



