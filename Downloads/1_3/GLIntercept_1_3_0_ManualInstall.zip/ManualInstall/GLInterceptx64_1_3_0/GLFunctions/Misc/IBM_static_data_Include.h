#define GLI_INCLUDE_GL_IBM_STATIC_DATA

enum Main {

//  GL_ALL_STATIC_DATA_IBM      = 103060,
//  GL_STATIC_VERTEX_ARRAY_IBM  = 103061,

};

void glFlushStaticDataIBM(GLenum[Main] target);
