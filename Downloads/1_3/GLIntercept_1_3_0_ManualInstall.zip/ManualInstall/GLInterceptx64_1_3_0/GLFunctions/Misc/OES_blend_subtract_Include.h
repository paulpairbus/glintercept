#define GLI_INCLUDE_GL_OES_BLEND_SUBTRACT

enum Main {

  //GL_BLEND_EQUATION_OES              = 0x8009,
  //GL_FUNC_ADD_OES                    = 0x8006,
  //GL_FUNC_SUBTRACT_OES               = 0x800A,
  //GL_FUNC_REVERSE_SUBTRACT_OES       = 0x800B,

};

void glBlendEquationOES(GLenum[Main] mode);
