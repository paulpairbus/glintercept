#define GLI_INCLUDE_GL_AMD_COMPRESSED_3DC_TEXTURE

enum Main {

  GL_3DC_X_AMD        = 0x87F9,
  GL_3DC_XY_AMD       = 0x87FA,

};

