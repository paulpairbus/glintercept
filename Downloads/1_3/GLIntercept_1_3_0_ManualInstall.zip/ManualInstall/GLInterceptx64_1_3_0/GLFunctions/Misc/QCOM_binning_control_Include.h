#define GLI_INCLUDE_GL_QCOM_BINNING_CONTROL

enum Main {

  GL_BINNING_CONTROL_HINT_QCOM               = 0x8FB0,
  GL_CPU_OPTIMIZED_QCOM                      = 0x8FB1,
  GL_GPU_OPTIMIZED_QCOM                      = 0x8FB2,
  GL_RENDER_DIRECT_TO_FRAMEBUFFER_QCOM       = 0x8FB3,

};

