#define GLI_INCLUDE_GL_SGIX_IR_INSTRUMENT1

enum Main {

  GL_IR_INSTRUMENT1_SGIX       = 0x817F,

};

