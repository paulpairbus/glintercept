#define GLI_INCLUDE_GL_SGIX_YCRCBA

enum Main {

  GL_YCRCB_SGIX        = 0x8318,
  GL_YCRCBA_SGIX       = 0x8319,

};

