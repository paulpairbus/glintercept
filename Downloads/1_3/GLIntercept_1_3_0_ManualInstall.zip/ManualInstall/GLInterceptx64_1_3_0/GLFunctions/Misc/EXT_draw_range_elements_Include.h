#define GLI_INCLUDE_EXT_DRAW_RANGE_ELEMENTS

void glDrawRangeElementsEXT( GLenum[Primitives] mode, GLuint start, GLuint end, GLsizei count, GLenum[Main] type, const GLvoid *indices );

