#define GLI_INCLUDE_GL_NV_TEXTURE_BARRIER

void glTextureBarrierNV(void);
