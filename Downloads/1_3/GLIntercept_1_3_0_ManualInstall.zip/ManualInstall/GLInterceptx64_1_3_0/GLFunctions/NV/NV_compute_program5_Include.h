#define GLI_INCLUDE_GL_NV_COMPUTE_PROGRAM5

enum Main {

  GL_COMPUTE_PROGRAM_NV                        = 0x90FB,
  GL_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV       = 0x90FC,

};

