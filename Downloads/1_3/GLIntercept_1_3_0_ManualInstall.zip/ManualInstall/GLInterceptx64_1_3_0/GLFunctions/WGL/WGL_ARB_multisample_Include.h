#define GLI_INCLUDE_WGL_ARB_MULTISAMPLE

enum Main {

  WGL_SAMPLE_BUFFERS_ARB       = 0x2041,
  WGL_SAMPLES_ARB              = 0x2042,

};

