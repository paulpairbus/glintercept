#define GLI_INCLUDE_ATI_TEXTURE_ENV_COMBINE3

enum Main {

  GL_MODULATE_ADD_ATI            =       0x8744,
  GL_MODULATE_SIGNED_ADD_ATI     =       0x8745,
  GL_MODULATE_SUBTRACT_ATI       =       0x8746,

};





      
