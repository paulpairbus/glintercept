#define GLI_INCLUDE_GL_ES_3_1

void glMemoryBarrierByRegion(GLbitfield barriers);
