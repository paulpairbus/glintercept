============================================================
  
  GLIntercept 

  Copyright (c) 2011 Damian Trebilco  All rights reserved.

============================================================

Notes on the source:

 - All source (except some utility classes) is MIT licenced.
   see the Doc\licence.txt for details. Feel free to use this source as
   a reference to your own work.

   Workspaces used to build can be found in GLIntercept\Src\WorkSpaces
   
   Libraries/tools linked into GLIntercept (scite, corona, GLSL validate)
   all have their own licences.   

 - The source to GLIntercept was compiled using Visual C++ 2008.

 - The corona image library is need to compile the image loggers
   (http://sourceforge.net/projects/corona/) and is included in the
   3rdParty folder. (automatically built when using the provided 
   workspaces)

 - A modified Scite version is included which is used as the shader
   editor.


