/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2005  Damian Trebilco

  Licensed under the MIT license - See Docs\license.txt for details.
=============================================================================*/
#ifndef __GLCORE_1_2
#define __GLCORE_1_2

#include "GLInterceptConfig.h"
#include "GLDriver.h"

#endif // __GLCORE_1_2
