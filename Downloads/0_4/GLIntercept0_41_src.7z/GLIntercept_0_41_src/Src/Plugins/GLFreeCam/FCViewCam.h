/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __FC_VIEW_CAM_H_
#define __FC_VIEW_CAM_H_

#include "..\\..\\InterceptPluginInterface.h"
#include <string>
#include <vector>

#include "FCConfigData.h"

using namespace std;


//@
//  Summary:
//    This class enables (attempts) a visualization of the view frustum.
//  
class FCViewCam
{
public:

  //@
  //  Summary:
  //    Constructor. Inits all config data to default values.
  //
  //  Parameters:
  //    gliCallBacks - The callback class for this plugin.
  //
  FCViewCam(InterceptPluginCallbacks *gliCallBacks);

  //@
  //  Summary:
  //    Destructor.
  //
  virtual ~FCViewCam();

  //@
  //  Summary:
  //    To init and test for required OpenGL extension support.
  //    Must be called when OpenGL calls are valid or Init will fail.
  //
  //  Parameters:
  //    configData - The config data to init with.
  //
  void Init(const FCConfigData &configData);


  //@
  //  Summary:
  //    To render the view frustum to the current screen.
  //    The altered model view matrix must be set in the OpenGL state 
  //    before this method is called.
  //
  void RenderViewFrustum();

protected:

  bool   initData;                                //Flag inidicating if init has been called successfully
  bool   extensionVertexProgram;                  //Flag inidicating if ARB/NV vertex programs are supported
  bool   extensionGLSLObjects;                    //Flag inidicating if GLSL shader objects are supported
  
  InterceptPluginCallbacks *gliCallBacks;         //The callback interface into GLIntercept
  const GLCoreDriver       *GLV;                  //The core OpenGL driver
  
  GLdouble projMatrix[16];                        //The last projection matrix the points were rendered for
  GLdouble frustumPoints[8][4];                   //The points that make up the view frustum for the current projection matrix
  GLenum   setLogicOp;                            //The logic operation to set before rendering 

  GLhandle (GLAPIENTRY *iglGetHandle) (GLenum pname); //Get current GLSL object/program
  void     (GLAPIENTRY *iglUseProgramObject) (GLhandle program); //Use GLSL program

  //@
  //  Summary:
  //    To update the view frustum rendre points by retrieving the current
  //    projection matrix and un-projecting through it.
  //
  void UpdateFrustumPoints();

  //@
  //  Summary:
  //    To render the view frustum with lines. No states are changed.
  //
  void RenderFrustumLines();

  //@
  //  Summary:
  //    To render the view frustum with quads. No states are changed.
  //
  void RenderFrustumSolid();

};



#endif // __FC_VIEW_CAM_H_
