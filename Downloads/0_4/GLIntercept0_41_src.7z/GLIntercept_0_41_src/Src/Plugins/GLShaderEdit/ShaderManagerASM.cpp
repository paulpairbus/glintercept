/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "ShaderManagerASM.h"


USING_ERRORLOG


//Set the class name for the shader manager
char *ShaderManager<class ShaderDataASM>::className = "ShaderASM";

///////////////////////////////////////////////////////////////////////////////
//
ShaderDataASM::ShaderDataASM(uint glID):
ShaderType(glID),
glType(0)
{
}

///////////////////////////////////////////////////////////////////////////////
//
ShaderManagerASM::ShaderManagerASM()
{
  //Add a shader (the zero shader always exists)
  AddData(0);

}

///////////////////////////////////////////////////////////////////////////////
//
ShaderManagerASM::~ShaderManagerASM()
{
  //Remove the 0 shader
  ShaderManager<ShaderDataASM>::RemoveData(0);
}


///////////////////////////////////////////////////////////////////////////////
//
bool ShaderManagerASM::RemoveData(uint glId)
{
  //Never delete 0
  if(glId != 0)
  {
    return ShaderManager<ShaderDataASM>::RemoveData(glId);
  }

  return true;
}





