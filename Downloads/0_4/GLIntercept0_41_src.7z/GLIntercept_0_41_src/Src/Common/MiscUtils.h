/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __MISC_UTILS_H__
#define __MISC_UTILS_H__

#include <string>
#include <vector>

using namespace std;

#if defined(_WIN32)
typedef   signed __int64  int64;
typedef unsigned __int64 uint64;
#endif
typedef unsigned int uint;

//Compile time Assert macro
#define	CASSERT(x,error) typedef char __CASSERT__##error[1]; typedef char __CASSERT__##error[(x)?1:2]

//@
//  Summary:
//    To write to the passed destination string using the passed "printf"
//    formatting and arguments. This method currently only allows resulting
//    strings of 1024 characters in length.
//  
//  Parameters:
//    dstString  - The string to store the passed formatting string and 
//                 arguments in.
//    
//    format     - The "printf" style formatting string. Following arguments
//                 are specified in this string
//
void StringPrintF(string &dstString, const char *format,...);

//@
//  Summary:
//    To get the activer thread ID.
// 
//  Returns:
//    The ID of the thread that called this function is returned.
//
int GetActiveThreadID();

//@
//  Summary:
//    Simple class to perform interval timing calculations.
//  
class TimeDiff
{
public:

  //@
  //  Summary:
  //    Constructor. Inits timing variables.
  // 
  TimeDiff();

  //@
  //  Summary:
  //    Destructor, shuts down the timer.
  // 
  virtual ~TimeDiff();

  //@
  //  Summary:
  //    Sets the initial start time of the timer. 
  // 
  void StartTimer();

  //@
  //  Summary:
  //    To get the number of microseconds that have elapsed since 
  //    that last call to StartTimer.
  // 
  //  Returns:
  //    The number of microseconds that have elapsed is returned.
  //    Zero is returned if the timer could not be init. 
  //    (or the interval was less than 1 microsecond)
  //
  uint GetTimeDiff();

private:
  int64 frequency;     //The frequency og the timer
  int64 startTime;     //The start time of the timer
};



#endif //__MISC_UTILS_H__
