/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "FunctionTable.h"

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
FunctionTable::FunctionTable()
{
  //Reserve a big table
  functionTable.reserve(300);
}

///////////////////////////////////////////////////////////////////////////////
//
FunctionTable::~FunctionTable()
{

}


///////////////////////////////////////////////////////////////////////////////
//
int FunctionTable::AddFunction(const string &name, void * function)
{
  //Create a new class to add
  FunctionData newData;

  //Attempt to find if it is a known function (use iterators for more speed)
  bool found=false;
  for(uint i=0;i<knownFunctionTable.size();i++)
  {
    //Check for a name match
    if(knownFunctionTable[i].functionName == name)
    {
      newData = knownFunctionTable[i];
      found=true;
      break;
    }
  }

  //If not found, log an error (All functions should have at least void as a paremeter)
  if(!found || newData.parameterArray.size() == 0)
  {
    LOGERR(("Diagnostic: Unknown function %s being logged.",name.c_str()));
  }

  //Assign the name and the function pointer
  newData.functionName = name;
  newData.functionPtr  = function;

  //Add it to the table
  functionTable.push_back(newData);

  return functionTable.size()-1;
}

///////////////////////////////////////////////////////////////////////////////
//
int FunctionTable::FindFunction(const string & name) const
{

  //Loop and find the function name (should use iterators this could be slow)
  for(uint i=0;i<functionTable.size();i++)
  {
    //Check for a name match
    if(functionTable[i].functionName == name)
    {
      return i;
    }
  }

  return -1;
}

///////////////////////////////////////////////////////////////////////////////
//
void FunctionTable::InitKnownFunctionTable(const FunctionDataArray & knownFunc,const EnumDataArray & enumData)
{
  uint i,i2,i3;

  //There should not be any existing known functions
  if(knownFunctionTable.size() > 0 || enumDataArray.size() >0)
  {
    LOGERR(("FunctionTable::InitKnownFunctionTable - Emptying existing known functions. Error?"));
  }

  //Empty all arrays
  knownFunctionTable.clear();
  enumDataArray.clear();

  //Loop and add all functions
  for(i=0;i<knownFunc.size();i++)
  {
    string s=knownFunc[i].functionName;
    knownFunctionTable.push_back(knownFunc[i]);
  }

  //Loop and add all enums
  for(i=0;i<enumData.size();i++)
  {
    enumDataArray.push_back(enumData[i]);
  }


  //Link up the enums with the parameters
  for(i=0;i<knownFunctionTable.size();i++)
  {
    //Loop for all parameters (plus the return type)
    for(i2=0;i2<knownFunctionTable[i].parameterArray.size()+1;i2++)
    {
      ParameterData * paramData;
      
      //Assign either a parameter or the return type
      if(i2 <knownFunctionTable[i].parameterArray.size())
      {
        paramData = &knownFunctionTable[i].parameterArray[i2];
      }
      else
      {
        paramData = &knownFunctionTable[i].returnType;
      }
      
      //Init the index
      paramData->index = -1;

      //If the parameter is a named enum, attempt to link up
      if((paramData->type == PT_enum || paramData->type == PT_bitfield) && paramData->typeName != "")
      {
        //Loop for all the enums
        for(i3=0;i3<enumData.size();i3++)
        {
           //If the enum matches, assign and break
           if(enumData[i3].GetName() == paramData->typeName)
           {
             //Assign the lookup index
             paramData->index = i3;
             break;
           }
        }

        //Log a warning if not found
        if(paramData->index == -1)
        {
          LOGERR(("FunctionTable::InitKnownFunctionTable - Enum %s not found",paramData->typeName.c_str()));
        }
      }
    }
  }

  //Assign any existing functions the new data
  for(i=0;i<knownFunctionTable.size();i++)
  {
    //Find the name
    int findIndex=FindFunction(knownFunctionTable[i].functionName);

    //Check for a match
    if(findIndex != -1)
    {
      //Save the pointer
      void * savePtr = functionTable[findIndex].functionPtr;

      //Save the flags (bitwise or with existing flags)
      knownFunctionTable[i].functionFlags |= functionTable[findIndex].functionFlags;

      //Copy the data
      functionTable[findIndex] = knownFunctionTable[i];

      //Re-assign the pointer
      functionTable[findIndex].functionPtr = savePtr;
    }
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void FunctionTable::SetFunctionFlag(const string & name, uint flag)
{

  //Set the flag in both the known and working function arrays

  //Attempt to find the flag 
  int funcIndex = FindFunction(name);

  //If a valid function was found - assign the flag
  if(funcIndex != -1)
  {
    functionTable[funcIndex].functionFlags |= flag;
  }

  //Attempt to find the function in the known function table
  bool found=false;
  for(uint i=0;i<knownFunctionTable.size();i++)
  {
    //Check for a name match
    if(knownFunctionTable[i].functionName == name)
    {
      //Assign the flags
      knownFunctionTable[i].functionFlags |= flag;
      found=true;
      break;
    }
  }

  //If not found, create
  if(!found)
  {
    //If the function was valid (but not known), just add it to the table
    if(funcIndex != -1)
    {
      knownFunctionTable.push_back(functionTable[funcIndex]);
    }
    else
    {
      FunctionData newData;
      newData.functionName  = name;
      newData.functionFlags = flag;

      //Add a new empty function with the name and flags
      knownFunctionTable.push_back(newData);
    }
  }

}