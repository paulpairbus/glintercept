/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "InterceptLogText.h"
#include "GLDriver.h"
#include <time.h>

USING_ERRORLOG

extern GLDriver glDriver;

///////////////////////////////////////////////////////////////////////////////
//
InterceptLogText::InterceptLogText(const string &fileName,FunctionTable * functionTable,const ConfigData &configData):
InterceptLog(functionTable),
logFileName(fileName),
logFile(NULL),
logFlush(configData.logFlush),
shaderRenderCallLog(configData.shaderRenderCallStateLog),
imageRenderCallLog(configData.imageRenderCallStateLog),
functionTimerEnabled(configData.timerLogEnabled),
functionTimerCutOff(configData.timerLogCutOff)
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool InterceptLogText::Init()
{
  //Write the log header
  struct tm *newtime;
  time_t     aclock;

  //Attempt to open the file
  logFile = fopen(logFileName.c_str(),"wt");

  //Prevent NULL file settings
  if(logFile == NULL)
  {
    LOGERR(("InterceptLog - Unable to open log file %s",logFileName.c_str()));
    return false;
  }

  //Get the current time
  time( &aclock );

  //Convert it
  newtime = localtime( &aclock );

  fprintf(logFile,
    "===============================================================================\n"
    " GLIntercept version %s Log generated on: %s \n"
    "===============================================================================\n",__GLI_BUILD_VER_STR,asctime(newtime));


  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
InterceptLogText::~InterceptLogText()
{
  //Close the log file
  if(logFile)
  {
    fclose(logFile);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogText::LogFunctionPre(const FunctionData *funcData,uint index, va_list args)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogText::LogFunctionPre - Function data for index %d is NULL",index)); 
    return;
  }

  //Save the args pointer
  va_list oldArgs = args;

  //Start the function on a newline
  fprintf(logFile,"\n");

  //Loop for the function call depth to flag sub-function calls
  for(uint i=0;i<glDriver.GetFunctionCallDepth();i++)
  {
    fprintf(logFile,"----->");
  }

  //Get the function data and args and write it out
  string functionString;
  GetFunctionString(funcData,index,args,functionString);
  fprintf(logFile,"%s",functionString.c_str());

  //Flush the log if necessary
  if(logFlush)
  {
    fflush(logFile);
  }

  //Reset the argument list
  va_end(args);

  //Flag to the driver if function timing is needed
  if(functionTimerEnabled) 
  {
    glDriver.SetFunctionTimer();
  }

  //If this is an rendering function (an there is a context)
  if(glDriver.GetCurrentContext() &&
     glDriver.GetCurrentContext()->IsRenderFuncion(funcData,index,oldArgs))
  {
    //If we log shaders on render calls, log them
    if(shaderRenderCallLog)
    {
      //Get the bound shaders
      uint vertexShader,fragmentShader;
      GLhandle programGLSL;
      glDriver.GetCurrentContext()->GetBoundShaders(vertexShader,fragmentShader,programGLSL);

      //If a valid vertex shader, log it
      if(vertexShader != 0)
      {
        fprintf(logFile," VP=%u ",vertexShader);
      }

      if(fragmentShader != 0)
      {
        fprintf(logFile," FP=%u ",fragmentShader);
      }
      
      if(programGLSL != 0)
      {
        fprintf(logFile," GLSL=%u ",programGLSL);
      }
    }

    //If we log images on render calls, log them
    if(imageRenderCallLog)
    {
      //Get the bound textures
      BoundTextureArray boundTextures;
      glDriver.GetCurrentContext()->GetBoundTextures(boundTextures);

      //If there are any textures
      if(boundTextures.size() > 0)
      {
        fprintf(logFile," Textures[ ");
        
        //Loop for all textures and log the stage and texture number
        for(uint i=0;i<boundTextures.size();i++)
        {
          fprintf(logFile,"(%u,%u) ",boundTextures[i].texStage,boundTextures[i].texID);
        }

        fprintf(logFile,"] ");
      }
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogText::LogFunctionPost(const FunctionData *funcData,uint index, void * retVal)
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Check the function data
  if(!funcData)
  {
    LOGERR(("InterceptLogText::LogFunctionPost - Function data for index %d is NULL",index)); 
    return;
  }

  //Get the return parameter
  const ParameterData * returnData = &funcData->returnType;

  //Determine if we are processing pointers
  bool isPointer=false;
  if(returnData->pointerCount > 0 || returnData->length != -1)
  {
    isPointer=true;
  }

  //Check the return value
  if(isPointer ||
     returnData->type != PT_void)
  {
    if(retVal != NULL)
    {
      //Look up the data
      string out = ConvertParam(retVal, isPointer, returnData);

      //Log the result
      fprintf(logFile,"=%s ",out.c_str());
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogText::LogFunctionError(uint errorCode)
{
  //If the log is not writing or the error code is 0, return
  if(!logEnabled || errorCode == 0x0)
  {
    return;
  }

  //Log that an error has occured
  fprintf(logFile," glGetError() =");

  //Get the error string
  string errorString;
  GetErrorStringValue(errorCode,errorString);

  //Print the error value out to the log
  fprintf(logFile,"%s",errorString.c_str());

}

///////////////////////////////////////////////////////////////////////////////
//
void InterceptLogText::LogFunctionComplete()
{
  //If the log is not writing, return
  if(!logEnabled)
  {
    return;
  }

  //Test if we log function timer values
  if(functionTimerEnabled)
  {
    //Get the function time
    uint funcTime = glDriver.GetFunctionTime();
    if(funcTime >= functionTimerCutOff)
    {
      //Print the function time if it is greater than the cutoff
      fprintf(logFile," Time= %uus",funcTime);
    }
  }
}







