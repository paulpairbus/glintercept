/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "InterceptImage.h"
#include "GLDriver.h"


USING_ERRORLOG

//Set the class name for the image manager
char *InterceptDataManager<class ImageData>::className = "Image";


///////////////////////////////////////////////////////////////////////////////
//
ImageData::ImageData(uint glID):
InterceptDataType(glID),
glType(0),
sizeEstimate(0),
pBufferBound(false),
pBufferHandle(NULL),
pBufferBufType(0)
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool ImageData::GetUniqueFileName(string &retString) const
{
  //Set the initial image name
  retString = "Image_";

  //Append the image type
  switch(glType)
  {
    case(GL_TEXTURE_1D):
      retString = retString + "1D_";
      break;
    case(GL_TEXTURE_2D):
      retString = retString + "2D_";
      break;
    case(GL_TEXTURE_3D):
      retString = retString + "3D_";
      break;
    case(GL_TEXTURE_CUBE_MAP):
      retString = retString + "CUBE_";
      break;
    case(GL_TEXTURE_RECTANGLE_NV):
      retString = retString + "NVRECT_";
      break;
    default:
      retString = retString + "UNKNOWN_";
      break;
  }

  //Add an extra flag for p-buffers
  if(IsPBufferBound())
  {
    retString = retString + "PBuf_";
  }

  //Add the texture ID
  string bufString;
  StringPrintF(bufString,"%04u_",id);
  retString = retString + bufString;
  
  //Add the save count
  static uint saveCount=0;
  saveCount++;
  StringPrintF(bufString,"%04u",saveCount);
  retString = retString + bufString;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
ImageManager::ImageManager()
{

  //Add a texture image (the zero image always exists)
  AddData(0);
}

///////////////////////////////////////////////////////////////////////////////
//
ImageManager::~ImageManager()
{

  //Remove the 0 texture image
  InterceptDataManager<ImageData>::RemoveData(0);
}


///////////////////////////////////////////////////////////////////////////////
//
void ImageManager::GetPBufferImages(HPBUFFERARB handle,vector<ImageData *> &pBufferImages)
{
  //Empty the array
  pBufferImages.clear();

  //Loop for all images
  for(DataArrayType::iterator i=dataArray.begin(); i!=dataArray.end(); ++i)
  {
    //If the image is ready and a p-buffer, save it
    if(i->second.IsReady() &&
       i->second.IsPBufferBound() && i->second.GetPBufferHandle() == handle)
    { 
      //Add the image to the return array
      pBufferImages.push_back(&(i->second));
    }
  }
}


///////////////////////////////////////////////////////////////////////////////
//
bool ImageManager::RemoveData(uint glId)
{
  //Never delete 0
  if(glId != 0)
  {
    return InterceptDataManager<ImageData>::RemoveData(glId);
  }

  return true;
}

