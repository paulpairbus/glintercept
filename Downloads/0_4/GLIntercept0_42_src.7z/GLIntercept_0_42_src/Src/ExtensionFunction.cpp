/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "ExtensionFunction.h"
#include "GLDriver.h"

//The driver to log calls by
extern GLDriver glDriver;

USING_ERRORLOG

//NOTE: This implementation is OS/Platform spacific 
#include "ExtensionFunctionStubs.cpp"

void * extFunctions[MAX_WRAPPER_FUNCTIONS];
uint   wrapperIndex[MAX_WRAPPER_FUNCTIONS];

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::ExtensionFunction(FunctionTable * functionTable):
currExtensionIndex(0),
functionTable(functionTable)
{

}

///////////////////////////////////////////////////////////////////////////////
//
ExtensionFunction::~ExtensionFunction()
{

}

///////////////////////////////////////////////////////////////////////////////
//
void * ExtensionFunction::AddFunction(const string & funcName,void * functionPtr)
{

  //Check for an existing function of that name
  int funcIndex = functionTable->FindFunction(funcName);
  if(funcIndex != -1)
  {
    //Check if the function matches (sanity check mostly for MS Windows)
    for(uint i=0; i<currExtensionIndex; i++)
    {
      //If the index is found (it does not have to be found in the case of built-in functions)
      if(wrapperIndex[i] == funcIndex)
      {
        //Test that the passed function pointer matches the old pointer
        if(extFunctions[i] != functionPtr)
        {
          LOGERR(("ExtensionFunction::AddFunction - Function %s does not match previous lookup (multiple OpenGL devices?)",funcName.c_str()));

          //Just return the "new" pointer
          return functionPtr;
        }

        break;
      }
    }

    //Get the function pointer to return
    return functionTable->GetFunctionData(funcIndex)->functionPtr;
  }

  //Catch bad function lookups 
  if(functionPtr == NULL)
  {
    return NULL;
  }

  //Check if we can add another extension function
  if(currExtensionIndex >= MAX_WRAPPER_FUNCTIONS)
  {
    //LOG an error
    LOGERR(("ExtensionFunction::AddFunction -Unable to log function %s exceeded %u num of wrapper functions",funcName.c_str(),MAX_WRAPPER_FUNCTIONS));

    //Else just return the pointer
    return functionPtr;
  }

  //Get the next available wrapper
  void *retPtr = wrapperFunctions[currExtensionIndex];

  //Add the data to the table and get the index
  funcIndex = functionTable->AddFunction(funcName,retPtr);

  //Assign the index to the lookup table
  wrapperIndex[currExtensionIndex] = funcIndex;
  extFunctions[currExtensionIndex] = functionPtr;

  //Increment the wrapper counter
  currExtensionIndex++;

  //Return the wrapper pointer
  return retPtr;
}








