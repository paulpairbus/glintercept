/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  Parts of this file may be derived from GLTrace version 2.3
  by Phil Frisbie, Jr. (phil@hawksoft.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "GLCore1_1.h"

#include "BuiltInFunction.h"

//
// Core OpenGL 1.1 function handlers
//
USING_ERRORLOG

//The driver to log calls by
extern GLDriver glDriver;

//A dummy value to pass to the logger
int glcDummyValue=0xBAADF00D;

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glAccum (GLenum op, GLfloat value)
{
  PRE_FUNCTION(glAccum,op);
  GLV.glAccum (op,value);
  POST_FUNCTION
}


///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glAlphaFunc (GLenum func, GLclampf ref)
{
  PRE_FUNCTION(glAlphaFunc,func);
  GLV.glAlphaFunc (func, ref);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY glAreTexturesResident (GLsizei n, const GLuint *textures, GLboolean *residences)
{
  PRE_FUNCTION(glAreTexturesResident,n);
  GLboolean retValue = GLV.glAreTexturesResident(n,textures,residences);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glArrayElement (GLint i)
{
  PRE_FUNCTION(glArrayElement,i);
  GLV.glArrayElement (i);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glBegin (GLenum mode)
{
  PRE_FUNCTION(glBegin,mode);

  //Test for existing glBegin mode
  if(glDriver.GetBeginEndState())
  {
    LOGERR(("glBegin called while previous glBegin was not closed"));
  }
  else
  {
    //Flag that we are now in a Begin/End section
    glDriver.SetBeginEndState(true);
  }

  GLV.glBegin (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glBindTexture (GLenum target, GLuint texture)
{
  PRE_FUNCTION(glBindTexture,target);
  GLV.glBindTexture (target, texture);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glBitmap (GLsizei width, GLsizei height, GLfloat xorig, GLfloat yorig, GLfloat xmove, GLfloat ymove, const GLubyte *bitmap)
{
  PRE_FUNCTION(glBitmap,width);
  GLV.glBitmap (width, height, xorig, yorig, xmove, ymove, bitmap);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glBlendFunc (GLenum sfactor, GLenum dfactor)
{
  PRE_FUNCTION(glBlendFunc,sfactor);
  GLV.glBlendFunc (sfactor, dfactor);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCallList (GLuint list)
{
  PRE_FUNCTION(glCallList,list);
  GLV.glCallList (list);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCallLists (GLsizei n, GLenum type, const GLvoid *lists)
{
  PRE_FUNCTION(glCallLists,n);
  GLV.glCallLists (n, type, lists);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClear (GLbitfield mask)
{
  PRE_FUNCTION(glClear,mask);
  GLV.glClear (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClearAccum (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
  PRE_FUNCTION(glClearAccum,red);
  GLV.glClearAccum (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClearColor (GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
{
  PRE_FUNCTION(glClearColor,red);
  GLV.glClearColor (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClearDepth (GLclampd depth)
{
  PRE_FUNCTION(glClearDepth,depth);
  GLV.glClearDepth (depth);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClearIndex (GLfloat c)
{
  PRE_FUNCTION(glClearIndex,c);
  GLV.glClearIndex (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClearStencil (GLint s)
{
  PRE_FUNCTION(glClearStencil,s);
  GLV.glClearStencil (s);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glClipPlane (GLenum plane, const GLdouble *equation)
{
  PRE_FUNCTION(glClipPlane,plane);
  GLV.glClipPlane (plane, equation);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3b (GLbyte red, GLbyte green, GLbyte blue)
{
  PRE_FUNCTION(glColor3b,red);
  GLV.glColor3b (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3bv (const GLbyte *v)
{
  PRE_FUNCTION(glColor3bv,v);
  GLV.glColor3bv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3d (GLdouble red, GLdouble green, GLdouble blue)
{
  PRE_FUNCTION(glColor3d,red);
  GLV.glColor3d (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3dv (const GLdouble *v)
{
  PRE_FUNCTION(glColor3dv,v);
  GLV.glColor3dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3f (GLfloat red, GLfloat green, GLfloat blue)
{
  PRE_FUNCTION(glColor3f,red);
  GLV.glColor3f (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3fv (const GLfloat *v)
{
  PRE_FUNCTION(glColor3fv,v);
  GLV.glColor3fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3i (GLint red, GLint green, GLint blue)
{
  PRE_FUNCTION(glColor3i,red);
  GLV.glColor3i (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3iv (const GLint *v)
{
  PRE_FUNCTION(glColor3iv,v);
  GLV.glColor3iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3s (GLshort red, GLshort green, GLshort blue)
{
  PRE_FUNCTION(glColor3s,red);
  GLV.glColor3s (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3sv (const GLshort *v)
{
  PRE_FUNCTION(glColor3sv,v);
  GLV.glColor3sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3ub (GLubyte red, GLubyte green, GLubyte blue)
{
  PRE_FUNCTION(glColor3ub,red);
  GLV.glColor3ub (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3ubv (const GLubyte *v)
{
  PRE_FUNCTION(glColor3ubv,v);
  GLV.glColor3ubv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3ui (GLuint red, GLuint green, GLuint blue)
{
  PRE_FUNCTION(glColor3ui,red);
  GLV.glColor3ui (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3uiv (const GLuint *v)
{
  PRE_FUNCTION(glColor3uiv,v);
  GLV.glColor3uiv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3us (GLushort red, GLushort green, GLushort blue)
{
  PRE_FUNCTION(glColor3us,red);
  GLV.glColor3us (red, green, blue);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor3usv (const GLushort *v)
{
  PRE_FUNCTION(glColor3usv,v);
  GLV.glColor3usv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4b (GLbyte red, GLbyte green, GLbyte blue, GLbyte alpha)
{
  PRE_FUNCTION(glColor4b,red);
  GLV.glColor4b (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4bv (const GLbyte *v)
{
  PRE_FUNCTION(glColor4bv,v);
  GLV.glColor4bv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4d (GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha)
{
  PRE_FUNCTION(glColor4d,(builtIn.GetFunctionIndex(),red, green, blue, alpha));
  GLV.glColor4d (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4dv (const GLdouble *v)
{
  PRE_FUNCTION(glColor4dv,v);
  GLV.glColor4dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4f (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
  PRE_FUNCTION(glColor4f,red);
  GLV.glColor4f (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4fv (const GLfloat *v)
{
  PRE_FUNCTION(glColor4fv,v);
  GLV.glColor4fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4i (GLint red, GLint green, GLint blue, GLint alpha)
{
  PRE_FUNCTION(glColor4i,red);
  GLV.glColor4i (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4iv (const GLint *v)
{                  
  PRE_FUNCTION(glColor4iv,v);
  GLV.glColor4iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4s (GLshort red, GLshort green, GLshort blue, GLshort alpha)
{
  PRE_FUNCTION(glColor4s,red);
  GLV.glColor4s (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4sv (const GLshort *v)
{
  PRE_FUNCTION(glColor4sv,v);
  GLV.glColor4sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4ub (GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha)
{
  PRE_FUNCTION(glColor4ub,red);
  GLV.glColor4ub (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4ubv (const GLubyte *v)
{
  PRE_FUNCTION(glColor4ubv,v);
  GLV.glColor4ubv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4ui (GLuint red, GLuint green, GLuint blue, GLuint alpha)
{
  PRE_FUNCTION(glColor4ui,red);
  GLV.glColor4ui (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4uiv (const GLuint *v)
{
  PRE_FUNCTION(glColor4uiv,v);
  GLV.glColor4uiv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4us (GLushort red, GLushort green, GLushort blue, GLushort alpha)
{
  PRE_FUNCTION(glColor4us,red);
  GLV.glColor4us (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColor4usv (const GLushort *v)
{
  PRE_FUNCTION(glColor4usv,v);
  GLV.glColor4usv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha)
{
  PRE_FUNCTION(glColorMask,red);
  GLV.glColorMask (red, green, blue, alpha);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColorMaterial (GLenum face, GLenum mode)
{
  PRE_FUNCTION(glColorMaterial,face);
  GLV.glColorMaterial (face, mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glColorPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glColorPointer,size);
  GLV.glColorPointer (size, type, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCopyPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum type)
{
  PRE_FUNCTION(glCopyPixels,x);
  GLV.glCopyPixels (x, y, width, height, type);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCopyTexImage1D (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border)
{
  PRE_FUNCTION(glCopyTexImage1D,target);
  GLV.glCopyTexImage1D (target, level, internalFormat, x, y, width, border);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCopyTexImage2D (GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border)
{
  PRE_FUNCTION(glCopyTexImage2D,target);
  GLV.glCopyTexImage2D (target, level, internalFormat, x, y, width, height, border);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width)
{
  PRE_FUNCTION(glCopyTexSubImage1D,target);
  GLV.glCopyTexSubImage1D (target, level, xoffset, x, y, width);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height)
{
  PRE_FUNCTION(glCopyTexSubImage2D,target);
  GLV.glCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glCullFace (GLenum mode)
{
  PRE_FUNCTION(glCullFace,mode);
  GLV.glCullFace (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDeleteLists (GLuint list, GLsizei range)
{
  PRE_FUNCTION(glDeleteLists,list);
  GLV.glDeleteLists (list, range);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDeleteTextures (GLsizei n, const GLuint *textures)
{
  PRE_FUNCTION(glDeleteTextures,n);
  GLV.glDeleteTextures (n, textures);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDepthFunc (GLenum func)
{
  PRE_FUNCTION(glDepthFunc,func);
  GLV.glDepthFunc (func);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDepthMask (GLboolean flag)
{
  PRE_FUNCTION(glDepthMask,flag);
  GLV.glDepthMask (flag);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDepthRange (GLclampd zNear, GLclampd zFar)
{
  PRE_FUNCTION(glDepthRange,zNear);
  GLV.glDepthRange (zNear, zFar);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDisable (GLenum cap)
{
  PRE_FUNCTION(glDisable,cap);
  GLV.glDisable (cap);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDisableClientState (GLenum array)
{
  PRE_FUNCTION(glDisableClientState,array);
  GLV.glDisableClientState (array);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDrawArrays (GLenum mode, GLint first, GLsizei count)
{
  PRE_FUNCTION(glDrawArrays,mode);
  GLV.glDrawArrays (mode, first, count);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDrawBuffer (GLenum mode)
{
  PRE_FUNCTION(glDrawBuffer,mode);
  GLV.glDrawBuffer (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDrawElements (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices)
{
  PRE_FUNCTION(glDrawElements,mode);
  GLV.glDrawElements (mode, count, type, indices);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glDrawPixels (GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
  PRE_FUNCTION(glDrawPixels,width);
  GLV.glDrawPixels (width, height, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEdgeFlag (GLboolean flag)
{
  PRE_FUNCTION(glEdgeFlag,flag);
  GLV.glEdgeFlag (flag);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEdgeFlagPointer (GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glEdgeFlagPointer,stride);
  GLV.glEdgeFlagPointer (stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEdgeFlagv (const GLboolean *flag)
{
  PRE_FUNCTION(glEdgeFlagv,flag);
  GLV.glEdgeFlagv (flag);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEnable (GLenum cap)
{
  PRE_FUNCTION(glEnable,cap);
  GLV.glEnable (cap);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEnableClientState (GLenum array)
{
  PRE_FUNCTION(glEnableClientState,array);
  GLV.glEnableClientState (array);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEnd ()
{

  PRE_FUNCTION(glEnd,glcDummyValue);
  GLV.glEnd();

  //Test for existing glBegin mode
  if(!glDriver.GetBeginEndState())
  {
    LOGERR(("glEnd called whithout a glBegin"));
  }
  else
  {
    //Flag that we are out of the Begin/End section
    glDriver.SetBeginEndState(false);
  }


  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEndList ()
{
  PRE_FUNCTION(glEndList,glcDummyValue);
  GLV.glEndList();

  //Test for existing glNewList mode
  if(!glDriver.GetNewListState())
  {
    LOGERR(("glEndList called whithout a glNewList"));
  }
  else
  {
    //Flag that we are out of the glNewList/glEndList section
    glDriver.SetNewListState(false);
  }

  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord1d (GLdouble u)
{
  PRE_FUNCTION(glEvalCoord1d,u);
  GLV.glEvalCoord1d (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord1dv (const GLdouble *u)
{
  PRE_FUNCTION(glEvalCoord1dv,u);
  GLV.glEvalCoord1dv (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord1f (GLfloat u)
{
  PRE_FUNCTION(glEvalCoord1f,u);
  GLV.glEvalCoord1f (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord1fv (const GLfloat *u)
{
  PRE_FUNCTION(glEvalCoord1fv,u);
  GLV.glEvalCoord1fv (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord2d (GLdouble u, GLdouble v)
{
  PRE_FUNCTION(glEvalCoord2d,u);
  GLV.glEvalCoord2d (u,v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord2dv (const GLdouble *u)
{
  PRE_FUNCTION(glEvalCoord2dv,u);
  GLV.glEvalCoord2dv (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord2f (GLfloat u, GLfloat v)
{
  PRE_FUNCTION(glEvalCoord2f,u);
  GLV.glEvalCoord2f (u,v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalCoord2fv (const GLfloat *u)
{
  PRE_FUNCTION(glEvalCoord2fv,u);
  GLV.glEvalCoord2fv (u);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalMesh1 (GLenum mode, GLint i1, GLint i2)
{
  PRE_FUNCTION(glEvalMesh1,mode);
  GLV.glEvalMesh1 (mode, i1, i2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalMesh2 (GLenum mode, GLint i1, GLint i2, GLint j1, GLint j2)
{
  PRE_FUNCTION(glEvalMesh2,mode);
  GLV.glEvalMesh2 (mode, i1, i2, j1, j2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalPoint1 (GLint i)
{
  PRE_FUNCTION(glEvalPoint1,i);
  GLV.glEvalPoint1 (i);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glEvalPoint2 (GLint i, GLint j)
{
  PRE_FUNCTION(glEvalPoint2,i);
  GLV.glEvalPoint2 (i, j);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFeedbackBuffer (GLsizei size, GLenum type, GLfloat *buffer)
{
  PRE_FUNCTION(glFeedbackBuffer,size);
  GLV.glFeedbackBuffer (size, type, buffer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFinish ()
{
  PRE_FUNCTION(glFinish,glcDummyValue);
  GLV.glFinish();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFlush ()
{
  PRE_FUNCTION(glFlush,glcDummyValue);
  GLV.glFlush();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFogf (GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glFogf,pname);
  GLV.glFogf (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFogfv (GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glFogfv,pname);
  GLV.glFogfv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFogi (GLenum pname, GLint param)
{
  PRE_FUNCTION(glFogi,pname);
  GLV.glFogi (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFogiv (GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glFogiv,pname);
  GLV.glFogiv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFrontFace (GLenum mode)
{
  PRE_FUNCTION(glFrontFace,mode);
  GLV.glFrontFace (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glFrustum (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar)
{
  PRE_FUNCTION(glFrustum,left);
  GLV.glFrustum (left, right, bottom, top, zNear, zFar);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
GLuint GLAPIENTRY glGenLists (GLsizei range)
{
  PRE_FUNCTION(glGenLists,range);
  GLuint retValue = GLV.glGenLists(range);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGenTextures (GLsizei n, GLuint *textures)
{
  PRE_FUNCTION(glGenTextures,n);
  GLV.glGenTextures (n, textures);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetBooleanv (GLenum pname, GLboolean *params)
{
  PRE_FUNCTION(glGetBooleanv,pname);
  GLV.glGetBooleanv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetClipPlane (GLenum plane, GLdouble *equation)
{
  PRE_FUNCTION(glGetClipPlane,plane);
  GLV.glGetClipPlane (plane, equation);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetDoublev (GLenum pname, GLdouble *params)
{
  PRE_FUNCTION(glGetDoublev,pname);
  GLV.glGetDoublev (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
GLenum GLAPIENTRY glGetError ()
{
  PRE_FUNCTION(glGetError,glcDummyValue);
  
  //Get the cached value from the driver
  GLenum retValue = glDriver.GetCachedErrorCode();

  //If the cached value is "no-error" call and return the correct error
  if(retValue == GL_NO_ERROR)
  {
    retValue = GLV.glGetError();
  }
  else
  {
    //Reset the cached error code (so further calls do not get the same error)
    glDriver.ResetCachedErrorCode();
  }
  
  POST_FUNCTION_RET(retValue)

  return retValue;
}

//Register glGetError forceably (will mean it is registered twice)
static BuiltInFunction glErrorBuiltIn("glGetError",glGetError);

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetFloatv (GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetFloatv,pname);
  GLV.glGetFloatv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetIntegerv (GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetIntegerv,pname);
  GLV.glGetIntegerv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetLightfv (GLenum light, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetLightfv,light);
  GLV.glGetLightfv (light, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetLightiv (GLenum light, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetLightiv,light);
  GLV.glGetLightiv (light, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetMapdv (GLenum target, GLenum query, GLdouble *v)
{
  PRE_FUNCTION(glGetMapdv,target);
  GLV.glGetMapdv (target, query, v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetMapfv (GLenum target, GLenum query, GLfloat *v)
{
  PRE_FUNCTION(glGetMapfv,target);
  GLV.glGetMapfv (target, query, v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetMapiv (GLenum target, GLenum query, GLint *v)
{
  PRE_FUNCTION(glGetMapiv,target);
  GLV.glGetMapiv (target, query, v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetMaterialfv (GLenum face, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetMaterialfv,face);
  GLV.glGetMaterialfv (face, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetMaterialiv (GLenum face, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetMaterialiv,face);
  GLV.glGetMaterialiv (face, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetPixelMapfv (GLenum map, GLfloat *values)
{
  PRE_FUNCTION(glGetPixelMapfv,map);
  GLV.glGetPixelMapfv (map, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetPixelMapuiv (GLenum map, GLuint *values)
{
  PRE_FUNCTION(glGetPixelMapuiv,map);
  GLV.glGetPixelMapuiv (map, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetPixelMapusv (GLenum map, GLushort *values)
{
  PRE_FUNCTION(glGetPixelMapusv,map);
  GLV.glGetPixelMapusv (map, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetPointerv (GLenum pname, GLvoid* *params)
{
  PRE_FUNCTION(glGetPointerv,pname);
  GLV.glGetPointerv (pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetPolygonStipple (GLubyte *mask)
{
  PRE_FUNCTION(glGetPolygonStipple,mask);
  GLV.glGetPolygonStipple (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
const GLubyte* GLAPIENTRY glGetString (GLenum name)
{
  PRE_FUNCTION(glGetString,name);
  const GLubyte* retValue = GLV.glGetString(name);
  POST_FUNCTION_RET(retValue);

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexEnvfv (GLenum target, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetTexEnvfv,target);
  GLV.glGetTexEnvfv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexEnviv (GLenum target, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetTexEnviv,target);
  GLV.glGetTexEnviv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexGendv (GLenum coord, GLenum pname, GLdouble *params)
{
  PRE_FUNCTION(glGetTexGendv,coord);
  GLV.glGetTexGendv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexGenfv (GLenum coord, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetTexGenfv,coord);
  GLV.glGetTexGenfv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexGeniv (GLenum coord, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetTexGeniv,coord);
  GLV.glGetTexGeniv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, GLvoid *pixels)
{
  PRE_FUNCTION(glGetTexImage,target);
  GLV.glGetTexImage (target, level, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetTexLevelParameterfv,target);
  GLV.glGetTexLevelParameterfv (target, level, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetTexLevelParameteriv,target);
  GLV.glGetTexLevelParameteriv (target, level, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params)
{
  PRE_FUNCTION(glGetTexParameterfv,target);
  GLV.glGetTexParameterfv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glGetTexParameteriv (GLenum target, GLenum pname, GLint *params)
{
  PRE_FUNCTION(glGetTexParameteriv,target);
  GLV.glGetTexParameteriv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glHint (GLenum target, GLenum mode)
{
  PRE_FUNCTION(glHint,target);
  GLV.glHint (target, mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexMask (GLuint mask)
{
  PRE_FUNCTION(glIndexMask,mask);
  GLV.glIndexMask (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexPointer (GLenum type, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glIndexPointer,type);
  GLV.glIndexPointer (type, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexd (GLdouble c)
{
  PRE_FUNCTION(glIndexd,c);
  GLV.glIndexd (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexdv (const GLdouble *c)
{
  PRE_FUNCTION(glIndexdv,c);
  GLV.glIndexdv (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexf (GLfloat c)
{
  PRE_FUNCTION(glIndexf,c);
  GLV.glIndexf (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexfv (const GLfloat *c)
{
  PRE_FUNCTION(glIndexfv,c);
  GLV.glIndexfv (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexi (GLint c)
{
  PRE_FUNCTION(glIndexi,c);
  GLV.glIndexi (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexiv (const GLint *c)
{
  PRE_FUNCTION(glIndexiv,c);
  GLV.glIndexiv (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexs (GLshort c)
{
  PRE_FUNCTION(glIndexs,c);
  GLV.glIndexs (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexsv (const GLshort *c)
{
  PRE_FUNCTION(glIndexsv,c);
  GLV.glIndexsv (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexub (GLubyte c)
{
  PRE_FUNCTION(glIndexub,c);
  GLV.glIndexub (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glIndexubv (const GLubyte *c)
{
  PRE_FUNCTION(glIndexubv,c);
  GLV.glIndexubv (c);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glInitNames ()
{
  PRE_FUNCTION(glInitNames,glcDummyValue);
  GLV.glInitNames();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glInterleavedArrays (GLenum format, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glInterleavedArrays,format);
  GLV.glInterleavedArrays (format, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY glIsEnabled (GLenum cap)
{
  PRE_FUNCTION(glIsEnabled,cap);
  GLboolean retValue = GLV.glIsEnabled(cap);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY glIsList (GLuint list)
{
  PRE_FUNCTION(glIsList,list);
  GLboolean retValue = GLV.glIsList(list);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
GLboolean GLAPIENTRY glIsTexture (GLuint texture)
{
  PRE_FUNCTION(glIsTexture,texture);
  GLboolean retValue = GLV.glIsTexture(texture);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightModelf (GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glLightModelf,pname);
  GLV.glLightModelf (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightModelfv (GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glLightModelfv,pname);
  GLV.glLightModelfv (pname,params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightModeli (GLenum pname, GLint param)
{
  PRE_FUNCTION(glLightModeli,pname);
  GLV.glLightModeli (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightModeliv (GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glLightModeliv,pname);
  GLV.glLightModeliv (pname,params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightf (GLenum light, GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glLightf,light);
  GLV.glLightf (light, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightfv (GLenum light, GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glLightfv,light);
  GLV.glLightfv (light, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLighti (GLenum light, GLenum pname, GLint param)
{
  PRE_FUNCTION(glLighti,light);
  GLV.glLighti (light, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLightiv (GLenum light, GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glLightiv,light);
  GLV.glLightiv (light, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLineStipple (GLint factor, GLushort pattern)
{
  PRE_FUNCTION(glLineStipple,factor);
  GLV.glLineStipple (factor, pattern);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLineWidth (GLfloat width)
{
  PRE_FUNCTION(glLineWidth,width);
  GLV.glLineWidth (width);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glListBase (GLuint base)
{
  PRE_FUNCTION(glListBase,base);
  GLV.glListBase (base);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLoadIdentity ()
{
  PRE_FUNCTION(glLoadIdentity,glcDummyValue);
  GLV.glLoadIdentity();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLoadMatrixd (const GLdouble *m)
{
  PRE_FUNCTION(glLoadMatrixd,m);
  GLV.glLoadMatrixd(m);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLoadMatrixf (const GLfloat *m)
{
  PRE_FUNCTION(glLoadMatrixf,m);
  GLV.glLoadMatrixf (m);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLoadName (GLuint name)
{
  PRE_FUNCTION(glLoadName,name);
  GLV.glLoadName (name);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glLogicOp (GLenum opcode)
{
  PRE_FUNCTION(glLogicOp,opcode);
  GLV.glLogicOp (opcode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMap1d (GLenum target, GLdouble u1, GLdouble u2, GLint stride, GLint order, const GLdouble *points)
{
  PRE_FUNCTION(glMap1d,target);
  GLV.glMap1d (target, u1, u2, stride, order, points);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMap1f (GLenum target, GLfloat u1, GLfloat u2, GLint stride, GLint order, const GLfloat *points)
{
  PRE_FUNCTION(glMap1f,target);
  GLV.glMap1f (target, u1, u2, stride, order, points);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMap2d (GLenum target, GLdouble u1, GLdouble u2, GLint ustride, GLint uorder, GLdouble v1, GLdouble v2, GLint vstride, GLint vorder, const GLdouble *points)
{
  PRE_FUNCTION(glMap2d,target);
  GLV.glMap2d (target, u1, u2, ustride, uorder, v1, v2, vstride, vorder, points);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMap2f (GLenum target, GLfloat u1, GLfloat u2, GLint ustride, GLint uorder, GLfloat v1, GLfloat v2, GLint vstride, GLint vorder, const GLfloat *points)
{
  PRE_FUNCTION(glMap2f,target);
  GLV.glMap2f (target, u1, u2, ustride, uorder, v1, v2, vstride, vorder, points);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMapGrid1d (GLint un, GLdouble u1, GLdouble u2)
{
  PRE_FUNCTION(glMapGrid1d,un);
  GLV.glMapGrid1d (un, u1, u2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMapGrid1f (GLint un, GLfloat u1, GLfloat u2)
{
  PRE_FUNCTION(glMapGrid1f,un);
  GLV.glMapGrid1f (un, u1, u2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMapGrid2d (GLint un, GLdouble u1, GLdouble u2, GLint vn, GLdouble v1, GLdouble v2)
{
  PRE_FUNCTION(glMapGrid2d,un);
  GLV.glMapGrid2d (un, u1, u2, vn, v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMapGrid2f (GLint un, GLfloat u1, GLfloat u2, GLint vn, GLfloat v1, GLfloat v2)
{
  PRE_FUNCTION(glMapGrid2f,un);
  GLV.glMapGrid2f (un, u1, u2, vn, v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMaterialf (GLenum face, GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glMaterialf,face);
  GLV.glMaterialf (face, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMaterialfv (GLenum face, GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glMaterialfv,face);
  GLV.glMaterialfv (face, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMateriali (GLenum face, GLenum pname, GLint param)
{
  PRE_FUNCTION(glMateriali,face);
  GLV.glMateriali (face, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMaterialiv (GLenum face, GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glMaterialiv,face);
  GLV.glMaterialiv (face, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMatrixMode (GLenum mode)
{
  PRE_FUNCTION(glMatrixMode,mode);
  GLV.glMatrixMode (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMultMatrixd (const GLdouble *m)
{
  PRE_FUNCTION(glMultMatrixd,m);
  GLV.glMultMatrixd (m);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glMultMatrixf (const GLfloat *m)
{
  PRE_FUNCTION(glMultMatrixf,m);
  GLV.glMultMatrixf (m);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNewList (GLuint list, GLenum mode)
{
  PRE_FUNCTION(glNewList,list);

  //Test for existing glNewList mode
  if(glDriver.GetNewListState())
  {
    LOGERR(("glNewList called while previous glNewList was not closed"));
  }
  else
  {
    //Flag that we are now in a glNewList/glEndList section
    glDriver.SetNewListState(true);
  }

  GLV.glNewList (list,mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3b (GLbyte nx, GLbyte ny, GLbyte nz)
{
  PRE_FUNCTION(glNormal3b,nx);
  GLV.glNormal3b (nx, ny, nz);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3bv (const GLbyte *v)
{
  PRE_FUNCTION(glNormal3bv,v);
  GLV.glNormal3bv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3d (GLdouble nx, GLdouble ny, GLdouble nz)
{
  PRE_FUNCTION(glNormal3d,nx);
  GLV.glNormal3d (nx, ny, nz);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3dv (const GLdouble *v)
{
  PRE_FUNCTION(glNormal3dv,v);
  GLV.glNormal3dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3f (GLfloat nx, GLfloat ny, GLfloat nz)
{
  PRE_FUNCTION(glNormal3f,nx);
  GLV.glNormal3f (nx, ny, nz);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3fv (const GLfloat *v)
{
  PRE_FUNCTION(glNormal3fv,v);
  GLV.glNormal3fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3i (GLint nx, GLint ny, GLint nz)
{
  PRE_FUNCTION(glNormal3i,nx);
  GLV.glNormal3i (nx, ny, nz);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3iv (const GLint *v)
{
  PRE_FUNCTION(glNormal3iv,v);
  GLV.glNormal3iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3s (GLshort nx, GLshort ny, GLshort nz)
{
  PRE_FUNCTION(glNormal3s,nx);
  GLV.glNormal3s (nx, ny, nz);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormal3sv (const GLshort *v)
{
  PRE_FUNCTION(glNormal3sv,v);
  GLV.glNormal3sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glNormalPointer (GLenum type, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glNormalPointer,type);
  GLV.glNormalPointer (type, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glOrtho (GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar)
{
  PRE_FUNCTION(glOrtho,left);
  GLV.glOrtho (left, right, bottom, top, zNear, zFar);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPassThrough (GLfloat token)
{
  PRE_FUNCTION(glPassThrough,token);
  GLV.glPassThrough (token);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelMapfv (GLenum map, GLsizei mapsize, const GLfloat *values)
{
  PRE_FUNCTION(glPixelMapfv,map);
  GLV.glPixelMapfv (map, mapsize, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelMapuiv (GLenum map, GLsizei mapsize, const GLuint *values)
{
  PRE_FUNCTION(glPixelMapuiv,map);
  GLV.glPixelMapuiv (map, mapsize, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelMapusv (GLenum map, GLsizei mapsize, const GLushort *values)
{
  PRE_FUNCTION(glPixelMapusv,map);
  GLV.glPixelMapusv (map, mapsize, values);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelStoref (GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glPixelStoref,pname);
  GLV.glPixelStoref (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelStorei (GLenum pname, GLint param)
{
  PRE_FUNCTION(glPixelStorei,pname);
  GLV.glPixelStorei (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelTransferf (GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glPixelTransferf,pname);
  GLV.glPixelTransferf (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelTransferi (GLenum pname, GLint param)
{
  PRE_FUNCTION(glPixelTransferi,pname);
  GLV.glPixelTransferi (pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPixelZoom (GLfloat xfactor, GLfloat yfactor)
{
  PRE_FUNCTION(glPixelZoom,xfactor);
  GLV.glPixelZoom (xfactor, yfactor);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPointSize (GLfloat size)
{
  PRE_FUNCTION(glPointSize,size);
  GLV.glPointSize (size);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPolygonMode (GLenum face, GLenum mode)
{
  PRE_FUNCTION(glPolygonMode,face);
  GLV.glPolygonMode (face, mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPolygonOffset (GLfloat factor, GLfloat units)
{
  PRE_FUNCTION(glPolygonOffset,factor);
  GLV.glPolygonOffset (factor, units);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPolygonStipple (const GLubyte *mask)
{
  PRE_FUNCTION(glPolygonStipple,mask);
  GLV.glPolygonStipple (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPopAttrib ()
{
  PRE_FUNCTION(glPopAttrib,glcDummyValue);
  GLV.glPopAttrib();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPopClientAttrib ()
{
  PRE_FUNCTION(glPopClientAttrib,glcDummyValue);
  GLV.glPopClientAttrib();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPopMatrix ()
{
  PRE_FUNCTION(glPopMatrix,glcDummyValue);
  GLV.glPopMatrix();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPopName ()
{
  PRE_FUNCTION(glPopName,glcDummyValue);
  GLV.glPopName();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPrioritizeTextures (GLsizei n, const GLuint *textures, const GLclampf *priorities)
{
  PRE_FUNCTION(glPrioritizeTextures,n);
  GLV.glPrioritizeTextures (n, textures, priorities);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPushAttrib (GLbitfield mask)
{
  PRE_FUNCTION(glPushAttrib,mask);
  GLV.glPushAttrib (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPushClientAttrib (GLbitfield mask)
{
  PRE_FUNCTION(glPushClientAttrib,mask);
  GLV.glPushClientAttrib (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPushMatrix ()
{
  PRE_FUNCTION(glPushMatrix,glcDummyValue);
  GLV.glPushMatrix();
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glPushName (GLuint name)
{
  PRE_FUNCTION(glPushName,name);
  GLV.glPushName (name);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2d (GLdouble x, GLdouble y)
{
  PRE_FUNCTION(glRasterPos2d,x);
  GLV.glRasterPos2d (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2dv (const GLdouble *v)
{
  PRE_FUNCTION(glRasterPos2dv,v);
  GLV.glRasterPos2dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2f (GLfloat x, GLfloat y)
{
  PRE_FUNCTION(glRasterPos2f,x);
  GLV.glRasterPos2f (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2fv (const GLfloat *v)
{
  PRE_FUNCTION(glRasterPos2fv,v);
  GLV.glRasterPos2fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2i (GLint x, GLint y)
{
  PRE_FUNCTION(glRasterPos2i,x);
  GLV.glRasterPos2i (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2iv (const GLint *v)
{
  PRE_FUNCTION(glRasterPos2iv,v);
  GLV.glRasterPos2iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2s (GLshort x, GLshort y)
{
  PRE_FUNCTION(glRasterPos2s,x);
  GLV.glRasterPos2s (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos2sv (const GLshort *v)
{
  PRE_FUNCTION(glRasterPos2sv,v);
  GLV.glRasterPos2sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3d (GLdouble x, GLdouble y, GLdouble z)
{
  PRE_FUNCTION(glRasterPos3d,x);
  GLV.glRasterPos3d (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3dv (const GLdouble *v)
{
  PRE_FUNCTION(glRasterPos3dv,v);
  GLV.glRasterPos3dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3f (GLfloat x, GLfloat y, GLfloat z)
{
  PRE_FUNCTION(glRasterPos3f,x);
  GLV.glRasterPos3f (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3fv (const GLfloat *v)
{
  PRE_FUNCTION(glRasterPos3fv,v);
  GLV.glRasterPos3fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3i (GLint x, GLint y, GLint z)
{
  PRE_FUNCTION(glRasterPos3i,x);
  GLV.glRasterPos3i (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3iv (const GLint *v)
{
  PRE_FUNCTION(glRasterPos3iv,v);
  GLV.glRasterPos3iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3s (GLshort x, GLshort y, GLshort z)
{
  PRE_FUNCTION(glRasterPos3s,x);
  GLV.glRasterPos3s (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos3sv (const GLshort *v)
{
  PRE_FUNCTION(glRasterPos3sv,v);
  GLV.glRasterPos3sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4d (GLdouble x, GLdouble y, GLdouble z, GLdouble w)
{
  PRE_FUNCTION(glRasterPos4d,x);
  GLV.glRasterPos4d (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4dv (const GLdouble *v)
{
  PRE_FUNCTION(glRasterPos4dv,v);
  GLV.glRasterPos4dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4f (GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
  PRE_FUNCTION(glRasterPos4f,x);
  GLV.glRasterPos4f (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4fv (const GLfloat *v)
{
  PRE_FUNCTION(glRasterPos4fv,v);
  GLV.glRasterPos4fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4i (GLint x, GLint y, GLint z, GLint w)
{
  PRE_FUNCTION(glRasterPos4i,x);
  GLV.glRasterPos4i (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4iv (const GLint *v)
{
  PRE_FUNCTION(glRasterPos4iv,v);
  GLV.glRasterPos4iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4s (GLshort x, GLshort y, GLshort z, GLshort w)
{
  PRE_FUNCTION(glRasterPos4s,x);
  GLV.glRasterPos4s (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRasterPos4sv (const GLshort *v)
{
  PRE_FUNCTION(glRasterPos4sv,v);
  GLV.glRasterPos4sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glReadBuffer (GLenum mode)
{
  PRE_FUNCTION(glReadBuffer,mode);
  GLV.glReadBuffer (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, GLvoid *pixels)
{
  PRE_FUNCTION(glReadPixels,x);
  GLV.glReadPixels (x, y, width, height, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectd (GLdouble x1, GLdouble y1, GLdouble x2, GLdouble y2)
{
  PRE_FUNCTION(glRectd,x1);
  GLV.glRectd (x1, y1, x2, y2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectdv (const GLdouble *v1, const GLdouble *v2)
{
  PRE_FUNCTION(glRectdv,v1);
  GLV.glRectdv (v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectf (GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2)
{
  PRE_FUNCTION(glRectf,x1);
  GLV.glRectf (x1, y1, x2, y2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectfv (const GLfloat *v1, const GLfloat *v2)
{
  PRE_FUNCTION(glRectfv,v1);
  GLV.glRectfv (v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRecti (GLint x1, GLint y1, GLint x2, GLint y2)
{
  PRE_FUNCTION(glRecti,x1);
  GLV.glRecti (x1, y1, x2, y2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectiv (const GLint *v1, const GLint *v2)
{
  PRE_FUNCTION(glRectiv,v1);
  GLV.glRectiv (v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRects (GLshort x1, GLshort y1, GLshort x2, GLshort y2)
{
  PRE_FUNCTION(glRects,x1);
  GLV.glRects (x1, y1, x2, y2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRectsv (const GLshort *v1, const GLshort *v2)
{
  PRE_FUNCTION(glRectsv,v1);
  GLV.glRectsv (v1, v2);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
GLint GLAPIENTRY glRenderMode (GLenum mode)
{
  PRE_FUNCTION(glRenderMode,mode);
  GLint retValue = GLV.glRenderMode(mode);
  POST_FUNCTION_RET(retValue)

  return retValue;
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRotated (GLdouble angle, GLdouble x, GLdouble y, GLdouble z)
{
  PRE_FUNCTION(glRotated,angle);
  GLV.glRotated (angle, x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glRotatef (GLfloat angle, GLfloat x, GLfloat y, GLfloat z)
{
  PRE_FUNCTION(glRotatef,angle);
  GLV.glRotatef (angle, x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glScaled (GLdouble x, GLdouble y, GLdouble z)
{
  PRE_FUNCTION(glScaled,x);
  GLV.glScaled (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glScalef (GLfloat x, GLfloat y, GLfloat z)
{
  PRE_FUNCTION(glScalef,x);
  GLV.glScalef (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glScissor (GLint x, GLint y, GLsizei width, GLsizei height)
{
  PRE_FUNCTION(glScissor,x);
  GLV.glScissor (x, y, width, height);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glSelectBuffer (GLsizei size, GLuint *buffer)
{
  PRE_FUNCTION(glSelectBuffer,size);
  GLV.glSelectBuffer (size, buffer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glShadeModel (GLenum mode)
{
  PRE_FUNCTION(glShadeModel,mode);
  GLV.glShadeModel (mode);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glStencilFunc (GLenum func, GLint ref, GLuint mask)
{
  PRE_FUNCTION(glStencilFunc,func);
  GLV.glStencilFunc (func, ref, mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glStencilMask (GLuint mask)
{
  PRE_FUNCTION(glStencilMask,mask);
  GLV.glStencilMask (mask);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glStencilOp (GLenum fail, GLenum zfail, GLenum zpass)
{
  PRE_FUNCTION(glStencilOp,fail);
  GLV.glStencilOp (fail, zfail, zpass);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1d (GLdouble s)
{
  PRE_FUNCTION(glTexCoord1d,s);
  GLV.glTexCoord1d (s);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1dv (const GLdouble *v)
{
  PRE_FUNCTION(glTexCoord1dv,v);
  GLV.glTexCoord1dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1f (GLfloat s)
{
  PRE_FUNCTION(glTexCoord1f,s);
  GLV.glTexCoord1f (s);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1fv (const GLfloat *v)
{
  PRE_FUNCTION(glTexCoord1fv,v);
  GLV.glTexCoord1fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1i (GLint s)
{
  PRE_FUNCTION(glTexCoord1i,s);
  GLV.glTexCoord1i (s);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1iv (const GLint *v)
{
  PRE_FUNCTION(glTexCoord1iv,v);
  GLV.glTexCoord1iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1s (GLshort s)
{
  PRE_FUNCTION(glTexCoord1s,s);
  GLV.glTexCoord1s (s);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord1sv (const GLshort *v)
{
  PRE_FUNCTION(glTexCoord1sv,v);
  GLV.glTexCoord1sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2d (GLdouble s, GLdouble t)
{
  PRE_FUNCTION(glTexCoord2d,s);
  GLV.glTexCoord2d (s, t);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2dv (const GLdouble *v)
{
  PRE_FUNCTION(glTexCoord2dv,v);
  GLV.glTexCoord2dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2f (GLfloat s, GLfloat t)
{
  PRE_FUNCTION(glTexCoord2f,s);
  GLV.glTexCoord2f (s, t);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2fv (const GLfloat *v)
{
  PRE_FUNCTION(glTexCoord2fv,v);
  GLV.glTexCoord2fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2i (GLint s, GLint t)
{
  PRE_FUNCTION(glTexCoord2i,s);
  GLV.glTexCoord2i (s, t);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2iv (const GLint *v)
{
  PRE_FUNCTION(glTexCoord2iv,v);
  GLV.glTexCoord2iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2s (GLshort s, GLshort t)
{
  PRE_FUNCTION(glTexCoord2s,s);
  GLV.glTexCoord2s (s, t);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord2sv (const GLshort *v)
{
  PRE_FUNCTION(glTexCoord2sv,v);
  GLV.glTexCoord2sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3d (GLdouble s, GLdouble t, GLdouble r)
{
  PRE_FUNCTION(glTexCoord3d,s);
  GLV.glTexCoord3d (s, t, r);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3dv (const GLdouble *v)
{
  PRE_FUNCTION(glTexCoord3dv,v);
  GLV.glTexCoord3dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3f (GLfloat s, GLfloat t, GLfloat r)
{
  PRE_FUNCTION(glTexCoord3f,s);
  GLV.glTexCoord3f (s, t, r);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3fv (const GLfloat *v)
{
  PRE_FUNCTION(glTexCoord3fv,v);
  GLV.glTexCoord3fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3i (GLint s, GLint t, GLint r)
{
  PRE_FUNCTION(glTexCoord3i,s);
  GLV.glTexCoord3i (s, t, r);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3iv (const GLint *v)
{
  PRE_FUNCTION(glTexCoord3iv,v);
  GLV.glTexCoord3iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3s (GLshort s, GLshort t, GLshort r)
{
  PRE_FUNCTION(glTexCoord3s,s);
  GLV.glTexCoord3s (s, t, r);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord3sv (const GLshort *v)
{
  PRE_FUNCTION(glTexCoord3sv,v);
  GLV.glTexCoord3sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4d (GLdouble s, GLdouble t, GLdouble r, GLdouble q)
{
  PRE_FUNCTION(glTexCoord4d,s);
  GLV.glTexCoord4d (s, t, r, q);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4dv (const GLdouble *v)
{
  PRE_FUNCTION(glTexCoord4dv,v);
  GLV.glTexCoord4dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4f (GLfloat s, GLfloat t, GLfloat r, GLfloat q)
{
  PRE_FUNCTION(glTexCoord4f,s);
  GLV.glTexCoord4f (s, t, r, q);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4fv (const GLfloat *v)
{
  PRE_FUNCTION(glTexCoord4fv,v);
  GLV.glTexCoord4fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4i (GLint s, GLint t, GLint r, GLint q)
{
  PRE_FUNCTION(glTexCoord4i,s);
  GLV.glTexCoord4i (s, t, r, q);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4iv (const GLint *v)
{
  PRE_FUNCTION(glTexCoord4iv,v);
  GLV.glTexCoord4iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4s (GLshort s, GLshort t, GLshort r, GLshort q)
{
  PRE_FUNCTION(glTexCoord4s,s);
  GLV.glTexCoord4s (s, t, r, q);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoord4sv (const GLshort *v)
{
  PRE_FUNCTION(glTexCoord4sv,v);
  GLV.glTexCoord4sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexCoordPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glTexCoordPointer,size);
  GLV.glTexCoordPointer (size, type, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexEnvf (GLenum target, GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glTexEnvf,target);
  GLV.glTexEnvf (target, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexEnvfv (GLenum target, GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glTexEnvfv,target);
  GLV.glTexEnvfv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexEnvi (GLenum target, GLenum pname, GLint param)
{
  PRE_FUNCTION(glTexEnvi,target);
  GLV.glTexEnvi (target, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexEnviv (GLenum target, GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glTexEnviv,target);
  GLV.glTexEnviv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGend (GLenum coord, GLenum pname, GLdouble param)
{
  PRE_FUNCTION(glTexGend,coord);
  GLV.glTexGend (coord, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGendv (GLenum coord, GLenum pname, const GLdouble *params)
{
  PRE_FUNCTION(glTexGendv,coord);
  GLV.glTexGendv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGenf (GLenum coord, GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glTexGenf,coord);
  GLV.glTexGenf (coord, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGenfv (GLenum coord, GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glTexGenfv,coord);
  GLV.glTexGenfv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGeni (GLenum coord, GLenum pname, GLint param)
{
  PRE_FUNCTION(glTexGeni,coord);
  GLV.glTexGeni (coord, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexGeniv (GLenum coord, GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glTexGeniv,coord);
  GLV.glTexGeniv (coord, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
  PRE_FUNCTION(glTexImage1D,target);
  GLV.glTexImage1D (target, level, internalformat, width, border, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
  PRE_FUNCTION(glTexImage2D,target);
  GLV.glTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexParameterf (GLenum target, GLenum pname, GLfloat param)
{
  PRE_FUNCTION(glTexParameterf,target);
  GLV.glTexParameterf (target, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexParameterfv (GLenum target, GLenum pname, const GLfloat *params)
{
  PRE_FUNCTION(glTexParameterfv,target);
  GLV.glTexParameterfv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexParameteri (GLenum target, GLenum pname, GLint param)
{
  PRE_FUNCTION(glTexParameteri,target);
  GLV.glTexParameteri (target, pname, param);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexParameteriv (GLenum target, GLenum pname, const GLint *params)
{
  PRE_FUNCTION(glTexParameteriv,target);
  GLV.glTexParameteriv (target, pname, params);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels)
{
  PRE_FUNCTION(glTexSubImage1D,target);
  GLV.glTexSubImage1D (target, level, xoffset, width, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
  PRE_FUNCTION(glTexSubImage2D,target);
  GLV.glTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTranslated (GLdouble x, GLdouble y, GLdouble z)
{
  PRE_FUNCTION(glTranslated,x);
  GLV.glTranslated (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glTranslatef (GLfloat x, GLfloat y, GLfloat z)
{
  PRE_FUNCTION(glTranslatef,x);
  GLV.glTranslatef (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2d (GLdouble x, GLdouble y)
{
  PRE_FUNCTION(glVertex2d,x);
  GLV.glVertex2d (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2dv (const GLdouble *v)
{
  PRE_FUNCTION(glVertex2dv,v);
  GLV.glVertex2dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2f (GLfloat x, GLfloat y)
{
  PRE_FUNCTION(glVertex2f,x);
  GLV.glVertex2f (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2fv (const GLfloat *v)
{
  PRE_FUNCTION(glVertex2fv,v);
  GLV.glVertex2fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2i (GLint x, GLint y)
{
  PRE_FUNCTION(glVertex2i,x);
  GLV.glVertex2i (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2iv (const GLint *v)
{
  PRE_FUNCTION(glVertex2iv,v);
  GLV.glVertex2iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2s (GLshort x, GLshort y)
{
  PRE_FUNCTION(glVertex2s,x);
  GLV.glVertex2s (x, y);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex2sv (const GLshort *v)
{
  PRE_FUNCTION(glVertex2sv,v);
  GLV.glVertex2sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3d (GLdouble x, GLdouble y, GLdouble z)
{
  PRE_FUNCTION(glVertex3d,x);
  GLV.glVertex3d (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3dv (const GLdouble *v)
{
  PRE_FUNCTION(glVertex3dv,v);
  GLV.glVertex3dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3f (GLfloat x, GLfloat y, GLfloat z)
{
  PRE_FUNCTION(glVertex3f,x);
  GLV.glVertex3f (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3fv (const GLfloat *v)
{
  PRE_FUNCTION(glVertex3fv,v);
  GLV.glVertex3fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3i (GLint x, GLint y, GLint z)
{
  PRE_FUNCTION(glVertex3i,x);
  GLV.glVertex3i (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3iv (const GLint *v)
{
  PRE_FUNCTION(glVertex3iv,v);
  GLV.glVertex3iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3s (GLshort x, GLshort y, GLshort z)
{
  PRE_FUNCTION(glVertex3s,x);
  GLV.glVertex3s (x, y, z);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex3sv (const GLshort *v)
{
  PRE_FUNCTION(glVertex3sv,v);
  GLV.glVertex3sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4d (GLdouble x, GLdouble y, GLdouble z, GLdouble w)
{
  PRE_FUNCTION(glVertex4d,x);
  GLV.glVertex4d (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4dv (const GLdouble *v)
{
  PRE_FUNCTION(glVertex4dv,v);
  GLV.glVertex4dv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4f (GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
  PRE_FUNCTION(glVertex4f,x);
  GLV.glVertex4f (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4fv (const GLfloat *v)
{
  PRE_FUNCTION(glVertex4fv,v);
  GLV.glVertex4fv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4i (GLint x, GLint y, GLint z, GLint w)
{
  PRE_FUNCTION(glVertex4i,x);
  GLV.glVertex4i (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4iv (const GLint *v)
{
  PRE_FUNCTION(glVertex4iv,v);
  GLV.glVertex4iv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4s (GLshort x, GLshort y, GLshort z, GLshort w)
{
  PRE_FUNCTION(glVertex4s,x);
  GLV.glVertex4s (x, y, z, w);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertex4sv (const GLshort *v)
{
  PRE_FUNCTION(glVertex4sv,v);
  GLV.glVertex4sv (v);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glVertexPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
  PRE_FUNCTION(glVertexPointer,size);
  GLV.glVertexPointer (size, type, stride, pointer);
  POST_FUNCTION
}

///////////////////////////////////////////////////////////////////////////////
//
void GLAPIENTRY glViewport (GLint x, GLint y, GLsizei width, GLsizei height)
{
  PRE_FUNCTION(glViewport,x);
  GLV.glViewport (x, y, width, height);
  POST_FUNCTION
}


