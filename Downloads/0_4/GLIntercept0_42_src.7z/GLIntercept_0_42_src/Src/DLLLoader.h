/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __DLL_LOADER_H_
#define __DLL_LOADER_H_

#include "GLInterceptConfig.h"

//@
//  Summary:
//    Class for loading a library and accessing functions from it
//  
class DLLLoader  
{
public:

  //Constructor and destructor
  DLLLoader();
  virtual ~DLLLoader();

  //@
  //  Summary:
  //    Inits the class with the library of the passed name
  //  
  //  Parameters:
  //    libName  - The name of the library to open
  //
  //  Returns;
  //    True is returned on success, false is otherwise
  //
  bool Init(const char *libName);

  //@
  //  Summary:
  //    Gets the specified funtion from the library.
  //  
  //  Parameters:
  //    functionName  - The name of the function to get from the library.
  //
  //  Returns;
  //    If the function exists in the library and it could be retrieved, it is returned.
  //    Else, NULL is returned.
  //
  void * GetFunction(const char *functionName);

  //@
  //  Summary:
  //    Gets the full dll file name with path.
  //  
  //  Returns;
  //    If the DLL is loaded, the full load name of the DLL is returned.
  //    Else an empty string is returned.
  //
  string GetFullDLLFileName() const;

  //@
  //  Summary:
  //    To determine if the passed dll library name matches this loaded DLL.
  //    (This will resolve the paths for the dll name before comparing against
  //    this loaded dll. Therefore this method is better for comparasons than 
  //    using GetFullDLLFileName and comparing the result)
  //  
  //  Parameters:
  //    libName  - The dll lib name to compare against. 
  //               (Will be resolved to full path first).
  //
  //  Returns;
  //    If the passed libName corresponds to this dll, true is returned. 
  //    Else false is returned.
  //
  bool IsDLLNameMatch(const char *libName) const;

  //@
  //  Summary:
  //    If this DLL is unloaded externally (ie by the OS), setting this flag
  //    will tell the class to not to try and unload the dll on destruction.
  //  
  void FlagDLLUnloaded();


protected:

  void * handle;                                  // The OS handle to the library
};

#endif // __DLL_LOADER_H_