/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/

#include "stdafx.h"
#include "InputUtils.h"

//Structure for holding key lookups
struct KeyLookup
{
  uint keyCode;
  const char *keyStr;
};


//Some defines (and re-defines) of some not commoonly used win32 virtual keys

#define VK_EQUALS        0xBB   //A virtual key code for the EQUAL SIGN (=) key. 
#define VK_MINUS         0xBD   //A virtual key code for the EQUAL SIGN (=) key. 

#define VK_LSHIFT        0xA0
#define VK_RSHIFT        0xA1
#define VK_LCONTROL      0xA2
#define VK_RCONTROL      0xA3
#define VK_LMENU         0xA4
#define VK_RMENU         0xA5

#define VK_BACK_QUOTE    0xC0   //A virtual key code for the apostrophe (`) key. 
#define VK_BACK_SLASH    0xDC   //A virtual key code for the BACKSLASH (\) key. 

#define VK_CLOSE_BRACKET 0xDD   //A virtual key code for the CLOSE BRACKET (]) key. 
#define VK_COMMA         0xBC   //A virtual key code for the COMMA (,) key. 
#define VK_OPEN_BRACKET  0xDB   //A virtual key code for the OPEN BRACKET ([) key. 
#define VK_PERIOD        0xBE   //A virtual key code for the PERIOD (.) key. 

#define VK_QUOTE         0xDE   //A virtual key code for the QUOTATION MARK key. 
#define VK_SEMICOLON     0xBA   //A virtual key code for the SEMICOLON (;) key. 
#define VK_SLASH         0xBF   //A virtual key code for the forward slash (/) key. 

#define VK_SCROLL_LOCK   0x91   //A virtual key code for the SCROLL LOCK key. 
#define VK_NUM_LOCK      0x90   //A virtual key code for the NUM LOCK key. 

//Key code lookups for windows
KeyLookup keyLookup[] = 
{
  {VK_BACK, "backspace"},
  {VK_TAB, "tab"},
  {VK_CLEAR, "clear"},
  {VK_RETURN, "enter"},

  {VK_SHIFT, "shift"},
  {VK_CONTROL, "ctrl"},
  {VK_MENU, "alt"},      

  {VK_LSHIFT, "lshift"},
  {VK_LCONTROL, "lctrl"},
  {VK_LMENU, "lalt"},      

  {VK_RSHIFT, "rshift"},
  {VK_RCONTROL, "rctrl"},
  {VK_RMENU, "ralt"},      

  {VK_PAUSE, "pause"},
  {VK_CAPITAL, "caps"},
  {VK_CAPITAL, "capslock"},
  {VK_ESCAPE, "esc"},
  {VK_SPACE, "space"},
  {VK_PRIOR, "pageup"},
  {VK_NEXT, "pagedown"},
  {VK_END, "end"},
  {VK_HOME, "home"},
  {VK_LEFT, "left"},
  {VK_UP, "up"},
  {VK_RIGHT, "right"},
  {VK_DOWN, "down"},
  {VK_SELECT, "select"},
  {VK_EXECUTE, "execute"},
  {VK_SNAPSHOT, "print"},
  {VK_SNAPSHOT, "printscreen"},
  {VK_INSERT, "insert"},
  {VK_DELETE, "delete"},
  {VK_HELP, "help"},
  {'0', "0"},
  {'1', "1"},
  {'2', "2"},
  {'3', "3"},
  {'4', "4"},
  {'5', "5"},
  {'6', "6"},
  {'7', "7"},
  {'8', "8"},
  {'8', "*"}, //Use the "8" key for multiplication also
  {'9', "9"},
  {'A', "a"},
  {'B', "b"},
  {'C', "c"},
  {'D', "d"},
  {'E', "e"},
  {'F', "f"},
  {'G', "g"},
  {'H', "h"},
  {'I', "i"},
  {'J', "j"},
  {'K', "k"},
  {'L', "l"},
  {'M', "m"},
  {'N', "n"},
  {'O', "o"},
  {'P', "p"},
  {'Q', "q"},
  {'R', "r"},
  {'S', "s"},
  {'T', "t"},
  {'U', "u"},
  {'V', "v"},
  {'W', "w"},
  {'X', "x"},
  {'Y', "y"},
  {'Z', "z"},
  {VK_LWIN, "lwin"},
  {VK_RWIN, "rwin"},
  {VK_APPS, "apps"},
  {VK_NUMPAD0, "num0"},
  {VK_NUMPAD1, "num1"},
  {VK_NUMPAD2, "num2"},
  {VK_NUMPAD3, "num3"},
  {VK_NUMPAD4, "num4"},
  {VK_NUMPAD5, "num5"},
  {VK_NUMPAD6, "num6"},
  {VK_NUMPAD7, "num7"},
  {VK_NUMPAD8, "num8"},
  {VK_NUMPAD9, "num9"},
  {VK_MULTIPLY, "num*"},
  {VK_ADD, "num+"},
  {VK_SUBTRACT, "num-"},
  {VK_DECIMAL, "num."},
  {VK_DIVIDE, "num/"},
  {VK_F1, "f1"},
  {VK_F2, "f2"},
  {VK_F3, "f3"},
  {VK_F4, "f4"},
  {VK_F5, "f5"},
  {VK_F6, "f6"},
  {VK_F7, "f7"},
  {VK_F8, "f8"},
  {VK_F9, "f9"},
  {VK_F10, "f10"},
  {VK_F11, "f11"},
  {VK_F12, "f12"},
  {VK_F13, "f13"},
  {VK_F14, "f14"},
  {VK_F15, "f15"},
  {VK_F16, "f16"},
  {VK_F17, "f17"},
  {VK_F18, "f18"},
  {VK_F19, "f19"},
  {VK_F20, "f20"},
  {VK_F21, "f21"},
  {VK_F22, "f22"},
  {VK_F23, "f23"},
  {VK_F24, "f24"},
  {VK_NUMLOCK, "numlock"},
  {VK_SCROLL, "scrolllock"},

  {VK_BACK_QUOTE,"~"},
  {VK_BACK_SLASH,"\\"},
  {VK_BACK_SLASH,"|"},
  
  {VK_CLOSE_BRACKET,"]"},
  {VK_OPEN_BRACKET,"["},

  {VK_CLOSE_BRACKET,"}"},
  {VK_OPEN_BRACKET,"{"},

  {VK_COMMA,","},
  {VK_COMMA,"<"},

  {VK_PERIOD,"."},
  {VK_PERIOD,">"},

  {VK_EQUALS,"="},
  {VK_EQUALS,"+"},

  {VK_MINUS,"_"},
  {VK_MINUS,"-"},

  {VK_NUM_LOCK,"numlock"},
    
  {VK_QUOTE,"\""},
  {VK_QUOTE,"'"},

  {VK_SCROLL_LOCK,"scrolllock"},
  {VK_SEMICOLON,":"},
  {VK_SEMICOLON,";"},

  {VK_SLASH,"/"},
  {VK_SLASH,"?"}
};







///////////////////////////////////////////////////////////////////////////////
//
uint InputUtils::GetKeyCode(const string & keyString)
{
  //Make the string lower case
  string lookUpStr = keyString;

  //Loop for all key lookups
  for(uint i=0;i < sizeof(keyLookup) / sizeof(KeyLookup); i++)
  {
    //If the string matches, return the code
    if(keyLookup[i].keyStr == lookUpStr)
    {
      return keyLookup[i].keyCode;
    }
  }

  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InputUtils::IsKeyDown(uint keyCode)
{
  //Return if the high byte is true (ie key is down)
  return (GetAsyncKeyState(keyCode) & 0x8000) != 0;
}

///////////////////////////////////////////////////////////////////////////////
//
bool InputUtils::IsAllKeyDown(const vector<uint> &keyCodes)
{
  //Loop for all the codes
  for(uint i=0;i<keyCodes.size();i++)
  {
    //If one of the keys is not down, return now
    if(!IsKeyDown(keyCodes[i]))
    {
      return false;
    }
  }

  //Only return true when there exists some keys to test
  if(keyCodes.size() > 0)
  {
    return true;
  }

  return false;
}

