/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/

#include "stdafx.h"

#include "MiscUtils.h"

#define MAX_STRING_BUF_LENGTH 1025

///////////////////////////////////////////////////////////////////////////////
//
void __cdecl StringPrintF(string &dstString, const char *format,...)
{
  char charBuffer[MAX_STRING_BUF_LENGTH+1];

  //Get the pointer to the arguments
  va_list marker;
  va_start( marker, format );

  //Write the formatted string
  if(_vsnprintf(charBuffer,MAX_STRING_BUF_LENGTH,format,marker) == -1)
  {
    //Append a NULL character if the string was too big
    charBuffer[MAX_STRING_BUF_LENGTH-1] = '\0';
  }
  
  //Reset the marker
  va_end( marker );

  //Assign the return string
  dstString = charBuffer;
}

///////////////////////////////////////////////////////////////////////////////
//
int GetActiveThreadID()
{
  //Just dirtecly call the API version
  return GetCurrentThreadId();
}


///////////////////////////////////////////////////////////////////////////////
//
TimeDiff::TimeDiff():
frequency(1),
startTime(0)
{
  //Assign the frequency
  LARGE_INTEGER freq;
  if(QueryPerformanceFrequency(&freq) == TRUE)
  {
    //Assign the frequency of the time values
    frequency = freq.QuadPart;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
TimeDiff::~TimeDiff()
{
}

///////////////////////////////////////////////////////////////////////////////
//
void TimeDiff::StartTimer()
{
  //Get the start time
  LARGE_INTEGER sTime;
  if(QueryPerformanceCounter(&sTime) == TRUE)
  {
    //Assign the starting time
    startTime = sTime.QuadPart;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
uint TimeDiff::GetTimeDiff()
{
  //Get the current time
  LARGE_INTEGER eTime;
  if(QueryPerformanceCounter(&eTime) == TRUE)
  {
    //Subtract from the start time and divide by the frequency
    int64 diffTime = ((eTime.QuadPart - startTime)*1000000) / frequency;

    //Return in milliseconds
    if(diffTime >= 0)
    {
      return (uint)(diffTime);
    }
  }

  return 0;
}
