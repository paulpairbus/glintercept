/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "SEInterface.h"
#include "ShaderEditManager.h"
#include <MiscUtils.h>
#include <CommonErrorLog.h>

USING_ERRORLOG

// The singleton instance.
SEInterface * SEInterface::seiInstance = NULL;

//DLL Instance
extern HINSTANCE dllInstance;

//Path to the dll
extern string dllPath;

//Prototype of the window callback
LRESULT PASCAL SEInterface_WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);


//The type of command that can be passed
enum CommandType
{
  CT_None          = 0,   // No command
  CT_Ping          = 1,   // Is active "ping" command        
  CT_ShaderList    = 2,   // Request shader list
  CT_ShaderSource  = 3,   // Request shader source
  CT_CompileShader = 4,   // Compile shader 
  CT_ShowShader    = 5,   // Request that the passed shader be "shown" visually
  CT_Shutdown      = 6,   // Shutdown message handling 
  CT_RevertShader  = 7,   // Revert shader
  CT_Max           = 8    // Maximum number of commands

};

struct CommandMsg
{
  CommandMsg();
  CommandType commandType; // The type of the command 
  uint        commandUID;  // The unique ID passed with the command
  string      commandData; // The raw command data

  HWND        commandWnd;  // The window that requested this command
};

static vector<CommandMsg>  cachedCommands; // Command that have been requested but not yet processed 

static char SEInterface_ClassName[] = "GLI_SEInterface_Win_Class";

///////////////////////////////////////////////////////////////////////////////
//
CommandMsg::CommandMsg():
commandType(CT_None),
commandUID(0),
commandWnd(NULL)
{
}

///////////////////////////////////////////////////////////////////////////////
//
SEInterface::SEInterface(ShaderEditManager *newManager, InterceptPluginCallbacks *callBacks):
manager(newManager),
gliCallbacks(callBacks),
messageWin(NULL),
editProcessHandle(NULL)
{
}

///////////////////////////////////////////////////////////////////////////////
//
SEInterface::~SEInterface()
{
  //Destroy the window if necessary
  if(messageWin)
  {
    if(!DestroyWindow(messageWin))
    {
      LOGERR(("~SEInterface - Error destroying message window"));
    }
    messageWin = NULL;

    if(!UnregisterClass(SEInterface_ClassName, dllInstance))
    {
      LOGERR(("~SEInterface - Error unregistering window class"));
    }
  }

  //Flag to no longer "show" the shader
  manager->SetShowShader(0,USID_Undefined); 

  //Close the process handle
  if(editProcessHandle)
  {
    CloseHandle(editProcessHandle);
  }

}

///////////////////////////////////////////////////////////////////////////////
//
bool SEInterface::Init()
{
  //Clar any possible cached commands
  cachedCommands.clear();

  //Create the class of the interface window
  WNDCLASS wndclass;
  wndclass.style = 0;
  wndclass.lpfnWndProc = SEInterface_WndProc;
  wndclass.cbClsExtra = 0;
  wndclass.cbWndExtra = 0;
  wndclass.hInstance = dllInstance;
  wndclass.hIcon = 0;
  wndclass.hCursor = NULL;
  wndclass.hbrBackground = NULL;
  wndclass.lpszMenuName = 0;
  wndclass.lpszClassName = SEInterface_ClassName;
  if (!::RegisterClass(&wndclass))
  {
    LOGERR(("SEInterface::Init - unable to register window class"));
    return false;
  }

  //Create the window
  messageWin = ::CreateWindow(
                      SEInterface_ClassName,
                      SEInterface_ClassName,
                      0,
                      0, 0, 0, 0,
                      0,
                      0,
                      dllInstance,
                      0);
  if (!messageWin)
  {
    UnregisterClass(SEInterface_ClassName, dllInstance);
    LOGERR(("SEInterface::Init - Unable to create message window"));
    return false;
  }

  //Create a process startup structures
  STARTUPINFO si;
  PROCESS_INFORMATION processID;

  //Create the editor and show it
  memset(&si, 0, sizeof(STARTUPINFO));
  si.cb = sizeof(STARTUPINFO);
  si.dwFlags = STARTF_USESHOWWINDOW;
  si.wShowWindow = SW_SHOW;

  //Pass the message window handle to the editor
  string cmdLine;
  StringPrintF(cmdLine, " -glintercept.hwnd=%u",messageWin); 

  //Create the new editor as a seperate process
  string exeName = dllPath + "GLISciTE.exe";
  if(!::CreateProcess(exeName.c_str(),
                      (char*)cmdLine.c_str(),
                      NULL, NULL, TRUE, CREATE_NEW_PROCESS_GROUP,
                      NULL, NULL, &si, &processID))
  {
    LOGERR(("SEInterface::Init - Unable to create editor process"));
    return false;
  }

  //Assign the process handle
  editProcessHandle = processID.hProcess;

  //Close thread handle. 
  CloseHandle(processID.hThread);

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::OnFrameEnd()
{
  //Check that the instance is available
  if(!seiInstance || !messageWin)
  {
    return;
  }

  //Peek at any messages for our window 
  //  (in case the main app does not have a main processing loop - unlikely)
  MSG processMsg;
  if(PeekMessage(&processMsg, messageWin, NULL, NULL, PM_REMOVE))
  {
    DispatchMessage(&processMsg);
  }

  //Check if the window is still active
  if(cachedCommands.size() == 0)
  {
    //Get if the editor process has crashed
    DWORD exitCode;
    if(GetExitCodeProcess(editProcessHandle, &exitCode) &&
       exitCode != STILL_ACTIVE)
    {
      LOGERR(("SEInterface::OnFrameEnd - Crashed editor process?"));

      //Destroy this class
      DestroyInstance();
      return;
    }
  }

  //Process any commands
  for(uint i=0; i<cachedCommands.size(); i++)
  {
    const CommandMsg &currCmd = cachedCommands[i];
    switch(currCmd.commandType)
    {
      //Ignore commands
      case(CT_None):
      case(CT_Ping):
        break;

      //Get a listing of all the current shaders
      case(CT_ShaderList):
        SendShaderList(currCmd.commandWnd, currCmd.commandUID);
        break;

      //Get the source of a particular shader
      case(CT_ShaderSource):
        SendShaderSource(currCmd.commandWnd, currCmd.commandUID, currCmd.commandData);
        break;

      //Compile a shader
      case(CT_CompileShader):
        CompileShaderSource(currCmd.commandWnd, currCmd.commandUID, currCmd.commandData);
        break;

      //Flag a shader as shown
      case(CT_ShowShader):
        ShowShader(currCmd.commandData);
        break;

      //Revert the shader
      case(CT_RevertShader):
        RevertShader(currCmd.commandData);
        break;

      //Destroy this message handler
      case(CT_Shutdown):
        //Remove all cached commands
        cachedCommands.clear();

        //Destroy this class
        DestroyInstance();
        return;
        break;

      default:
        LOGERR(("SEInterface::OnFrameEnd - Unknown command"));
    }
  }

  //Remove all cached commands
  cachedCommands.clear();

}



///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::SendShaderList(HWND sendWnd, uint cmdUID)
{
  //Get the sahder list
  const vector<UniqueShaderID *> &shaderList = UniqueShaderID::GetUniqueShaderIDList();  

  string shaderListStr;
  shaderListStr.reserve(2000);

  string buffer;

  //Loop for all the shaders and append the data to the string
  for(uint i=0; i<shaderList.size(); i++)
  {
    const UniqueShaderID * currShader = shaderList[i];

    //Determine the shader type
    string strShaderType;
    switch(currShader->GetShaderType())
    {
      case(USID_GLSLProgram):
        strShaderType = "GLSL";
        break;

      case(USID_ARB_VP):
        strShaderType = "ARBVP";
        break;

      case(USID_ARB_FP):
        strShaderType = "ARBFP";
        break;

      case(USID_NV_VP):
        strShaderType = "NVVP";
        break;

      case(USID_NV_FP):
        strShaderType = "NVFP";
        break;

      default:
        //Ignore all other types
        break;
    };

    //Ony add if it was a valid type
    if(strShaderType.length() > 0)
    {
      StringPrintF(buffer,"%u:%u:%s:%u:*",
                    currShader->GetUniqueIndex(),currShader->GetShaderOpenGLID(),
                    strShaderType.c_str(), currShader->GetLastFrameUsed());
      shaderListStr += buffer;
    }
  }

  //Send the message
  SendWinMessage(sendWnd, cmdUID, shaderListStr);
}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::SendShaderSource(HWND sendWnd, uint cmdUID, const string &strShaderID)
{
  string shaderSource;

  //Get the shader ID
  uint shaderUIDIndex = atoi(strShaderID.c_str());

  //Look up the string value
  const UniqueShaderID * shaderDataID = UniqueShaderID::FindUniqueShaderID(shaderUIDIndex);
  if(shaderDataID)
  {
    //Get any override source first
    shaderSource = shaderDataID->GetOverrideShaderSource();
    if(shaderSource.size() == 0)
    {
      //Retrieve the origional shader source
      shaderSource = shaderDataID->GetShaderSource();
      if(shaderSource.size() == 0)
      {
        shaderSource = "<No current source>";
      }
    }
  }
  else
  {
    //Flag that the shader source no longer exists
    shaderSource = "The specified shader ";
    shaderSource += strShaderID;
    shaderSource += " no longer exists in the program - refresh";
  }

  //Send the message
  SendWinMessage(sendWnd, cmdUID, shaderSource);

}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::CompileShaderSource(HWND sendWnd, uint cmdUID, const string &shaderData)
{
  string shaderLog;
  string shaderSrc;
  string strShaderID;

  //Extract the first digits
  int endPos = shaderData.find(":");
  if(endPos == string::npos)
  {
    //An error message
    SendWinMessage(sendWnd, cmdUID, "CompileShaderSource - No shader ID");
    return;
  }

  //Extracte the ID and the shader source
  strShaderID = shaderData.substr(0, endPos);
  shaderSrc   = shaderData.substr(endPos+1, shaderData.length() - endPos - 1);

  //Get the shader ID
  uint shaderUIDIndex = atoi(strShaderID.c_str());

  //Look up the string value
  if(manager->CompileShader(shaderUIDIndex, shaderSrc, shaderLog))
  {
    shaderLog = string(" Success\n") + shaderLog;
  }
  else
  {
    shaderLog = string(" Error\n") + shaderLog;
  }

  //Send the message
  SendWinMessage(sendWnd, cmdUID, shaderLog);
}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::ShowShader(const string &shaderID)
{
  //Get the shader ID
  uint shaderUIDIndex = 0;
  if(shaderID.length() > 0)
  {
    shaderUIDIndex = atoi(shaderID.c_str());
  }

  //Look up the string value
  const UniqueShaderID * shaderDataID = NULL;
  if(shaderUIDIndex > 0)
  {
    shaderDataID = UniqueShaderID::FindUniqueShaderID(shaderUIDIndex);
  }

  //Flag to the manager the new ID
  if(shaderDataID)
  {
    manager->SetShowShader(shaderUIDIndex,shaderDataID->GetShaderType()); 
  }
  else
  {
    manager->SetShowShader(0,USID_Undefined); 
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::RevertShader(const string &shaderID)
{
  //Get the shader ID
  uint shaderUIDIndex = 0;
  if(shaderID.length() > 0)
  {
    shaderUIDIndex = atoi(shaderID.c_str());
  }

  //Look up the string value
  UniqueShaderID * shaderDataID = NULL;
  if(shaderUIDIndex > 0)
  {
    shaderDataID = UniqueShaderID::FindUniqueShaderID(shaderUIDIndex);
  }
  
  //Return if the shader is not found
  if(!shaderDataID)
  {
    return;
  }

  //If the type is GLSL, simply detach the substitute
  if(shaderDataID->GetShaderType() == USID_GLSLProgram)
  {
    //Reset the override shader source
    shaderDataID->SetOverrideShaderSource("");

    //Assign a empty substitute
    shaderDataID->SetSubstituteShader(SubShaderGLSLRef());
    return;
  }

  //If a ASM type shader, compile it with the origional source
  string shaderSrc = shaderDataID->GetShaderSource();
  string shaderLog;

  //Look up the string value
  if(!manager->CompileShader(shaderUIDIndex, shaderSrc, shaderLog))
  {
    LOGERR(("SEInterface::RevertShader - Error compiling shader with origional source?"));
    return;
  }

  //Reset the override shader source
  shaderDataID->SetOverrideShaderSource("");
}

///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::SendWinMessage(HWND sendWnd, uint cmdUID, const string &data)
{
  COPYDATASTRUCT sendData;
  sendData.dwData = cmdUID;
  sendData.cbData = 0;
  sendData.lpData = NULL;

  //Point to the string if it has some data
  if(data.size() > 0)
  {
    sendData.cbData = data.size();
    sendData.lpData = (char*)data.c_str();
  }

  //Send the message and time out if not responded to in 3 seconds
  DWORD result;
  if(!SendMessageTimeout(sendWnd, WM_COPYDATA, 
                         reinterpret_cast<WPARAM>(messageWin), reinterpret_cast<LPARAM>(&sendData),
                         SMTO_ABORTIFHUNG | SMTO_NORMAL, 3000, &result))
  {
    LOGERR(("SEInterface::SendWinMessage - Error sending message"));
  }

}

///////////////////////////////////////////////////////////////////////////////
//
LRESULT PASCAL SEInterface_WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
  //Only handle copy data messages
  if (iMessage == WM_COPYDATA)
  {
    CommandMsg newCommand;
    
    //Extract the command type and UID
    PCOPYDATASTRUCT srcData = (PCOPYDATASTRUCT)lParam;
    newCommand.commandType = (CommandType)LOWORD(srcData->dwData);
    newCommand.commandUID  = srcData->dwData;

    //Assign the calling windows' ID
    newCommand.commandWnd = (HWND)wParam;

    //Copy the command data
    if(srcData->cbData > 0 && srcData->lpData)
    {
      newCommand.commandData = string((const char*)srcData->lpData, srcData->cbData);
    }

    //Check the command type
    if(newCommand.commandType >= CT_Max || newCommand.commandType < 0)
    {
      LOGERR(("SEInterface_WndProc - Invalid command"));
      return FALSE;
    }

    //Add the command to the cached command array
    cachedCommands.push_back(newCommand);

    return TRUE;
  }

  return ::DefWindowProc(hWnd, iMessage, wParam, lParam);
}




///////////////////////////////////////////////////////////////////////////////
//
SEInterface * SEInterface::CreateInstance(ShaderEditManager *manager, InterceptPluginCallbacks *callBacks)
{
  //If the instance already exists, return it
  if(seiInstance)
  {
    return seiInstance;  
  }

  //Create an init the new interface
  SEInterface * newInterface = new SEInterface(manager, callBacks);
  if(!newInterface->Init())
  {
    LOGERR(("SEInterface::CreateInstance - Error creating the shader editor interface"));
    return false;
  }

  //Assign the interface an return
  seiInstance = newInterface;

  return seiInstance;
}

///////////////////////////////////////////////////////////////////////////////
//
SEInterface * SEInterface::GetInstance()
{
  return seiInstance;
}


///////////////////////////////////////////////////////////////////////////////
//
void SEInterface::DestroyInstance()
{
  //Destroy if allocated
  if(seiInstance)
  {
    delete seiInstance;
    seiInstance = NULL;
  }
}





