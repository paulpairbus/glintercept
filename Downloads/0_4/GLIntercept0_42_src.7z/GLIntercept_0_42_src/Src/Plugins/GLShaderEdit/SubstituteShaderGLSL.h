/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __SUBSTITUTE_SHADER_GLSL_H_
#define __SUBSTITUTE_SHADER_GLSL_H_

#include "..\\..\\InterceptPluginInterface.h"
#include <ReferenceCount.h>
#include <AutoReferenceCount.h>

#include <string>
#include <vector>

using namespace std;

class GLDriver;


//@
//  Summary:
//    This class provides the ability to replace an existing GLSL program
//    with another program. This is accomplished by binding the substitute
//    when the program to be replaced is bound during a render call. All
//    the uniforms are then copied from the old program to the new program.
//  
class SubstituteShaderGLSL : public ReferenceCount
{
public:

  //@
  //  Summary:
  //    Constructor, inits all data to default values.
  //
  //  Parameters:
  //    programID  - The OpenGL ID of the new substitute program. 
  //                 (must already have been successfully linked) 
  //
  //    gliCallBacks  - The callbacks to GLIntercept.
  //
  SubstituteShaderGLSL(GLhandle programID,InterceptPluginCallbacks *gliCallBacks);

  //@
  //  Summary:
  //    To initialize this substitue (with the passed old program).
  //    This will retrieve all the old uniform offsets from the old 
  //    program and map them to the uniforms in the new program.
  //
  //  Parameters:
  //    oldProgram  - The OpenGL ID of the old program. 
  //
  //    initLog  - The string listing any errors/warnings that 
  //               occured during initialization.
  //
  //  Returns:
  //    True is returned if substitution was successful. Else false
  //    is returned.
  //
  bool Init(GLhandle oldProgram, string &initLog);

  //@
  //  Summary:
  //    To bind the substitute GLSL program and copy all uniform data
  //    from the old program to the new program.
  //
  void BindSubstitute();

  //@
  //  Summary:
  //    To bind the old program that this substitute shader replaces.
  //
  void UnBindSubstitute();

  //@
  //  Summary:
  //    To destroy the substitute. This will prevent further Bind calls 
  //    from having effect. This is to be called when the old program 
  //    is deleted (this must be done in the same context that has the
  //    old program and that context must be active)
  //
  void DestroyProgram();

protected:

  //Structure to hold data about the uniforms in the program
  struct UniformData
  {
    UniformData();

    vector<uint> indexData; // The origional indices of the uniform (can be multiple for an array)
    uint remapIndex;        // The new index of the uniform

    string name;            // The name of the uniform
    GLenum type;            // The type of the uniform
    uint   size;            // The size of the uniform

    uint   numTypeElements; // The number of elements in the type 
    bool   isFloatType;     // Flag indicating a float or int based type 

  };
  typedef vector<UniformData> UniformDataArray;
  
  GLhandle  programID;                            // The handle to the OpenGL substitute program
  GLhandle  oldProgramID;                         // The handle to the OpenGL program we are replacing

  InterceptPluginCallbacks *gliCallBacks;         // The callback interface into GLIntercept

  UniformDataArray remapUniformArray;             // Array of re-mapped uniform data


  //Internal OpenGL function entry points
  void (GLAPIENTRY *iglUseProgramObject) (GLhandle programObj);
  void (GLAPIENTRY *iglGetObjectParameteriv) (GLhandle object,GLenum pname,GLint *params);
  void (GLAPIENTRY *iglDeleteObject) (GLhandle object);

  void (GLAPIENTRY *iglGetActiveUniform) (GLhandle program,GLuint GLindex, GLsizei maxLength, GLsizei *length, GLint *size, GLenum *type, GLchar *name);
  GLint (GLAPIENTRY *iglGetUniformLocation) (GLhandle programObj, const GLchar *name);
  void (GLAPIENTRY *iglGetUniformfv) (GLhandle programObj, GLint location, GLfloat *params);
  void (GLAPIENTRY *iglGetUniformiv) (GLhandle programObj, GLint location, GLint *params);

  void (GLAPIENTRY *iglUniform1fv) (GLint location, GLsizei count, const GLfloat *value);
  void (GLAPIENTRY *iglUniform2fv) (GLint location, GLsizei count, const GLfloat *value);
  void (GLAPIENTRY *iglUniform3fv) (GLint location, GLsizei count, const GLfloat *value);
  void (GLAPIENTRY *iglUniform4fv) (GLint location, GLsizei count, const GLfloat *value);
  void (GLAPIENTRY *iglUniformMatrix2fv) (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
  void (GLAPIENTRY *iglUniformMatrix3fv) (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
  void (GLAPIENTRY *iglUniformMatrix4fv) (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
  void (GLAPIENTRY *iglUniform1iv) (GLint location, GLsizei count, const GLint *value);
  void (GLAPIENTRY *iglUniform2iv) (GLint location, GLsizei count, const GLint *value);
  void (GLAPIENTRY *iglUniform3iv) (GLint location, GLsizei count, const GLint *value);
  void (GLAPIENTRY *iglUniform4iv) (GLint location, GLsizei count, const GLint *value);


  //@
  //  Summary:
  //    Destructor, will not destroy the substitute program as 
  //    the context it was created in may no longer be valid.
  //  
  virtual ~SubstituteShaderGLSL();

  //@
  //  Summary:
  //    To get the remap array of uniform data from the old to the new program.
  //    (The old and new program IDs must be set before this is called)
  //
  //  Parameters:
  //    initLog  - The string log to record differences in the programs. 
  //
  void GenerateUniformRemapArray(string &initLog);

  //@
  //  Summary:
  //    To retrieve the uniform data for the passed program ID.
  //
  //  Parameters:
  //    programHandle  - The OpenGL ID of the program to get the uniform
  //                     data for. 
  //
  //    retData  - The array to return the uniform data in. 
  //
  //  Returns:
  //    Returns true on success, false on failure
  //
  bool GetUniformData(GLhandle programHandle, UniformDataArray &retData);

  //@
  //  Summary:
  //    To get data about a specific uniform data type.
  //
  //  Parameters:
  //    type  - The uniform data type to get info for. 
  //
  //    numElements  - The returned number of elements of the type. 
  //
  //    floatFormat  - The returned bool indicating a float or int based 
  //                   format. (ie. bool/integer)
  //
  //  Returns:
  //    If the type is known, true is returned and the num elements and float
  //    format are assigned valid data. Else false is returned and the data
  //    values are undefined.
  //
  bool GetTypeData(GLenum type, uint &numElements, bool &floatFormat) const;

  //@
  //  Summary:
  //    To copy all the re-mapped uniform data from the old program to the
  //    new program. The new program must be bound before calling.
  //  
  void UniformDataCopy();

  //@
  //  Summary:
  //    To retrieve the data from the old program and test for OpenGL errors.
  //  
  //  Parameters:
  //    remapData  - The info about the uniform data to copy. 
  //
  //    retLog     - The log of any errors detected.
  //
  //  Returns:
  //    True is returned if no errors were detected. Else false is returned.
  //
  bool TestUniformDataCopy(const UniformData &remapData, string &retLog) const;

  //@
  //  Summary:
  //    To load the uniform data.
  //
  //  Parameters:
  //    loadPos  - The position to load the data. 
  //
  //    type  - The type of the data loaded. 
  //
  //    count  - The count of how many of the type exists. 
  //
  //    buffer  - The buffer containing the data to upload. 
  //
  void LoadUniformDataFloat(GLuint loadPos, GLenum type, GLuint count, const GLfloat *buffer) const; 
  void LoadUniformDataInt(GLuint loadPos, GLenum type, GLuint count, const GLint *buffer) const; 

};

//Auto reference count type def for substitute shaders
typedef AutoReferenceCount<SubstituteShaderGLSL> SubShaderGLSLRef;



#endif // __SUBSTITUTE_SHADER_GLSL_H_
