#ifndef __SHADER_EDIT_MANAGER_H_
#define __SHADER_EDIT_MANAGER_H_

#include "..\\..\\InterceptPluginInterface.h"
#include <string>
#include <vector>
#include <MiscUtils.h>

using namespace std;

class ConfigParser;
class SEContext;
enum  USIDType;

//@
//  Summary:
//    This class provides a plugin implementation for GLIntercept to
//    provide shader editing of OpenGL shaders. 
//  
class ShaderEditManager : public InterceptPluginInterface
{
public:

  //@
  //  Summary:
  //    Constructor. Sets up call back data.
  //  
  //  Parameters:
  //    callBacks - The call back interface from GLIntercept.
  //
  ShaderEditManager(InterceptPluginCallbacks *callBacks);

  //@
  //  Summary:
  //    Destructor. Only to be called from Destroy().
  //  
  virtual ~ShaderEditManager();

  //@
  //  Summary:
  //    Called when an OpenGL function that has been registered 
  //    (via RegisterGLFunction) is about to be made.
  //  
  //  Parameters:
  //    updateID - The ID of the registered function. 
  //
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  virtual void GLIAPI GLFunctionPre (uint updateID, const char *funcName, uint funcIndex, va_list args );

  //@
  //  Summary:
  //    Called when an OpenGL function that has been registered 
  //    (via RegisterGLFunction) has been made.
  //  
  //  Parameters:
  //    updateID - The ID of the registered function. 
  //
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - The return vlaue of the function (if any).
  //
  inline virtual void GLIAPI GLFunctionPost(uint updateID, const char *funcName, uint funcIndex, void * retVal);

  //@
  //  Summary:
  //    Called when the OpenGL "frame end" call is about to be made.
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  inline virtual void GLIAPI GLFrameEndPre(const char *funcName, uint funcIndex, va_list args );

  //@
  //  Summary:
  //    Called after OpenGL "frame end" call has been made.
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
  virtual void GLIAPI GLFrameEndPost(const char *funcName, uint funcIndex, void * retVal);

  //@
  //  Summary:
  //    Called when a OpenGL "render" call is about to be made.
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    args     - The arguments of the function.
  //
 virtual void GLIAPI GLRenderPre(const char *funcName, uint funcIndex, va_list args );

  //@
  //  Summary:
  //    Called when a OpenGL "render" call has been made.
  //  
  //  Parameters:
  //    funcData - The data of the function logged.
  //
  //    index    - A index to the function logged (In the function table).
  //
  //    retVal   - The return value of the function. (If any).
  //
  virtual void GLIAPI GLRenderPost(const char *funcName, uint funcIndex, void * retVal);

  //@
  //  Summary:
  //    Called when a OpenGL error occurs.
  //  
  //  Parameters:
  //    funcData - The data of the function that cause the error.
  //
  //    index    - A index to the function (In the function table).
  //
  inline virtual void GLIAPI OnGLError(const char *funcName, uint funcIndex);

  //@
  //  Summary:
  //    Called when a OpenGL context is created.
  //  
  //  Parameters:
  //    rcHandle - The new OpenGL context.
  //
  virtual void GLIAPI OnGLContextCreate(HGLRC rcHandle);

  //@
  //  Summary:
  //    Called when a OpenGL context is deleted.
  //  
  //  Parameters:
  //    rcHandle - The OpenGL context that is deleted.
  //
  virtual void GLIAPI OnGLContextDelete(HGLRC rcHandle);

  //@
  //  Summary:
  //    Called when a OpenGL context is assigned (set).
  //  
  //  Parameters:
  //    oldRCHandle - The old (previous) OpenGL context.
  //
  //    newRCHandle - The new OpenGL context.
  //
  virtual void GLIAPI OnGLContextSet(HGLRC oldRCHandle, HGLRC newRCHandle);

  //@
  //  Summary:
  //    Called when a OpenGL context share lists.
  //  
  //  Parameters:
  //    srcHandle - The context constaining the lists.
  //
  //    dstHandle - The context to now share the lists.
  //
  virtual void GLIAPI OnGLContextShareLists(HGLRC srcHandle, HGLRC dstHandle);


  //@
  //  Summary:
  //    Called when this plugin is to be destroyed. The plugin should delete 
  //    itself. (Note: If a plugin needs to shutdown, always request deletion
  //    via InterceptPluginCallbacks::DestroyPlugin which will call this method
  //    on the next update. Do not destroy the plugin by other means.)
  //  
  virtual void GLIAPI Destroy();

  //@
  //  Summary:
  //    To compile the passed shader source and to override the 
  //    passed shader ID.
  //  
  //  Parameters:
  //    shaderID    - The unique ID of the shader to override.
  //
  //    shaderSrc   - The shader source to compile.
  //
  //    retLog      - The returned log of any errors/warnings during compile.
  //
  //  Returns:
  //    If the shader source was compiled successfully, true is returned.
  //    Else false is returned.
  //
  bool CompileShader(uint shaderID, const string &shaderSrc, string &retLog);

  //@
  //  Summary:
  //    To set the "show" shader ID. Can be 0 for no shader ID.
  //  
  //  Parameters:
  //    shaderUID    - The unique ID of the shader to show.
  //
  //    shaderType   - The type of the shader that is shown.
  //
  inline void SetShowShader(uint shaderUID, USIDType shaderType);

protected:

  InterceptPluginCallbacks *gliCallBacks;         //The callback interface into GLIntercept
  const GLCoreDriver       *GLV;                  //The core OpenGL driver

  SEContext          *currContext;                // The current OpenGL context
  vector<SEContext *> contextArray;               // The array of all the OpenGL contexts

  uint      showShaderUID;                        // The unique ID of the shader to "show" (0 if no shader)
  USIDType  showShaderType;                       // The type of the shader to show
  uint      showShaderStage;                      // The stage number the shader "show" is up to 
  TimeDiff  showShaderTimer;                      // The timer for altering the "show" shader
  bool      showShaderApplied;                    // Flag indicating if the "show" shader is currently applied

  vector<uint>    enableKeys;                     // The key combination to enable the shader editor

  //@
  //  Summary:
  //    To find the internal context that uses the passed handle.
  //  
  //  Parameters:
  //    handle - The context handle to search for.
  //
  //  Returns:
  //    If the context is found it is returned. Else NULL is returned.
  // 
  SEContext *FindContext(HGLRC handle);

  //@
  //  Summary:
  //    Process the passed config parser to load the configuration data.
  //  
  void ProcessConfigData(const ConfigParser *parser);

  //@
  //  Summary:
  //    Process that ta render has just been completed
  //  
  void ProcessPostRender();

private:

  GLint oldLogicOpEnable;                         //Flags used to cache the logic op changes
  GLint oldLogicOpMode;                           //Flags used to cache the logic op changes 

  //@
  //  Summary:
  //    To apply a visualization of the currently bound shader.
  //  
  //  Parameters:
  //    revert - If the visualization is being applied or being reverted.
  //
  //  Returns:
  //    Returns true if the change was applied.
  // 
  bool ApplyShowShader(bool revert = false);

};


//Unused entry points

///////////////////////////////////////////////////////////////////////////////
//
inline void ShaderEditManager::GLFrameEndPre(const char *funcName, uint funcIndex, va_list args )
{
}

///////////////////////////////////////////////////////////////////////////////
//
inline void ShaderEditManager::OnGLError(const char *funcName, uint funcIndex)
{

}

///////////////////////////////////////////////////////////////////////////////
//
inline void ShaderEditManager::SetShowShader(uint shaderUID, USIDType shaderType)
{
  //Assign the shader and reset the stage
  showShaderUID   = shaderUID;
  showShaderType  = shaderType;
  showShaderStage = 0;
  showShaderTimer.StartTimer(); 
}



#endif // __SHADER_EDIT_MANAGER_H_