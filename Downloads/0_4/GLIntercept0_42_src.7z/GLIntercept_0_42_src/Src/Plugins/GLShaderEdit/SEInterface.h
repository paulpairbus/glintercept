/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#ifndef __SE_INTERFACE_H_
#define __SE_INTERFACE_H_

#include "..\\..\\InterceptPluginInterface.h"
#include "ReferenceCount.h"
#include "ShaderManagerASM.h"

#include <string>
#include <vector>

using namespace std;



class ShaderEditManager;

//@
//  Summary:
//    This class acts as an interface to an external editor of shaders.
//    The singleton instance will create the external process on initialization
//    and the singleton will be destroyed when the external editor is 
//    destroyed. (ie. so check for existance before using)
//  
class SEInterface
{
public:

  //@
  //  Summary:
  //    To create and initialize the interface that is used to communicate with
  //    an external editor.
  //  
  //  Parameters:
  //    manager    - The manager that uses this instance.
  //
  //    callBacks  - The callbacks to GLIntercept.
  //
  //  Returns:
  //    If a interface could be created and init, it is returned. 
  //    Else NULL is returned.
  //
  static SEInterface * CreateInstance(ShaderEditManager *manager, InterceptPluginCallbacks *callBacks);

  //@
  //  Summary:
  //    To retrieve the external editor interface.
  //  
  //  Returns:
  //    If a interface has been init with CreateInstance (and not been destroyed) it is returned. 
  //    Else NULL is returned.
  //
  static SEInterface * GetInstance();

  //@
  //  Summary:
  //    To destroy the singleton instance when the manager becomes invalid.
  //  
  static void DestroyInstance();

  //@
  //  Summary:
  //    To process any editor messages on the end of the current frame.
  //
  //  Note: The interface may be destroyed at the end of this call if 
  //        the editor has been destroyed.  
  //  
  void OnFrameEnd();

protected:

  static SEInterface *seiInstance;                // The singleton instance.

  ShaderEditManager        *manager;              // The manager of the interface
  InterceptPluginCallbacks *gliCallbacks;         // The callbacks to glIntercept  

  HWND                      messageWin;           // The created message window
  HANDLE                    editProcessHandle;    // The created process handle

  //@
  //  Summary:
  //    Constructor 
  //  
  //  Parameters:
  //    manager    - The manager that uses this instance.
  //
  //    gliCallBacks  - The callbacks to GLIntercept.
  //
	SEInterface(ShaderEditManager *manager, InterceptPluginCallbacks *gliCallBacks);

  //@
  //  Summary:
  //    Destructor.
  // 
  virtual ~SEInterface();

  //@
  //  Summary:
  //    To initialize the interface and start the external shader editor.
  // 
  bool Init();

  //@
  //  Summary:
  //    To send a shader list of all current shaders to the specified window.
  // 
  //  Parameters:
  //    sendWnd    - The window to send the message to.
  //
  //    cmdUID     - The message id.
  //
  void SendShaderList(HWND sendWnd, uint cmdUID);

  //@
  //  Summary:
  //    To send the shader source to the specified window.
  // 
  //  Parameters:
  //    sendWnd    - The window to send the message to.
  //
  //    cmdUID     - The message id.
  //
  //    shaderID   - The ID of the shader to send the source for.
  //
  void SendShaderSource(HWND sendWnd, uint cmdUID, const string &shaderID);

  //@
  //  Summary:
  //    To compile the passed shader source and send the status back
  //    to the passed window.
  // 
  //  Parameters:
  //    sendWnd    - The window to send the result to.
  //
  //    cmdUID     - The message id.
  //
  //    shaderID   - The ID of the shader to compile and the shader source.
  //
  void CompileShaderSource(HWND sendWnd, uint cmdUID, const string &shaderData);

  //@
  //  Summary:
  //    To flag that the passed shader ID should be visiably "shown" when
  //    rendering.
  // 
  //  Parameters:
  //    shaderID    - The shader ID in string format to "show".
  //
  void ShowShader(const string &shaderID);

  //@
  //  Summary:
  //    To revert any changes to the passed shader ID.
  // 
  //  Parameters:
  //    shaderID    - The shader ID in string format to "show".
  //
  void RevertShader(const string &shaderID);


  //@
  //  Summary:
  //    To send a windows message. (and time out if not sent)
  // 
  //  Parameters:
  //    sendWnd    - The window to send the message to.
  //
  //    cmdUID     - The message id.
  //
  //    data       - The message data.
  //
  void SendWinMessage(HWND sendWnd, uint cmdUID, const string &data);
};


#endif // __SE_INTERFACE_H_
