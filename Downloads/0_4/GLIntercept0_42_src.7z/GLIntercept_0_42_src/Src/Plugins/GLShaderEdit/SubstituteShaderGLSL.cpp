/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"
#include "MiscUtils.h"

#include "SubstituteShaderGLSL.h"
#include <CommonErrorLog.h>

USING_ERRORLOG

///////////////////////////////////////////////////////////////////////////////
//
SubstituteShaderGLSL::UniformData::UniformData():
remapIndex(0),

type(0),
size(0),

numTypeElements(0),
isFloatType(true)

{

}

///////////////////////////////////////////////////////////////////////////////
//
SubstituteShaderGLSL::SubstituteShaderGLSL(GLhandle newProgramID,InterceptPluginCallbacks *callBacks):
programID(newProgramID),
oldProgramID(0),
gliCallBacks(callBacks),

iglUseProgramObject(NULL),
iglGetObjectParameteriv(NULL),
iglDeleteObject(NULL),

iglGetActiveUniform(NULL),
iglGetUniformLocation(NULL),
iglGetUniformfv(NULL),
iglGetUniformiv(NULL),

iglUniform1fv(NULL),
iglUniform2fv(NULL),
iglUniform3fv(NULL),
iglUniform4fv(NULL),
iglUniformMatrix2fv(NULL),
iglUniformMatrix3fv(NULL),
iglUniformMatrix4fv(NULL),
iglUniform1iv(NULL),
iglUniform2iv(NULL),
iglUniform3iv(NULL),
iglUniform4iv(NULL)

{
}

///////////////////////////////////////////////////////////////////////////////
//
SubstituteShaderGLSL::~SubstituteShaderGLSL()
{
  //Do not delete the substitute here.
  // (this will mean a shader leak if the main GLSL program leaks itself)
}

///////////////////////////////////////////////////////////////////////////////
//
bool SubstituteShaderGLSL::Init(GLhandle oldProgram, string &initLog)
{
  //Check the program ID's
  if(oldProgram == 0 || programID == 0)
  {
    return false;
  }

  //Assign the old program ID
  oldProgramID = oldProgram;

  //Check if GL calls can be made
  if(!gliCallBacks->GetGLInternalCallState())
  {
    return false;
  }

  void **loadFunc;

  //Helper define for function lookups

/* Update for OGL2.0 support
#define GL_FUNC_LOOKUP(string)                           \
  loadFunc  = (void**)(&i##string);                      \
  *loadFunc = gliCallBacks->GetGLFunction(#string);      \
  if(*loadFunc == NULL)                                  \
  {                                                      \
    *loadFunc = gliCallBacks->GetGLFunction(#string"ARB");\
    if(*loadFunc == NULL)                                \
    {                                                    \
      LOGERR(("Function %s unable to be mapped",#string));\
      return false;                                      \
    }                                                    \
  }
*/

#define GL_FUNC_LOOKUP(string)                           \
  loadFunc  = (void**)(&i##string);                      \
  *loadFunc = gliCallBacks->GetGLFunction(#string"ARB"); \
  if(*loadFunc == NULL)                                  \
  {                                                      \
    LOGERR(("Function %s unable to be mapped",#string)); \
    return false;                                        \
  }                                                    


  GL_FUNC_LOOKUP(glUseProgramObject);
  GL_FUNC_LOOKUP(glGetObjectParameteriv);
  GL_FUNC_LOOKUP(glDeleteObject);

  GL_FUNC_LOOKUP(glGetActiveUniform);
  GL_FUNC_LOOKUP(glGetUniformLocation);
  GL_FUNC_LOOKUP(glGetUniformfv);
  GL_FUNC_LOOKUP(glGetUniformiv);

  GL_FUNC_LOOKUP(glUniform1fv);
  GL_FUNC_LOOKUP(glUniform2fv);
  GL_FUNC_LOOKUP(glUniform3fv);
  GL_FUNC_LOOKUP(glUniform4fv);
  GL_FUNC_LOOKUP(glUniformMatrix2fv);
  GL_FUNC_LOOKUP(glUniformMatrix3fv);
  GL_FUNC_LOOKUP(glUniformMatrix4fv);
  GL_FUNC_LOOKUP(glUniform1iv);
  GL_FUNC_LOOKUP(glUniform2iv);
  GL_FUNC_LOOKUP(glUniform3iv);
  GL_FUNC_LOOKUP(glUniform4iv);


#undef GL_FUNC_LOOKUP

  //Generate the lookup table of values to copy
  string uniformLog;
  GenerateUniformRemapArray(uniformLog);
  if(uniformLog.size() > 0)
  {
    initLog += "New program uniform mismatchs:\n\n";
    initLog += uniformLog;
    initLog += "\n";
  }

  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::DestroyProgram()
{
  //Delete the program id if possible
  if(programID != 0)
  {
    //If driver is available delete the program
    if(gliCallBacks->GetGLInternalCallState())
    {
      iglDeleteObject(programID);
    }
    //Else log an error
    else
    {
      LOGERR(("Unable to delete substitute program %u",programID));
    }

    //Set the program ID to zero 
    programID = 0;
  }
  
}

///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::BindSubstitute()
{
  //Get if OpenGL calls can be made
  if(programID == 0 || !gliCallBacks->GetGLInternalCallState())
  {
    return;
  }

  //Note: Perhaps make sure the current program is the oldProgram?

  //Bind the substitute program
  iglUseProgramObject(programID);

  //Copy the uniform data
  UniformDataCopy();

}

///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::UnBindSubstitute()
{
  //Get if OpenGL calls can be made
  if(programID == 0 || !gliCallBacks->GetGLInternalCallState())
  {
    return;
  }

  //Reset to the origional program
  iglUseProgramObject(oldProgramID);

}

//DT_TODO: Use a pre-allocated float/int copy buffer
///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::UniformDataCopy()
{
  //Check that OpenGL calls can be made 
  if(!gliCallBacks->GetGLInternalCallState())
  {
    return;
  }

  //Loop for all re-map types
  for(uint i=0; i<remapUniformArray.size(); i++)
  {
    const UniformData &remapData = remapUniformArray[i];

    if(remapData.size > remapData.indexData.size())
    {
      LOGERR(("UniformDataCopy - Invalid uniform size value"));
      return;
    } 

    //If the data is float based
    if(remapData.isFloatType)
    {
      GLfloat *floatBuffer = new GLfloat[remapData.size * remapData.numTypeElements];
      GLfloat *copyData = floatBuffer;

      //Loop for the size of the type
      for(uint s=0; s<remapData.size; s++)
      {
        //Get the old uniform data
        iglGetUniformfv(oldProgramID, remapData.indexData[s], copyData);

        //Update the location pointer
        copyData += remapData.numTypeElements;
      }

      //Load the uniform data
      LoadUniformDataFloat(remapData.remapIndex, remapData.type, remapData.size, floatBuffer); 

      delete [] floatBuffer;
    }
    else
    {
      //Data must be int based
      GLint *intBuffer = new GLint[remapData.size * remapData.numTypeElements];
      GLint *copyData  = intBuffer;

      //Loop for the size of the type
      for(uint s=0; s<remapData.size; s++)
      {
        //Get the old uniform data
        iglGetUniformiv(oldProgramID, remapData.indexData[s], copyData);

        //Update the location pointer
        copyData += remapData.numTypeElements;
      }

      //Load the uniform data
      LoadUniformDataInt(remapData.remapIndex, remapData.type, remapData.size, intBuffer); 

      delete [] intBuffer;
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
bool SubstituteShaderGLSL::TestUniformDataCopy(const UniformData &remapData, string &retLog) const
{
  string bufferStr;

  //Test for OpenGL errors during copy
  if(gliCallBacks->GetCoreGLFunctions()->glGetError() != GL_NO_ERROR)
  {
    StringPrintF(bufferStr,"Existing OpenGL error - fix application?\n");
    retLog += bufferStr;
  }

  //Check the size
  if(remapData.size > remapData.indexData.size())
  {
    StringPrintF(bufferStr,"%s - Invalid uniform size values\n",remapData.name.c_str());
    retLog += bufferStr;
    return false;
  } 

  //If the data is float based
  if(remapData.isFloatType)
  {
    GLfloat *floatBuffer = new GLfloat[remapData.numTypeElements];

    //Loop for the size of the type
    for(uint s=0; s<remapData.size; s++)
    {
      //Get the old uniform data
      iglGetUniformfv(oldProgramID, remapData.indexData[s], floatBuffer);
    }

    delete [] floatBuffer;
  }
  else
  {
    //Data must be int based
    GLint *intBuffer = new GLint[remapData.numTypeElements];

    //Loop for the size of the type
    for(uint s=0; s<remapData.size; s++)
    {
      //Get the old uniform data
      iglGetUniformiv(oldProgramID, remapData.indexData[s], intBuffer);
    }

    delete [] intBuffer;
  }


  //If a error occured during retrieval
  if(gliCallBacks->GetCoreGLFunctions()->glGetError() != GL_NO_ERROR)
  {
    StringPrintF(bufferStr," %s - OpenGL error on uniform copy - (broken drivers?)\n", remapData.name.c_str());
    retLog += bufferStr;
    return false;
  }

  return true;
}



///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::GenerateUniformRemapArray(string &initLog)
{
  uint i;
  string bufferStr;

  //Get the uniforms of the old program
  UniformDataArray oldUniformData;
  if(!GetUniformData(oldProgramID, oldUniformData))
  {
    initLog += "Unble to get old program unform data\n";
    return;
  }

  //Get the uniforms of the new program
  UniformDataArray newUniformData;
  if(!GetUniformData(programID, newUniformData))
  {
    initLog += "Unble to get new program unform data\n";
    return;
  }

  //Clear the mapping array
  remapUniformArray.clear();

  //Loop for all values in the old array
  for(i=0; i<oldUniformData.size(); i++)
  {
    bool foundFlag = false;
    const UniformData & oldData = oldUniformData[i];

    //Loop for all new values
    for(uint i2=0; i2<newUniformData.size(); i2++)
    {
      const UniformData & newData = newUniformData[i2];

      //Check for a name match
      if(oldData.name == newData.name)
      {
        foundFlag = true;

        //Check the types and abort if not equal 
        if(oldData.type != newData.type)
        {
          StringPrintF(bufferStr," %s - Uniforms types are different\n",oldData.name.c_str());
          initLog += bufferStr;
          break;
        }

        //Check the sizes 
        uint addDataTypeSize = oldData.size;
        if(oldData.size != newData.size)
        {
          StringPrintF(bufferStr," %s - Uniform sizes are different (%u != %u)\n",
                                    oldData.name.c_str(),oldData.size,newData.size);
          initLog += bufferStr;

          //Take the minimum of the two sizes
          if(newData.size < addDataTypeSize)
          {
            addDataTypeSize = newData.size;
          }
        }
        
        //Check the type size
        if(addDataTypeSize == 0)
        {
          StringPrintF(bufferStr," %s - Uniform size is zero?\n", oldData.name.c_str());
          initLog += bufferStr;
          break;
        }

        //Create a new entry in the mapping array
        UniformData addData;
        
        addData.indexData  = oldData.indexData;
        addData.remapIndex = newData.indexData[0];

        addData.name = newData.name;
        addData.size = addDataTypeSize;
        addData.type = newData.type;

        //Get the data about the type 
        if(!GetTypeData(addData.type, addData.numTypeElements, addData.isFloatType))
        {
          StringPrintF(bufferStr," %s - Uniform is not a known type: 0x%x\n", addData.name.c_str(),addData.type);
          initLog += bufferStr;
          break;
        }

        //Test if the data can be copied without OpenGL errors (ATI bug)
        if(TestUniformDataCopy(addData, initLog))
        {
          //Add the data to the array
          remapUniformArray.push_back(addData);
        }
        break;
      }
    }

    //If not found
    if(!foundFlag)
    {
      StringPrintF(bufferStr," %s - Uniform not found in new program\n",
                                oldData.name.c_str());
      initLog += bufferStr;
    }
  }

  //Log all the new uniforms not in the old program
  for(i=0; i<newUniformData.size(); i++)
  {
    bool foundFlag = false;
    const UniformData & newData = newUniformData[i];

    //Loop for all old values
    for(uint i2=0; i2<oldUniformData.size(); i2++)
    {
      const UniformData & oldData = oldUniformData[i2];

      //Check for a name match
      if(oldData.name == newData.name)
      {
        foundFlag = true;
        break;
      }
    }

    //If not found
    if(!foundFlag)
    {
      StringPrintF(bufferStr," %s - Uniform in new program -not in old program\n",
                               newData.name.c_str());
      initLog += bufferStr;
    }
  }

}



///////////////////////////////////////////////////////////////////////////////
//
bool SubstituteShaderGLSL::GetUniformData(GLhandle programHandle, UniformDataArray &retData)
{
  //Empty the return array
  retData.clear();  

  //Get if OpenGL calls can be made
  if(!gliCallBacks->GetGLInternalCallState())
  {
    return false;
  }

  //Get the number of uniforms for the program
  GLint numUniforms;
  iglGetObjectParameteriv(programHandle, GL_OBJECT_ACTIVE_UNIFORMS_ARB, &numUniforms);
  if(numUniforms == 0)
  {
    return true;
  }


  //Get the max uniform string size
  GLint maxUniformSize;
  iglGetObjectParameteriv(programHandle, GL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB, &maxUniformSize);
  if(maxUniformSize == 0)
  {
    return false;
  }

  //Allocate the array to get the uniform strings
  GLchar * readUniformName = new GLchar[maxUniformSize+1];

  //Loop for the number of uniforms in the program
  for(uint i=0;i<numUniforms;i++)
  {
    GLint  typeSize=0;
    GLenum type;
    GLsizei lengthWritten=0;
    string  newUniformName;

    //Call GetActiveUniform to get the name,type and size of the type
    iglGetActiveUniform(programHandle,i,maxUniformSize,&lengthWritten,&typeSize,&type,readUniformName);

    if(lengthWritten > 0)
    {
      //Convert to a string
      newUniformName = (char*)readUniformName;


      //Nvidia Hack ======================================
      // Nvidia (in 69.xx drivers) return a uniform for every element of arrays.
      // Only take note of the first one and ignore the rest
      bool ignoreUniform = false;
      if(newUniformName.length() > 3 &&
         newUniformName[newUniformName.length()-1] == ']')
      {
        //If the characters end with "[0]"
        if(newUniformName[newUniformName.length()-2] == '0' &&
           newUniformName[newUniformName.length()-3] == '[')
        {
          //Erase the last three characters
          newUniformName.erase(newUniformName.length()-3, 3);
          LOGERR(("Nvidia uniform array workaround for %s",newUniformName.c_str()));
        }
        else
        {
          //Don't process this uniform
          ignoreUniform = true;
        }
      }
      //End Hack ======================================


      //Ignore built in gl types
      if(newUniformName.find("gl_") != 0 && !ignoreUniform)
      {

        vector<uint> indexDataArray;
        for(uint s=0; s<typeSize; s++)
        {
          string testUniformName = newUniformName;
          if(s > 0)
          {
            //If it is an array type, get the index of each component
            string strBuffer;             
            StringPrintF(strBuffer, "[%u]",s);
            testUniformName += strBuffer;
          }

          //Get the location of the uniform
          GLint uniLocation = iglGetUniformLocation(programHandle,(const GLchar*)testUniformName.c_str());
          if(uniLocation < 0)
          {
            LOGERR(("GetUniformData - Uniform %s does not exist?",testUniformName.c_str()));

            //Clean up the uniform name
            delete [] readUniformName;
            return false;
          }

          //Add to the index data array
          indexDataArray.push_back(uniLocation);
        }

        UniformData newData;
        newData.indexData  = indexDataArray;
        newData.remapIndex = 0;

        newData.name = newUniformName;
        newData.size = typeSize;
        newData.type = type;

        //Add the new data to the return array
        retData.push_back(newData);

      }
    }

  }

  //Clean up the uniform name
  delete [] readUniformName;

  return true;

}


///////////////////////////////////////////////////////////////////////////////
//
bool SubstituteShaderGLSL::GetTypeData(GLenum type, uint &numElements, bool &floatFormat) const
{
  numElements = 0;
  floatFormat = true;

  switch(type)
  {
    case(GL_FLOAT):
      numElements = 1;
      floatFormat = true;
      break;

    case(GL_FLOAT_VEC2_ARB):
      numElements = 2;
      floatFormat = true;
      break;

    case(GL_FLOAT_VEC3_ARB):
      numElements = 3;
      floatFormat = true;
      break;

    case(GL_FLOAT_VEC4_ARB):
      numElements = 4; 
      floatFormat = true;
      break;

    case(GL_SAMPLER_1D_ARB):
    case(GL_SAMPLER_2D_ARB):
    case(GL_SAMPLER_3D_ARB):
    case(GL_SAMPLER_CUBE_ARB):
    case(GL_SAMPLER_1D_SHADOW_ARB):
    case(GL_SAMPLER_2D_SHADOW_ARB):
    case(GL_SAMPLER_2D_RECT_ARB):
    case(GL_SAMPLER_2D_RECT_SHADOW_ARB):
    case(GL_INT)       :
      numElements = 1;
      floatFormat = false;
      break;

    case(GL_INT_VEC2_ARB):
      numElements = 2;
      floatFormat = false;
      break;

    case(GL_INT_VEC3_ARB):
      numElements = 3;
      floatFormat = false;
      break;

    case(GL_INT_VEC4_ARB):
      numElements = 4;
      floatFormat = false;
      break;


    case(GL_BOOL_ARB)  :
      numElements = 1;
      floatFormat = false;
      break;

    case(GL_BOOL_VEC2_ARB):
      numElements = 2;
      floatFormat = false;
      break;

    case(GL_BOOL_VEC3_ARB):
      numElements = 3;
      floatFormat = false;
      break;

    case(GL_BOOL_VEC4_ARB):
      numElements = 4;
      floatFormat = false;
      break;


    case(GL_FLOAT_MAT2_ARB):
      numElements = 4;
      floatFormat = true;
      break;

    case(GL_FLOAT_MAT3_ARB):
      numElements = 9;
      floatFormat = true;
      break;

    case(GL_FLOAT_MAT4_ARB):
      numElements = 16;
      floatFormat = true;
      break;

    default:
      return false;
  }

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::LoadUniformDataFloat(GLuint loadPos, GLenum type, GLuint count, const GLfloat *buffer) const
{
  switch(type)
  {
    case(GL_FLOAT):
      iglUniform1fv(loadPos, count, buffer);
      break;

    case(GL_FLOAT_VEC2_ARB):
      iglUniform2fv(loadPos, count, buffer);
      break;

    case(GL_FLOAT_VEC3_ARB):
      iglUniform3fv(loadPos, count, buffer);
      break;

    case(GL_FLOAT_VEC4_ARB):
      iglUniform4fv(loadPos, count, buffer);
      break;

    case(GL_FLOAT_MAT2_ARB):
      iglUniformMatrix2fv(loadPos, count, GL_FALSE, buffer);
      break;

    case(GL_FLOAT_MAT3_ARB):
      iglUniformMatrix3fv(loadPos, count, GL_FALSE, buffer);
      break;

    case(GL_FLOAT_MAT4_ARB):
      iglUniformMatrix4fv(loadPos, count, GL_FALSE, buffer);
      break;

    default:
      LOGERR(("SubstituteShaderGLSL::LoadUniformDataFloat - Invalid type 0x%x",type));
      return;
  }

}



///////////////////////////////////////////////////////////////////////////////
//
void SubstituteShaderGLSL::LoadUniformDataInt(GLuint loadPos, GLenum type, GLuint count, const GLint *buffer) const
{
  switch(type)
  {
    case(GL_SAMPLER_1D_ARB):
    case(GL_SAMPLER_2D_ARB):
    case(GL_SAMPLER_3D_ARB):
    case(GL_SAMPLER_CUBE_ARB):
    case(GL_SAMPLER_1D_SHADOW_ARB):
    case(GL_SAMPLER_2D_SHADOW_ARB):
    case(GL_SAMPLER_2D_RECT_ARB):
    case(GL_SAMPLER_2D_RECT_SHADOW_ARB):
    case(GL_INT)       :
    case(GL_BOOL_ARB)  :
      iglUniform1iv(loadPos, count, buffer);
      break;

    case(GL_INT_VEC2_ARB):
    case(GL_BOOL_VEC2_ARB):
      iglUniform2iv(loadPos, count, buffer);
      break;

    case(GL_INT_VEC3_ARB):
    case(GL_BOOL_VEC3_ARB):
      iglUniform3iv(loadPos, count, buffer);
      break;

    case(GL_INT_VEC4_ARB):
    case(GL_BOOL_VEC4_ARB):
      iglUniform4iv(loadPos, count, buffer);
      break;

    default:
      LOGERR(("SubstituteShaderGLSL::LoadUniformDataInt - Invalid type 0x%x",type));
      return;

  }

}



