/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "UniqueShaderID.h"
#include <CommonErrorLog.h>

USING_ERRORLOG

//Static data

//Index counter -zero is reserved "no index"
uint UniqueShaderID::indexCounter = 1;
vector<UniqueShaderID *> UniqueShaderID::loadedShaderIDArray;

///////////////////////////////////////////////////////////////////////////////
//
UniqueShaderID::UniqueShaderID(GLuint newProgramID):
uniqueIndex(indexCounter),
shaderGLID(newProgramID),
shaderType(USID_Undefined),
lastFrameUsed(0)
{
  //Increment the unique index counter
  indexCounter++;

  //Add to the loaded array
  loadedShaderIDArray.push_back(this);
}

///////////////////////////////////////////////////////////////////////////////
//
UniqueShaderID::~UniqueShaderID()
{
  //Loop and remove from the loaded shader iD array
  for(uint i=0;i<loadedShaderIDArray.size(); i++)
  {
    //If equal, remove
    if(loadedShaderIDArray[i] == this)
    {
      loadedShaderIDArray.erase(loadedShaderIDArray.begin() +i);
      break;
    }
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void UniqueShaderID::SetShaderType(USIDType newType)
{
  //Check that the type does not change once it is set
  if(shaderType != newType &&
     shaderType != USID_Undefined)
  {
    LOGERR(("UniqueShaderID::SetShaderType - Setting a defferent type on the shader!"));
  }

  shaderType = newType;
}

///////////////////////////////////////////////////////////////////////////////
//
UniqueShaderID * UniqueShaderID::FindUniqueShaderID(uint uIndex)
{
  //Loop for all loaded IDs
  for(uint i=0;i<loadedShaderIDArray.size(); i++)
  {
    //If equal, return
    if(loadedShaderIDArray[i]->uniqueIndex == uIndex)
    {
      return loadedShaderIDArray[i];
    }
  }

  return NULL;
}


///////////////////////////////////////////////////////////////////////////////
//
const vector<UniqueShaderID *> & UniqueShaderID::GetUniqueShaderIDList()
{
  return loadedShaderIDArray;
}



