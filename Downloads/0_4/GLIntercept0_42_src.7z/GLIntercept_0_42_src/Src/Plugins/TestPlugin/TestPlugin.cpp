// TestPlugin.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "..\\InterceptPluginInterface.h"
#include "LogPlugin.h"

#include <string>

using namespace std;

//Exported functions
extern "C" {
__declspec(dllexport) uint GLIAPI GetFunctionLogPluginVersion();
__declspec(dllexport) InterceptPluginInterface * GLIAPI CreateFunctionLogPlugin(const char *pluginName, InterceptPluginCallbacks * callBacks);
__declspec(dllexport) bool GLIAPI RegisterDLLEventHandler(DLLEventHandler *eventHandler);
__declspec(dllexport) bool GLIAPI UnRegisterDLLEventHandler(DLLEventHandler *eventHandler);
}

//The dll event handler (if any)
DLLEventHandler * dllEventHandler = NULL;

//The error logger
LOGERRPROC errorLog = NULL;


///////////////////////////////////////////////////////////////////////////////
//
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
  switch (ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
    { 
      break;
    }

    //NOTE: GLIntercept does not currently support multiple threads
    case DLL_THREAD_ATTACH:
    {
      break;
    }
    case DLL_THREAD_DETACH:
    {
      break;
    }
    case DLL_PROCESS_DETACH:
    {
      //If there is an event handler, flag that the plugin is being deleted
      if(dllEventHandler)
      {
        dllEventHandler->OnDLLDelete();
      }
      break;
    }
  }

  return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//
uint GLIAPI GetFunctionLogPluginVersion()
{
  return __GLI_INTERCEPT_PLUGIN_VER;
}



///////////////////////////////////////////////////////////////////////////////
//
InterceptPluginInterface * GLIAPI CreateFunctionLogPlugin(const char *pluginName, InterceptPluginCallbacks * callBacks)
{
  //If no call backs, return NULL
  if(callBacks == NULL)
  {
    return NULL;
  }

  //Assign the error logger
  if(errorLog == NULL)
  {
    errorLog = callBacks->GetLogErrorFunction();
  }

  string cmpPluginName(pluginName);

  //Test for the logger plugin
  if(cmpPluginName == "LogPlugin")
  {
    return new LogPlugin(callBacks);
  }

  return NULL;
}
///////////////////////////////////////////////////////////////////////////////
//
bool GLIAPI RegisterDLLEventHandler(DLLEventHandler *eventHandler)
{
  //Check for an existing handler
  if(dllEventHandler)
  {
    return false;
  }

  //Assign the event handler
  dllEventHandler = eventHandler;

  return true;
}

///////////////////////////////////////////////////////////////////////////////
//
bool GLIAPI UnRegisterDLLEventHandler(DLLEventHandler *eventHandler)
{
  if(dllEventHandler != eventHandler)
  {
    return false;
  }

  //Unset the event handler
  dllEventHandler = NULL;
  return true;
}

