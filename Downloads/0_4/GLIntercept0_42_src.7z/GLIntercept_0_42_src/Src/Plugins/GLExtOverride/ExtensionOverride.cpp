#include "stdafx.h"
#include "ExtensionOverride.h"

#include <ConfigParser.h>
#include <CommonErrorLog.h>


USING_ERRORLOG

//The call back ids
enum CallBackIDs
{
  CBI_None =0,
  CBI_glGetString,
  CBI_wglGetExtensionsString
};

//Path to the dll
extern string dllPath;

///////////////////////////////////////////////////////////////////////////////
//
ExtensionOverride::ExtensionOverride(InterceptPluginCallbacks *callBacks):
gliCallBacks(callBacks),
initFlag(false),
strEnum(0),

vendorOverride(false),
vendorString(""),

rendererOverride(false),
rendererString(""),

versionOverride(false),
versionString(""),

shaderVersionOverride(false),
shaderVersionString(""),

extensionsOverride(false),
extensionsString(""),

wglExtensionsOverride(false),
wglExtensionsString("")
{
  //LOGERR(("Ext Override Plugin Created"));

  //Register all the callbacks
  gliCallBacks->RegisterGLFunction("glGetString");
  gliCallBacks->RegisterGLFunction("wglGetExtensionsStringEXT");
  gliCallBacks->RegisterGLFunction("wglGetExtensionsStringARB");


  //Register the user ids for the callbacks
  gliCallBacks->SetFunctionID("glGetString",CBI_glGetString);
  gliCallBacks->SetFunctionID("wglGetExtensionsStringEXT",CBI_wglGetExtensionsString);
  gliCallBacks->SetFunctionID("wglGetExtensionsStringARB",CBI_wglGetExtensionsString);

  //Parse the config file
  ConfigParser fileParser;
  if(fileParser.Parse(dllPath + "config.ini"))
  {
    ProcessConfigData(&fileParser);
    fileParser.LogUnusedTokens(); 
  }

  //Parse the config string
  ConfigParser stringParser;
  if(stringParser.ParseString(gliCallBacks->GetConfigString()))
  {
    ProcessConfigData(&stringParser);
    stringParser.LogUnusedTokens(); 
  }
}

///////////////////////////////////////////////////////////////////////////////
//
ExtensionOverride::~ExtensionOverride()
{

}

///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::Destroy()
{
  //LOGERR(("Ext Override Plugin Destroyed"));
  
  //Destroy this plugin
  delete this;
}


///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::GLFunctionPre(uint updateID, const char *funcName, uint funcIndex, va_list args )
{
  //Return if not init
  if(!initFlag)
  {
    return;
  }

  // If this is the glGetString method
  if(updateID == CBI_glGetString)
  {
    //Get the enum of the string
    strEnum = va_arg(args, GLenum);
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::GLFunctionPost(uint updateID, const char *funcName, uint funcIndex, void * retVal)
{
  //Return if not init
  if(!initFlag)
  {
    return;
  }

  // If this is the glGetString method
  if(updateID == CBI_glGetString)
  {
    //Handle the enum
    switch(strEnum)
    {
      //Replace vendor string
      case(GL_VENDOR) :
         if(vendorOverride)
         {
           *((const char **)retVal) = vendorString.c_str(); 
         }
         break;

      //Replace renderer string
      case(GL_RENDERER) :
         if(rendererOverride)
         {
           *((const char **)retVal) = rendererString.c_str(); 
         }
         break;

      //Replace version string
      case(GL_VERSION) :
         if(versionOverride)
         {
           *((const char **)retVal) = versionString.c_str(); 
         }
         break;

      //Replace GLSL version string
      case(GL_SHADING_LANGUAGE_VERSION_ARB) :
         if(shaderVersionOverride)
         {
           *((const char **)retVal) = shaderVersionString.c_str(); 
         }
         break;


      //Replace extensions string
      case(GL_EXTENSIONS) :
         if(extensionsOverride)
         {
           *((const char **)retVal) = extensionsString.c_str(); 
         }
         break;
    }
  }

  //If this is the wgl extension string version
  else if(updateID == CBI_wglGetExtensionsString)
  {
    if(wglExtensionsOverride)
    {
      *((const char **)retVal) = wglExtensionsString.c_str(); 
    }
  }
  else
  {
    LOGERR(("Unexpected function logging %s",funcName));
  }


}


///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::OnGLContextSet(HGLRC oldRCHandle, HGLRC newRCHandle)
{
  //If the new context is NULL or already init return now
  if(newRCHandle == NULL || initFlag )
  { 
    return;
  }

  //If there are extensions to add/remove
  if(addExtensions.size() > 0 || removeExtensions.size() > 0)
  {
    //If the extensions string is not set, get the string and add/remove the neccessary extensions
    if(!extensionsOverride)
    {
      //If unable to make OpenGL calls, return now
      if(!gliCallBacks->GetGLInternalCallState())
      {
        return;
      }

      //Get the real extensions string
      extensionsString = (const char*)gliCallBacks->GetCoreGLFunctions()->glGetString(GL_EXTENSIONS);
      extensionsOverride = true;
    }

    //Add/Remove the extensions from the string
    FormatExtensionString(extensionsString,addExtensions,removeExtensions);
  }


  //If there are WGL extenisons to process
  if(wglAddExtensions.size() > 0 || wglRemoveExtensions.size() > 0)
  {
    //If the wgl extensions string is not set, get the string and add/remove the neccessary extensions
    if(!wglExtensionsOverride)
    {
      //If unable to make OpenGL calls, return now
      if(!gliCallBacks->GetGLInternalCallState())
      {
        return;
      }

      //Attempt to get the entry points
      const char * (GLAPIENTRY *wglGetExtensionsStringARB) (HDC hdc) = NULL;
      const char * (GLAPIENTRY *wglGetExtensionsStringEXT) (void)    = NULL;
      
      void **funcLoader;
      funcLoader= (void**)&wglGetExtensionsStringARB;
      *funcLoader = gliCallBacks->GetWGLFunctions()->wglGetProcAddress("wglGetExtensionsStringARB");

      funcLoader = (void**)&wglGetExtensionsStringEXT;
      *funcLoader = gliCallBacks->GetWGLFunctions()->wglGetProcAddress("wglGetExtensionsStringEXT");

      //Use the ARB version first 
      if(wglGetExtensionsStringARB)
      {
        //Note: Is getting the "current" HDC ok? 
        // Will future possible "multiple ICD" drivers cause issues?
        wglExtensionsString = wglGetExtensionsStringARB(gliCallBacks->GetWGLFunctions()->wglGetCurrentDC());
      }
      else if(wglGetExtensionsStringEXT)
      {
        //If found, copy the string
        wglExtensionsString = wglGetExtensionsStringEXT();
      }
      else
      {
        LOGERR(("WGL extension override - No WGL extension entry point?"));
        wglExtensionsString = "";
      }

      wglExtensionsOverride = true;
    }

    //Add/Remove the extensions from the string
    FormatExtensionString(wglExtensionsString,wglAddExtensions,wglRemoveExtensions);
  }


  //Flag that initialization was successful 
  initFlag = true;
}

///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::FormatExtensionString(string &extString, const vector<string> &addList, const vector<string> &removeList) const
{
  //Extract all the extensions from the extension string
  vector<string> extArray;
  GetExtensionsList(extString,extArray);

  //Add extensions
  for(uint addNum=0; addNum < addList.size(); addNum++)
  {
    //Search the existing array for a match
    bool strMatch = false;
    for(uint i=0;i<extArray.size();i++)
    { 
      //Break if a match is found
      if(addList[addNum] == extArray[i])
      { 
        strMatch = true;
        break;
      }
    }

    //Add the extension
    if(!strMatch)
    {
      extArray.push_back(addList[addNum]);
    }
  }

  //Remove extensions
  for(uint removeNum=0; removeNum < removeList.size(); removeNum++)
  {
    //Search the existing array for a match
    bool strMatch = false;
    for(uint i=0;i<extArray.size();i++)
    { 
      //Break if a match is found
      if(removeList[removeNum] == extArray[i])
      { 
        //Erase the extension
        extArray.erase(extArray.begin() + i);
        break;
      }
    }
  }

  //Reform the extension string
  extString = "";
  for(uint i=0;i<extArray.size();i++)
  {
    extString += extArray[i] + string(" ");
  }
}


///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::GetExtensionsList(const string &extString, vector<string> &retExtList) const
{
  //Init variables
  string subString;
  int startOffset   = -1;
  int strCopyLength = 0;
  retExtList.clear();
  
  //Loop for the entire length of the string
  for(uint i=0;i<extString.length();i++)
  {
    //Check if not a space seperator
    if(isspace(extString[i]) == 0)
    {
      //Set the starting offset of the string
      if(startOffset == -1)
      {
        startOffset = i;
      }

      strCopyLength++;
    }
    else
    {
      //Extract the sub string
      if(startOffset != -1)
      {
        subString.assign(extString,startOffset,strCopyLength);
        retExtList.push_back(subString);
        //LOGERR(("%s",subString.c_str()));
      }

      //Reset string counters
      startOffset   = -1;
      strCopyLength = 0;
    }
  }

  //Extract any remainder string
  if(startOffset != -1)
  {
    subString.assign(extString,startOffset,strCopyLength);
    retExtList.push_back(subString);
    //LOGERR(("%s",subString.c_str()));
  }

}


///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::ProcessConfigData(const ConfigParser *parser)
{
  //Process all the straight string replacements
  ProcessString(parser,"VendorString",vendorOverride,vendorString);
  
  ProcessString(parser,"RendererString",rendererOverride,rendererString);
  
  ProcessString(parser,"VersionString",versionOverride,versionString);
  
  ProcessString(parser,"ShaderVersionString",shaderVersionOverride,shaderVersionString);

  //Process core extensions
  ProcessExtensionList(parser, "ExtensionsString", extensionsString,
                               "AddExtensions",    addExtensions,
                               "RemoveExtensions", removeExtensions);

  //Only enable for a valid string
  if(extensionsString.length() > 0)
  {
    extensionsOverride = true;
  }
  else
  {
    extensionsOverride = false;
  }

  //Process WGL extensions
  ProcessExtensionList(parser, "WGLExtensionsString", wglExtensionsString,
                               "WGLAddExtensions",    wglAddExtensions,
                               "WGLRemoveExtensions", wglRemoveExtensions);

  //Only enable for a valid string
  if(wglExtensionsString.length() > 0)
  {
    wglExtensionsOverride = true;
  }
  else
  {
    wglExtensionsOverride = false;
  }

}

///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::ProcessString(const ConfigParser *parser, const string &searchStr, bool &enable, string &setString) const
{
  const ConfigToken *testToken;

  //Get the token for the string
  testToken = parser->GetToken(searchStr);
  if(testToken)
  {
    //Only enable for a valid string
    if(testToken->Get(setString) && setString.length() > 0)
    {
      enable = true;
    }
  }
}

///////////////////////////////////////////////////////////////////////////////
//
void ExtensionOverride::ProcessExtensionList(const ConfigParser *parser, 
                                             const string &extName, string &extString,
                                             const string &extAddName, vector<string> &addList,
                                             const string &extRemoveName, vector<string> &removeList) const
{

  //Get the extensions
  const ConfigToken *testToken;

  //Get the token for the extensions
  testToken = parser->GetToken(extName);
  if(testToken)
  {
    //Reset the extension string
    extString = "";

    //Loop for all values
    for(uint i=0;i<testToken->GetNumValues();i++)
    {
      //Append the child to the extension string
      string childString;
      if(testToken->Get(childString,i))
      {
        extString += childString + string(" "); 
      }
    }
  }

  //Process the add/remove extensions
  testToken = parser->GetToken(extAddName);
  if(testToken)
  {
    //Empty the array
    addList.clear();

    //Loop for all values
    for(uint i=0;i<testToken->GetNumValues();i++)
    {
      //Append the child
      string childString;
      if(testToken->Get(childString,i))
      {
        addList.push_back(childString); 
      }
    }
  }
  testToken = parser->GetToken(extRemoveName);
  if(testToken)
  {
    //Empty the array
    removeList.clear();

    //Loop for all values
    for(uint i=0;i<testToken->GetNumValues();i++)
    {
      //Append the child
      string childString;
      if(testToken->Get(childString,i))
      {
        removeList.push_back(childString); 
      }
    }
  }

}




