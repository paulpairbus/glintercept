/*=============================================================================
  GLIntercept - OpenGL intercept/debugging tool
  Copyright (C) 2004  Damian Trebilco

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
=============================================================================*/
#include "stdafx.h"

#include "ShaderGLSLManager.h"
#include "GLDriver.h"


USING_ERRORLOG


//Set the class name for the shader manager
char *InterceptDataManager<class ShaderGLSLData>::className = "ShaderGLSL";

///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLData::ShaderGLSLData(uint glID):
InterceptDataType(glID),
glType(0),
userDeleted(false),
saveFileName(""),
shaderSource(""),
shaderLog("")
{
}

///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLData::~ShaderGLSLData()
{
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLData::GetUniqueFileName(string &retString) const
{
  //Set the initial shader name
  retString = "ShaderGLSL_";

  //Append the shader type
  switch(glType)
  {
    case(GL_VERTEX_SHADER_ARB):
      retString = retString + "VP_";
      break;
    case(GL_FRAGMENT_SHADER_ARB):
      retString = retString + "FP_";
      break;
    case(GL_PROGRAM_OBJECT_ARB):
      retString = retString + "PROG_";
      break;
    default:
      retString = retString + "UNKNOWN_";
      break;
  }

  //Add the shader ID
  string bufString;
  StringPrintF(bufString,"%04u_",id);
  retString = retString + bufString;
  
  //Add the save count
  static uint saveCount=0;
  saveCount++;
  StringPrintF(bufString,"%04u",saveCount);
  retString = retString + bufString;

  return true;
}


///////////////////////////////////////////////////////////////////////////////
//
void ShaderGLSLData::AttachObject(GLhandle newHandle)
{
  //Attempt to find the object
  for(uint i=0;i<attachArray.size();i++)
  {
    //If already attached, just return
    if(attachArray[i] == newHandle)
    {
      return;
    }
  }

  //Add to the array
  attachArray.push_back(newHandle);
}

///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLData::DetachObject(GLhandle handle)
{
  //Attempt to find the object
  for(uint i=0;i<attachArray.size();i++)
  {
    //If equal, remove and return
    if(attachArray[i] == handle)
    {
      attachArray.erase(attachArray.begin() + i);
      return true;
    }
  }

  //Not found
  return false;
}


///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLManager::ShaderGLSLManager()
{
  //Add a shader (the zero shader always exists)
  AddData(0);

}

///////////////////////////////////////////////////////////////////////////////
//
ShaderGLSLManager::~ShaderGLSLManager()
{
  //Remove the 0 shader
  InterceptDataManager<ShaderGLSLData>::RemoveData(0);
}


///////////////////////////////////////////////////////////////////////////////
//
bool ShaderGLSLManager::RemoveData(uint glId)
{
  //Never delete 0
  if(glId != 0)
  {
    return InterceptDataManager<ShaderGLSLData>::RemoveData(glId);
  }

  return true;
}




